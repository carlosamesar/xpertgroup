# Plan de Implementación: Validación de Umbrales y Reintentos de Kafka

**Fecha:** 21 de Noviembre de 2025  
**Proyecto:** send-register-core  
**Autor:** GitHub Copilot

---

## 📋 Resumen Ejecutivo

Este documento describe el plan de implementación para dos casos de uso críticos en el sistema de procesamiento de archivos:

1. **Validación de Umbral de Registros**: Validar la cantidad de registros en el archivo Excel antes de procesarlo y bifurcar el flujo según un umbral configurable (default: 300 registros)

2. **Mecanismo de Reintentos para Kafka**: Implementar un sistema de reintentos con 3 intentos máximos y envío a Dead Letter Queue (DLQ) en caso de fallo

---

## 🎯 Objetivos

### Caso de Uso 1: Validación de Umbral
- Contar registros del archivo **antes** de iniciar el procesamiento completo
- Si registros < umbral (300): retornar mensaje indicando que se usa flujo alternativo
- Si registros >= umbral: continuar con proceso actual (Kafka)
- Umbral configurable mediante variable de entorno

### Caso de Uso 2: Reintentos de Kafka
- Implementar 3 intentos de envío a Kafka con backoff exponencial
- En caso de 3 fallos consecutivos: enviar mensaje a tópico de errores (DLQ)
- Registrar cada intento con logs detallados
- Número de reintentos configurable mediante variable de entorno

---

## 🏗️ Arquitectura de Solución

### Componentes Afectados

```
send-register-core/
├── src/main/java/com/bancoldex/sendregistercore/
│   ├── config/
│   │   └── KafkaRetryConfig.java [NUEVO]
│   ├── component/
│   │   └── FileProcessingComponent.java [MODIFICAR]
│   ├── controller/
│   │   └── FileUploadController.java [MODIFICAR]
│   ├── dto/
│   │   └── RecordCountValidationResponse.java [NUEVO]
│   ├── model/
│   │   └── FileRegister.java [MODIFICAR]
│   └── util/kafka/
│       └── MessageProducer.java [MODIFICAR]
├── src/main/resources/
│   └── application.properties [MODIFICAR]
└── src/test/java/com/bancoldex/sendregistercore/
    ├── component/
    │   └── FileProcessingComponentTest.java [NUEVO]
    └── util/kafka/
        └── MessageProducerTest.java [NUEVO]
```

### Diagrama de Flujo de Decisión

```
┌─────────────────────────┐
│  Archivo Excel Cargado  │
└───────────┬─────────────┘
            │
            ▼
┌─────────────────────────┐
│ Contar Registros        │
│ (sin cargar todo)       │
└───────────┬─────────────┘
            │
            ▼
      ┌─────────┐
      │ Count?  │
      └────┬────┘
           │
     ┌─────┴─────┐
     │           │
  < 300       >= 300
     │           │
     ▼           ▼
┌────────┐   ┌─────────────┐
│ Flujo  │   │ Procesar y  │
│ Alt.   │   │ Enviar a    │
│        │   │ Kafka       │
└────────┘   └──────┬──────┘
                    │
              ┌─────┴─────┐
              │ Intento 1 │
              └─────┬─────┘
                    │
               ¿Éxito?
                 ┌──┴──┐
              NO │     │ SÍ → FIN
                 ▼     │
           ┌──────────┐│
           │ Intento 2││
           └─────┬────┘│
                 │     │
            ¿Éxito?    │
              ┌──┴──┐  │
           NO │     │ SÍ
              ▼     │  │
        ┌──────────┐│  │
        │ Intento 3││  │
        └─────┬────┘│  │
              │     │  │
         ¿Éxito?    │  │
           ┌──┴──┐  │  │
        NO │     │ SÍ │
           ▼     │  │  │
      ┌────────┐│  │  │
      │  DLQ   ││  │  │
      │ (Error)││  │  │
      └────────┘▼  ▼  ▼
              FIN
```

---

## 📝 Detalles de Implementación

### 1. Variables de Entorno (application.properties)

```properties
# Configuración de umbral para procesamiento
file.processing.kafka-threshold=300

# Configuración de reintentos de Kafka
kafka.retry.max-attempts=3
kafka.retry.initial-interval=1000
kafka.retry.multiplier=2.0
kafka.retry.max-interval=10000

# Tópico de Dead Letter Queue para errores
kafka.topic.dead-letter=RegistrosDeadLetter
```

**Justificación:**
- `kafka-threshold`: Permite ajustar el umbral según necesidades del negocio sin recompilar
- `max-attempts`: Configurable para diferentes ambientes (dev: 2, prod: 3, etc.)
- `initial-interval` y `multiplier`: Backoff exponencial (1s → 2s → 4s)
- `dead-letter`: Topic separado para análisis de fallos

---

### 2. Configuración de Reintentos (KafkaRetryConfig.java)

```java
@Configuration
public class KafkaRetryConfig {
    
    @Autowired
    private Environment env;
    
    @Bean
    public RetryTemplate kafkaRetryTemplate() {
        RetryTemplate retryTemplate = new RetryTemplate();
        
        // Política de reintentos
        SimpleRetryPolicy retryPolicy = new SimpleRetryPolicy();
        int maxAttempts = Integer.parseInt(
            env.getProperty("kafka.retry.max-attempts", "3")
        );
        retryPolicy.setMaxAttempts(maxAttempts);
        
        // Política de backoff exponencial
        ExponentialBackOffPolicy backOffPolicy = new ExponentialBackOffPolicy();
        backOffPolicy.setInitialInterval(
            Long.parseLong(env.getProperty("kafka.retry.initial-interval", "1000"))
        );
        backOffPolicy.setMultiplier(
            Double.parseDouble(env.getProperty("kafka.retry.multiplier", "2.0"))
        );
        backOffPolicy.setMaxInterval(
            Long.parseLong(env.getProperty("kafka.retry.max-interval", "10000"))
        );
        
        retryTemplate.setRetryPolicy(retryPolicy);
        retryTemplate.setBackOffPolicy(backOffPolicy);
        
        return retryTemplate;
    }
}
```

**Características:**
- Backoff exponencial para evitar saturar Kafka durante fallos temporales
- Configuración inyectada desde properties
- Reutilizable para otros componentes que necesiten reintentos

---

### 3. Actualización de MessageProducer

```java
@Component
public class MessageProducer {
    
    @Autowired
    private RetryTemplate kafkaRetryTemplate;
    
    @Autowired
    private Environment env;
    
    private final AtomicInteger attemptCounter = new AtomicInteger(0);
    
    /**
     * Publica mensaje con reintentos automáticos
     */
    public void publishProcessedRegister(String message) {
        attemptCounter.set(0);
        
        try {
            kafkaRetryTemplate.execute(
                context -> {
                    int attempt = attemptCounter.incrementAndGet();
                    logger.log(Level.INFO, 
                        String.format("Intento %d de envío a Kafka", attempt));
                    
                    kafkaTemplate.send(
                        env.getProperty("kafka.topic.processed-register"), 
                        message
                    ).get(5, TimeUnit.SECONDS); // Timeout 5s
                    
                    logger.log(Level.INFO, 
                        String.format("Mensaje enviado exitosamente en intento %d", attempt));
                    return true;
                },
                context -> {
                    // Recovery callback - enviar a DLQ
                    logger.log(Level.SEVERE, 
                        String.format("Falló después de %d intentos. Enviando a DLQ", 
                            attemptCounter.get()));
                    publishToDeadLetterQueue(message, context.getLastThrowable());
                    return false;
                }
            );
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error en proceso de reintentos", e);
            publishToDeadLetterQueue(message, e);
        }
    }
    
    /**
     * Envía mensaje fallido a Dead Letter Queue
     */
    private void publishToDeadLetterQueue(String originalMessage, Throwable error) {
        try {
            Map<String, Object> dlqMessage = new HashMap<>();
            dlqMessage.put("originalMessage", originalMessage);
            dlqMessage.put("error", error.getMessage());
            dlqMessage.put("stackTrace", getStackTraceAsString(error));
            dlqMessage.put("timestamp", LocalDateTime.now().toString());
            dlqMessage.put("attempts", attemptCounter.get());
            
            String dlqTopic = env.getProperty("kafka.topic.dead-letter");
            kafkaTemplate.send(dlqTopic, gson.toJson(dlqMessage));
            
            logger.log(Level.INFO, "Mensaje enviado a DLQ: " + dlqTopic);
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error crítico: no se pudo enviar a DLQ", e);
        }
    }
}
```

**Características:**
- Contador de intentos visible en logs
- Timeout de 5 segundos por intento
- Recovery callback automático para DLQ
- Metadata completa en mensajes de error (stacktrace, timestamp, intentos)

---

### 4. DTO para Respuesta de Validación

```java
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RecordCountValidationResponse {
    
    private int recordCount;
    private int threshold;
    private boolean shouldUseKafka;
    private String message;
    private String processingRoute; // "KAFKA" o "ALTERNATIVE"
    
    public static RecordCountValidationResponse create(
            int recordCount, 
            int threshold) {
        
        boolean shouldUseKafka = recordCount >= threshold;
        String route = shouldUseKafka ? "KAFKA" : "ALTERNATIVE";
        
        String message = String.format(
            "Se detectaron %d registros. Umbral configurado: %d. " +
            "Procesamiento por flujo: %s",
            recordCount, threshold, route
        );
        
        return RecordCountValidationResponse.builder()
            .recordCount(recordCount)
            .threshold(threshold)
            .shouldUseKafka(shouldUseKafka)
            .message(message)
            .processingRoute(route)
            .build();
    }
}
```

---

### 5. Método de Validación en FileProcessingComponent

```java
/**
 * Valida si el archivo cumple con el umbral para procesamiento Kafka
 * Cuenta registros eficientemente sin cargar todo el archivo en memoria
 */
private RecordCountValidationResponse validateRecordCountThreshold(File file) 
        throws IOException {
    
    int threshold = Integer.parseInt(
        env.getProperty("file.processing.kafka-threshold", "300")
    );
    
    int recordCount = countRecordsEfficiently(file);
    
    return RecordCountValidationResponse.create(recordCount, threshold);
}

/**
 * Cuenta registros sin cargar el archivo completo en memoria
 */
private int countRecordsEfficiently(File file) throws IOException {
    String extension = getFileExtension(file.getName()).toLowerCase();
    
    switch (extension) {
        case "csv":
        case "txt":
            return countLinesInTextFile(file);
        case "xlsx":
            return countRowsInExcelXlsx(file);
        case "xls":
            return countRowsInExcelXls(file);
        default:
            throw new IllegalArgumentException("Tipo de archivo no soportado");
    }
}

/**
 * Cuenta líneas en archivo de texto (CSV/TXT)
 */
private int countLinesInTextFile(File file) throws IOException {
    try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
        int count = 0;
        while (reader.readLine() != null) {
            count++;
        }
        return Math.max(0, count - 1); // Excluir header
    }
}

/**
 * Cuenta filas en Excel XLSX sin cargar todo en memoria
 */
private int countRowsInExcelXlsx(File file) throws IOException {
    try (FileInputStream fis = new FileInputStream(file);
         XSSFWorkbook workbook = new XSSFWorkbook(fis)) {
        Sheet sheet = workbook.getSheetAt(0);
        return Math.max(0, sheet.getPhysicalNumberOfRows() - 1); // Excluir header
    }
}

/**
 * Cuenta filas en Excel XLS
 */
private int countRowsInExcelXls(File file) throws IOException {
    try (FileInputStream fis = new FileInputStream(file);
         HSSFWorkbook workbook = new HSSFWorkbook(fis)) {
        Sheet sheet = workbook.getSheetAt(0);
        return Math.max(0, sheet.getPhysicalNumberOfRows() - 1); // Excluir header
    }
}
```

**Optimizaciones:**
- No carga archivos completos en memoria
- Para Excel, usa `getPhysicalNumberOfRows()` que es O(1)
- Para CSV/TXT, lee línea por línea sin almacenar contenido
- Manejo separado por tipo de archivo

---

### 6. Modificación de processFile()

```java
private void processFile(File file, String processedDirectory, String errorDirectory) {
    logger.log(Level.INFO, "Procesando archivo: " + file.getName());
    
    // [... código existente de búsqueda de FileRegister ...]
    
    try {
        // NUEVO: Validar umbral de registros
        RecordCountValidationResponse validation = validateRecordCountThreshold(file);
        
        logger.log(Level.INFO, validation.getMessage());
        
        // Actualizar FileRegister con información de validación
        fileRegister.setRecordCount(validation.getRecordCount());
        fileRegister.setRecordCountThreshold(validation.getThreshold());
        fileRegister.setProcessingRoute(validation.getProcessingRoute());
        
        // Si no cumple umbral, no procesar por Kafka
        if (!validation.isShouldUseKafka()) {
            fileRegister.setStatus("PENDING_ALTERNATIVE");
            fileRegister.setProcessEndTime(LocalDateTime.now());
            fileRegisterService.save(fileRegister);
            
            logger.log(Level.INFO, String.format(
                "Archivo %s con %d registros no cumple umbral. " +
                "Debe procesarse por flujo alternativo.",
                file.getName(), validation.getRecordCount()
            ));
            
            // NO mover archivo - queda pendiente para flujo alternativo
            return;
        }
        
        // Continuar con procesamiento normal (Kafka)
        logger.log(Level.INFO, String.format(
            "Archivo %s cumple umbral. Iniciando procesamiento Kafka",
            file.getName()
        ));
        
        // [... resto del código existente ...]
        
    } catch (Exception e) {
        // [... manejo de errores existente ...]
    }
}
```

**Cambios:**
- Validación antes de cualquier procesamiento costoso
- Estado especial `PENDING_ALTERNATIVE` para archivos bajo umbral
- Archivos bajo umbral NO se mueven (quedan para otro proceso)
- Logs detallados de decisión tomada

---

### 7. Endpoint REST de Validación Previa

```java
/**
 * Valida si un archivo cumple el umbral sin procesarlo
 * Útil para validación previa al upload definitivo
 */
@Operation(
    summary = "Validar umbral de registros",
    description = "Valida si el archivo cumple el umbral de registros para procesamiento Kafka"
)
@PostMapping(value = "/validate-threshold", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
public ResponseEntity<RecordCountValidationResponse> validateThreshold(
        @Parameter(description = "Archivo a validar", required = true)
        @RequestParam("file") MultipartFile file) {
    
    try {
        if (file.isEmpty()) {
            return ResponseEntity.badRequest().build();
        }
        
        // Guardar temporalmente para análisis
        File tempFile = File.createTempFile("validate_", "_" + file.getOriginalFilename());
        file.transferTo(tempFile);
        
        try {
            RecordCountValidationResponse response = 
                validateRecordCountThreshold(tempFile);
            return ResponseEntity.ok(response);
        } finally {
            tempFile.delete();
        }
        
    } catch (Exception e) {
        logger.log(Level.SEVERE, "Error validando umbral", e);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    }
}

// Método auxiliar inyectado desde FileProcessingComponent
private RecordCountValidationResponse validateRecordCountThreshold(File file) 
        throws IOException {
    // Delegar a FileProcessingComponent o duplicar lógica
    // (Considerar extraer a un servicio compartido)
}
```

**Uso:**
```bash
POST /api/files/validate-threshold
Content-Type: multipart/form-data

Response:
{
  "recordCount": 150,
  "threshold": 300,
  "shouldUseKafka": false,
  "message": "Se detectaron 150 registros. Umbral configurado: 300. Procesamiento por flujo: ALTERNATIVE",
  "processingRoute": "ALTERNATIVE"
}
```

---

### 8. Actualización del Modelo FileRegister

```java
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FileRegister {
    
    // [... campos existentes ...]
    
    // NUEVOS CAMPOS
    
    /**
     * Ruta de procesamiento tomada: KAFKA o ALTERNATIVE
     */
    private String processingRoute;
    
    /**
     * Umbral configurado al momento de la validación
     */
    private Integer recordCountThreshold;
    
    /**
     * Número de intentos de envío a Kafka realizados
     */
    private Integer retryAttempts;
    
    /**
     * Indica si el mensaje fue enviado al Dead Letter Queue
     */
    private Boolean sentToDeadLetter;
    
    /**
     * Timestamp del último intento de envío
     */
    private LocalDateTime lastRetryTime;
}
```

---

## 🧪 Estrategia de Testing

### Tests Unitarios - FileProcessingComponent

```java
@Test
void testValidation_BelowThreshold_ShouldReturnAlternative() {
    // Arrange
    File testFile = createTestExcelFile(150); // 150 registros
    
    // Act
    RecordCountValidationResponse response = 
        component.validateRecordCountThreshold(testFile);
    
    // Assert
    assertEquals(150, response.getRecordCount());
    assertEquals(300, response.getThreshold());
    assertFalse(response.isShouldUseKafka());
    assertEquals("ALTERNATIVE", response.getProcessingRoute());
}

@Test
void testValidation_AtThreshold_ShouldReturnKafka() {
    // 300 registros = umbral exacto
    File testFile = createTestExcelFile(300);
    
    RecordCountValidationResponse response = 
        component.validateRecordCountThreshold(testFile);
    
    assertTrue(response.isShouldUseKafka());
    assertEquals("KAFKA", response.getProcessingRoute());
}

@Test
void testValidation_AboveThreshold_ShouldReturnKafka() {
    // 500 registros > 300
    File testFile = createTestExcelFile(500);
    
    RecordCountValidationResponse response = 
        component.validateRecordCountThreshold(testFile);
    
    assertTrue(response.isShouldUseKafka());
}
```

### Tests Unitarios - MessageProducer

```java
@Test
void testRetry_SuccessOnSecondAttempt() {
    // Simular fallo en primer intento, éxito en segundo
    when(kafkaTemplate.send(anyString(), anyString()))
        .thenThrow(new RuntimeException("Connection failed"))
        .thenReturn(CompletableFuture.completedFuture(null));
    
    messageProducer.publishProcessedRegister("{\"test\": \"data\"}");
    
    // Verificar 2 intentos
    verify(kafkaTemplate, times(2)).send(anyString(), anyString());
    verify(kafkaTemplate, never()).send(eq("RegistrosDeadLetter"), anyString());
}

@Test
void testRetry_SendToDLQAfterThreeFailures() {
    // Simular 3 fallos consecutivos
    when(kafkaTemplate.send(anyString(), anyString()))
        .thenThrow(new RuntimeException("Kafka unavailable"));
    
    messageProducer.publishProcessedRegister("{\"test\": \"data\"}");
    
    // Verificar 3 intentos + 1 envío a DLQ
    verify(kafkaTemplate, times(3))
        .send(eq("RegistrosProcesados"), anyString());
    verify(kafkaTemplate, times(1))
        .send(eq("RegistrosDeadLetter"), anyString());
}
```

### Tests de Integración

```java
@Test
@Transactional
void testEndToEnd_SmallFile_AlternativeRoute() {
    // Crear archivo con 100 registros
    MultipartFile file = createMockExcelFile(100);
    
    // Upload
    ResponseEntity<?> response = controller.uploadFile(file);
    assertEquals(HttpStatus.ACCEPTED, response.getStatusCode());
    
    // Esperar procesamiento
    await().atMost(Duration.ofSeconds(45))
        .until(() -> {
            List<FileRegister> registers = 
                fileRegisterService.findByFileName(file.getOriginalFilename());
            return !registers.isEmpty() && 
                   "PENDING_ALTERNATIVE".equals(registers.get(0).getStatus());
        });
    
    // Verificar estado
    FileRegister register = fileRegisterService
        .findByFileName(file.getOriginalFilename()).get(0);
    assertEquals("ALTERNATIVE", register.getProcessingRoute());
    assertEquals(100, register.getRecordCount());
}

@Test
@Transactional
void testEndToEnd_LargeFile_KafkaRoute() {
    // Crear archivo con 500 registros
    MultipartFile file = createMockExcelFile(500);
    
    // Upload
    ResponseEntity<?> response = controller.uploadFile(file);
    assertEquals(HttpStatus.ACCEPTED, response.getStatusCode());
    
    // Esperar procesamiento completo
    await().atMost(Duration.ofSeconds(60))
        .until(() -> {
            List<FileRegister> registers = 
                fileRegisterService.findByFileName(file.getOriginalFilename());
            return !registers.isEmpty() && 
                   "COMPLETED".equals(registers.get(0).getStatus());
        });
    
    // Verificar envío a Kafka
    FileRegister register = fileRegisterService
        .findByFileName(file.getOriginalFilename()).get(0);
    assertEquals("KAFKA", register.getProcessingRoute());
    assertEquals(500, register.getPublishedCount());
}
```

---

## 📊 Métricas y Monitoreo

### Logs Clave a Monitorear

```
INFO: Archivo test.xlsx: 250 registros detectados. Umbral: 300. Flujo: ALTERNATIVE
INFO: Archivo big.xlsx: 450 registros detectados. Umbral: 300. Flujo: KAFKA
INFO: Intento 1 de envío a Kafka
WARNING: Intento 1 fallido. Reintentando en 1000ms
INFO: Intento 2 de envío a Kafka
INFO: Mensaje enviado exitosamente en intento 2
SEVERE: Falló después de 3 intentos. Enviando a DLQ
```

### Métricas Recomendadas (futuro)

- `files_below_threshold_total`: Contador de archivos bajo umbral
- `files_above_threshold_total`: Contador de archivos sobre umbral
- `kafka_retry_attempts_total`: Histograma de intentos de reintento
- `kafka_dlq_messages_total`: Contador de mensajes en DLQ
- `processing_route_distribution`: Distribución KAFKA vs ALTERNATIVE

---

## 🚀 Plan de Despliegue

### Fase 1: Desarrollo y Testing Local (Semana 1)
- ✅ Implementar configuración y clases base
- ✅ Crear tests unitarios
- ✅ Validación local con Kafka embebido

### Fase 2: Testing en Desarrollo (Semana 2)
- ✅ Desplegar en ambiente DEV
- ✅ Pruebas con archivos reales
- ✅ Ajustar valores de backoff según resultados

### Fase 3: QA y UAT (Semana 3)
- ✅ Pruebas de carga con diferentes tamaños
- ✅ Validación de flujo alternativo
- ✅ Pruebas de resiliencia (Kafka caído)

### Fase 4: Producción (Semana 4)
- ✅ Despliegue gradual (canary deployment)
- ✅ Monitoreo intensivo primeras 48h
- ✅ Rollback plan preparado

---

## ⚙️ Configuración por Ambiente

### Desarrollo
```properties
file.processing.kafka-threshold=50
kafka.retry.max-attempts=2
kafka.retry.initial-interval=500
```

### QA
```properties
file.processing.kafka-threshold=200
kafka.retry.max-attempts=3
kafka.retry.initial-interval=1000
```

### Producción
```properties
file.processing.kafka-threshold=300
kafka.retry.max-attempts=3
kafka.retry.initial-interval=1000
kafka.retry.multiplier=2.0
kafka.retry.max-interval=10000
```

---

## 🔍 Consideraciones y Riesgos

### Riesgo 1: Archivos Gigantes
**Problema:** Archivos con 100k+ registros pueden saturar Kafka  
**Mitigación:**
- Implementar límite máximo de registros (ej: 50,000)
- Dividir archivos grandes en lotes
- Agregar validación de tamaño antes del upload

### Riesgo 2: DLQ Saturado
**Problema:** Muchos mensajes en DLQ sin procesamiento  
**Mitigación:**
- Implementar alertas cuando DLQ > 100 mensajes
- Proceso batch para reprocesar mensajes de DLQ
- Dashboard de monitoreo de DLQ

### Riesgo 3: Flujo Alternativo No Definido
**Problema:** Archivos < 300 quedan en estado PENDING_ALTERNATIVE sin procesamiento  
**Mitigación:**
- Documentar claramente qué proceso debe consumir estos archivos
- Considerar implementar endpoint para triggering manual
- Definir SLA para procesamiento alternativo

---

## 📚 Referencias

- Spring Retry: https://github.com/spring-projects/spring-retry
- Apache Kafka Dead Letter Queue Pattern
- Apache POI: https://poi.apache.org/
- Exponential Backoff Best Practices

---

## ✅ Checklist de Implementación

- [ ] 1. Agregar variables de entorno en application.properties
- [ ] 2. Crear KafkaRetryConfig.java
- [ ] 3. Modificar MessageProducer.java con reintentos
- [ ] 4. Crear RecordCountValidationResponse.java
- [ ] 5. Implementar validateRecordCountThreshold() en FileProcessingComponent
- [ ] 6. Modificar processFile() con lógica de umbral
- [ ] 7. Agregar endpoint /validate-threshold en FileUploadController
- [ ] 8. Actualizar modelo FileRegister
- [ ] 9. Crear tests unitarios FileProcessingComponentTest
- [ ] 10. Crear tests unitarios MessageProducerTest
- [ ] 11. Actualizar DOCUMENTACION.md
- [ ] 12. Pruebas de integración end-to-end

---

**Fin del Plan de Implementación**
