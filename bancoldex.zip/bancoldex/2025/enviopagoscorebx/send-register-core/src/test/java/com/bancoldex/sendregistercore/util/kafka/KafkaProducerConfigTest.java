package com.bancoldex.sendregistercore.util.kafka;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.env.Environment;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class KafkaProducerConfigTest {

	@Mock
	private Environment env;

	@InjectMocks
	private KafkaProducerConfig kafkaProducerConfig;

	@Test
	void testProducerFactory() {
		// Arrange
		when(env.getProperty("spring.kafka.bootstrap-servers")).thenReturn("localhost:9092");

		// Act
		ProducerFactory<String, String> factory = kafkaProducerConfig.producerFactory();

		// Assert
		assertNotNull(factory, "ProducerFactory no debe ser null");
	}

	@Test
	void testKafkaTemplate() {
		// Arrange
		when(env.getProperty("spring.kafka.bootstrap-servers")).thenReturn("localhost:9092");

		// Act
		KafkaTemplate<String, String> template = kafkaProducerConfig.kafkaTemplate();

		// Assert
		assertNotNull(template, "KafkaTemplate no debe ser null");
	}
}
