package com.bancoldex.sendregistercore.controller;

import com.bancoldex.sendregistercore.dto.FileStatusResponse;
import com.bancoldex.sendregistercore.dto.FileUploadResponse;
import com.bancoldex.sendregistercore.model.FileRegister;
import com.bancoldex.sendregistercore.service.InMemoryFileRegisterService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.io.TempDir;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class FileUploadControllerTest {

	@Mock
	private Environment env;

	@Mock
	private InMemoryFileRegisterService fileRegisterService;

	@InjectMocks
	private FileUploadController fileUploadController;

	@TempDir
	Path tempDir;

	@BeforeEach
	void setUp() {
		when(env.getProperty("file.processing.input-directory")).thenReturn(tempDir.toString());
		when(env.getProperty("file.upload.max-size-mb", "50")).thenReturn("50");
	}

	@Test
	void testUploadExcelFile_Success() throws IOException {
		// Arrange
		byte[] content = "Test Excel Content".getBytes();
		MockMultipartFile file = new MockMultipartFile(
			"file",
			"test.xlsx",
			"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
			content
		);

		FileRegister mockRegister = FileRegister.builder()
			.id(1L)
			.fileName("test.xlsx")
			.fileSize((long) content.length)
			.status("PENDING")
			.build();

		when(fileRegisterService.existsByFileNameAndStatus(anyString(), eq("COMPLETED"))).thenReturn(false);
		when(fileRegisterService.save(any(FileRegister.class))).thenReturn(mockRegister);

		// Act
		ResponseEntity<?> response = fileUploadController.uploadFile(file);

		// Assert
		assertEquals(HttpStatus.ACCEPTED, response.getStatusCode());
		assertNotNull(response.getBody());
		assertTrue(response.getBody() instanceof FileUploadResponse);
		
		FileUploadResponse uploadResponse = (FileUploadResponse) response.getBody();
		assertEquals("test.xlsx", uploadResponse.getFileName());
		assertEquals("PENDING", uploadResponse.getStatus());
		assertEquals(1L, uploadResponse.getTrackingId());
		
		verify(fileRegisterService).save(any(FileRegister.class));
		assertTrue(Files.exists(tempDir.resolve("test.xlsx")));
	}

	@Test
	void testUploadFile_EmptyFile() {
		// Arrange
		MockMultipartFile file = new MockMultipartFile(
			"file",
			"empty.xlsx",
			"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
			new byte[0]
		);

		// Act
		ResponseEntity<?> response = fileUploadController.uploadFile(file);

		// Assert
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		FileUploadResponse uploadResponse = (FileUploadResponse) response.getBody();
		assertNotNull(uploadResponse);
		assertEquals("ERROR", uploadResponse.getStatus());
		assertTrue(uploadResponse.getMessage().contains("empty"));
	}

	@Test
	void testUploadFile_InvalidExtension() {
		// Arrange
		MockMultipartFile file = new MockMultipartFile(
			"file",
			"test.pdf",
			"application/pdf",
			"Test content".getBytes()
		);

		// Act
		ResponseEntity<?> response = fileUploadController.uploadFile(file);

		// Assert
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		FileUploadResponse uploadResponse = (FileUploadResponse) response.getBody();
		assertNotNull(uploadResponse);
		assertEquals("ERROR", uploadResponse.getStatus());
		assertTrue(uploadResponse.getMessage().contains("Invalid file type"));
	}

	@Test
	void testUploadFile_FileTooLarge() {
		// Arrange
		byte[] largeContent = new byte[51 * 1024 * 1024]; // 51 MB
		MockMultipartFile file = new MockMultipartFile(
			"file",
			"large.xlsx",
			"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
			largeContent
		);

		// Act
		ResponseEntity<?> response = fileUploadController.uploadFile(file);

		// Assert
		assertEquals(HttpStatus.PAYLOAD_TOO_LARGE, response.getStatusCode());
		FileUploadResponse uploadResponse = (FileUploadResponse) response.getBody();
		assertNotNull(uploadResponse);
		assertEquals("ERROR", uploadResponse.getStatus());
		assertTrue(uploadResponse.getMessage().contains("exceeds maximum limit"));
	}

	@Test
	void testUploadFile_DuplicateFile() {
		// Arrange
		MockMultipartFile file = new MockMultipartFile(
			"file",
			"duplicate.xlsx",
			"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
			"Test content".getBytes()
		);

		when(fileRegisterService.existsByFileNameAndStatus("duplicate.xlsx", "COMPLETED")).thenReturn(true);

		// Act
		ResponseEntity<?> response = fileUploadController.uploadFile(file);

		// Assert
		assertEquals(HttpStatus.CONFLICT, response.getStatusCode());
		FileUploadResponse uploadResponse = (FileUploadResponse) response.getBody();
		assertNotNull(uploadResponse);
		assertEquals("ERROR", uploadResponse.getStatus());
		assertTrue(uploadResponse.getMessage().contains("already been processed"));
		
		verify(fileRegisterService, never()).save(any(FileRegister.class));
	}

	@Test
	void testUploadCsvFile_Success() throws IOException {
		// Arrange
		byte[] content = "header1,header2\nvalue1,value2".getBytes();
		MockMultipartFile file = new MockMultipartFile(
			"file",
			"test.csv",
			"text/csv",
			content
		);

		FileRegister mockRegister = FileRegister.builder()
			.id(2L)
			.fileName("test.csv")
			.fileSize((long) content.length)
			.status("PENDING")
			.build();

		when(fileRegisterService.existsByFileNameAndStatus(anyString(), eq("COMPLETED"))).thenReturn(false);
		when(fileRegisterService.save(any(FileRegister.class))).thenReturn(mockRegister);

		// Act
		ResponseEntity<?> response = fileUploadController.uploadFile(file);

		// Assert
		assertEquals(HttpStatus.ACCEPTED, response.getStatusCode());
		FileUploadResponse uploadResponse = (FileUploadResponse) response.getBody();
		assertNotNull(uploadResponse);
		assertEquals("test.csv", uploadResponse.getFileName());
	}

	@Test
	void testGetFileStatus_Success() {
		// Arrange
		Long trackingId = 1L;
		FileRegister fileRegister = FileRegister.builder()
			.id(trackingId)
			.fileName("test.xlsx")
			.status("COMPLETED")
			.recordCount(100)
			.publishedCount(100)
			.processStartTime(LocalDateTime.now().minusMinutes(5))
			.processEndTime(LocalDateTime.now())
			.build();

		when(fileRegisterService.findById(trackingId)).thenReturn(Optional.of(fileRegister));

		// Act
		ResponseEntity<?> response = fileUploadController.getFileStatus(trackingId);

		// Assert
		assertEquals(HttpStatus.OK, response.getStatusCode());
		FileStatusResponse statusResponse = (FileStatusResponse) response.getBody();
		assertNotNull(statusResponse);
		assertEquals(trackingId, statusResponse.getTrackingId());
		assertEquals("test.xlsx", statusResponse.getFileName());
		assertEquals("COMPLETED", statusResponse.getStatus());
		assertEquals(100, statusResponse.getRecordCount());
	}

	@Test
	void testGetFileStatus_NotFound() {
		// Arrange
		Long trackingId = 999L;
		when(fileRegisterService.findById(trackingId)).thenReturn(Optional.empty());

		// Act
		ResponseEntity<?> response = fileUploadController.getFileStatus(trackingId);

		// Assert
		assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
		FileStatusResponse statusResponse = (FileStatusResponse) response.getBody();
		assertNotNull(statusResponse);
		assertEquals("NOT_FOUND", statusResponse.getStatus());
		assertTrue(statusResponse.getErrorMessage().contains("No file found"));
	}

	@Test
	void testGetFileStatus_Processing() {
		// Arrange
		Long trackingId = 1L;
		FileRegister fileRegister = FileRegister.builder()
			.id(trackingId)
			.fileName("processing.xlsx")
			.status("PROCESSING")
			.processStartTime(LocalDateTime.now())
			.build();

		when(fileRegisterService.findById(trackingId)).thenReturn(Optional.of(fileRegister));

		// Act
		ResponseEntity<?> response = fileUploadController.getFileStatus(trackingId);

		// Assert
		assertEquals(HttpStatus.OK, response.getStatusCode());
		FileStatusResponse statusResponse = (FileStatusResponse) response.getBody();
		assertNotNull(statusResponse);
		assertEquals("PROCESSING", statusResponse.getStatus());
		assertNull(statusResponse.getProcessEndTime());
	}

	@Test
	void testGetFileStatus_Error() {
		// Arrange
		Long trackingId = 1L;
		FileRegister fileRegister = FileRegister.builder()
			.id(trackingId)
			.fileName("error.xlsx")
			.status("ERROR")
			.errorMessage("Invalid file format")
			.processStartTime(LocalDateTime.now().minusMinutes(1))
			.processEndTime(LocalDateTime.now())
			.build();

		when(fileRegisterService.findById(trackingId)).thenReturn(Optional.of(fileRegister));

		// Act
		ResponseEntity<?> response = fileUploadController.getFileStatus(trackingId);

		// Assert
		assertEquals(HttpStatus.OK, response.getStatusCode());
		FileStatusResponse statusResponse = (FileStatusResponse) response.getBody();
		assertNotNull(statusResponse);
		assertEquals("ERROR", statusResponse.getStatus());
		assertEquals("Invalid file format", statusResponse.getErrorMessage());
	}

	@Test
	void testGetHealth_Success() {
		// Arrange
		when(fileRegisterService.countByStatus("PENDING")).thenReturn(5L);
		when(fileRegisterService.countByStatus("PROCESSING")).thenReturn(2L);
		when(fileRegisterService.countByStatus("COMPLETED")).thenReturn(100L);
		when(fileRegisterService.countByStatus("ERROR")).thenReturn(3L);
		when(fileRegisterService.findTop5ByStatusOrderByProcessEndTimeDesc("COMPLETED"))
			.thenReturn(java.util.Collections.emptyList());

		// Act
		ResponseEntity<?> response = fileUploadController.getHealth();

		// Assert
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertNotNull(response.getBody());
		
		@SuppressWarnings("unchecked")
		java.util.Map<String, Object> health = (java.util.Map<String, Object>) response.getBody();
		assertEquals("UP", health.get("status"));
		assertEquals(5L, health.get("pendingFiles"));
		assertEquals(2L, health.get("processingFiles"));
		assertEquals(100L, health.get("completedFiles"));
		assertEquals(3L, health.get("errorFiles"));
		assertNotNull(health.get("timestamp"));
	}

	@Test
	void testUploadFile_MissingFileName() {
		// Arrange
		MockMultipartFile fileWithoutName = new MockMultipartFile(
			"file",
			null,
			"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
			"content".getBytes()
		);

		// Act
		ResponseEntity<?> response = fileUploadController.uploadFile(fileWithoutName);

		// Assert
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		FileUploadResponse uploadResponse = (FileUploadResponse) response.getBody();
		assertNotNull(uploadResponse);
		assertEquals("ERROR", uploadResponse.getStatus());
		assertTrue(uploadResponse.getMessage().contains("File name is missing"));
	}
}
