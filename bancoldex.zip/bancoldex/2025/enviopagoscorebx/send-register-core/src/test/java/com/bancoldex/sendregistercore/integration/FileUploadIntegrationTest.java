package com.bancoldex.sendregistercore.integration;

import com.bancoldex.sendregistercore.dto.FileStatusResponse;
import com.bancoldex.sendregistercore.dto.FileUploadResponse;
import com.bancoldex.sendregistercore.model.FileRegister;
import com.bancoldex.sendregistercore.service.InMemoryFileRegisterService;
import com.bancoldex.sendregistercore.util.kafka.MessageProducer;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.TestPropertySource;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

/**
 * Integration tests for end-to-end file upload and processing flow.
 * Tests full upload to save to process to Kafka to status complete cycle.
 */
@SpringBootTest
@TestPropertySource(properties = {
	"file.processing.input-directory=${java.io.tmpdir}/bancoldex-test/input",
	"file.processing.processed-directory=${java.io.tmpdir}/bancoldex-test/processed",
	"file.processing.error-directory=${java.io.tmpdir}/bancoldex-test/error",
	"file.upload.max-size-mb=50"
})
class FileUploadIntegrationTest {

	@Autowired
	private com.bancoldex.sendregistercore.controller.FileUploadController fileUploadController;

	@Autowired
	private InMemoryFileRegisterService fileRegisterService;

	@MockBean
	private MessageProducer messageProducer;

	@TempDir
	Path tempDir;

	@BeforeEach
	void setUp() {
		// Mock Kafka producer to avoid actual message sending
		doNothing().when(messageProducer).publishProcessedRegister(anyString());
		doNothing().when(messageProducer).publishExcelProcessed(anyString());
		doNothing().when(messageProducer).publishToErrorTopic(anyString(), anyString());
	}

	@AfterEach
	void tearDown() {
		// Clean up test data
		// In-memory service will be cleared automatically on restart
		// No explicit cleanup needed for in-memory storage
	}

	@Test
	void testEndToEndFileUploadAndStatusQuery() throws IOException {
		// Step 1: Create and upload Excel file
		byte[] excelContent = createMockExcelFile(100);
		MockMultipartFile file = new MockMultipartFile(
			"file",
			"integration_test.xlsx",
			"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
			excelContent
		);

		// Step 2: Upload file via REST API
		ResponseEntity<?> uploadResponse = fileUploadController.uploadFile(file);

		// Step 3: Verify upload response
		assertEquals(HttpStatus.ACCEPTED, uploadResponse.getStatusCode());
		assertNotNull(uploadResponse.getBody());
		
		FileUploadResponse uploadResult = (FileUploadResponse) uploadResponse.getBody();
		assertNotNull(uploadResult.getTrackingId());
		assertEquals("integration_test.xlsx", uploadResult.getFileName());
		assertEquals("PENDING", uploadResult.getStatus());

		// Step 4: Verify database record created
		Long trackingId = uploadResult.getTrackingId();
		Optional<FileRegister> savedRegister = fileRegisterService.findById(trackingId);
		assertTrue(savedRegister.isPresent());
		assertEquals("PENDING", savedRegister.get().getStatus());

		// Step 5: Query status via REST API
		ResponseEntity<?> statusResponse = fileUploadController.getFileStatus(trackingId);
		assertEquals(HttpStatus.OK, statusResponse.getStatusCode());
		
		FileStatusResponse statusResult = (FileStatusResponse) statusResponse.getBody();
		assertNotNull(statusResult);
		assertEquals(trackingId, statusResult.getTrackingId());
		assertEquals("integration_test.xlsx", statusResult.getFileName());
		assertEquals("PENDING", statusResult.getStatus());
	}

	@Test
	void testLargeFileUpload_10kRows() throws IOException {
		// Create Excel file with 10,000 rows
		byte[] largeExcelContent = createMockExcelFile(10000);
		MockMultipartFile largeFile = new MockMultipartFile(
			"file",
			"large_file_10k.xlsx",
			"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
			largeExcelContent
		);

		// Upload large file
		ResponseEntity<?> uploadResponse = fileUploadController.uploadFile(largeFile);

		// Verify successful upload
		assertEquals(HttpStatus.ACCEPTED, uploadResponse.getStatusCode());
		FileUploadResponse uploadResult = (FileUploadResponse) uploadResponse.getBody();
		assertNotNull(uploadResult);
		assertNotNull(uploadResult.getTrackingId());

		// Verify file size is reasonable (memory efficient)
		assertTrue(largeExcelContent.length > 0);
		assertTrue(largeExcelContent.length < 100 * 1024 * 1024); // Less than 100MB
	}

	@Test
	void testConcurrentUploads() throws IOException {
		// Upload 3 files concurrently
		MockMultipartFile file1 = createMockMultipartFile("concurrent_1.xlsx", 50);
		MockMultipartFile file2 = createMockMultipartFile("concurrent_2.xlsx", 75);
		MockMultipartFile file3 = createMockMultipartFile("concurrent_3.xlsx", 100);

		// Upload all files
		ResponseEntity<?> response1 = fileUploadController.uploadFile(file1);
		ResponseEntity<?> response2 = fileUploadController.uploadFile(file2);
		ResponseEntity<?> response3 = fileUploadController.uploadFile(file3);

		// Verify all uploads successful
		assertEquals(HttpStatus.ACCEPTED, response1.getStatusCode());
		assertEquals(HttpStatus.ACCEPTED, response2.getStatusCode());
		assertEquals(HttpStatus.ACCEPTED, response3.getStatusCode());

		// Verify unique tracking IDs
		FileUploadResponse result1 = (FileUploadResponse) response1.getBody();
		FileUploadResponse result2 = (FileUploadResponse) response2.getBody();
		FileUploadResponse result3 = (FileUploadResponse) response3.getBody();

		assertNotEquals(result1.getTrackingId(), result2.getTrackingId());
		assertNotEquals(result2.getTrackingId(), result3.getTrackingId());
		assertNotEquals(result1.getTrackingId(), result3.getTrackingId());
	}

	@Test
	void testHealthEndpoint() {
		// Query health endpoint
		ResponseEntity<?> healthResponse = fileUploadController.getHealth();

		// Verify health response
		assertEquals(HttpStatus.OK, healthResponse.getStatusCode());
		assertNotNull(healthResponse.getBody());

		@SuppressWarnings("unchecked")
		java.util.Map<String, Object> health = (java.util.Map<String, Object>) healthResponse.getBody();
		assertEquals("UP", health.get("status"));
		assertNotNull(health.get("pendingFiles"));
		assertNotNull(health.get("processingFiles"));
		assertNotNull(health.get("completedFiles"));
		assertNotNull(health.get("errorFiles"));
	}

	@Test
	void testUploadAndPreventDuplicate() throws IOException {
		// Step 1: Upload file first time
		MockMultipartFile file = createMockMultipartFile("duplicate_test.xlsx", 20);
		ResponseEntity<?> firstUpload = fileUploadController.uploadFile(file);
		assertEquals(HttpStatus.ACCEPTED, firstUpload.getStatusCode());

		FileUploadResponse firstResult = (FileUploadResponse) firstUpload.getBody();
		Long trackingId = firstResult.getTrackingId();

		// Step 2: Manually mark as COMPLETED in database
		FileRegister register = fileRegisterService.findById(trackingId).get();
		register.setStatus("COMPLETED");
		fileRegisterService.save(register);

		// Step 3: Try to upload same file again
		MockMultipartFile duplicateFile = createMockMultipartFile("duplicate_test.xlsx", 20);
		ResponseEntity<?> secondUpload = fileUploadController.uploadFile(duplicateFile);

		// Verify duplicate rejection
		assertEquals(HttpStatus.CONFLICT, secondUpload.getStatusCode());
		FileUploadResponse secondResult = (FileUploadResponse) secondUpload.getBody();
		assertTrue(secondResult.getMessage().contains("already been processed"));
	}

	/**
	 * Helper method to create mock Excel file with specified number of rows
	 */
	private byte[] createMockExcelFile(int rowCount) throws IOException {
		Workbook workbook = new XSSFWorkbook();
		Sheet sheet = workbook.createSheet("Test Data");

		// Create header row
		Row headerRow = sheet.createRow(0);
		headerRow.createCell(0).setCellValue("ID");
		headerRow.createCell(1).setCellValue("Name");
		headerRow.createCell(2).setCellValue("Email");
		headerRow.createCell(3).setCellValue("Amount");
		headerRow.createCell(4).setCellValue("Date");

		// Create data rows
		for (int i = 1; i <= rowCount; i++) {
			Row row = sheet.createRow(i);
			row.createCell(0).setCellValue(i);
			row.createCell(1).setCellValue("User " + i);
			row.createCell(2).setCellValue("user" + i + "@example.com");
			row.createCell(3).setCellValue(1000.50 * i);
			row.createCell(4).setCellValue("2025-11-" + (i % 28 + 1));
		}

		// Write to byte array
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		workbook.write(outputStream);
		workbook.close();

		return outputStream.toByteArray();
	}

	/**
	 * Helper method to create MockMultipartFile with Excel content
	 */
	private MockMultipartFile createMockMultipartFile(String filename, int rowCount) throws IOException {
		byte[] content = createMockExcelFile(rowCount);
		return new MockMultipartFile(
			"file",
			filename,
			"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
			content
		);
	}
}
