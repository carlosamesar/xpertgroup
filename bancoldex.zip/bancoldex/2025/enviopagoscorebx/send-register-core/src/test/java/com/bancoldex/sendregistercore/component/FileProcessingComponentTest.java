package com.bancoldex.sendregistercore.component;

import com.bancoldex.sendregistercore.dto.RecordCountValidationResponse;
import com.bancoldex.sendregistercore.model.FileRegister;
import com.bancoldex.sendregistercore.service.InMemoryFileRegisterService;
import com.bancoldex.sendregistercore.util.kafka.MessageProducer;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.io.TempDir;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.env.Environment;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class FileProcessingComponentTest {

	@Mock
	private Environment env;

	@Mock
	private MessageProducer messageProducer;

	@Mock
	private InMemoryFileRegisterService fileRegisterService;

	@InjectMocks
	private FileProcessingComponent fileProcessingComponent;

	@TempDir
	Path tempDir;

	@BeforeEach
	void setUp() {
		// Configurar propiedades mock
		when(env.getProperty("file.processing.input-directory")).thenReturn(tempDir.toString());
		when(env.getProperty("file.processing.processed-directory")).thenReturn(tempDir.resolve("processed").toString());
		when(env.getProperty("file.processing.error-directory")).thenReturn(tempDir.resolve("error").toString());
		when(env.getProperty("kafka.topic.processed-register")).thenReturn("RegistrosProcesados");
		when(env.getProperty("kafka.topic.error-register")).thenReturn("RegistrosError");
		when(env.getProperty("file.processing.kafka-threshold", "300")).thenReturn("300");
	}

	@Test
	void testProcessFilesScheduled_NoFilesInDirectory() {
		// Arrange
		when(fileRegisterService.existsByFileNameAndStatus(anyString(), anyString())).thenReturn(false);

		// Act
		fileProcessingComponent.processFilesScheduled();

		// Assert
		verify(messageProducer, never()).publishProcessedRegister(anyString());
	}

	@Test
	void testProcessCsvFile_Success() throws IOException {
		// Arrange
		File csvFile = tempDir.resolve("test.csv").toFile();
		try (FileWriter writer = new FileWriter(csvFile)) {
			writer.write("campo1,campo2,campo3\n");
			writer.write("valor1,valor2,valor3\n");
			writer.write("valor4,valor5,valor6\n");
		}

		FileRegister mockRegister = FileRegister.builder()
				.id(1L)
				.fileName("test.csv")
				.status("PROCESSING")
				.build();

		when(fileRegisterService.existsByFileNameAndStatus(anyString(), eq("COMPLETED"))).thenReturn(false);
		when(fileRegisterService.save(any(FileRegister.class))).thenReturn(mockRegister);
		doNothing().when(messageProducer).publishProcessedRegister(anyString());

		// Act
		fileProcessingComponent.processFiles();

		// Assert
		verify(messageProducer, atLeastOnce()).publishProcessedRegister(anyString());
		verify(fileRegisterService, atLeastOnce()).save(any(FileRegister.class));
	}

	@Test
	void testProcessTxtFile_Success() throws IOException {
		// Arrange
		File txtFile = tempDir.resolve("test.txt").toFile();
		try (FileWriter writer = new FileWriter(txtFile)) {
			writer.write("campo1|campo2|campo3\n");
			writer.write("valor1|valor2|valor3\n");
			writer.write("valor4|valor5|valor6\n");
		}

		FileRegister mockRegister = FileRegister.builder()
				.id(1L)
				.fileName("test.txt")
				.status("PROCESSING")
				.build();

		when(fileRegisterService.existsByFileNameAndStatus(anyString(), eq("COMPLETED"))).thenReturn(false);
		when(fileRegisterService.save(any(FileRegister.class))).thenReturn(mockRegister);
		doNothing().when(messageProducer).publishProcessedRegister(anyString());

		// Act
		fileProcessingComponent.processFiles();

		// Assert
		verify(messageProducer, atLeastOnce()).publishProcessedRegister(anyString());
		verify(fileRegisterService, atLeastOnce()).save(any(FileRegister.class));
	}

	@Test
	void testProcessFile_DuplicateFile() throws IOException {
		// Arrange
		File csvFile = tempDir.resolve("duplicate.csv").toFile();
		try (FileWriter writer = new FileWriter(csvFile)) {
			writer.write("campo1,campo2\n");
			writer.write("valor1,valor2\n");
		}

		when(fileRegisterService.existsByFileNameAndStatus("duplicate.csv", "COMPLETED")).thenReturn(true);

		// Act
		fileProcessingComponent.processFiles();

		// Assert
		verify(messageProducer, never()).publishProcessedRegister(anyString());
		verify(fileRegisterService, never()).save(any(FileRegister.class));
	}

	@Test
	void testProcessFile_InvalidExtension() throws IOException {
		// Arrange
		File xmlFile = tempDir.resolve("test.xml").toFile();
		xmlFile.createNewFile();

		// Act
		fileProcessingComponent.processFiles();

		// Assert - archivo XML no debe procesarse
		verify(messageProducer, never()).publishProcessedRegister(anyString());
	}

	@Test
	void testProcessExcelFile_Success() throws IOException {
		// Arrange
		// Note: This test requires a real Excel file or mocking Apache POI
		// For simplicity, we'll test with a CSV file that passes the extension check
		File xlsxFile = tempDir.resolve("test.xlsx").toFile();
		xlsxFile.createNewFile();

		FileRegister mockRegister = FileRegister.builder()
				.id(1L)
				.fileName("test.xlsx")
				.status("PROCESSING")
				.build();

		when(fileRegisterService.existsByFileNameAndStatus(anyString(), eq("COMPLETED"))).thenReturn(false);
		when(fileRegisterService.save(any(FileRegister.class))).thenReturn(mockRegister);
		doNothing().when(messageProducer).publishProcessedRegister(anyString());

		// Act
		fileProcessingComponent.processFiles();

		// Assert - Excel file should be picked up for processing
		verify(fileRegisterService, atLeastOnce()).save(any(FileRegister.class));
	}

	@Test
	void testProcessExcelFile_XLS_Extension() throws IOException {
		// Arrange
		File xlsFile = tempDir.resolve("legacy.xls").toFile();
		xlsFile.createNewFile();

		FileRegister mockRegister = FileRegister.builder()
				.id(1L)
				.fileName("legacy.xls")
				.status("PROCESSING")
				.build();

		when(fileRegisterService.existsByFileNameAndStatus(anyString(), eq("COMPLETED"))).thenReturn(false);
		when(fileRegisterService.save(any(FileRegister.class))).thenReturn(mockRegister);
		doNothing().when(messageProducer).publishProcessedRegister(anyString());

		// Act
		fileProcessingComponent.processFiles();

		// Assert - .xls file should be picked up for processing
		verify(fileRegisterService, atLeastOnce()).save(any(FileRegister.class));
	}

	// ==================== Tests de Validación de Umbral ====================

	@Test
	void testValidateThreshold_BelowThreshold_ShouldReturnAlternative() throws IOException {
		// Arrange: Crear archivo Excel con 150 registros (menos que 300)
		File testFile = createTestExcelFileWithRecords(150, "test_below.xlsx");

		// Act: Validar umbral
		RecordCountValidationResponse response = 
			fileProcessingComponent.validateRecordCountThreshold(testFile);

		// Assert: Debe indicar flujo ALTERNATIVE
		assertEquals(150, response.getRecordCount());
		assertEquals(300, response.getThreshold());
		assertFalse(response.isShouldUseKafka());
		assertEquals("ALTERNATIVE", response.getProcessingRoute());
		assertTrue(response.getMessage().contains("150 registros"));
	}

	@Test
	void testValidateThreshold_AtThreshold_ShouldReturnKafka() throws IOException {
		// Arrange: Crear archivo Excel con exactamente 300 registros
		File testFile = createTestExcelFileWithRecords(300, "test_at_threshold.xlsx");

		// Act
		RecordCountValidationResponse response = 
			fileProcessingComponent.validateRecordCountThreshold(testFile);

		// Assert: Debe indicar flujo KAFKA (300 >= 300)
		assertEquals(300, response.getRecordCount());
		assertEquals(300, response.getThreshold());
		assertTrue(response.isShouldUseKafka());
		assertEquals("KAFKA", response.getProcessingRoute());
	}

	@Test
	void testValidateThreshold_AboveThreshold_ShouldReturnKafka() throws IOException {
		// Arrange: Crear archivo Excel con 500 registros
		File testFile = createTestExcelFileWithRecords(500, "test_above.xlsx");

		// Act
		RecordCountValidationResponse response = 
			fileProcessingComponent.validateRecordCountThreshold(testFile);

		// Assert: Debe indicar flujo KAFKA
		assertEquals(500, response.getRecordCount());
		assertTrue(response.isShouldUseKafka());
		assertEquals("KAFKA", response.getProcessingRoute());
	}

	@Test
	void testValidateThreshold_CsvFile_ShouldCountCorrectly() throws IOException {
		// Arrange: Crear archivo CSV con 250 registros
		File testFile = createTestCsvFileWithRecords(250, "test.csv");

		// Act
		RecordCountValidationResponse response = 
			fileProcessingComponent.validateRecordCountThreshold(testFile);

		// Assert
		assertEquals(250, response.getRecordCount());
		assertFalse(response.isShouldUseKafka());
		assertEquals("ALTERNATIVE", response.getProcessingRoute());
	}

	@Test
	void testValidateThreshold_CustomThreshold_ShouldRespect() throws IOException {
		// Arrange: Configurar umbral personalizado de 100
		when(env.getProperty("file.processing.kafka-threshold", "300")).thenReturn("100");
		File testFile = createTestExcelFileWithRecords(150, "test_custom.xlsx");

		// Act
		RecordCountValidationResponse response = 
			fileProcessingComponent.validateRecordCountThreshold(testFile);

		// Assert: Con threshold=100, 150 debe ir a KAFKA
		assertEquals(150, response.getRecordCount());
		assertEquals(100, response.getThreshold());
		assertTrue(response.isShouldUseKafka());
	}

	// ==================== Helper Methods ====================

	/**
	 * Crea archivo Excel XLSX de prueba con número específico de registros
	 */
	private File createTestExcelFileWithRecords(int recordCount, String fileName) throws IOException {
		File file = tempDir.resolve(fileName).toFile();
		
		try (Workbook workbook = new XSSFWorkbook();
		     FileOutputStream fos = new FileOutputStream(file)) {
			
			Sheet sheet = workbook.createSheet("Test Data");
			
			// Crear header
			Row headerRow = sheet.createRow(0);
			headerRow.createCell(0).setCellValue("Column1");
			headerRow.createCell(1).setCellValue("Column2");
			headerRow.createCell(2).setCellValue("Column3");
			
			// Crear registros de datos
			for (int i = 0; i < recordCount; i++) {
				Row row = sheet.createRow(i + 1);
				row.createCell(0).setCellValue("Value" + i);
				row.createCell(1).setCellValue(i);
				row.createCell(2).setCellValue("Data" + i);
			}
			
			workbook.write(fos);
		}
		
		return file;
	}

	/**
	 * Crea archivo CSV de prueba
	 */
	private File createTestCsvFileWithRecords(int recordCount, String fileName) throws IOException {
		File file = tempDir.resolve(fileName).toFile();
		
		try (FileWriter writer = new FileWriter(file)) {
			// Escribir header
			writer.write("Column1,Column2,Column3\n");
			
			// Escribir registros
			for (int i = 0; i < recordCount; i++) {
				writer.write(String.format("Value%d,%d,Data%d\n", i, i, i));
			}
		}
		
		return file;
	}
}
