package com.bancoldex.sendregistercore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.builder.SpringApplicationBuilder;

import static org.junit.jupiter.api.Assertions.assertNotNull;

class ServletInitializerTest {

	@Test
	void testConfigure() {
		ServletInitializer initializer = new ServletInitializer();
		SpringApplicationBuilder builder = new SpringApplicationBuilder();
		SpringApplicationBuilder result = initializer.configure(builder);
		
		assertNotNull(result, "SpringApplicationBuilder no debe ser null");
	}
}
