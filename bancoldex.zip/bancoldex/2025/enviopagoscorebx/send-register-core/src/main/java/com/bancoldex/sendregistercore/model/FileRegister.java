package com.bancoldex.sendregistercore.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * FileRegister entity for tracking file processing
 * Phase 1: In-memory storage (no JPA/Database)
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FileRegister {

	private Long id;
	private String fileName;
	private String filePath;
	private Long fileSize;
	private Integer recordCount;
	private Integer publishedCount;
	private String status;
	private String errorMessage;
	private LocalDateTime processStartTime;
	private LocalDateTime processEndTime;
	private LocalDateTime createdAt;
	private LocalDateTime updatedAt;
	
	// Nuevos campos para validación de umbral y reintentos
	
	/**
	 * Ruta de procesamiento tomada: 'KAFKA' o 'ALTERNATIVE'
	 */
	private String processingRoute;
	
	/**
	 * Umbral configurado al momento de la validación
	 */
	private Integer recordCountThreshold;
	
	/**
	 * Número de intentos de envío a Kafka realizados
	 */
	private Integer retryAttempts;
	
	/**
	 * Indica si el mensaje fue enviado al Dead Letter Queue
	 */
	private Boolean sentToDeadLetter;
	
	/**
	 * Timestamp del último intento de envío
	 */
	private LocalDateTime lastRetryTime;
}
