package com.bancoldex.sendregistercore.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.retry.backoff.ExponentialBackOffPolicy;
import org.springframework.retry.policy.SimpleRetryPolicy;
import org.springframework.retry.support.RetryTemplate;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Configuración de reintentos para operaciones de Kafka
 * Implementa política de backoff exponencial para manejo de fallos temporales
 */
@Configuration
public class KafkaRetryConfig {

	private static final Logger logger = Logger.getLogger(KafkaRetryConfig.class.getName());

	@Autowired
	private Environment env;

	/**
	 * RetryTemplate configurado para reintentos de Kafka
	 * 
	 * Configuración:
	 * - Max intentos: configurable vía kafka.retry.max-attempts (default: 3)
	 * - Backoff inicial: configurable vía kafka.retry.initial-interval (default: 1000ms)
	 * - Multiplicador: configurable vía kafka.retry.multiplier (default: 2.0)
	 * - Backoff máximo: configurable vía kafka.retry.max-interval (default: 10000ms)
	 * 
	 * Ejemplo con defaults: 1s → 2s → 4s
	 * 
	 * @return RetryTemplate configurado
	 */
	@Bean
	public RetryTemplate kafkaRetryTemplate() {
		RetryTemplate retryTemplate = new RetryTemplate();

		// Política de reintentos simples
		SimpleRetryPolicy retryPolicy = new SimpleRetryPolicy();
		int maxAttempts = Integer.parseInt(
			env.getProperty("kafka.retry.max-attempts", "3")
		);
		retryPolicy.setMaxAttempts(maxAttempts);

		// Política de backoff exponencial
		ExponentialBackOffPolicy backOffPolicy = new ExponentialBackOffPolicy();
		
		long initialInterval = Long.parseLong(
			env.getProperty("kafka.retry.initial-interval", "1000")
		);
		backOffPolicy.setInitialInterval(initialInterval);

		double multiplier = Double.parseDouble(
			env.getProperty("kafka.retry.multiplier", "2.0")
		);
		backOffPolicy.setMultiplier(multiplier);

		long maxInterval = Long.parseLong(
			env.getProperty("kafka.retry.max-interval", "10000")
		);
		backOffPolicy.setMaxInterval(maxInterval);

		retryTemplate.setRetryPolicy(retryPolicy);
		retryTemplate.setBackOffPolicy(backOffPolicy);

		logger.log(Level.INFO, String.format(
			"KafkaRetryTemplate configurado: maxAttempts=%d, initialInterval=%dms, multiplier=%.1f, maxInterval=%dms",
			maxAttempts, initialInterval, multiplier, maxInterval
		));

		return retryTemplate;
	}
}
