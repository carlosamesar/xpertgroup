package com.bancoldex.sendregistercore.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Response DTO for file processing status queries
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FileStatusResponse {
	
	private Long trackingId;
	private String fileName;
	private String status;
	private Integer recordCount;
	private Integer publishedCount;
	private LocalDateTime processStartTime;
	private LocalDateTime processEndTime;
	private String errorMessage;
	
}
