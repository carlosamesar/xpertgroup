package com.bancoldex.sendregistercore.component;

import com.bancoldex.sendregistercore.dto.RecordCountValidationResponse;
import com.bancoldex.sendregistercore.model.FileRegister;
import com.bancoldex.sendregistercore.service.InMemoryFileRegisterService;
import com.bancoldex.sendregistercore.util.kafka.MessageProducer;
import com.google.gson.Gson;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Stream;

@Component
public class FileProcessingComponent {

	private static final Logger logger = Logger.getLogger(FileProcessingComponent.class.getName());

	@Autowired
	private Environment env;

	@Autowired
	private MessageProducer messageProducer;

	@Autowired
	private InMemoryFileRegisterService fileRegisterService;

	private final Gson gson = new Gson();

	/**
	 * Procesa archivos de forma programada cada 30 segundos
	 */
	@Scheduled(fixedDelay = 30000, initialDelay = 10000)
	public void processFilesScheduled() {
		logger.log(Level.INFO, "Iniciando procesamiento programado de archivos");
		processFiles();
	}

	/**
	 * Procesa todos los archivos pendientes en el directorio de entrada
	 */
	public void processFiles() {
		String inputDirectory = env.getProperty("file.processing.input-directory");
		String processedDirectory = env.getProperty("file.processing.processed-directory");
		String errorDirectory = env.getProperty("file.processing.error-directory");

		if (inputDirectory == null || inputDirectory.isEmpty()) {
			logger.log(Level.WARNING, "Directorio de entrada no configurado");
			return;
		}

		Path inputPath = Paths.get(inputDirectory);
		if (!Files.exists(inputPath)) {
			logger.log(Level.WARNING, "Directorio de entrada no existe: " + inputDirectory);
			return;
		}

		try (Stream<Path> paths = Files.walk(inputPath, 1)) {
			paths.filter(Files::isRegularFile)
				.filter(path -> isValidFileExtension(path.toString()))
				.forEach(filePath -> processFile(filePath.toFile(), processedDirectory, errorDirectory));
		} catch (IOException e) {
			logger.log(Level.SEVERE, "Error listando archivos en directorio: " + inputDirectory, e);
		}
	}

	/**
	 * Procesa un archivo individual
	 */
	private void processFile(File file, String processedDirectory, String errorDirectory) {
		logger.log(Level.INFO, "Procesando archivo: " + file.getName());

		// Buscar FileRegister existente por nombre de archivo en estado PENDING
		List<FileRegister> pendingRegisters = fileRegisterService.findByFileNameAndStatus(file.getName(), "PENDING");
		FileRegister fileRegister;
		
		if (!pendingRegisters.isEmpty()) {
			// Usar el FileRegister existente creado durante el upload
			fileRegister = pendingRegisters.get(0);
			fileRegister.setProcessStartTime(LocalDateTime.now());
			fileRegister.setStatus("PROCESSING");
		} else {
			// Crear nuevo registro si no existe (caso de archivos copiados directamente al input)
			fileRegister = new FileRegister();
			fileRegister.setFileName(file.getName());
			fileRegister.setFilePath(file.getAbsolutePath());
			fileRegister.setFileSize(file.length());
			fileRegister.setProcessStartTime(LocalDateTime.now());
			fileRegister.setStatus("PROCESSING");
		}

		try {
			// Validar que el archivo no fue procesado previamente
			if (fileRegisterService.existsByFileNameAndStatus(file.getName(), "COMPLETED")) {
				logger.log(Level.WARNING, "Archivo ya fue procesado: " + file.getName());
				moveFile(file, errorDirectory, "DUPLICADO");
				return;
			}

			fileRegister = fileRegisterService.save(fileRegister);

			// NUEVO: Validar umbral de registros antes de procesar
			RecordCountValidationResponse validation = validateRecordCountThreshold(file);
			
			logger.log(Level.INFO, validation.getMessage());
			
			// Actualizar FileRegister con información de validación
			fileRegister.setRecordCount(validation.getRecordCount());
			fileRegister.setRecordCountThreshold(validation.getThreshold());
			fileRegister.setProcessingRoute(validation.getProcessingRoute());
			
			// Si no cumple umbral, no procesar por Kafka
			if (!validation.isShouldUseKafka()) {
				fileRegister.setStatus("PENDING_ALTERNATIVE");
				fileRegister.setProcessEndTime(LocalDateTime.now());
				fileRegisterService.save(fileRegister);
				
				logger.log(Level.INFO, String.format(
					"Archivo %s con %d registros no cumple umbral (%d). Debe procesarse por flujo alternativo.",
					file.getName(), validation.getRecordCount(), validation.getThreshold()
				));
				
				// NO mover archivo - queda pendiente para flujo alternativo
				return;
			}
			
			// Continuar con procesamiento normal (Kafka)
			logger.log(Level.INFO, String.format(
				"Archivo %s cumple umbral (%d >= %d). Iniciando procesamiento Kafka",
				file.getName(), validation.getRecordCount(), validation.getThreshold()
			));

			// Determinar tipo de archivo y procesar
			String extension = getFileExtension(file.getName()).toLowerCase();
			List<Map<String, String>> records;

			if ("csv".equals(extension)) {
				records = processCsvFile(file);
			} else if ("txt".equals(extension)) {
				records = processTextFile(file);
			} else if ("xlsx".equals(extension) || "xls".equals(extension)) {
				records = processExcelFile(file);
			} else {
				throw new IllegalArgumentException("Tipo de archivo no soportado: " + extension);
			}

			// Publicar registros en Kafka
			int publishedCount = publishRecords(records, file.getName());

			// Actualizar registro en BD
			fileRegister.setRecordCount(records.size());
			fileRegister.setPublishedCount(publishedCount);
			fileRegister.setProcessEndTime(LocalDateTime.now());
			fileRegister.setStatus("COMPLETED");
			fileRegister = fileRegisterService.save(fileRegister);

			// Publicar evento de archivo Excel procesado
			String fileExtension = getFileExtension(file.getName()).toLowerCase();
			if ("xlsx".equals(fileExtension) || "xls".equals(fileExtension)) {
				publishExcelProcessedEvent(fileRegister);
			}

			// Mover archivo a directorio de procesados
			moveFile(file, processedDirectory, null);

			logger.log(Level.INFO, String.format("Archivo procesado exitosamente: %s (%d registros publicados)", 
				file.getName(), publishedCount));

		} catch (Exception e) {
			logger.log(Level.SEVERE, "Error procesando archivo: " + file.getName(), e);

			fileRegister.setStatus("ERROR");
			fileRegister.setErrorMessage(e.getMessage());
			fileRegister.setProcessEndTime(LocalDateTime.now());
			fileRegisterService.save(fileRegister);

			moveFile(file, errorDirectory, e.getMessage());
		}
	}

	/**
	 * Procesa archivo CSV
	 */
	private List<Map<String, String>> processCsvFile(File file) throws IOException {
		List<Map<String, String>> records = new ArrayList<>();
		
		try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
			String headerLine = reader.readLine();
			if (headerLine == null) {
				return records;
			}
			
			String[] headers = headerLine.split(",");
			String line;
			
			while ((line = reader.readLine()) != null) {
				String[] values = line.split(",");
				Map<String, String> record = new HashMap<>();
				
				for (int i = 0; i < Math.min(headers.length, values.length); i++) {
					record.put(headers[i].trim(), values[i].trim());
				}
				
				records.add(record);
			}
		}

		return records;
	}

	/**
	 * Procesa archivo Excel (.xlsx o .xls)
	 * Utiliza Apache POI con procesamiento streaming para archivos grandes
	 */
	private List<Map<String, String>> processExcelFile(File file) throws IOException {
		List<Map<String, String>> records = new ArrayList<>();
		
		try (FileInputStream fis = new FileInputStream(file)) {
			Workbook workbook;
			
			// Determinar tipo de Excel y crear workbook apropiado
			String extension = getFileExtension(file.getName()).toLowerCase();
			if ("xlsx".equals(extension)) {
				workbook = new XSSFWorkbook(fis);
			} else {
				workbook = new HSSFWorkbook(fis);
			}
			
			try {
				// Procesar primera hoja del libro
				Sheet sheet = workbook.getSheetAt(0);
				if (sheet == null) {
					return records;
				}
				
				// Leer encabezados de la primera fila
				Row headerRow = sheet.getRow(0);
				if (headerRow == null) {
					return records;
				}
				
				List<String> headers = new ArrayList<>();
				for (Cell cell : headerRow) {
					headers.add(getCellValueAsString(cell));
				}
				
				// Procesar filas de datos
				int rowCount = sheet.getPhysicalNumberOfRows();
				for (int i = 1; i < rowCount; i++) {
					Row row = sheet.getRow(i);
					if (row == null) {
						continue;
					}
					
					Map<String, String> record = new HashMap<>();
					for (int j = 0; j < headers.size(); j++) {
						Cell cell = row.getCell(j);
						String value = (cell != null) ? getCellValueAsString(cell) : "";
						record.put(headers.get(j), value);
					}
					
					records.add(record);
					
					// Log progreso cada 1000 registros para archivos grandes
					if (i % 1000 == 0) {
						logger.log(Level.INFO, String.format("Procesados %d registros de %s", i, file.getName()));
					}
				}
				
			} finally {
				workbook.close();
			}
		}
		
		return records;
	}
	
	/**
	 * Convierte el valor de una celda de Excel a String
	 */
	private String getCellValueAsString(Cell cell) {
		if (cell == null) {
			return "";
		}
		
		switch (cell.getCellType()) {
			case STRING:
				return cell.getStringCellValue().trim();
			case NUMERIC:
				if (DateUtil.isCellDateFormatted(cell)) {
					return cell.getDateCellValue().toString();
				} else {
					return String.valueOf(cell.getNumericCellValue());
				}
			case BOOLEAN:
				return String.valueOf(cell.getBooleanCellValue());
			case FORMULA:
				try {
					return String.valueOf(cell.getNumericCellValue());
				} catch (IllegalStateException e) {
					return cell.getStringCellValue().trim();
				}
			case BLANK:
				return "";
			default:
				return "";
		}
	}

	/**
	 * Procesa archivo de texto delimitado por pipes
	 */
	private List<Map<String, String>> processTextFile(File file) throws IOException {
		List<Map<String, String>> records = new ArrayList<>();
		
		try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
			String headerLine = reader.readLine();
			if (headerLine == null) {
				return records;
			}
			
			String[] headers = headerLine.split("\\|");
			String line;
			
			while ((line = reader.readLine()) != null) {
				String[] values = line.split("\\|");
				Map<String, String> record = new HashMap<>();
				
				for (int j = 0; j < Math.min(headers.length, values.length); j++) {
					record.put(headers[j].trim(), values[j].trim());
				}
				
				records.add(record);
			}
		}

		return records;
	}

	/**
	 * Publica registros en Kafka
	 */
	private int publishRecords(List<Map<String, String>> records, String fileName) {
		int publishedCount = 0;

		for (Map<String, String> record : records) {
			try {
				// Agregar metadata del archivo
				record.put("_fileName", fileName);
				record.put("_timestamp", LocalDateTime.now().toString());

				String jsonMessage = gson.toJson(record);
				
				// Log tamaño del mensaje para detectar anomalías
				int messageSize = jsonMessage.getBytes(java.nio.charset.StandardCharsets.UTF_8).length;
				if (messageSize > 1048576) { // > 1 MB
					logger.log(Level.WARNING, String.format(
						"Mensaje grande detectado: %d bytes (%.2f MB) para archivo %s", 
						messageSize, messageSize / 1048576.0, fileName));
				}
				
				messageProducer.publishProcessedRegister(jsonMessage);
				publishedCount++;

			} catch (Exception e) {
				logger.log(Level.WARNING, "Error publicando registro en Kafka", e);
			}
		}

		return publishedCount;
	}

	/**
	 * Mueve archivo a directorio destino
	 */
	private void moveFile(File file, String targetDirectory, String errorSuffix) {
		if (targetDirectory == null || targetDirectory.isEmpty()) {
			logger.log(Level.WARNING, "Directorio destino no configurado");
			return;
		}

		try {
			Path targetPath = Paths.get(targetDirectory);
			if (!Files.exists(targetPath)) {
				Files.createDirectories(targetPath);
			}

			String fileName = file.getName();
			if (errorSuffix != null) {
				int dotIndex = fileName.lastIndexOf('.');
				if (dotIndex > 0) {
					String baseName = fileName.substring(0, dotIndex);
					String extension = fileName.substring(dotIndex + 1);
					fileName = baseName + "_ERROR." + extension;
				} else {
					fileName = fileName + "_ERROR";
				}
			}

			Path destination = targetPath.resolve(fileName);
			Files.move(file.toPath(), destination, StandardCopyOption.REPLACE_EXISTING);

			logger.log(Level.INFO, "Archivo movido a: " + destination);

		} catch (IOException e) {
			logger.log(Level.SEVERE, "Error moviendo archivo: " + file.getName(), e);
		}
	}

	/**
	 * Valida extensiones de archivo permitidas
	 */
	private boolean isValidFileExtension(String fileName) {
		String extension = getFileExtension(fileName).toLowerCase();
		return "csv".equals(extension) || "txt".equals(extension) || 
		       "xlsx".equals(extension) || "xls".equals(extension);
	}

	/**
	 * Obtiene la extensión de un archivo
	 */
	private String getFileExtension(String fileName) {
		int dotIndex = fileName.lastIndexOf('.');
		if (dotIndex > 0 && dotIndex < fileName.length() - 1) {
			return fileName.substring(dotIndex + 1);
		}
		return "";
	}
	
	/**
	 * Publica evento de archivo Excel procesado a Kafka
	 */
	private void publishExcelProcessedEvent(FileRegister fileRegister) {
		try {
			Map<String, Object> event = new HashMap<>();
			event.put("fileName", fileRegister.getFileName());
			event.put("trackingId", fileRegister.getId());
			event.put("status", fileRegister.getStatus());
			event.put("recordCount", fileRegister.getRecordCount());
			event.put("publishedCount", fileRegister.getPublishedCount());
			event.put("processStartTime", fileRegister.getProcessStartTime() != null ? 
				fileRegister.getProcessStartTime().toString() : null);
			event.put("processEndTime", fileRegister.getProcessEndTime() != null ? 
				fileRegister.getProcessEndTime().toString() : null);
			event.put("errorMessage", fileRegister.getErrorMessage());
			
			String jsonEvent = gson.toJson(event);
			messageProducer.publishExcelProcessed(jsonEvent);
			
			logger.log(Level.INFO, "Evento de Excel procesado publicado: " + fileRegister.getFileName());
			
		} catch (Exception e) {
			logger.log(Level.WARNING, "Error publicando evento de Excel procesado", e);
		}
	}

	/**
	 * Valida si el archivo cumple con el umbral para procesamiento Kafka
	 * Cuenta registros eficientemente sin cargar todo el archivo en memoria
	 * 
	 * @param file Archivo a validar
	 * @return RecordCountValidationResponse con decisión de procesamiento
	 * @throws IOException Si hay error leyendo el archivo
	 */
	public RecordCountValidationResponse validateRecordCountThreshold(File file) throws IOException {
		int threshold = Integer.parseInt(
			env.getProperty("file.processing.kafka-threshold", "300")
		);
		
		int recordCount = countRecordsEfficiently(file);
		
		return RecordCountValidationResponse.create(recordCount, threshold);
	}

	/**
	 * Cuenta registros sin cargar el archivo completo en memoria
	 * Optimizado para diferentes tipos de archivo
	 * 
	 * @param file Archivo a contar
	 * @return Número de registros (excluyendo header)
	 * @throws IOException Si hay error leyendo el archivo
	 */
	private int countRecordsEfficiently(File file) throws IOException {
		String extension = getFileExtension(file.getName()).toLowerCase();
		
		switch (extension) {
			case "csv":
			case "txt":
				return countLinesInTextFile(file);
			case "xlsx":
				return countRowsInExcelXlsx(file);
			case "xls":
				return countRowsInExcelXls(file);
			default:
				throw new IllegalArgumentException("Tipo de archivo no soportado: " + extension);
		}
	}

	/**
	 * Cuenta líneas en archivo de texto (CSV/TXT)
	 * No carga el contenido completo en memoria
	 * 
	 * @param file Archivo de texto
	 * @return Número de registros (excluyendo header)
	 * @throws IOException Si hay error leyendo el archivo
	 */
	private int countLinesInTextFile(File file) throws IOException {
		try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
			int count = 0;
			while (reader.readLine() != null) {
				count++;
			}
			// Excluir header (primera línea)
			return Math.max(0, count - 1);
		}
	}

	/**
	 * Cuenta filas en Excel XLSX sin cargar todo en memoria
	 * Usa método eficiente getPhysicalNumberOfRows() que es O(1)
	 * 
	 * @param file Archivo Excel XLSX
	 * @return Número de registros (excluyendo header)
	 * @throws IOException Si hay error leyendo el archivo
	 */
	private int countRowsInExcelXlsx(File file) throws IOException {
		try (FileInputStream fis = new FileInputStream(file);
		     XSSFWorkbook workbook = new XSSFWorkbook(fis)) {
			Sheet sheet = workbook.getSheetAt(0);
			if (sheet == null) {
				return 0;
			}
			// Excluir header (primera fila)
			return Math.max(0, sheet.getPhysicalNumberOfRows() - 1);
		}
	}

	/**
	 * Cuenta filas en Excel XLS
	 * 
	 * @param file Archivo Excel XLS
	 * @return Número de registros (excluyendo header)
	 * @throws IOException Si hay error leyendo el archivo
	 */
	private int countRowsInExcelXls(File file) throws IOException {
		try (FileInputStream fis = new FileInputStream(file);
		     HSSFWorkbook workbook = new HSSFWorkbook(fis)) {
			Sheet sheet = workbook.getSheetAt(0);
			if (sheet == null) {
				return 0;
			}
			// Excluir header (primera fila)
			return Math.max(0, sheet.getPhysicalNumberOfRows() - 1);
		}
	}
}
