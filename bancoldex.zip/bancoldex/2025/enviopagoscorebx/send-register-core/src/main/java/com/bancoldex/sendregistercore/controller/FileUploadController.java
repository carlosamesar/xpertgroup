package com.bancoldex.sendregistercore.controller;

import com.bancoldex.sendregistercore.component.FileProcessingComponent;
import com.bancoldex.sendregistercore.dto.FileStatusResponse;
import com.bancoldex.sendregistercore.dto.FileUploadResponse;
import com.bancoldex.sendregistercore.dto.RecordCountValidationResponse;
import com.bancoldex.sendregistercore.model.FileRegister;
import com.bancoldex.sendregistercore.service.InMemoryFileRegisterService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

/**
 * REST controller for file upload operations
 * Handles asynchronous Excel file uploads for processing
 */
@RestController
@RequestMapping("/api/files")
@Tag(name = "File Upload", description = "Asynchronous file upload and processing APIs")
public class FileUploadController {
	
	private static final Logger logger = Logger.getLogger(FileUploadController.class.getName());
	
	@Autowired
	private Environment env;
	
	@Autowired
	private InMemoryFileRegisterService fileRegisterService;
	
	@Autowired
	private FileProcessingComponent fileProcessingComponent;
	
	/**
	 * Upload Excel file for asynchronous processing
	 * 
	 * @param file Excel file (.xlsx or .xls)
	 * @return FileUploadResponse with tracking ID and status
	 */
	@Operation(
		summary = "Upload file for asynchronous processing",
		description = "Upload Excel (.xlsx, .xls), CSV, or TXT files for async processing. Returns tracking ID immediately (202 Accepted)."
	)
	@ApiResponses(value = {
		@ApiResponse(responseCode = "202", description = "File accepted and queued for processing",
			content = @Content(schema = @Schema(implementation = FileUploadResponse.class))),
		@ApiResponse(responseCode = "400", description = "Invalid file (empty, wrong type, missing name)"),
		@ApiResponse(responseCode = "409", description = "File already processed"),
		@ApiResponse(responseCode = "413", description = "File size exceeds limit"),
		@ApiResponse(responseCode = "500", description = "Server error")
	})
	@PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<?> uploadFile(
		@Parameter(description = "File to upload (.xlsx, .xls, .csv, .txt)", required = true)
		@RequestParam("file") MultipartFile file) {
		
		try {
			// Validate file is not empty
			if (file.isEmpty()) {
				return ResponseEntity.badRequest().body(
					FileUploadResponse.builder()
						.status("ERROR")
						.message("File is empty")
						.build()
				);
			}
			
			// Get original filename
			String fileName = file.getOriginalFilename();
			if (fileName == null || fileName.isEmpty()) {
				return ResponseEntity.badRequest().body(
					FileUploadResponse.builder()
						.status("ERROR")
						.message("File name is missing")
						.build()
				);
			}
			
			// Validate file extension
			if (!isValidFileExtension(fileName)) {
				return ResponseEntity.badRequest().body(
					FileUploadResponse.builder()
						.fileName(fileName)
						.status("ERROR")
						.message("Invalid file type. Only .xlsx, .xls, .csv, and .txt files are allowed")
						.build()
				);
			}
			
			// Validate file size
			String maxSizeStr = env.getProperty("file.upload.max-size-mb", "50");
			long maxSizeBytes = Long.parseLong(maxSizeStr) * 1024 * 1024;
			
			if (file.getSize() > maxSizeBytes) {
				return ResponseEntity.status(HttpStatus.PAYLOAD_TOO_LARGE).body(
					FileUploadResponse.builder()
						.fileName(fileName)
						.fileSize(file.getSize())
						.status("ERROR")
						.message("File size exceeds maximum limit of " + maxSizeStr + " MB")
						.build()
				);
			}
			
			// Check for duplicate file
			if (fileRegisterService.existsByFileNameAndStatus(fileName, "COMPLETED")) {
				return ResponseEntity.status(HttpStatus.CONFLICT).body(
					FileUploadResponse.builder()
						.fileName(fileName)
						.status("ERROR")
						.message("File has already been processed")
						.build()
				);
			}
			
			// Get input directory
			String inputDirectory = env.getProperty("file.processing.input-directory");
			if (inputDirectory == null || inputDirectory.isEmpty()) {
				logger.log(Level.SEVERE, "Input directory not configured");
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(
					FileUploadResponse.builder()
						.status("ERROR")
						.message("Server configuration error")
						.build()
				);
			}
			
			// Create input directory if it doesn't exist
			Path inputPath = Paths.get(inputDirectory);
			if (!Files.exists(inputPath)) {
				Files.createDirectories(inputPath);
			}
			
			// Save file to input directory
			Path filePath = inputPath.resolve(fileName);
			file.transferTo(filePath.toFile());
			
			// Create file register entry
			FileRegister fileRegister = FileRegister.builder()
				.fileName(fileName)
				.filePath(filePath.toString())
				.fileSize(file.getSize())
				.status("PENDING")
				.processStartTime(LocalDateTime.now())
				.build();
			
			fileRegister = fileRegisterService.save(fileRegister);
			
			logger.log(Level.INFO, "File uploaded successfully: " + fileName + " (Tracking ID: " + fileRegister.getId() + ")");
			
			// Return 202 Accepted with tracking information
			return ResponseEntity.accepted().body(
				FileUploadResponse.builder()
					.trackingId(fileRegister.getId())
					.fileName(fileName)
					.fileSize(file.getSize())
					.status("PENDING")
					.message("File uploaded successfully and queued for processing")
					.build()
			);
			
		} catch (IOException e) {
			logger.log(Level.SEVERE, "Error saving uploaded file", e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(
				FileUploadResponse.builder()
					.status("ERROR")
					.message("Error saving file: " + e.getMessage())
					.build()
			);
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Unexpected error during file upload", e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(
				FileUploadResponse.builder()
					.status("ERROR")
					.message("Unexpected error: " + e.getMessage())
					.build()
			);
		}
	}
	
	/**
	 * Get file processing status by tracking ID
	 * 
	 * @param trackingId File register ID
	 * @return FileStatusResponse with processing status
	 */
	@Operation(
		summary = "Query file processing status",
		description = "Retrieve current processing status by tracking ID. Poll this endpoint to monitor progress."
	)
	@ApiResponses(value = {
		@ApiResponse(responseCode = "200", description = "Status retrieved successfully",
			content = @Content(schema = @Schema(implementation = FileStatusResponse.class))),
		@ApiResponse(responseCode = "404", description = "Tracking ID not found"),
		@ApiResponse(responseCode = "500", description = "Server error")
	})
	@GetMapping("/{trackingId}/status")
	public ResponseEntity<?> getFileStatus(
		@Parameter(description = "File tracking ID", required = true)
		@PathVariable Long trackingId) {
		
		try {
			FileRegister fileRegister = fileRegisterService.findById(trackingId).orElse(null);
			
			if (fileRegister == null) {
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(
					FileStatusResponse.builder()
						.trackingId(trackingId)
						.status("NOT_FOUND")
						.errorMessage("No file found with tracking ID: " + trackingId)
						.build()
				);
			}
			
			return ResponseEntity.ok(
				FileStatusResponse.builder()
					.trackingId(fileRegister.getId())
					.fileName(fileRegister.getFileName())
					.status(fileRegister.getStatus())
					.recordCount(fileRegister.getRecordCount())
					.publishedCount(fileRegister.getPublishedCount())
					.processStartTime(fileRegister.getProcessStartTime())
					.processEndTime(fileRegister.getProcessEndTime())
					.errorMessage(fileRegister.getErrorMessage())
					.build()
			);
			
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Error retrieving file status", e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(
				FileStatusResponse.builder()
					.trackingId(trackingId)
					.status("ERROR")
					.errorMessage("Error retrieving status: " + e.getMessage())
					.build()
			);
		}
	}
	
	/**
	 * Validate file extension
	 */
	private boolean isValidFileExtension(String fileName) {
		String extension = getFileExtension(fileName).toLowerCase();
		return "xlsx".equals(extension) || "xls".equals(extension) || 
		       "csv".equals(extension) || "txt".equals(extension);
	}
	
	/**
	 * Get file extension
	 */
	private String getFileExtension(String fileName) {
		int dotIndex = fileName.lastIndexOf('.');
		if (dotIndex > 0 && dotIndex < fileName.length() - 1) {
			return fileName.substring(dotIndex + 1);
		}
		return "";
	}
	
	/**
	 * Validate file record count threshold without full processing
	 * Useful for pre-validation before committing to upload
	 * 
	 * @param file File to validate
	 * @return RecordCountValidationResponse with processing route decision
	 */
	@Operation(
		summary = "Validate file record count threshold",
		description = "Validates if the file meets the record count threshold for Kafka processing. " +
		              "Returns whether file should be processed via Kafka or alternative flow. " +
		              "Useful for pre-upload validation."
	)
	@ApiResponses(value = {
		@ApiResponse(responseCode = "200", description = "Validation completed successfully",
			content = @Content(schema = @Schema(implementation = RecordCountValidationResponse.class))),
		@ApiResponse(responseCode = "400", description = "Invalid file (empty or wrong type)"),
		@ApiResponse(responseCode = "500", description = "Server error during validation")
	})
	@PostMapping(value = "/validate-threshold", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<?> validateThreshold(
		@Parameter(description = "File to validate (.xlsx, .xls, .csv, .txt)", required = true)
		@RequestParam("file") MultipartFile file) {
		
		try {
			// Validate file is not empty
			if (file.isEmpty()) {
				return ResponseEntity.badRequest().body(
					Map.of("error", "File is empty")
				);
			}
			
			// Get original filename
			String fileName = file.getOriginalFilename();
			if (fileName == null || fileName.isEmpty()) {
				return ResponseEntity.badRequest().body(
					Map.of("error", "File name is missing")
				);
			}
			
			// Validate file extension
			if (!isValidFileExtension(fileName)) {
				return ResponseEntity.badRequest().body(
					Map.of("error", "Invalid file type. Only .xlsx, .xls, .csv, and .txt files are allowed")
				);
			}
			
			// Create temporary file for validation
			File tempFile = File.createTempFile("validate_", "_" + fileName);
			
			try {
				// Transfer uploaded file to temp location
				file.transferTo(tempFile);
				
				// Validate threshold using FileProcessingComponent
				RecordCountValidationResponse response = 
					fileProcessingComponent.validateRecordCountThreshold(tempFile);
				
				logger.log(Level.INFO, String.format(
					"Threshold validation for %s: %d records (threshold: %d, route: %s)",
					fileName, response.getRecordCount(), response.getThreshold(), 
					response.getProcessingRoute()
				));
				
				return ResponseEntity.ok(response);
				
			} finally {
				// Clean up temporary file
				if (tempFile.exists()) {
					tempFile.delete();
				}
			}
			
		} catch (IOException e) {
			logger.log(Level.SEVERE, "IO error during threshold validation", e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(
				Map.of("error", "Error reading file: " + e.getMessage())
			);
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Unexpected error during threshold validation", e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(
				Map.of("error", "Validation error: " + e.getMessage())
			);
		}
	}
	
	/**
	 * Health check endpoint for monitoring processing queue status
	 * 
	 * @return System health information
	 */
	@Operation(
		summary = "Health check endpoint",
		description = "Monitor processing queue status, pending files count, and system health"
	)
	@ApiResponses(value = {
		@ApiResponse(responseCode = "200", description = "Health status retrieved successfully"),
		@ApiResponse(responseCode = "500", description = "Server error")
	})
	@GetMapping("/health")
	public ResponseEntity<?> getHealth() {
		try {
			Map<String, Object> health = new HashMap<>();
			
			// Count pending and processing files
			long pendingCount = fileRegisterService.countByStatus("PENDING");
			long processingCount = fileRegisterService.countByStatus("PROCESSING");
			long completedCount = fileRegisterService.countByStatus("COMPLETED");
			long errorCount = fileRegisterService.countByStatus("ERROR");
			
			health.put("status", "UP");
			health.put("pendingFiles", pendingCount);
			health.put("processingFiles", processingCount);
			health.put("completedFiles", completedCount);
			health.put("errorFiles", errorCount);
			health.put("timestamp", LocalDateTime.now().toString());
			
			// Check input directory
			String inputDirectory = env.getProperty("file.processing.input-directory");
			if (inputDirectory != null && !inputDirectory.isEmpty()) {
				Path inputPath = Paths.get(inputDirectory);
				if (Files.exists(inputPath)) {
					long filesInQueue = Files.list(inputPath)
						.filter(Files::isRegularFile)
						.count();
					health.put("filesInInputDirectory", filesInQueue);
					
					// Check disk space
					File inputDir = inputPath.toFile();
					long usableSpaceMB = inputDir.getUsableSpace() / (1024 * 1024);
					health.put("diskSpaceAvailableMB", usableSpaceMB);
				} else {
					health.put("inputDirectoryStatus", "NOT_FOUND");
				}
			}
			
			// Get last processed file
			List<FileRegister> recentFiles = fileRegisterService.findTopByStatusOrderByProcessEndTimeDesc("COMPLETED", 5);
			if (!recentFiles.isEmpty()) {
				FileRegister lastFile = recentFiles.get(0);
				health.put("lastProcessedFile", lastFile.getFileName());
				health.put("lastProcessedTime", lastFile.getProcessEndTime() != null ? 
					lastFile.getProcessEndTime().toString() : null);
			}
			
			return ResponseEntity.ok(health);
			
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Error retrieving health status", e);
			Map<String, Object> errorHealth = new HashMap<>();
			errorHealth.put("status", "DOWN");
			errorHealth.put("error", e.getMessage());
			errorHealth.put("timestamp", LocalDateTime.now().toString());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorHealth);
		}
	}
}
