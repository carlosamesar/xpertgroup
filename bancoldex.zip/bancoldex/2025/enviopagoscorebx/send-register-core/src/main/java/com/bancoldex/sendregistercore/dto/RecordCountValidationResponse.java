package com.bancoldex.sendregistercore.dto;

/**
 * Response DTO para validación de umbral de registros
 * Determina si un archivo debe procesarse por Kafka o flujo alternativo
 */
public class RecordCountValidationResponse {
	
	private int recordCount;
	private int threshold;
	private boolean shouldUseKafka;
	private String message;
	private String processingRoute;

	// Constructor por defecto
	public RecordCountValidationResponse() {
	}

	// Constructor completo
	public RecordCountValidationResponse(int recordCount, int threshold, boolean shouldUseKafka, 
	                                     String message, String processingRoute) {
		this.recordCount = recordCount;
		this.threshold = threshold;
		this.shouldUseKafka = shouldUseKafka;
		this.message = message;
		this.processingRoute = processingRoute;
	}

	/**
	 * Factory method para crear respuesta de validación
	 * 
	 * @param recordCount Cantidad de registros detectados en el archivo
	 * @param threshold Umbral configurado
	 * @return RecordCountValidationResponse con decisión de procesamiento
	 */
	public static RecordCountValidationResponse create(int recordCount, int threshold) {
		boolean shouldUseKafka = recordCount >= threshold;
		String route = shouldUseKafka ? "KAFKA" : "ALTERNATIVE";
		
		String message = String.format(
			"Se detectaron %d registros. Umbral configurado: %d. Procesamiento por flujo: %s",
			recordCount, threshold, route
		);
		
		return new RecordCountValidationResponse(recordCount, threshold, shouldUseKafka, message, route);
	}

	// Getters y Setters
	public int getRecordCount() {
		return recordCount;
	}

	public void setRecordCount(int recordCount) {
		this.recordCount = recordCount;
	}

	public int getThreshold() {
		return threshold;
	}

	public void setThreshold(int threshold) {
		this.threshold = threshold;
	}

	public boolean isShouldUseKafka() {
		return shouldUseKafka;
	}

	public void setShouldUseKafka(boolean shouldUseKafka) {
		this.shouldUseKafka = shouldUseKafka;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getProcessingRoute() {
		return processingRoute;
	}

	public void setProcessingRoute(String processingRoute) {
		this.processingRoute = processingRoute;
	}

	@Override
	public String toString() {
		return "RecordCountValidationResponse{" +
			"recordCount=" + recordCount +
			", threshold=" + threshold +
			", shouldUseKafka=" + shouldUseKafka +
			", message='" + message + '\'' +
			", processingRoute='" + processingRoute + '\'' +
			'}';
	}
}
