package com.bancoldex.sendregistercore.service;

import com.bancoldex.sendregistercore.model.FileRegister;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;

/**
 * In-Memory storage service for FileRegister entities
 * Replaces Oracle Database for Phase 1 (File Upload + Kafka only)
 * Thread-safe implementation using ConcurrentHashMap
 */
@Service
public class InMemoryFileRegisterService {

	private final Map<Long, FileRegister> storage = new ConcurrentHashMap<>();
	private final AtomicLong idGenerator = new AtomicLong(1);

	/**
	 * Save or update a FileRegister
	 */
	public FileRegister save(FileRegister fileRegister) {
		if (fileRegister.getId() == null) {
			// New entity - generate ID
			fileRegister.setId(idGenerator.getAndIncrement());
			fileRegister.setCreatedAt(LocalDateTime.now());
		}
		fileRegister.setUpdatedAt(LocalDateTime.now());
		storage.put(fileRegister.getId(), fileRegister);
		return fileRegister;
	}

	/**
	 * Find FileRegister by ID
	 */
	public Optional<FileRegister> findById(Long id) {
		return Optional.ofNullable(storage.get(id));
	}

	/**
	 * Find FileRegisters by fileName and status
	 */
	public List<FileRegister> findByFileNameAndStatus(String fileName, String status) {
		return storage.values().stream()
			.filter(fr -> fr.getFileName().equals(fileName) && fr.getStatus().equals(status))
			.collect(Collectors.toList());
	}

	/**
	 * Check if FileRegister exists by fileName and status
	 */
	public boolean existsByFileNameAndStatus(String fileName, String status) {
		return storage.values().stream()
			.anyMatch(fr -> fr.getFileName().equals(fileName) && fr.getStatus().equals(status));
	}

	/**
	 * Find FileRegisters by status
	 */
	public List<FileRegister> findByStatus(String status) {
		return storage.values().stream()
			.filter(fr -> fr.getStatus().equals(status))
			.collect(Collectors.toList());
	}

	/**
	 * Count FileRegisters by status
	 */
	public long countByStatus(String status) {
		return storage.values().stream()
			.filter(fr -> fr.getStatus().equals(status))
			.count();
	}

	/**
	 * Find top N FileRegisters by status ordered by processEndTime descending
	 */
	public List<FileRegister> findTopByStatusOrderByProcessEndTimeDesc(String status, int limit) {
		return storage.values().stream()
			.filter(fr -> fr.getStatus().equals(status))
			.filter(fr -> fr.getProcessEndTime() != null)
			.sorted(Comparator.comparing(FileRegister::getProcessEndTime).reversed())
			.limit(limit)
			.collect(Collectors.toList());
	}

	/**
	 * Find top 5 FileRegisters by status ordered by processEndTime descending
	 */
	public List<FileRegister> findTop5ByStatusOrderByProcessEndTimeDesc(String status) {
		return findTopByStatusOrderByProcessEndTimeDesc(status, 5);
	}

	/**
	 * Find all FileRegisters
	 */
	public List<FileRegister> findAll() {
		return new ArrayList<>(storage.values());
	}

	/**
	 * Delete FileRegister by ID
	 */
	public void deleteById(Long id) {
		storage.remove(id);
	}

	/**
	 * Delete all FileRegisters
	 */
	public void deleteAll() {
		storage.clear();
	}

	/**
	 * Get total count
	 */
	public long count() {
		return storage.size();
	}
}
