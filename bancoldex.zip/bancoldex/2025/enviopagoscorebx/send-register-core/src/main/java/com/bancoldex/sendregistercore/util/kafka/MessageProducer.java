package com.bancoldex.sendregistercore.util.kafka;

import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Component;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.logging.Logger;

@Component
public class MessageProducer {

	private static final Logger logger = Logger.getLogger(MessageProducer.class.getName());

	@Autowired
	private KafkaTemplate<String, String> kafkaTemplate;

	@Autowired
	private RetryTemplate kafkaRetryTemplate;

	@Autowired
	private Environment env;

	private final Gson gson = new Gson();

	public void sendMessage(String topic, String message) {
		kafkaTemplate.send(topic, message);
	}

	/**
	 * Publica un mensaje en el tópico de registros procesados
	 * Incluye lógica de reintentos con backoff exponencial
	 * 
	 * @param message JSON del registro procesado
	 */
	public void publishProcessedRegister(String message) {
		publishWithRetry(
			env.getProperty("kafka.topic.processed-register", "RegistrosProcesados"),
			message,
			"registro procesado"
		);
	}

	/**
	 * Publica un mensaje en el tópico de errores
	 * @param message Mensaje original
	 * @param error Descripción del error
	 */
	public void publishToErrorTopic(String message, String error) {
		try {
			String topic = env.getProperty("kafka.topic.error-register", "RegistrosError");
			String errorMessage = String.format("{\"original\":%s,\"error\":\"%s\"}", message, error);
			sendMessage(topic, errorMessage);
			logger.log(Level.INFO, "Mensaje enviado a tópico de errores: " + topic);
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Error crítico publicando en tópico de errores", e);
		}
	}
	
	/**
	 * Publica evento de procesamiento de archivo Excel
	 * @param message JSON con información del archivo procesado
	 */
	public void publishExcelProcessed(String message) {
		publishWithRetry(
			env.getProperty("kafka.topic.excel-processed", "ExcelProcesados"),
			message,
			"evento de Excel procesado"
		);
	}

	/**
	 * Publica mensaje con reintentos automáticos y envío a DLQ en caso de fallo
	 * 
	 * @param topic Tópico de Kafka destino
	 * @param message Mensaje a publicar
	 * @param description Descripción del tipo de mensaje (para logs)
	 */
	private void publishWithRetry(String topic, String message, String description) {
		final AtomicInteger attemptCounter = new AtomicInteger(0);
		
		try {
			kafkaRetryTemplate.execute(
				context -> {
					int attempt = attemptCounter.incrementAndGet();
					logger.log(Level.INFO, String.format(
						"Intento %d de envío a Kafka (%s) - Topic: %s", 
						attempt, description, topic
					));
					
					try {
						// Enviar mensaje a Kafka con timeout
						kafkaTemplate.send(topic, message)
							.get(5, TimeUnit.SECONDS);
						
						logger.log(Level.INFO, String.format(
							"Mensaje enviado exitosamente en intento %d (%s)", 
							attempt, description
						));
						return true;
						
					} catch (Exception e) {
						logger.log(Level.WARNING, String.format(
							"Intento %d fallido para %s: %s", 
							attempt, description, e.getMessage()
						));
						throw new RuntimeException("Fallo en envío a Kafka", e);
					}
				},
				context -> {
					// Recovery callback - enviar a DLQ tras agotar reintentos
					int totalAttempts = attemptCounter.get();
					logger.log(Level.SEVERE, String.format(
						"Falló después de %d intentos (%s). Enviando a Dead Letter Queue", 
						totalAttempts, description
					));
					
					publishToDeadLetterQueue(message, context.getLastThrowable(), totalAttempts);
					return false;
				}
			);
			
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Error en proceso de reintentos para " + description, e);
			publishToDeadLetterQueue(message, e, attemptCounter.get());
		}
	}

	/**
	 * Envía mensaje fallido a Dead Letter Queue con metadata completa
	 * 
	 * @param originalMessage Mensaje original que falló
	 * @param error Excepción que causó el fallo
	 * @param attempts Número de intentos realizados
	 */
	private void publishToDeadLetterQueue(String originalMessage, Throwable error, int attempts) {
		try {
			Map<String, Object> dlqMessage = new HashMap<>();
			dlqMessage.put("originalMessage", originalMessage);
			dlqMessage.put("error", error != null ? error.getMessage() : "Unknown error");
			dlqMessage.put("stackTrace", getStackTraceAsString(error));
			dlqMessage.put("timestamp", LocalDateTime.now().toString());
			dlqMessage.put("attempts", attempts);
			
			String dlqTopic = env.getProperty("kafka.topic.dead-letter", "RegistrosDeadLetter");
			String dlqMessageJson = gson.toJson(dlqMessage);
			
			// Envío directo sin reintentos para evitar recursión
			kafkaTemplate.send(dlqTopic, dlqMessageJson);
			
			logger.log(Level.INFO, String.format(
				"Mensaje enviado a DLQ '%s' después de %d intentos", 
				dlqTopic, attempts
			));
			
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Error crítico: no se pudo enviar a Dead Letter Queue", e);
			// En este punto, el mensaje se pierde - considerar persistencia en filesystem
		}
	}

	/**
	 * Convierte stack trace a String para logging
	 */
	private String getStackTraceAsString(Throwable throwable) {
		if (throwable == null) {
			return "No stack trace available";
		}
		
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		throwable.printStackTrace(pw);
		return sw.toString();
	}
}
