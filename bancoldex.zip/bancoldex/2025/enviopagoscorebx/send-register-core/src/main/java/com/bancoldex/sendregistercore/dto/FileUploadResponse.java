package com.bancoldex.sendregistercore.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Response DTO for file upload operations
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FileUploadResponse {
	
	private Long trackingId;
	private String fileName;
	private Long fileSize;
	private String status;
	private String message;
	
}
