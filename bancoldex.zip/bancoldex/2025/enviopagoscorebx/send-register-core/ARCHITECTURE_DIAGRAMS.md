# Diagramas de Arquitectura - Send Register Core

## 📋 Índice
1. [Diagrama de APIs y Flujo de Datos](#diagrama-de-apis-y-flujo-de-datos)
2. [Diagrama de Componentes C4](#diagrama-de-componentes-c4)
3. [Diagrama de Secuencia - Procesamiento de Archivos](#diagrama-de-secuencia)
4. [Diagrama de Estados](#diagrama-de-estados)

---

## 🔌 Diagrama de APIs y Flujo de Datos

### APIs REST Disponibles

```
┌──────────────────────────────────────────────────────────────────┐
│                     FileUploadController                         │
│                      Base: /api/files                            │
└──────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────┐
│  POST /api/files/upload                                          │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│  Descripción: Carga archivo para procesamiento asíncrono        │
│  Content-Type: multipart/form-data                              │
│  Request:                                                        │
│    - file: MultipartFile (Required)                             │
│      Formatos: .xlsx, .xls, .csv, .txt                         │
│      Tamaño máximo: 50MB (configurable)                        │
│                                                                  │
│  Response: 202 Accepted                                         │
│  {                                                               │
│    "trackingId": 12345,                                         │
│    "fileName": "datos.csv",                                     │
│    "fileSize": 1048576,                                         │
│    "status": "PENDING",                                         │
│    "message": "File uploaded successfully..."                   │
│  }                                                               │
│                                                                  │
│  Errores:                                                        │
│    400 - Archivo vacío, tipo inválido, sin nombre              │
│    409 - Archivo ya procesado                                   │
│    413 - Tamaño excede límite                                   │
│    500 - Error del servidor                                     │
└──────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────┐
│  GET /api/files/{trackingId}/status                             │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│  Descripción: Consulta estado de procesamiento                  │
│  Path Parameter:                                                 │
│    - trackingId: Long (Required)                                │
│                                                                  │
│  Response: 200 OK                                               │
│  {                                                               │
│    "trackingId": 12345,                                         │
│    "fileName": "datos.csv",                                     │
│    "status": "COMPLETED",                                       │
│    "recordCount": 1500,                                         │
│    "publishedCount": 1500,                                      │
│    "processStartTime": "2024-11-27T10:30:00",                  │
│    "processEndTime": "2024-11-27T10:31:45",                    │
│    "errorMessage": null                                         │
│  }                                                               │
│                                                                  │
│  Estados posibles:                                               │
│    - PENDING: En cola para procesamiento                        │
│    - PROCESSING: Procesando registros                           │
│    - COMPLETED: Procesado exitosamente                          │
│    - ERROR: Error durante procesamiento                         │
│    - PENDING_ALTERNATIVE: No cumple umbral Kafka                │
│                                                                  │
│  Errores:                                                        │
│    404 - Tracking ID no encontrado                              │
│    500 - Error del servidor                                     │
└──────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────┐
│  POST /api/files/validate-threshold                             │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│  Descripción: Valida umbral de registros sin procesar           │
│  Content-Type: multipart/form-data                              │
│  Request:                                                        │
│    - file: MultipartFile (Required)                             │
│                                                                  │
│  Response: 200 OK                                               │
│  {                                                               │
│    "recordCount": 1500,                                         │
│    "threshold": 100,                                            │
│    "shouldUseKafka": true,                                      │
│    "processingRoute": "KAFKA",                                  │
│    "message": "File meets threshold..."                         │
│  }                                                               │
│                                                                  │
│  Rutas de procesamiento:                                         │
│    - KAFKA: >= threshold (procesamiento por Kafka)              │
│    - ALTERNATIVE: < threshold (flujo alternativo)               │
│                                                                  │
│  Errores:                                                        │
│    400 - Archivo vacío o tipo inválido                          │
│    500 - Error durante validación                               │
└──────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────┐
│  GET /api/files/health                                          │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│  Descripción: Estado de salud del sistema                       │
│                                                                  │
│  Response: 200 OK                                               │
│  {                                                               │
│    "status": "UP",                                              │
│    "pendingFiles": 5,                                           │
│    "processingFiles": 2,                                        │
│    "completedFiles": 150,                                       │
│    "errorFiles": 3,                                             │
│    "filesInInputDirectory": 5,                                  │
│    "diskSpaceAvailableMB": 102400,                             │
│    "lastProcessedFile": "datos_2024.csv",                      │
│    "lastProcessedTime": "2024-11-27T10:31:45",                 │
│    "timestamp": "2024-11-27T11:00:00"                          │
│  }                                                               │
│                                                                  │
│  Errores:                                                        │
│    500 - Error obteniendo estado (status: "DOWN")              │
└──────────────────────────────────────────────────────────────────┘
```

### Flujo Completo de Procesamiento de Archivos

```
┌─────────────┐
│   Cliente   │
│  (Sistema   │
│  Externo)   │
└──────┬──────┘
       │
       │ 1. POST /api/files/upload
       │    (archivo multipart)
       ▼
┌─────────────────────────────────────────────────────────────┐
│              FileUploadController                           │
│  ┌───────────────────────────────────────────────────────┐  │
│  │ 1.1 Validaciones                                      │  │
│  │     - Archivo no vacío                                │  │
│  │     - Extensión válida (.xlsx, .xls, .csv, .txt)     │  │
│  │     - Tamaño < 50MB                                   │  │
│  │     - No duplicado (ya procesado)                     │  │
│  └───────────────────────────────────────────────────────┘  │
│  ┌───────────────────────────────────────────────────────┐  │
│  │ 1.2 Guardar archivo físico                           │  │
│  │     - Crear INPUT directory si no existe             │  │
│  │     - Copiar archivo: INPUT/nombre.csv               │  │
│  └───────────────────────────────────────────────────────┘  │
│  ┌───────────────────────────────────────────────────────┐  │
│  │ 1.3 Crear registro en memoria                        │  │
│  │     - InMemoryFileRegisterService.save()             │  │
│  │     - Status: PENDING                                │  │
│  │     - Generar trackingId                             │  │
│  └───────────────────────────────────────────────────────┘  │
└──────┬──────────────────────────────────────────────────────┘
       │
       │ 2. Response 202 Accepted
       │    { trackingId: 12345, status: "PENDING" }
       ▼
┌─────────────┐
│   Cliente   │ ◄─────────────────────────────────────────┐
│             │                                            │
│ Polling:    │                                            │
│ GET /status │                                            │
└──────┬──────┘                                            │
       │                                                   │
       │ 3. Polling cada 2-5 segundos                     │
       │    GET /api/files/{trackingId}/status            │
       ▼                                                   │
┌──────────────────────────────────────────────────────┐  │
│      InMemoryFileRegisterService                     │  │
│      (retorna estado actual del archivo)             │  │
└──────────────────────────────────────────────────────┘  │
                                                          │
       ┌──────────────────────────────────────────────────┘
       │
       │ 4. Procesamiento Programado (@Scheduled)
       │    cada 30 segundos
       ▼
┌─────────────────────────────────────────────────────────────┐
│           FileProcessingComponent                           │
│  ┌───────────────────────────────────────────────────────┐  │
│  │ 4.1 Escanear INPUT directory                         │  │
│  │     - Files.walk(inputPath, 1)                       │  │
│  │     - Filtrar extensiones válidas                    │  │
│  └───────────────────────────────────────────────────────┘  │
│  ┌───────────────────────────────────────────────────────┐  │
│  │ 4.2 Validar umbral de registros                     │  │
│  │     - validateRecordCountThreshold()                 │  │
│  │     - Si < threshold: status = PENDING_ALTERNATIVE   │  │
│  │     - Si >= threshold: continuar procesamiento       │  │
│  └───────────────────────────────────────────────────────┘  │
│  ┌───────────────────────────────────────────────────────┐  │
│  │ 4.3 Parsear archivo                                  │  │
│  │     CSV: Apache Commons CSV                          │  │
│  │     - CSVFormat.DEFAULT.withFirstRecordAsHeader()    │  │
│  │     TXT: Pipe-delimited                              │  │
│  │     - Split por "\\|"                                │  │
│  │     Excel: Apache POI                                │  │
│  │     - XSSFWorkbook / HSSFWorkbook                    │  │
│  └───────────────────────────────────────────────────────┘  │
│  ┌───────────────────────────────────────────────────────┐  │
│  │ 4.4 Transformar a JSON                               │  │
│  │     - Cada registro = Map<String, String>            │  │
│  │     - Agregar metadata:                              │  │
│  │       "_fileName", "_timestamp"                      │  │
│  │     - Serializar con Gson                            │  │
│  └───────────────────────────────────────────────────────┘  │
│  ┌───────────────────────────────────────────────────────┐  │
│  │ 4.5 Actualizar contadores                            │  │
│  │     - recordCount                                    │  │
│  │     - publishedCount                                 │  │
│  │     - Status: PROCESSING                             │  │
│  └───────────────────────────────────────────────────────┘  │
└──────┬──────────────────────────────────────────────────────┘
       │
       │ 5. Publicar a Kafka
       ▼
┌─────────────────────────────────────────────────────────────┐
│                  MessageProducer                            │
│  ┌───────────────────────────────────────────────────────┐  │
│  │ publishProcessedRegister(jsonMessage)                │  │
│  │                                                       │  │
│  │ Try:                                                 │  │
│  │   - KafkaTemplate.send(topic, message)              │  │
│  │   - Topic: RegistrosProcesados                      │  │
│  │   - Acks: all, Retries: 3                           │  │
│  │   - Compression: snappy                             │  │
│  │                                                       │  │
│  │ Catch Error:                                         │  │
│  │   - Auto-redirect a RegistrosError                  │  │
│  │   - Agregar error details al mensaje                │  │
│  └───────────────────────────────────────────────────────┘  │
└──────┬──────────────────────────────────────────────────────┘
       │
       │ 6. Kafka Topics
       ▼
┌─────────────────────────────────────────────────────────────┐
│                    Apache Kafka                             │
│  ┌───────────────────────────────┐  ┌──────────────────┐   │
│  │  Topic: RegistrosProcesados   │  │ Topic:           │   │
│  │  (mensajes exitosos)          │  │ RegistrosError   │   │
│  │                               │  │ (mensajes        │   │
│  │  Particiones: configurable    │  │  fallidos)       │   │
│  │  Replication: configurable    │  │                  │   │
│  └───────────────┬───────────────┘  └──────────────────┘   │
└──────────────────┼──────────────────────────────────────────┘
                   │
                   │ 7. Consumidores
                   ▼
┌─────────────────────────────────────────────────────────────┐
│             Sistemas Externos Consumidores                  │
│  - Sistemas Core (T24, AS400)                              │
│  - Sistemas de Análisis                                    │
│  - Otros microservicios                                    │
└─────────────────────────────────────────────────────────────┘

       ┌─────────────────────────────────────┐
       │ 8. Post-procesamiento               │
       ▼                                     │
┌──────────────────────────────────────┐    │
│  FileProcessingComponent             │    │
│  ┌────────────────────────────────┐  │    │
│  │ 8.1 Actualizar FileRegister    │  │    │
│  │     - Status: COMPLETED/ERROR  │  │    │
│  │     - processEndTime           │  │    │
│  │     - errorMessage (si aplica) │  │    │
│  └────────────────────────────────┘  │    │
│  ┌────────────────────────────────┐  │    │
│  │ 8.2 Mover archivo físico       │  │    │
│  │     Éxito:                     │  │    │
│  │       INPUT/ → PROCESSED/      │  │    │
│  │     Error:                     │  │    │
│  │       INPUT/ → ERROR/          │  │    │
│  │       (sufijo _ERROR)          │  │    │
│  └────────────────────────────────┘  │    │
└──────────────────────────────────────┘    │
                                            │
       ┌────────────────────────────────────┘
       │ 9. Cliente consulta estado final
       ▼
┌─────────────┐
│   Cliente   │ GET /api/files/{trackingId}/status
│             │ Response: { status: "COMPLETED" }
└─────────────┘
```

---

## 🏗️ Diagrama de Componentes C4

### Nivel 1: Contexto del Sistema

```
                    ┌──────────────────────────┐
                    │   Sistemas Externos      │
                    │  (Productores de datos)  │
                    └───────────┬──────────────┘
                                │
                                │ Archivos CSV/TXT/Excel
                                │ vía API REST
                                ▼
┌────────────────────────────────────────────────────────────┐
│                                                            │
│              Send Register Core Service                    │
│              (Microservicio Spring Boot)                   │
│                                                            │
│  Procesa archivos de datos y publica mensajes en Kafka   │
│  para integración con sistemas core de Bancoldex          │
│                                                            │
└───────────┬────────────────────────────┬───────────────────┘
            │                            │
            │ Publica mensajes           │ Persiste auditoría
            ▼                            ▼
┌───────────────────────┐    ┌──────────────────────────┐
│   Apache Kafka        │    │   Oracle Database        │
│   (Message Broker)    │    │   (Registro y Auditoría) │
│                       │    │                          │
│ Topics:               │    │ Tables:                  │
│ - RegistrosProcesados │    │ - file_register          │
│ - RegistrosError      │    │ - log_file_register      │
└───────────┬───────────┘    └──────────────────────────┘
            │
            │ Consume mensajes
            ▼
┌───────────────────────────────────────┐
│    Sistemas Consumidores              │
│  - Sistemas Core (T24, AS400)         │
│  - Sistemas de Análisis y Reportería  │
│  - Microservicios de integración      │
└───────────────────────────────────────┘
```

### Nivel 2: Contenedores (Containers)

```
┌─────────────────────────────────────────────────────────────────────────┐
│                    Send Register Core Service                           │
│                      (Spring Boot Application)                          │
│                                                                         │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │                   Presentation Layer                              │ │
│  │  ┌─────────────────────────────────────────────────────────────┐ │ │
│  │  │  FileUploadController (REST API)                            │ │ │
│  │  │  - POST /api/files/upload                                   │ │ │
│  │  │  - GET /api/files/{id}/status                               │ │ │
│  │  │  - POST /api/files/validate-threshold                       │ │ │
│  │  │  - GET /api/files/health                                    │ │ │
│  │  │                                                              │ │ │
│  │  │  Tecnologías:                                                │ │ │
│  │  │  - Spring Web MVC                                            │ │ │
│  │  │  - Spring Validation                                         │ │ │
│  │  │  - Swagger/OpenAPI 3.0                                       │ │ │
│  │  └─────────────────────────────────────────────────────────────┘ │ │
│  └────────────────────────────┬────────────────────────────────────── │ │
│                                │                                        │
│  ┌────────────────────────────▼──────────────────────────────────────┐ │
│  │                   Application Layer                               │ │
│  │  ┌──────────────────────────────────────────────────────────────┐│ │
│  │  │  FileProcessingComponent (@Scheduled)                        ││ │
│  │  │  - processFilesScheduled() [cada 30s]                        ││ │
│  │  │  - processFile()                                             ││ │
│  │  │  - validateRecordCountThreshold()                            ││ │
│  │  │  - processCSVFile()                                          ││ │
│  │  │  - processTXTFile()                                          ││ │
│  │  │  - processExcelFile()                                        ││ │
│  │  │                                                               ││ │
│  │  │  Tecnologías:                                                 ││ │
│  │  │  - Spring @Scheduled                                          ││ │
│  │  │  - Apache Commons CSV                                         ││ │
│  │  │  - Apache POI (Excel)                                         ││ │
│  │  └──────────────────────────────────────────────────────────────┘│ │
│  │  ┌──────────────────────────────────────────────────────────────┐│ │
│  │  │  InMemoryFileRegisterService                                 ││ │
│  │  │  - save()                                                     ││ │
│  │  │  - findById()                                                 ││ │
│  │  │  - findByFileNameAndStatus()                                 ││ │
│  │  │  - existsByFileNameAndStatus()                               ││ │
│  │  │  - countByStatus()                                            ││ │
│  │  │  - findTopByStatusOrderByProcessEndTimeDesc()                ││ │
│  │  │                                                               ││ │
│  │  │  Almacenamiento: ConcurrentHashMap (in-memory)               ││ │
│  │  └──────────────────────────────────────────────────────────────┘│ │
│  └────────────────────────────┬──────────────────────────────────────┘ │
│                                │                                        │
│  ┌────────────────────────────▼──────────────────────────────────────┐ │
│  │                   Infrastructure Layer                            │ │
│  │  ┌──────────────────────────────────────────────────────────────┐│ │
│  │  │  MessageProducer (Kafka Integration)                         ││ │
│  │  │  - publishProcessedRegister()                                ││ │
│  │  │  - publishErrorRegister()                                    ││ │
│  │  │                                                               ││ │
│  │  │  Tecnologías:                                                 ││ │
│  │  │  - Spring Kafka                                               ││ │
│  │  │  - KafkaTemplate                                              ││ │
│  │  │  - Gson (JSON serialization)                                 ││ │
│  │  │                                                               ││ │
│  │  │  Configuración:                                               ││ │
│  │  │  - acks=all, retries=3                                        ││ │
│  │  │  - compression=snappy                                         ││ │
│  │  └──────────────────────────────────────────────────────────────┘│ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │                   Domain Layer                                    │ │
│  │  ┌─────────────────────────────────────────────────────────────┐ │ │
│  │  │  Entities:                                                   │ │ │
│  │  │  - FileRegister (@Entity)                                    │ │ │
│  │  │    * id, fileName, filePath, fileSize                        │ │ │
│  │  │    * status, recordCount, publishedCount                     │ │ │
│  │  │    * processStartTime, processEndTime                        │ │ │
│  │  │    * errorMessage, createdAt                                 │ │ │
│  │  │                                                               │ │ │
│  │  │  DTOs:                                                        │ │ │
│  │  │  - FileUploadResponse                                        │ │ │
│  │  │  - FileStatusResponse                                        │ │ │
│  │  │  - RecordCountValidationResponse                             │ │ │
│  │  │                                                               │ │ │
│  │  │  Tecnologías: Lombok (@Data, @Builder)                       │ │ │
│  │  └─────────────────────────────────────────────────────────────┘ │ │
│  └───────────────────────────────────────────────────────────────────┘ │
│                                                                         │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │                   Configuration Layer                             │ │
│  │  - SwaggerConfig (OpenAPI 3.0)                                   │ │
│  │  - KafkaProducerConfig                                           │ │
│  │  - Environment Properties (application.properties)               │ │
│  └───────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────┘
         │                                        │
         │ Kafka Messages                         │ In-Memory Storage
         │ (JSON over TCP)                        │ (ConcurrentHashMap)
         ▼                                        ▼
┌──────────────────────┐              ┌──────────────────────────┐
│   Apache Kafka       │              │   Almacenamiento         │
│   Cluster            │              │   en Memoria             │
│                      │              │                          │
│ Topics:              │              │ - Tracking de archivos   │
│ - RegistrosProcesados│              │ - Estado de procesamiento│
│ - RegistrosError     │              │ - Contadores y métricas  │
│                      │              │                          │
│ Bootstrap Servers:   │              │ Nota: Sin persistencia   │
│ kafka:9092           │              │ en base de datos         │
└──────────────────────┘              └──────────────────────────┘
```

### Nivel 3: Componentes (Components)

```
┌─────────────────────────────────────────────────────────────────────┐
│                   FileUploadController Component                    │
│                                                                     │
│  Responsabilidades:                                                 │
│  - Validar archivos cargados (extensión, tamaño, duplicados)       │
│  - Guardar archivos en directorio INPUT                            │
│  - Crear registros de seguimiento (FileRegister)                   │
│  - Exponer endpoints de consulta de estado                         │
│  - Endpoint de health check                                        │
│                                                                     │
│  Dependencias:                                                      │
│  ├─ Environment (configuración)                                    │
│  ├─ InMemoryFileRegisterService (gestión de registros)            │
│  └─ FileProcessingComponent (validación de umbrales)               │
│                                                                     │
│  Endpoints:                                                         │
│  ├─ POST /api/files/upload                                         │
│  │   Input: MultipartFile                                          │
│  │   Output: FileUploadResponse (202 Accepted)                     │
│  │   Validaciones: tamaño, extensión, duplicados                   │
│  │                                                                  │
│  ├─ GET /api/files/{trackingId}/status                             │
│  │   Input: Long trackingId                                        │
│  │   Output: FileStatusResponse (200 OK)                           │
│  │   Estados: PENDING, PROCESSING, COMPLETED, ERROR                │
│  │                                                                  │
│  ├─ POST /api/files/validate-threshold                             │
│  │   Input: MultipartFile                                          │
│  │   Output: RecordCountValidationResponse (200 OK)                │
│  │   Decisión: KAFKA vs ALTERNATIVE route                          │
│  │                                                                  │
│  └─ GET /api/files/health                                          │
│      Output: Map<String, Object> con métricas del sistema          │
│                                                                     │
│  Tecnologías:                                                       │
│  - @RestController, @RequestMapping                                │
│  - @Operation, @ApiResponses (Swagger)                             │
│  - java.util.logging.Logger                                        │
└─────────────────────────────────────────────────────────────────────┘
                              │
                              │ delegates processing
                              ▼
┌─────────────────────────────────────────────────────────────────────┐
│               FileProcessingComponent Component                     │
│                                                                     │
│  Responsabilidades:                                                 │
│  - Escanear directorio INPUT cada 30 segundos (@Scheduled)         │
│  - Validar umbral de registros antes de procesar                   │
│  - Parsear archivos CSV, TXT y Excel                               │
│  - Transformar registros a JSON                                    │
│  - Publicar mensajes en Kafka                                      │
│  - Actualizar estado de FileRegister                               │
│  - Mover archivos a PROCESSED o ERROR                              │
│                                                                     │
│  Dependencias:                                                      │
│  ├─ Environment (directorios, umbrales)                            │
│  ├─ MessageProducer (publicación Kafka)                            │
│  ├─ InMemoryFileRegisterService (gestión de estado)               │
│  └─ Gson (serialización JSON)                                      │
│                                                                     │
│  Métodos principales:                                               │
│  ├─ processFilesScheduled()                                        │
│  │   Trigger: @Scheduled(fixedDelay=30000, initialDelay=10000)    │
│  │   Acción: Procesa todos los archivos pendientes                │
│  │                                                                  │
│  ├─ processFile(File)                                              │
│  │   1. Buscar/crear FileRegister                                  │
│  │   2. Validar no duplicado                                       │
│  │   3. Validar umbral de registros                                │
│  │   4. Parsear según extensión                                    │
│  │   5. Publicar registros en Kafka                                │
│  │   6. Actualizar estado y mover archivo                          │
│  │                                                                  │
│  ├─ validateRecordCountThreshold(File)                             │
│  │   Input: File                                                   │
│  │   Output: RecordCountValidationResponse                         │
│  │   Decisión: >= threshold → KAFKA, < threshold → ALTERNATIVE     │
│  │                                                                  │
│  ├─ processCSVFile(File)                                           │
│  │   Parser: Apache Commons CSV                                    │
│  │   Format: CSVFormat.DEFAULT.withFirstRecordAsHeader()          │
│  │   Output: List<Map<String, String>>                             │
│  │                                                                  │
│  ├─ processTXTFile(File)                                           │
│  │   Parser: BufferedReader + String.split("\\|")                 │
│  │   Delimiter: Pipe (|)                                           │
│  │   Output: List<Map<String, String>>                             │
│  │                                                                  │
│  └─ processExcelFile(File)                                         │
│      Parser: Apache POI (XSSFWorkbook/HSSFWorkbook)               │
│      Format: Primera fila = headers                                │
│      Output: List<Map<String, String>>                             │
│                                                                     │
│  Configuración de umbrales:                                         │
│  - kafka.producer.record-count-threshold (default: 100)            │
│  - Archivos < threshold → PENDING_ALTERNATIVE                      │
│  - Archivos >= threshold → Procesamiento normal Kafka              │
│                                                                     │
│  Gestión de errores:                                                │
│  - Try/catch por archivo (no afecta otros)                         │
│  - Mover a ERROR/ con sufijo _ERROR                                │
│  - Status = ERROR en FileRegister                                  │
│  - errorMessage guardado para diagnóstico                          │
│                                                                     │
│  Tecnologías:                                                       │
│  - @Component, @Scheduled                                          │
│  - Apache Commons CSV                                              │
│  - Apache POI (poi, poi-ooxml)                                     │
│  - java.nio.file (Files, Path, StandardCopyOption)                │
└─────────────────────────────────────────────────────────────────────┘
                              │
                              │ publishes messages
                              ▼
┌─────────────────────────────────────────────────────────────────────┐
│                   MessageProducer Component                         │
│                                                                     │
│  Responsabilidades:                                                 │
│  - Publicar mensajes JSON en tópicos Kafka                         │
│  - Manejar errores de publicación                                  │
│  - Auto-redirect a topic de error en caso de fallo                 │
│  - Agregar metadata a mensajes (_fileName, _timestamp)             │
│                                                                     │
│  Dependencias:                                                      │
│  ├─ KafkaTemplate<String, String>                                  │
│  ├─ Environment (nombres de topics)                                │
│  └─ Gson (serialización)                                           │
│                                                                     │
│  Métodos principales:                                               │
│  ├─ publishProcessedRegister(String jsonMessage)                   │
│  │   Topic: kafka.topic.processed-register (RegistrosProcesados)  │
│  │   Retry: 3 intentos automáticos                                │
│  │   Acks: all (espera confirmación de todas las réplicas)        │
│  │   Compression: snappy                                           │
│  │   Error handling: Auto-redirect a publishErrorRegister()       │
│  │                                                                  │
│  └─ publishErrorRegister(String jsonMessage, String error)         │
│      Topic: kafka.topic.error-register (RegistrosError)            │
│      Enriquece mensaje con información de error                    │
│      Timestamp: ISO-8601 format                                    │
│                                                                     │
│  Formato de mensaje publicado:                                     │
│  {                                                                  │
│    "campo1": "valor1",                                             │
│    "campo2": "valor2",                                             │
│    ...                                                              │
│    "_fileName": "datos.csv",                                       │
│    "_timestamp": "2024-11-27T10:30:45.123"                         │
│  }                                                                  │
│                                                                     │
│  Configuración Kafka Producer:                                     │
│  - bootstrap.servers: kafka:9092                                   │
│  - key.serializer: StringSerializer                                │
│  - value.serializer: StringSerializer                              │
│  - acks: all                                                       │
│  - retries: 3                                                      │
│  - compression.type: snappy                                        │
│  - max.in.flight.requests.per.connection: 5                        │
│  - enable.idempotence: true                                        │
│                                                                     │
│  Tecnologías:                                                       │
│  - @Component                                                      │
│  - Spring Kafka (KafkaTemplate)                                    │
│  - Gson                                                            │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│              InMemoryFileRegisterService Component                  │
│                                                                     │
│  Responsabilidades:                                                 │
│  - Gestionar registros de archivos en memoria                      │
│  - Proveer operaciones CRUD thread-safe                            │
│  - Generar IDs únicos secuenciales                                 │
│  - Consultas por estado y nombre de archivo                        │
│                                                                     │
│  Almacenamiento:                                                    │
│  - ConcurrentHashMap<Long, FileRegister>                           │
│  - AtomicLong para generación de IDs                               │
│  - Thread-safe para procesamiento concurrente                      │
│                                                                     │
│  Métodos principales:                                               │
│  ├─ save(FileRegister)                                             │
│  │   Asigna ID si es nuevo, actualiza si existe                    │
│  │   Return: FileRegister con ID asignado                          │
│  │                                                                  │
│  ├─ findById(Long)                                                 │
│  │   Return: Optional<FileRegister>                                │
│  │                                                                  │
│  ├─ findByFileNameAndStatus(String, String)                        │
│  │   Busca por nombre exacto y estado                              │
│  │   Return: List<FileRegister>                                    │
│  │                                                                  │
│  ├─ existsByFileNameAndStatus(String, String)                      │
│  │   Validación de duplicados                                      │
│  │   Return: boolean                                               │
│  │                                                                  │
│  ├─ countByStatus(String)                                          │
│  │   Conteo para métricas de health                                │
│  │   Return: long                                                  │
│  │                                                                  │
│  └─ findTopByStatusOrderByProcessEndTimeDesc(String, int)          │
│      Últimos N archivos por estado                                 │
│      Return: List<FileRegister>                                    │
│                                                                     │
│  Nota importante:                                                   │
│  - NO persiste en base de datos                                    │
│  - Datos se pierden al reiniciar la aplicación                     │
│  - Diseñado para procesamiento efímero                             │
│  - Ideal para tracking de procesamiento en tiempo real             │
│                                                                     │
│  Tecnologías:                                                       │
│  - @Service                                                        │
│  - java.util.concurrent.ConcurrentHashMap                          │
│  - java.util.concurrent.atomic.AtomicLong                          │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 🔄 Diagrama de Secuencia - Procesamiento de Archivos

### Secuencia 1: Upload de Archivo

```
Cliente         Controller      Service              FileSystem      Kafka
  │                 │              │                     │             │
  │  POST /upload   │              │                     │             │
  ├────────────────>│              │                     │             │
  │                 │              │                     │             │
  │                 │ Validar      │                     │             │
  │                 │ (extensión,  │                     │             │
  │                 │  tamaño,     │                     │             │
  │                 │  duplicado)  │                     │             │
  │                 │              │                     │             │
  │                 │              │ Guardar archivo     │             │
  │                 │              ├────────────────────>│             │
  │                 │              │ INPUT/file.csv      │             │
  │                 │              │<────────────────────┤             │
  │                 │              │                     │             │
  │                 │ save()       │                     │             │
  │                 ├─────────────>│                     │             │
  │                 │ FileRegister │                     │             │
  │                 │ status=PENDING                     │             │
  │                 │ trackingId=123                     │             │
  │                 │<─────────────┤                     │             │
  │                 │              │                     │             │
  │  202 Accepted   │              │                     │             │
  │  trackingId=123 │              │                     │             │
  │<────────────────┤              │                     │             │
  │                 │              │                     │             │
```

### Secuencia 2: Procesamiento Programado

```
@Scheduled      Component        Service         MessageProducer    Kafka
  │                 │              │                     │             │
  │ [30 segundos]   │              │                     │             │
  ├────────────────>│              │                     │             │
  │                 │              │                     │             │
  │                 │ Escanear     │                     │             │
  │                 │ INPUT/       │                     │             │
  │                 │              │                     │             │
  │                 │ findById()   │                     │             │
  │                 ├─────────────>│                     │             │
  │                 │<─────────────┤                     │             │
  │                 │ FileRegister │                     │             │
  │                 │              │                     │             │
  │                 │ Validar      │                     │             │
  │                 │ umbral       │                     │             │
  │                 │ (100 reg)    │                     │             │
  │                 │              │                     │             │
  │                 │ Parsear CSV  │                     │             │
  │                 │ (Apache      │                     │             │
  │                 │  Commons)    │                     │             │
  │                 │              │                     │             │
  │                 │ Loop: Para cada registro           │             │
  │                 │ ┌─────────────────────────────────┐│             │
  │                 │ │Transformar a JSON               ││             │
  │                 │ │+ metadata                       ││             │
  │                 │ └─────────────────────────────────┘│             │
  │                 │              │                     │             │
  │                 │              │ publish()           │             │
  │                 │              ├────────────────────>│             │
  │                 │              │ jsonMessage         │             │
  │                 │              │                     │             │
  │                 │              │                     │ send()      │
  │                 │              │                     ├────────────>│
  │                 │              │                     │ Topic:      │
  │                 │              │                     │ Registros   │
  │                 │              │                     │ Procesados  │
  │                 │              │                     │<────────────┤
  │                 │              │                     │ ack         │
  │                 │              │<────────────────────┤             │
  │                 │              │                     │             │
  │                 │ save()       │                     │             │
  │                 │ status=      │                     │             │
  │                 │ COMPLETED    │                     │             │
  │                 ├─────────────>│                     │             │
  │                 │<─────────────┤                     │             │
  │                 │              │                     │             │
  │                 │ Mover archivo│                     │             │
  │                 │ INPUT/ →     │                     │             │
  │                 │ PROCESSED/   │                     │             │
  │                 │              │                     │             │
```

### Secuencia 3: Consulta de Estado (Polling)

```
Cliente         Controller      Service
  │                 │              │
  │                 │              │
  │ GET /status/123 │              │
  ├────────────────>│              │
  │                 │              │
  │                 │ findById(123)│
  │                 ├─────────────>│
  │                 │              │
  │                 │<─────────────┤
  │                 │ FileRegister │
  │                 │ (status,     │
  │                 │  counts,     │
  │                 │  timestamps) │
  │                 │              │
  │  200 OK         │              │
  │  FileStatusResp │              │
  │<────────────────┤              │
  │                 │              │
  │                 │              │
  │ [espera 2-5s]   │              │
  │                 │              │
  │ GET /status/123 │              │
  ├────────────────>│              │
  │                 │ ...          │
  │                 │              │
  │  (repite hasta  │              │
  │   COMPLETED     │              │
  │   o ERROR)      │              │
```

### Secuencia 4: Manejo de Errores

```
Component        MessageProducer    Kafka(OK)    Kafka(Error)
  │                     │              │              │
  │ publish()           │              │              │
  ├────────────────────>│              │              │
  │                     │              │              │
  │                     │ send()       │              │
  │                     ├─────────────>│              │
  │                     │              │              │
  │                     │  X ERROR     │              │
  │                     │<─────────────┤              │
  │                     │ (timeout/    │              │
  │                     │  connection) │              │
  │                     │              │              │
  │                     │ [Auto-retry 3x]             │
  │                     │              │              │
  │                     │  X FAILED    │              │
  │                     │              │              │
  │                     │ publish      │              │
  │                     │ ErrorReg()   │              │
  │                     │              │              │
  │                     │ send()       │              │
  │                     ├──────────────┼─────────────>│
  │                     │              │ Topic:       │
  │                     │              │ Registros    │
  │                     │              │ Error        │
  │                     │<─────────────┼──────────────┤
  │                     │              │  ack         │
  │<────────────────────┤              │              │
  │ error logged        │              │              │
  │                     │              │              │
  │ save()              │              │              │
  │ status=ERROR        │              │              │
  │ errorMessage=...    │              │              │
  │                     │              │              │
  │ Mover archivo       │              │              │
  │ INPUT/ →            │              │              │
  │ ERROR/file_ERROR    │              │              │
```

---

## 📊 Diagrama de Estados

### Estados de FileRegister

```
                    ┌─────────────────┐
                    │    INITIAL      │
                    │   (no existe)   │
                    └────────┬────────┘
                             │
                             │ POST /upload
                             │ o archivo copiado a INPUT/
                             ▼
                    ┌─────────────────┐
                    │    PENDING      │◄──────────────┐
                    │                 │               │
                    │ En cola para    │               │
                    │ procesamiento   │               │
                    └────────┬────────┘               │
                             │                        │
                             │ @Scheduled task        │
                             │ (cada 30s)             │
                             ▼                        │
                    ┌─────────────────┐               │
                    │   PROCESSING    │               │
                    │                 │               │
                    │ Parseando y     │               │
                    │ publicando      │               │
                    └────────┬────────┘               │
                             │                        │
                ┌────────────┼────────────┐           │
                │            │            │           │
                │ Umbral     │ Umbral     │ Error     │
                │ no cumple  │ cumple     │           │
                │            │            │           │
                ▼            ▼            ▼           │
     ┌──────────────┐  ┌──────────┐  ┌────────┐     │
     │  PENDING_    │  │COMPLETED │  │ ERROR  │     │
     │ ALTERNATIVE  │  │          │  │        │     │
     │              │  │Procesado │  │Falló   │     │
     │< threshold   │  │exitosa-  │  │proceso │     │
     │registros     │  │mente     │  │        │     │
     │              │  │          │  │        │     │
     │Requiere flujo│  │Archivo en│  │Archivo │     │
     │alternativo   │  │PROCESSED/│  │en      │     │
     │              │  │          │  │ERROR/  │     │
     └──────┬───────┘  └──────────┘  └────────┘     │
            │                                        │
            │ Procesamiento manual                   │
            │ o flujo alternativo                    │
            └────────────────────────────────────────┘

Estados y Transiciones:

1. PENDING → PROCESSING
   - Trigger: @Scheduled task detecta archivo
   - Validación: No duplicado, archivo válido
   
2. PROCESSING → COMPLETED
   - Condición: Todos los registros publicados exitosamente
   - Acción: Mover a PROCESSED/, actualizar contadores
   
3. PROCESSING → ERROR
   - Condición: Error en parsing o publicación Kafka
   - Acción: Mover a ERROR/, guardar errorMessage
   
4. PROCESSING → PENDING_ALTERNATIVE
   - Condición: recordCount < threshold (default 100)
   - Acción: Dejar archivo en INPUT/, no procesar por Kafka
   
5. PENDING_ALTERNATIVE → PENDING
   - Condición: Corrección manual o cambio de umbral
   - Acción: Reprocesar cuando sea adecuado

Estados Finales:
- COMPLETED: Procesamiento exitoso
- ERROR: Requiere intervención manual
- PENDING_ALTERNATIVE: Requiere flujo alternativo
```

### Flujo de Archivos en FileSystem

```
                    ┌───────────────────────────┐
                    │     File Uploaded         │
                    │  (POST /upload o copia)   │
                    └─────────────┬─────────────┘
                                  │
                                  ▼
                    ┌───────────────────────────┐
                    │   INPUT Directory         │
                    │   - datos.csv             │
                    │   - registros.txt         │
                    │   - archivo.xlsx          │
                    └─────────────┬─────────────┘
                                  │
                                  │ @Scheduled
                                  │ processing
                                  ▼
                    ┌───────────────────────────┐
                    │   File Processing         │
                    │   - Parse                 │
                    │   - Transform             │
                    │   - Publish to Kafka      │
                    └─────────────┬─────────────┘
                                  │
                    ┌─────────────┼─────────────┐
                    │             │             │
                    │ Success     │ Error       │
                    ▼             ▼             │
         ┌──────────────┐  ┌─────────────┐    │
         │  PROCESSED   │  │   ERROR     │    │
         │  Directory   │  │  Directory  │    │
         │              │  │             │    │
         │ datos.csv    │  │ archivo_    │    │
         │              │  │ ERROR.xlsx  │    │
         │ (original    │  │             │    │
         │  name)       │  │ (con sufijo)│    │
         └──────────────┘  └─────────────┘    │
                                               │
         ┌─────────────────────────────────────┘
         │ Threshold not met
         │
         │ ┌──────────────────────────┐
         └─┤  INPUT Directory         │
           │  (file remains)          │
           │  Status: PENDING_        │
           │  ALTERNATIVE             │
           └──────────────────────────┘
```

---

## 🔍 Notas Adicionales

### Características Clave

1. **Procesamiento Asíncrono**
   - Upload retorna inmediatamente (202 Accepted)
   - Procesamiento en background vía @Scheduled
   - Cliente consulta estado mediante polling

2. **Validación de Umbrales**
   - Umbral configurable (default: 100 registros)
   - Archivos pequeños → Flujo alternativo
   - Archivos grandes → Procesamiento Kafka

3. **Almacenamiento en Memoria**
   - No persistencia en base de datos
   - ConcurrentHashMap para thread-safety
   - Datos se pierden al reiniciar

4. **Gestión de Errores**
   - Auto-retry en Kafka (3 intentos)
   - Redirect a topic de error
   - Archivos movidos a ERROR/

5. **Monitoreo**
   - Endpoint /health con métricas
   - Contadores por estado
   - Espacio en disco
   - Último archivo procesado

### Formatos Soportados

| Formato | Parser | Delimiter | Primera Línea |
|---------|--------|-----------|---------------|
| CSV | Apache Commons CSV | Coma (,) | Headers |
| TXT | BufferedReader | Pipe (\|) | Headers |
| Excel | Apache POI | N/A | Headers |

### Configuración Kafka

- **Acks**: all (máxima durabilidad)
- **Retries**: 3
- **Compression**: snappy
- **Idempotence**: true
- **Topics**: RegistrosProcesados, RegistrosError

### Límites y Restricciones

- Tamaño máximo archivo: 50MB (configurable)
- Extensiones permitidas: .xlsx, .xls, .csv, .txt
- Umbral mínimo registros: 100 (configurable)
- Intervalo procesamiento: 30 segundos
- Inicialización: 10 segundos

---

**Generado**: 2024-11-27  
**Versión**: 1.0  
**Microservicio**: Send Register Core 0.0.1-SNAPSHOT
