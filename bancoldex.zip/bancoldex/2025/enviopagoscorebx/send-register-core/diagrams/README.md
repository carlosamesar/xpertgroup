# Guía de Importación de Diagramas en Lucidchart

## 📁 Archivos Disponibles

Este directorio contiene 10 diagramas en formato PlantUML (.puml) listos para importar en Lucidchart:

### Diagramas C4 Model
1. **01-contexto-c4.puml** - Vista de contexto del sistema completo
2. **02-contenedores-c4.puml** - Arquitectura de contenedores de la aplicación
3. **03-componentes-c4.puml** - Detalle de componentes internos

### Diagramas de Secuencia
4. **04-secuencia-upload.puml** - Flujo de carga de archivo
5. **05-secuencia-procesamiento.puml** - Procesamiento programado (@Scheduled)
6. **06-secuencia-polling.puml** - Consulta de estado por polling
7. **07-secuencia-errores.puml** - Manejo de errores con Kafka

### Diagramas de Comportamiento
8. **08-estados.puml** - Máquina de estados de FileRegister
9. **09-flujo-archivos.puml** - Flujo de movimiento de archivos
10. **10-api-rest.puml** - Documentación de APIs REST

---

## 🚀 Cómo Importar en Lucidchart

### Método 1: Importación Directa (Recomendado)

1. **Abrir Lucidchart**
   - Ve a https://lucid.app/
   - Inicia sesión en tu cuenta

2. **Importar Archivo**
   - Haz clic en "**+ New**" → "**Import**"
   - O desde un documento abierto: "**File**" → "**Import**" → "**PlantUML**"

3. **Seleccionar Archivo**
   - Navega a la carpeta `diagrams/`
   - Selecciona el archivo `.puml` que deseas importar
   - O arrastra y suelta el archivo en Lucidchart

4. **Configurar Importación**
   - Lucidchart procesará el código PlantUML automáticamente
   - El diagrama se generará en el canvas

5. **Personalizar**
   - Ajusta colores según tu paleta corporativa
   - Modifica tamaños y posiciones
   - Agrega logos de tecnologías (Spring Boot, Kafka, Oracle)

### Método 2: Copiar y Pegar Código

Si la importación directa no funciona:

1. **Abrir Archivo**
   - Abre el archivo `.puml` en un editor de texto
   - Copia todo el contenido

2. **Usar PlantUML Online**
   - Ve a: https://www.plantuml.com/plantuml/uml/
   - Pega el código en el editor
   - Genera la imagen

3. **Exportar Imagen**
   - Descarga el diagrama como PNG/SVG
   - Importa la imagen en Lucidchart

### Método 3: VS Code Extension (Para Desarrolladores)

1. **Instalar Extension**
   ```bash
   code --install-extension jebbs.plantuml
   ```

2. **Previsualizar**
   - Abre cualquier archivo `.puml` en VS Code
   - Presiona `Alt+D` para previsualizar
   - Exporta como PNG/SVG

3. **Importar a Lucidchart**
   - Usa la imagen exportada

---

## 🎨 Personalización Post-Importación

### Paleta de Colores Sugerida

```
Azul (#4A90E2)      → Controladores y APIs
Verde (#7ED321)     → Procesamiento y lógica
Naranja (#F5A623)   → Servicios y almacenamiento
Púrpura (#BD10E0)   → Integración externa (Kafka)
Gris (#4A4A4A)      → Base de datos
Rojo (#D0021B)      → Estados de error
Cyan (#50E3C2)      → Estados completados
```

### Mejores Prácticas

1. **Layout Automático**
   - Usa "Auto Layout" después de importar
   - Alinea elementos manualmente si es necesario

2. **Agrupación**
   - Agrupa componentes relacionados en contenedores
   - Usa swimlanes para separar capas (Presentation, Application, Infrastructure)

3. **Iconografía**
   - Agrega íconos de Spring Boot, Kafka, Oracle desde biblioteca de Lucidchart
   - Usa colores consistentes para tipos de componentes

4. **Flechas**
   - Línea sólida → Comunicación síncrona
   - Línea punteada → Comunicación asíncrona
   - Flecha gruesa → Flujo principal de datos

5. **Exportación**
   - Exporta en alta resolución (300 DPI) para documentación
   - Formatos recomendados: PNG, PDF, SVG

---

## 🔧 Solución de Problemas

### Error: "PlantUML Import Not Available"

**Solución 1:** Verifica tu plan de Lucidchart
- La importación de PlantUML requiere Lucidchart Professional o superior
- Prueba con la versión trial gratuita

**Solución 2:** Usa el servidor PlantUML online
1. Ve a https://www.plantuml.com/plantuml/uml/
2. Pega el código del archivo `.puml`
3. Descarga la imagen generada
4. Importa la imagen en Lucidchart

### Error: "Syntax Error" al Importar

**Causa:** Algunos símbolos especiales pueden causar problemas
**Solución:** 
- Abre el archivo `.puml` y verifica que no tenga caracteres especiales
- Usa el servidor PlantUML online para validar el código primero

### Diagrama se ve desorganizado

**Solución:**
1. Selecciona todos los elementos (Ctrl+A)
2. Haz clic en "Auto Layout" en el menú superior
3. Selecciona el estilo de layout (Top-Down, Left-Right, etc.)
4. Ajusta manualmente los elementos que lo necesiten

---

## 📊 Descripción de cada Diagrama

### 01-contexto-c4.puml
**Propósito:** Vista de alto nivel del sistema  
**Muestra:** Actores externos, sistema principal, Kafka, Oracle  
**Usar para:** Presentaciones ejecutivas, documentación de arquitectura

### 02-contenedores-c4.puml
**Propósito:** Arquitectura de contenedores internos  
**Muestra:** REST API, File Processor, Services, Kafka Producer  
**Usar para:** Diseño técnico, onboarding de desarrolladores

### 03-componentes-c4.puml
**Propósito:** Detalle de componentes y sus interacciones  
**Muestra:** Controllers, Services, Parsers, MessageProducer  
**Usar para:** Documentación técnica detallada, code reviews

### 04-secuencia-upload.puml
**Propósito:** Flujo de carga de archivo vía API REST  
**Muestra:** Validaciones, guardado en INPUT, creación de registro  
**Usar para:** Documentación de API, troubleshooting de errores de upload

### 05-secuencia-procesamiento.puml
**Propósito:** Proceso completo de procesamiento programado  
**Muestra:** @Scheduled task, parsing, publicación a Kafka  
**Usar para:** Entender el flujo completo, debugging de procesamiento

### 06-secuencia-polling.puml
**Propósito:** Consulta de estado mediante polling  
**Muestra:** Cliente consultando estado repetidamente  
**Usar para:** Documentación de cliente, implementación de polling

### 07-secuencia-errores.puml
**Propósito:** Manejo de errores y reintentos  
**Muestra:** Retry de Kafka, redirect a topic de error  
**Usar para:** Troubleshooting, configuración de reintentos

### 08-estados.puml
**Propósito:** Máquina de estados de FileRegister  
**Muestra:** PENDING → PROCESSING → COMPLETED/ERROR/PENDING_ALTERNATIVE  
**Usar para:** Entender ciclo de vida de archivos, validaciones de estado

### 09-flujo-archivos.puml
**Propósito:** Movimiento de archivos en file system  
**Muestra:** INPUT → PROCESSED/ERROR según resultado  
**Usar para:** Operaciones, troubleshooting de archivos perdidos

### 10-api-rest.puml
**Propósito:** Documentación completa de endpoints REST  
**Muestra:** Request/Response de cada endpoint con códigos HTTP  
**Usar para:** Documentación de API, Swagger alternative

---

## 📝 Ejemplos de Uso

### Caso 1: Presentación a Stakeholders
Usar:
- 01-contexto-c4.puml (vista general)
- 04-secuencia-upload.puml (ejemplo de uso)
- 08-estados.puml (explicar estados)

### Caso 2: Onboarding de Desarrollador
Usar:
- 02-contenedores-c4.puml (arquitectura)
- 03-componentes-c4.puml (componentes detallados)
- 05-secuencia-procesamiento.puml (flujo principal)

### Caso 3: Documentación de API
Usar:
- 10-api-rest.puml (endpoints completos)
- 04-secuencia-upload.puml (ejemplo de upload)
- 06-secuencia-polling.puml (ejemplo de consulta)

### Caso 4: Troubleshooting
Usar:
- 07-secuencia-errores.puml (manejo de errores)
- 08-estados.puml (estados del sistema)
- 09-flujo-archivos.puml (movimiento de archivos)

---

## 🌐 Recursos Adicionales

### Herramientas Online
- **PlantUML Editor**: https://www.plantuml.com/plantuml/uml/
- **PlantUML Live Server**: https://plantuml-editor.kkeisuke.com/
- **C4 Model Documentation**: https://c4model.com/

### VS Code Extensions
- **PlantUML**: jebbs.plantuml
- **PlantUML Previewer**: okazuki.okazukiplantuml
- **C4 DSL**: systemticks.c4-dsl-extension

### Lucidchart Resources
- **Lucidchart Help**: https://lucid.co/help
- **PlantUML Import Guide**: https://lucid.co/import/plantuml
- **Shape Libraries**: Buscar "AWS", "Azure", "Spring" en biblioteca

---

## ✅ Checklist de Importación

- [ ] Archivo `.puml` descargado o copiado
- [ ] Lucidchart abierto con cuenta activa
- [ ] Diagrama importado exitosamente
- [ ] Layout ajustado y elementos alineados
- [ ] Colores personalizados según paleta corporativa
- [ ] Íconos de tecnologías agregados
- [ ] Texto legible y sin solapamientos
- [ ] Exportado en formato deseado (PNG/PDF/SVG)
- [ ] Guardado en carpeta compartida/documentación

---

**Generado**: 2024-11-27  
**Versión**: 1.0  
**Formato**: PlantUML (.puml)  
**Microservicio**: Send Register Core 0.0.1-SNAPSHOT  
**Total de Diagramas**: 10
