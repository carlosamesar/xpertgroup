# HU-01 Quick Start Guide

## 🚀 Quick Start (5 Minutes)

> **⚠️ NOTA IMPORTANTE**: Esta versión NO requiere base de datos Oracle. Los registros se almacenan en memoria.

### Step 1: Start Required Services
```powershell
# Create Kafka network
docker network create kafka-net

# Start Zookeeper (required for Kafka)
docker run -d --name zookeeper --network kafka-net `
  -p 2181:2181 `
  -e ZOOKEEPER_CLIENT_PORT=2181 `
  -e ZOOKEEPER_TICK_TIME=2000 `
  confluentinc/cp-zookeeper:7.5.0

# Wait for Zookeeper to start
Start-Sleep -Seconds 10

# Start Apache Kafka (required for message publishing)
docker run -d --name kafka --network kafka-net `
  -p 9092:9092 `
  -e KAFKA_BROKER_ID=1 `
  -e KAFKA_ZOOKEEPER_CONNECT=zookeeper:2181 `
  -e KAFKA_ADVERTISED_LISTENERS=PLAINTEXT://localhost:9092 `
  -e KAFKA_LISTENER_SECURITY_PROTOCOL_MAP=PLAINTEXT:PLAINTEXT `
  -e KAFKA_INTER_BROKER_LISTENER_NAME=PLAINTEXT `
  -e KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR=1 `
  -e KAFKA_MESSAGE_MAX_BYTES=524288000 `
  -e KAFKA_REPLICA_FETCH_MAX_BYTES=524288000 `
  -e KAFKA_MAX_REQUEST_SIZE=524288000 `
  confluentinc/cp-kafka:7.5.0

# Wait for Kafka to be ready
Start-Sleep -Seconds 15

# Verify containers are running
docker ps

# (Optional) Pre-create Kafka topics to avoid LEADER_NOT_AVAILABLE warnings
docker exec kafka kafka-topics --create --topic RegistrosProcesados --bootstrap-server localhost:9092 --partitions 1 --replication-factor 1 --config max.message.bytes=524288000
docker exec kafka kafka-topics --create --topic RegistrosError --bootstrap-server localhost:9092 --partitions 1 --replication-factor 1 --config max.message.bytes=524288000
docker exec kafka kafka-topics --create --topic ExcelProcesados --bootstrap-server localhost:9092 --partitions 1 --replication-factor 1 --config max.message.bytes=524288000
```

> **Oracle Database ha sido DESHABILITADO**: La aplicación funciona con almacenamiento en memoria para la Fase 1.

### Step 2: Create Directories
```powershell
New-Item -ItemType Directory -Force -Path "C:\bancoldex\input"
New-Item -ItemType Directory -Force -Path "C:\bancoldex\processed"
New-Item -ItemType Directory -Force -Path "C:\bancoldex\error"
```

### Step 3: Build and Run
```powershell
cd send-register-core
.\mvnw.cmd clean install -DskipTests
.\mvnw.cmd spring-boot:run
```

### Step 4: Verify Health
```powershell
curl http://localhost:8081/api/files/health
```

Expected response:
```json
{
  "status": "UP",
  "pendingFiles": 0,
  "processingFiles": 0,
  "completedFiles": 0,
  "errorFiles": 0,
  "timestamp": "2025-11-18T..."
}
```

### Step 5: Test Upload
```powershell
# Create a test Excel file or use existing one
curl -X POST http://localhost:8081/api/files/upload `
  -F "file=@path\to\test.xlsx" `
  -H "Content-Type: multipart/form-data"
```

Expected response:
```json
{
  "trackingId": 1,
  "fileName": "test.xlsx",
  "fileSize": 12345,
  "status": "PENDING",
  "message": "File uploaded successfully and queued for processing"
}
```

### Step 6: Check Status
```powershell
curl http://localhost:8081/api/files/1/status
```

---

## 📖 API Usage Examples

### Upload Excel File
```bash
curl -X POST http://localhost:8081/api/files/upload \
  -F "file=@sales_data.xlsx" \
  -H "Content-Type: multipart/form-data"
```

### Upload CSV File
```bash
curl -X POST http://localhost:8081/api/files/upload \
  -F "file=@data.csv" \
  -H "Content-Type: multipart/form-data"
```

### Query Status
```bash
curl http://localhost:8081/api/files/{trackingId}/status
```

### Check Health
```bash
curl http://localhost:8081/api/files/health
```

### View Swagger Documentation
Open browser: `http://localhost:8081/swagger-ui.html`

---

## 🧪 Run Tests

### Unit Tests Only
```powershell
.\mvnw.cmd test
```

### Integration Tests
```powershell
.\mvnw.cmd verify
```

### Specific Test Class
```powershell
.\mvnw.cmd test -Dtest=FileUploadControllerTest
```

### With Coverage Report
```powershell
.\mvnw.cmd clean test jacoco:report
# View report: target/site/jacoco/index.html
```

---

## 🔧 Configuration

### application.properties
```properties
# Server Configuration
server.port=8081

# Kafka Configuration
spring.kafka.bootstrap-servers=localhost:9092
kafka.topic.processed-register=RegistrosProcesados
kafka.topic.error-register=RegistrosError
kafka.topic.excel-processed=ExcelProcesados

# File Processing Configuration
file.processing.input-directory=C:/bancoldex/input
file.processing.processed-directory=C:/bancoldex/processed
file.processing.error-directory=C:/bancoldex/error

# File Upload Configuration
file.upload.max-size-mb=50
file.upload.allowed-extensions=xlsx,xls,csv,txt
file.upload.batch-size=1000

# ⚠️ Oracle Database Configuration - DESHABILITADO
# La configuración de base de datos ha sido comentada en application.properties
# Los registros se almacenan en memoria con InMemoryFileRegisterService
# spring.datasource.url=jdbc:oracle:thin:@//localhost:1521/ORCLPDB1
# spring.datasource.username=dev
# spring.datasource.password=pass1234
```

---

## 📊 Monitoring Kafka Topics

### View Processed Records
```bash
kafka-console-consumer --bootstrap-server localhost:9092 \
  --topic RegistrosProcesados \
  --from-beginning
```

### View Excel Events
```bash
kafka-console-consumer --bootstrap-server localhost:9092 \
  --topic ExcelProcesados \
  --from-beginning
```

### View Error Records
```bash
kafka-console-consumer --bootstrap-server localhost:9092 \
  --topic RegistrosError \
  --from-beginning
```

---

## 🐛 Troubleshooting

### Issue: File not processing
**Solution**: Check scheduled task is running
```bash
# View logs for: "Iniciando procesamiento programado de archivos"
tail -f logs/application.log | grep "procesamiento programado"
```

### Issue: Out of Memory
**Solution**: Increase heap size
```bash
.\mvnw.cmd spring-boot:run -Dspring-boot.run.jvmArguments="-Xmx2g"
```

### Issue: Kafka connection refused
**Solution**: Verify Kafka is running
```bash
docker ps | grep kafka
docker logs kafka
```

### Issue: Kafka message too large error
**Solution**: This has been fixed by increasing Kafka message size limits to 500 MB
- Kafka broker configured with `KAFKA_MESSAGE_MAX_BYTES=524288000`
- Topics created with `max.message.bytes=524288000`
- Spring Boot producer configured with `spring.kafka.producer.max-request-size=524288000`
- If error persists, check that messages are being sent individually, not in batches

### ~~Issue: Database connection failed~~ (NO APLICA)
**⚠️ NOTA**: La base de datos Oracle ha sido deshabilitada. La aplicación usa almacenamiento en memoria.
```bash
# Ya no es necesario verificar Oracle
# La aplicación NO requiere base de datos en la Fase 1
```

### Issue: File remains in input directory
**Solution**: Check for errors in error directory
```bash
dir C:\bancoldex\error
```

---

## 📝 Common Use Cases

### Process Large File (10k+ rows)
1. Upload file via `/upload` endpoint
2. Note the `trackingId` from response
3. Poll `/status` endpoint every 5-10 seconds
4. File processing takes ~30-60 seconds for 10k rows
5. Check status changes: PENDING → PROCESSING → COMPLETED

### Concurrent Uploads
- Upload multiple files simultaneously
- Each receives unique `trackingId`
- Scheduled processor handles queue automatically
- No conflicts or duplicate processing

### Error Recovery
- Failed files moved to `error` directory
- Check error message in status query
- Fix issue and manually move file back to input directory
- Scheduled processor retries automatically

### Monitor System Health
- Call `/health` endpoint regularly
- Monitor `pendingFiles` and `processingFiles` counts
- Alert if `errorFiles` count increases rapidly
- Track `diskSpaceAvailableMB` to prevent disk full

---

## 🎯 Performance Tips

### For Small Files (<1000 rows)
- Default configuration optimal
- Expect <3 second processing time

### For Medium Files (1000-10000 rows)
- Default configuration optimal
- Expect 3-30 second processing time
- Progress logged every 1000 records

### For Large Files (>10000 rows)
- Consider increasing heap: `-Xmx2g`
- Expect 30-120 second processing time
- Monitor memory usage via health endpoint

### For Very Large Files (>50000 rows)
- Use heap: `-Xmx4g`
- Consider implementing SXSSF streaming
- Process may take several minutes
- Monitor disk space for Kafka logs

---

## 📞 Support

### Log Files
- Location: `logs/application.log`
- Level: INFO (default)
- Change level in `application.properties`:
  ```properties
  logging.level.com.bancoldex=DEBUG
  ```

### Health Check
Always start troubleshooting with health check:
```bash
curl http://localhost:8081/api/files/health
```

### Database Queries
Check file processing status directly:
```sql
SELECT id, file_name, status, record_count, process_start_time, process_end_time
FROM file_register
ORDER BY process_start_time DESC
LIMIT 10;
```

---

## ✅ Production Deployment Checklist (Fase 1 - Sin Base de Datos)

- [ ] ~~Oracle Database configured and accessible~~ **NO REQUERIDO** (almacenamiento en memoria)
- [ ] Kafka cluster running and reachable
- [ ] File directories created with proper permissions
- [ ] Configuration properties updated for production
- [ ] JVM heap size configured (recommend 2GB)
- [ ] Health monitoring endpoint accessible
- [ ] **IMPORTANTE**: Los datos se perderán al reiniciar la aplicación (almacenamiento en memoria)
- [ ] Planear migración a base de datos persistente en Fase 2
- [ ] Log aggregation configured
- [ ] Backup strategy for processed files
- [ ] Disk space monitoring alerts set
- [ ] Kafka consumer applications deployed
- [ ] API Gateway configuration updated
- [ ] Load balancer configured (if multiple instances)
- [ ] SSL/TLS certificates installed (if required)
- [ ] Firewall rules configured
- [ ] Performance testing completed
- [ ] Rollback plan documented

---

**Quick Start Guide Version**: 1.0  
**Last Updated**: November 18, 2025  
**Author**: GitHub Copilot
