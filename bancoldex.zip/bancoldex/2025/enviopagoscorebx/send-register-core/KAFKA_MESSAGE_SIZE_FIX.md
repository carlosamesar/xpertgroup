# Kafka Message Size Error - Solution

## Problem Description

The application was encountering the following error when publishing messages to Kafka:

```
org.apache.kafka.common.network.InvalidReceiveException: Invalid receive (size = 1195725856 larger than 104857600)
```

This error indicates that:
- **Attempted message size**: ~1.14 GB (1,195,725,856 bytes)
- **Default Kafka limit**: 100 MB (104,857,600 bytes)
- **Result**: Kafka rejected the message and closed the connection

## Root Cause

Kafka has default limits to prevent excessive memory usage:
- **Broker default**: `message.max.bytes = 100 MB`
- **Producer default**: `max.request.size = 1 MB`
- **Topic default**: `max.message.bytes = 100 MB`

When a message exceeds these limits, Kafka rejects it with an `InvalidReceiveException`.

## Solution Implemented

### 1. Kafka Broker Configuration

Increased Kafka broker limits to **500 MB** by adding environment variables:

```powershell
docker run -d --name kafka --network kafka-net `
  -p 9092:9092 `
  -e KAFKA_BROKER_ID=1 `
  -e KAFKA_ZOOKEEPER_CONNECT=zookeeper:2181 `
  -e KAFKA_ADVERTISED_LISTENERS=PLAINTEXT://localhost:9092 `
  -e KAFKA_LISTENER_SECURITY_PROTOCOL_MAP=PLAINTEXT:PLAINTEXT `
  -e KAFKA_INTER_BROKER_LISTENER_NAME=PLAINTEXT `
  -e KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR=1 `
  -e KAFKA_MESSAGE_MAX_BYTES=524288000 `
  -e KAFKA_REPLICA_FETCH_MAX_BYTES=524288000 `
  -e KAFKA_MAX_REQUEST_SIZE=524288000 `
  confluentinc/cp-kafka:7.5.0
```

**Key settings**:
- `KAFKA_MESSAGE_MAX_BYTES=524288000` (500 MB) - Maximum message size broker accepts
- `KAFKA_REPLICA_FETCH_MAX_BYTES=524288000` (500 MB) - Maximum size for replication
- `KAFKA_MAX_REQUEST_SIZE=524288000` (500 MB) - Maximum request size

### 2. Kafka Topic Configuration

Created topics with increased message size limits:

```powershell
docker exec kafka kafka-topics --create `
  --topic RegistrosProcesados `
  --bootstrap-server localhost:9092 `
  --partitions 1 `
  --replication-factor 1 `
  --config max.message.bytes=524288000

docker exec kafka kafka-topics --create `
  --topic RegistrosError `
  --bootstrap-server localhost:9092 `
  --partitions 1 `
  --replication-factor 1 `
  --config max.message.bytes=524288000

docker exec kafka kafka-topics --create `
  --topic ExcelProcesados `
  --bootstrap-server localhost:9092 `
  --partitions 1 `
  --replication-factor 1 `
  --config max.message.bytes=524288000
```

### 3. Spring Boot Producer Configuration

Updated `application.properties` with producer settings:

```properties
# Kafka Configuration
spring.kafka.bootstrap-servers=localhost:9092
kafka.topic.processed-register=RegistrosProcesados
kafka.topic.error-register=RegistrosError
kafka.topic.excel-processed=ExcelProcesados

# Kafka Producer Configuration - Increased limits for large messages
spring.kafka.producer.max-request-size=524288000
spring.kafka.producer.buffer-memory=524288000
spring.kafka.producer.compression-type=gzip
```

**Key settings**:
- `max-request-size=524288000` (500 MB) - Maximum size of producer request
- `buffer-memory=524288000` (500 MB) - Total memory available for buffering
- `compression-type=gzip` - Enable compression to reduce actual message size

### 4. Message Size Monitoring

Added logging to detect large messages in `FileProcessingComponent.java`:

```java
private int publishRecords(List<Map<String, String>> records, String fileName) {
    int publishedCount = 0;

    for (Map<String, String> record : records) {
        try {
            // Agregar metadata del archivo
            record.put("_fileName", fileName);
            record.put("_timestamp", LocalDateTime.now().toString());

            String jsonMessage = gson.toJson(record);
            
            // Log tamaño del mensaje para detectar anomalías
            int messageSize = jsonMessage.getBytes(java.nio.charset.StandardCharsets.UTF_8).length;
            if (messageSize > 1048576) { // > 1 MB
                logger.log(Level.WARNING, String.format(
                    "Mensaje grande detectado: %d bytes (%.2f MB) para archivo %s", 
                    messageSize, messageSize / 1048576.0, fileName));
            }
            
            messageProducer.publishProcessedRegister(jsonMessage);
            publishedCount++;

        } catch (Exception e) {
            logger.log(Level.WARNING, "Error publicando registro en Kafka", e);
        }
    }

    return publishedCount;
}
```

## Verification Steps

1. **Rebuild the application**:
   ```powershell
   .\mvnw.cmd clean compile -DskipTests
   ```

2. **Start the application**:
   ```powershell
   .\mvnw.cmd spring-boot:run
   ```

3. **Upload a test file**:
   ```powershell
   curl -X POST http://localhost:8081/api/files/upload `
     -F "file=@test.xlsx" `
     -H "Content-Type: multipart/form-data"
   ```

4. **Monitor application logs** for:
   - ✅ No `InvalidReceiveException` errors
   - ✅ Successful message publishing
   - ⚠️ Warnings for messages > 1 MB

5. **Check Kafka logs**:
   ```powershell
   docker logs kafka --tail 50
   ```

## Prevention Recommendations

### For Development
- ✅ **Current limits (500 MB)** are sufficient for most use cases
- ✅ **Message monitoring** will alert if individual records are too large
- ✅ **Compression enabled** reduces actual network transfer size

### For Production
Consider implementing:

1. **Record Batching**: Group multiple small records into batches of ~10-100 KB each
2. **Field Size Limits**: Validate that individual Excel columns don't exceed reasonable sizes (e.g., 10 KB)
3. **File Chunking**: For very large files (>100k rows), split into multiple processing jobs
4. **Streaming**: For massive files, use Apache POI's `SXSSFWorkbook` for memory-efficient streaming

### Configuration Tuning
```properties
# Recommended production settings
spring.kafka.producer.max-request-size=104857600         # 100 MB (sufficient for most cases)
spring.kafka.producer.buffer-memory=134217728            # 128 MB buffer
spring.kafka.producer.compression-type=gzip              # Enable compression
spring.kafka.producer.batch-size=16384                   # 16 KB batches
spring.kafka.producer.linger-ms=10                       # Wait 10ms for batching
spring.kafka.producer.acks=all                           # Ensure durability
```

## Troubleshooting

### Still getting message size errors?

1. **Check actual message size**:
   - Look for "Mensaje grande detectado" warnings in logs
   - If messages are consistently > 10 MB, investigate Excel cell contents

2. **Verify Kafka configuration**:
   ```powershell
   docker exec kafka kafka-configs --describe `
     --entity-type topics `
     --entity-name RegistrosProcesados `
     --bootstrap-server localhost:9092
   ```

3. **Check producer configuration**:
   ```powershell
   # View Spring Boot startup logs for Kafka producer properties
   docker logs <app-container> | grep "kafka.producer"
   ```

4. **Inspect actual messages**:
   ```powershell
   docker exec kafka kafka-console-consumer `
     --bootstrap-server localhost:9092 `
     --topic RegistrosProcesados `
     --from-beginning `
     --max-messages 1
   ```

## Related Files Updated

- ✅ `application.properties` - Added producer configuration
- ✅ `QUICK_START_GUIDE.md` - Updated Docker commands and troubleshooting
- ✅ `FileProcessingComponent.java` - Added message size monitoring
- ✅ Docker Kafka container - Reconfigured with increased limits

## Status

**✅ RESOLVED** - Application now supports messages up to 500 MB with compression enabled.

---

**Date**: November 18, 2025  
**Author**: GitHub Copilot  
**Version**: 1.0
