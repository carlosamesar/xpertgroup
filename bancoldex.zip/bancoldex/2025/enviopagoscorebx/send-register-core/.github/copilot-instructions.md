# Send Register Core - AI Coding Agent Instructions

## Architecture Overview

**Purpose**: Spring Boot 2.7.14 microservice for automated file processing (CSV/TXT) and publishing to Apache Kafka topics. Designed for asynchronous integration with Bancoldex Core systems through message-driven architecture.

**Deployment**: WAR packaging for WebLogic (`ServletInitializer.java`, `weblogic.xml`), with Docker support using embedded Tomcat.

### Core Data Flow
```
File System (INPUT dir) → @Scheduled(30s) → FileProcessingComponent →
  Parse (CSV/TXT) → Transform to JSON → MessageProducer →
    Kafka (RegistrosProcesados) → External Consumers →
      Audit (Oracle DB: file_register, log_file_register)
```

## Critical Architecture Patterns

### 1. Scheduled File Processing
- **Trigger**: `@Scheduled(fixedDelay=30000, initialDelay=10000)` - runs every 30 seconds
- **Scan**: Walks `file.processing.input-directory` for `.csv` and `.txt` files
- **Idempotency**: Checks `FileRegisterRepository.existsByFileNameAndStatus(fileName, "COMPLETED")` to prevent reprocessing
- **State Machine**: `PROCESSING` → `COMPLETED` or `ERROR`

### 2. Multi-Format File Parsing
**CSV Files** (Apache Commons CSV):
```java
CSVFormat.DEFAULT.withFirstRecordAsHeader()
// First line = headers, subsequent lines = data rows
```

**TXT Files** (Pipe-delimited):
```
Format: header1|header2|header3
        value1|value2|value3
// Split by "\\|", first line = headers, rest = data
```

### 3. Message Publishing Pattern
Every parsed record becomes a JSON message with metadata:
```json
{
  "campo1": "valor1",
  "campo2": "valor2",
  "_fileName": "datos.csv",
  "_timestamp": "2024-11-15T10:30:45.123"
}
```
- **Success**: Publishes to `kafka.topic.processed-register`
- **Failure**: Auto-redirects to `kafka.topic.error-register` with error details

### 4. File Lifecycle Management
```
INPUT/ → (parse + publish) → 
  ├─ Success: PROCESSED/ (original name)
  └─ Error: ERROR/ (with _ERROR suffix)
```
Uses `Files.move()` with `StandardCopyOption.REPLACE_EXISTING`

## Database Schema (Oracle)

**Tables**: 
- `file_register` - Main processing log (id, file_name, record_count, published_count, status, error_message, timestamps)
- `log_file_register` - Detailed audit trail (id, file_register_id, action, kafka_topic, record_data CLOB)

**Sequences**: `FILE_REGISTER_SEQ`, `LOG_FILE_REGISTER_SEQ`  
**Connection**: JPA with Hibernate, schema from `spring.datasource.hikari.schema`

## Key Configuration Properties

```properties
# Critical paths
file.processing.input-directory=C:/bancoldex/input
file.processing.processed-directory=C:/bancoldex/processed
file.processing.error-directory=C:/bancoldex/error

# Kafka topics
kafka.topic.processed-register=RegistrosProcesados
kafka.topic.error-register=RegistrosError

# Server port (different from send-payment-core-service)
server.port=8081
```

## Build & Test Commands

```powershell
# Build (Maven wrapper included)
./mvnw clean package

# Skip tests during build
./mvnw clean package -DskipTests

# Run tests only
./mvnw test

# Run locally (requires Kafka + Oracle)
./mvnw spring-boot:run

# Docker build (multi-stage)
docker build -t send-register-core .
```

**Note**: Tests use Mockito + JUnit 5 with `@ExtendWith(MockitoExtension.class)`.

## Code Conventions

- **Dependency Injection**: `@Autowired` field injection (legacy style, matching send-payment-core-service)
- **Logging**: `java.util.logging.Logger` with `Level.INFO`, `Level.WARNING`, `Level.SEVERE`
- **JSON**: Google Gson for serialization (not Jackson)
- **DTOs**: Lombok `@Data`, `@Builder`, `@NoArgsConstructor`, `@AllArgsConstructor` for models
- **Repositories**: Spring Data JPA with `JpaRepository<Entity, Long>`

## Common Pitfalls

1. **File Extensions**: Only `.csv` and `.txt` are processed - validate with `isValidFileExtension()`
2. **Duplicate Processing**: ALWAYS check `existsByFileNameAndStatus()` before processing
3. **Kafka Error Handling**: `MessageProducer` auto-publishes to error topic on failure - don't duplicate error handling
4. **CSV Headers**: First line is ALWAYS headers - never skip it
5. **TXT Delimiter**: Use `"\\|"` regex pattern (escaped pipe) for splitting
6. **File Movement**: Create target directories if they don't exist with `Files.createDirectories()`
7. **WAR Deployment**: Requires `ServletInitializer` extending `SpringBootServletInitializer`

## Testing Patterns

Mock external calls in this order:
```java
@Mock Environment env;  // Config properties
@Mock FileRegisterRepository fileRegisterRepository;  // DB queries
@Mock MessageProducer messageProducer;  // Kafka publishing
```

**Test Data Format**:
- CSV: `"field1,field2\nvalue1,value2"`
- TXT: `"field1|field2\nvalue1|value2"`

## Performance Considerations

- **Batch Size**: Processes all files in INPUT directory per scheduled run
- **Kafka Producer**: Configured with `acks=all`, `retries=3`, `compression=snappy`
- **Database**: Hikari pool with `maximum-pool-size=10`, `minimum-idle=0`
- **Scheduling**: `fixedDelay=30000ms` ensures previous run completes before next starts

## Monitoring Queries

```sql
-- Files processed today
SELECT file_name, status, record_count, published_count 
FROM file_register 
WHERE TRUNC(process_start_time) = TRUNC(SYSDATE);

-- Error rate
SELECT status, COUNT(*) 
FROM file_register 
WHERE TRUNC(created_at) = TRUNC(SYSDATE) 
GROUP BY status;
```

## Extension Points

**To add new file format** (e.g., XML):
1. Create `processXmlFile(File file)` method in `FileProcessingComponent`
2. Add condition in `processFile()`: `if ("xml".equals(extension)) { records = processXmlFile(file); }`
3. Update `isValidFileExtension()` to include "xml"
4. Update `file.processing.allowed-extensions` property

**To add new Kafka topic**:
1. Add property in `application.properties`: `kafka.topic.new-topic=NewTopicName`
2. Create method in `MessageProducer`: `publishToNewTopic(String message)`
3. Inject `Environment` to read topic name

---

**Further Reading**: See `DOCUMENTACION.md` for complete Spanish documentation including architecture diagrams, troubleshooting, and operational guidelines.
