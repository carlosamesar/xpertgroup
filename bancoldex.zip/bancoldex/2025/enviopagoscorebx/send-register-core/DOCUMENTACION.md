# Documentación del Proyecto: Send Register Core

## 📋 Índice
1. [Descripción General](#descripción-general)
2. [Arquitectura del Sistema](#arquitectura-del-sistema)
3. [Componentes Principales](#componentes-principales)
4. [Procesamiento de Archivos](#procesamiento-de-archivos)
5. [Integración con Kafka](#integración-con-kafka)
6. [Modelos de Datos](#modelos-de-datos)
7. [Configuración](#configuración)
8. [Despliegue](#despliegue)
9. [Guía de Uso](#guía-de-uso)
10. [Troubleshooting](#troubleshooting)

---

## 🎯 Descripción General

**Send Register Core** es un microservicio desarrollado en Spring Boot 2.7.14 diseñado para el procesamiento automatizado de archivos (CSV y TXT) y su publicación en tópicos de Apache Kafka para integraciones asíncronas con sistemas core de Bancoldex.

### Propósito
- Monitorear directorios configurados para detectar nuevos archivos
- Procesar archivos CSV y TXT con validación de estructura
- Transformar registros de archivos a formato JSON
- Publicar mensajes procesados en tópicos de Kafka
- Mantener auditoría completa en base de datos Oracle
- Gestionar archivos procesados y errores en directorios separados

### Información Técnica
- **Versión**: 0.0.1-SNAPSHOT
- **Java**: 11
- **Spring Boot**: 2.7.14
- **Empaquetado**: WAR (WebLogic compatible)
- **Puerto**: 8081
- **Base de Datos**: Oracle 19c
- **Mensajería**: Apache Kafka

---

## 🏗️ Arquitectura del Sistema

### Diagrama de Arquitectura

```
┌─────────────────────────────────────────────────────────────┐
│                  DIRECTORIOS DE ARCHIVOS                    │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │   INPUT/     │  │  PROCESSED/  │  │   ERROR/     │      │
│  │  (entrada)   │  │  (exitosos)  │  │  (errores)   │      │
│  └──────┬───────┘  └──────────────┘  └──────────────┘      │
└─────────┼──────────────────────────────────────────────────┘
          │
          ▼
┌─────────────────────────────────────────────────────────────┐
│          SEND REGISTER CORE SERVICE                         │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  @Scheduled (cada 30 segundos)                       │   │
│  │  FileProcessingComponent.processFiles()              │   │
│  └──────────────────┬───────────────────────────────────┘   │
│                     │                                        │
│                     ▼                                        │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  Validación y Parseo de Archivos                     │   │
│  │  - CSV: Apache Commons CSV                           │   │
│  │  - TXT: Delimitado por pipes (|)                     │   │
│  └──────────────────┬───────────────────────────────────┘   │
│                     │                                        │
│                     ▼                                        │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  Transformación a JSON y Publicación                 │   │
│  │  MessageProducer.publishProcessedRegister()          │   │
│  └──────────────────┬───────────────────────────────────┘   │
│                     │                                        │
│                     ▼                                        │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  Registro en Base de Datos (Oracle)                  │   │
│  │  - FileRegister (estado, contadores)                 │   │
│  │  - LogFileRegister (auditoría detallada)             │   │
│  └──────────────────────────────────────────────────────┘   │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│                    KAFKA CLUSTER                            │
│  ┌──────────────────────────┐  ┌─────────────────────────┐ │
│  │  RegistrosProcesados     │  │  RegistrosError         │ │
│  │  (mensajes exitosos)     │  │  (mensajes fallidos)    │ │
│  └──────────────────────────┘  └─────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│              SISTEMAS CONSUMIDORES                          │
│  - Sistemas Core (T24, AS400)                               │
│  - Sistemas de Análisis y Reportería                        │
│  - Otros microservicios de integración                      │
└─────────────────────────────────────────────────────────────┘
```

### Flujo de Procesamiento

```
1. DETECCIÓN
   └─> @Scheduled escanea directorio INPUT cada 30s
   
2. VALIDACIÓN
   ├─> Verificar extensión (.csv, .txt)
   ├─> Verificar no duplicado en BD
   └─> Crear registro FileRegister (status=PROCESSING)
   
3. PARSEO
   ├─> CSV: Leer con Apache Commons CSV
   │   └─> Primera fila = headers
   │       Siguientes filas = datos
   │
   └─> TXT: Leer línea por línea
       └─> Primera línea = headers (delimitado por |)
           Siguientes líneas = datos (delimitado por |)
   
4. TRANSFORMACIÓN
   ├─> Convertir cada registro a Map<String, String>
   ├─> Agregar metadata: _fileName, _timestamp
   └─> Serializar a JSON con Gson
   
5. PUBLICACIÓN
   ├─> Enviar a Kafka topic: RegistrosProcesados
   └─> En caso de error: RegistrosError
   
6. AUDITORÍA
   ├─> Actualizar FileRegister
   │   ├─> recordCount
   │   ├─> publishedCount
   │   ├─> status = COMPLETED/ERROR
   │   └─> processEndTime
   │
   └─> Mover archivo
       ├─> COMPLETED → PROCESSED directory
       └─> ERROR → ERROR directory (sufijo _ERROR)
```

---

## 🔧 Componentes Principales

### 1. FileProcessingComponent

**Ubicación**: `com.bancoldex.sendregistercore.component.FileProcessingComponent`

**Responsabilidades**:
- Escaneo automático de directorios mediante `@Scheduled`
- Validación de extensiones de archivo
- Procesamiento de archivos CSV y TXT
- Gestión de movimiento de archivos entre directorios
- Orquestación del flujo completo de procesamiento

**Métodos Clave**:

```java
@Scheduled(fixedDelay = 30000, initialDelay = 10000)
public void processFilesScheduled()
// Ejecuta cada 30 segundos, inicia 10 segundos después del arranque

private void processFile(File file, String processedDir, String errorDir)
// Procesa un archivo individual con manejo completo de errores

private List<Map<String, String>> processCsvFile(File file)
// Parser específico para archivos CSV con headers

private List<Map<String, String>> processTextFile(File file)
// Parser para archivos TXT delimitados por pipes

private int publishRecords(List<Map<String, String>> records, String fileName)
// Publica registros a Kafka con conteo de éxitos
```

**Configuración Requerida**:
```properties
file.processing.input-directory=C:/bancoldex/input
file.processing.processed-directory=C:/bancoldex/processed
file.processing.error-directory=C:/bancoldex/error
```

---

### 2. MessageProducer

**Ubicación**: `com.bancoldex.sendregistercore.util.kafka.MessageProducer`

**Responsabilidades**:
- Publicación de mensajes en tópicos de Kafka
- Manejo de errores y reintentos automáticos (configurado en producer)
- Logging de operaciones de publicación

**Métodos Principales**:

```java
public void publishProcessedRegister(String message)
// Publica mensaje en topic: RegistrosProcesados
// En caso de error, redirige automáticamente a topic de errores

public void publishToErrorTopic(String message, String error)
// Publica en topic: RegistrosError
// Formato: {"original":<mensaje>, "error":"<descripción>"}
```

**Configuración Producer**:
```java
// Configuración de confiabilidad
ACKS_CONFIG = "all"          // Espera confirmación de todos los brokers
RETRIES_CONFIG = 3           // 3 reintentos automáticos
COMPRESSION_TYPE_CONFIG = "snappy"  // Compresión para eficiencia
```

---

### 3. Kafka Configuration

#### KafkaProducerConfig

**Ubicación**: `com.bancoldex.sendregistercore.util.kafka.KafkaProducerConfig`

**Configuración**:
```java
@Bean
public ProducerFactory<String, String> producerFactory()
// Crea factory con configuraciones de confiabilidad y performance

@Bean
public KafkaTemplate<String, String> kafkaTemplate()
// Template para operaciones de publicación
```

**Propiedades Kafka**:
```properties
spring.kafka.bootstrap-servers=localhost:9092
kafka.topic.processed-register=RegistrosProcesados
kafka.topic.error-register=RegistrosError
```

---

## 📦 Modelos de Datos

### 1. FileRegister (Entidad Principal)

**Tabla**: `file_register`

```sql
CREATE TABLE file_register (
    id NUMBER PRIMARY KEY,
    file_name VARCHAR2(255) NOT NULL,
    file_path VARCHAR2(500),
    file_size NUMBER,
    record_count NUMBER,
    published_count NUMBER,
    status VARCHAR2(50) NOT NULL,
    error_message VARCHAR2(1000),
    process_start_time TIMESTAMP,
    process_end_time TIMESTAMP,
    created_at TIMESTAMP,
    updated_at TIMESTAMP
);

CREATE SEQUENCE FILE_REGISTER_SEQ START WITH 1 INCREMENT BY 1;
```

**Estados Posibles**:
- `PROCESSING`: Archivo en proceso
- `COMPLETED`: Procesado exitosamente
- `ERROR`: Error en procesamiento

**Campos Clave**:
- `record_count`: Total de registros en el archivo
- `published_count`: Registros publicados exitosamente en Kafka
- `error_message`: Descripción del error (si aplica)

---

### 2. LogFileRegister (Auditoría)

**Tabla**: `log_file_register`

```sql
CREATE TABLE log_file_register (
    id NUMBER PRIMARY KEY,
    file_register_id NUMBER,
    action VARCHAR2(100) NOT NULL,
    description VARCHAR2(500),
    status VARCHAR2(50),
    kafka_topic VARCHAR2(100),
    record_data CLOB,
    created_at TIMESTAMP
);

CREATE SEQUENCE LOG_FILE_REGISTER_SEQ START WITH 1 INCREMENT BY 1;
```

**Uso**:
- Registro detallado de cada acción sobre archivos
- Almacenamiento de payloads JSON publicados
- Auditoría de operaciones Kafka

---

## ⚙️ Configuración

### application.properties Completo

```properties
# Server Configuration
server.port=8081

# Kafka Configuration
spring.kafka.bootstrap-servers=localhost:9092
spring.kafka.consumer.group-id=send-register-core-group
kafka.topic.processed-register=RegistrosProcesados
kafka.topic.error-register=RegistrosError

# File Processing Configuration
file.processing.input-directory=C:/bancoldex/input
file.processing.processed-directory=C:/bancoldex/processed
file.processing.error-directory=C:/bancoldex/error
file.processing.allowed-extensions=csv,txt
file.processing.kafka-threshold=300

# Kafka Retry Configuration
kafka.retry.max-attempts=3
kafka.retry.initial-interval=1000
kafka.retry.multiplier=2.0
kafka.retry.max-interval=10000

# Kafka Topics
kafka.topic.processed-register=RegistrosProcesados
kafka.topic.error-register=RegistrosError
kafka.topic.dead-letter=RegistrosDeadLetter

# Oracle Database Configuration
spring.datasource.url=jdbc:oracle:thin:@//localhost:1521/ORCLPDB1
spring.datasource.username=dev
spring.datasource.password=pass1234
spring.datasource.hikari.schema=DEV

# JPA Configuration
spring.jpa.hibernate.ddl-auto=none
spring.jpa.show-sql=false
spring.jpa.properties.hibernate.format_sql=true
spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.Oracle10gDialect

# Hikari Connection Pool Configuration
spring.datasource.hikari.maxLifeTime=600000
spring.datasource.hikari.minimum-idle=0
spring.datasource.hikari.maximum-pool-size=10

# Logging Configuration
logging.level.root=INFO
logging.level.com.bancoldex.sendregistercore=INFO
```

### Variables de Entorno (Producción)

```bash
export DB_PASSWORD=<password-seguro>
export KAFKA_BOOTSTRAP_SERVERS=kafka-cluster:9092
export INPUT_DIRECTORY=/app/data/input
export PROCESSED_DIRECTORY=/app/data/processed
export ERROR_DIRECTORY=/app/data/error
```

---

## 🚀 Despliegue

### Construcción Local

```powershell
# Compilar proyecto
./mvnw clean package

# Compilar sin tests
./mvnw clean package -DskipTests

# Ejecutar localmente
./mvnw spring-boot:run
```

### Docker Build

```powershell
# Construir imagen
docker build -t send-register-core:0.0.1 .

# Ejecutar contenedor
docker run -p 8081:8081 `
  -e DB_PASSWORD=password `
  -v C:/bancoldex/input:/app/input `
  -v C:/bancoldex/processed:/app/processed `
  -v C:/bancoldex/error:/app/error `
  send-register-core:0.0.1
```

### WebLogic Deployment

1. Generar WAR:
```powershell
./mvnw clean package
```

2. Ubicar WAR en: `target/send-register-core-0.0.1-SNAPSHOT.war`

3. Desplegar en WebLogic Console:
   - Subir archivo WAR
   - Context root: `/send-register-core`
   - Target: Seleccionar servidor

4. Configurar datasource JNDI en WebLogic (opcional)

---

## 📖 Guía de Uso

### Formato de Archivos CSV

```csv
campo1,campo2,campo3,fecha
valor1,valor2,valor3,2024-11-15
valor4,valor5,valor6,2024-11-15
```

**Notas**:
- Primera línea siempre debe ser headers
- Sin espacios extras en headers
- Encoding UTF-8 recomendado

### Formato de Archivos TXT

```
campo1|campo2|campo3|fecha
valor1|valor2|valor3|2024-11-15
valor4|valor5|valor6|2024-11-15
```

**Notas**:
- Delimitador: pipe (|)
- Primera línea = headers
- Sin pipes adicionales al final de línea

### Mensaje JSON Publicado en Kafka

```json
{
  "campo1": "valor1",
  "campo2": "valor2",
  "campo3": "valor3",
  "fecha": "2024-11-15",
  "_fileName": "datos_20241115.csv",
  "_timestamp": "2024-11-15T10:30:45.123"
}
```

**Metadata Agregada**:
- `_fileName`: Nombre del archivo origen
- `_timestamp`: Timestamp de procesamiento (ISO-8601)

---

## 🔍 Monitoreo y Troubleshooting

### Consultas SQL Útiles

```sql
-- Ver archivos procesados hoy
SELECT file_name, record_count, published_count, status, process_end_time
FROM file_register
WHERE TRUNC(process_start_time) = TRUNC(SYSDATE)
ORDER BY process_start_time DESC;

-- Ver archivos con errores
SELECT file_name, error_message, process_start_time
FROM file_register
WHERE status = 'ERROR'
ORDER BY process_start_time DESC;

-- Estadísticas de procesamiento
SELECT 
    status,
    COUNT(*) as total,
    SUM(record_count) as total_records,
    SUM(published_count) as total_published
FROM file_register
WHERE TRUNC(created_at) = TRUNC(SYSDATE)
GROUP BY status;
```

### Logs de Aplicación

```powershell
# Ver logs en tiempo real
tail -f logs/send-register-core.log

# Filtrar por errores
grep "ERROR" logs/send-register-core.log

# Filtrar procesamiento de archivos
grep "Procesando archivo" logs/send-register-core.log
```

### Problemas Comunes

#### 1. Archivos no se procesan

**Síntomas**: Archivos permanecen en directorio INPUT

**Verificar**:
```sql
-- ¿Archivo ya fue procesado?
SELECT * FROM file_register WHERE file_name = 'nombre_archivo.csv';
```

**Soluciones**:
- Verificar que el directorio INPUT esté configurado correctamente
- Revisar permisos de lectura/escritura en directorios
- Confirmar que la extensión sea .csv o .txt
- Verificar que el servicio esté en ejecución

#### 2. Errores de conexión Kafka

**Síntomas**: Mensajes no llegan a tópicos

**Verificar**:
```bash
# Probar conexión a Kafka
telnet localhost 9092

# Listar tópicos
kafka-topics.sh --list --bootstrap-server localhost:9092
```

**Soluciones**:
- Verificar que Kafka esté en ejecución
- Confirmar configuración `spring.kafka.bootstrap-servers`
- Crear tópicos manualmente si no existen:
```bash
kafka-topics.sh --create --topic RegistrosProcesados \
  --bootstrap-server localhost:9092 --partitions 3 --replication-factor 1
```

#### 3. Errores de base de datos

**Síntomas**: FileRegister no se guarda

**Verificar**:
```sql
-- Verificar existencia de tablas
SELECT table_name FROM user_tables WHERE table_name LIKE '%FILE%';

-- Verificar secuencias
SELECT sequence_name FROM user_sequences WHERE sequence_name LIKE '%FILE%';
```

**Soluciones**:
- Ejecutar scripts DDL de creación de tablas
- Verificar credenciales de BD
- Confirmar que el esquema (`spring.datasource.hikari.schema`) existe

---

## 🔐 Seguridad

### Buenas Prácticas

1. **Credenciales**:
   - Usar variables de entorno para passwords
   - Nunca hardcodear credenciales en código
   - Usar application.properties.token para desarrollo

2. **Archivos**:
   - Validar extensiones permitidas
   - Sanitizar nombres de archivo
   - Limitar tamaño de archivos procesados

3. **Kafka**:
   - Usar SSL/TLS en producción
   - Configurar autenticación SASL
   - Encriptar mensajes sensibles

---

## 📊 Métricas y KPIs

### Métricas Clave

- **Throughput**: Archivos procesados por minuto
- **Latencia**: Tiempo promedio de procesamiento por archivo
- **Error Rate**: % de archivos con errores
- **Message Success Rate**: % de mensajes publicados exitosamente

### Query de Métricas

```sql
SELECT 
    TRUNC(process_start_time) as fecha,
    COUNT(*) as archivos_procesados,
    AVG(EXTRACT(SECOND FROM (process_end_time - process_start_time))) as tiempo_promedio_seg,
    SUM(CASE WHEN status='ERROR' THEN 1 ELSE 0 END) * 100.0 / COUNT(*) as error_rate_pct,
    SUM(published_count) as mensajes_kafka_total
FROM file_register
WHERE process_start_time >= TRUNC(SYSDATE) - 7
GROUP BY TRUNC(process_start_time)
ORDER BY fecha DESC;
```

---

## 🧪 Testing

### Ejecutar Tests

```powershell
# Todos los tests
./mvnw test

# Test específico
./mvnw test -Dtest=FileProcessingComponentTest

# Con cobertura
./mvnw test jacoco:report
```

### Estructura de Tests

```
src/test/java/
└── com.bancoldex.sendregistercore/
    ├── component/
    │   └── FileProcessingComponentTest.java
    └── util/kafka/
        └── MessageProducerTest.java
```

---

## 📝 Changelog

### Version 0.0.1-SNAPSHOT (2024-11-15)

**Características Iniciales**:
- ✅ Procesamiento automático de archivos CSV y TXT
- ✅ Integración con Apache Kafka
- ✅ Persistencia en Oracle Database
- ✅ Gestión de directorios (input/processed/error)
- ✅ Scheduling configurable (@Scheduled)
- ✅ Despliegue en WebLogic (WAR)
- ✅ Soporte Docker
- ✅ Logging completo
- ✅ Auditoría de operaciones

---

## 🤝 Contribución

### Convenciones de Código

- **Lenguaje**: Java 11
- **Framework**: Spring Boot 2.7.14
- **Estilo**: Lombok para reducir boilerplate
- **Logging**: `java.util.logging.Logger`
- **Inyección**: `@Autowired` en campos
- **Tests**: JUnit 5 + Mockito

### Agregar Nuevo Formato de Archivo

1. Crear método parser en `FileProcessingComponent`:
```java
private List<Map<String, String>> processXmlFile(File file) {
    // Implementación
}
```

2. Actualizar método `processFile()`:
```java
if ("xml".equals(extension)) {
    records = processXmlFile(file);
}
```

3. Agregar extensión a configuración:
```properties
file.processing.allowed-extensions=csv,txt,xml
```

---

## 🆕 Nuevas Funcionalidades (Nov 2025)

### 1. Validación de Umbral de Registros

#### Descripción
Sistema de validación que determina automáticamente la ruta de procesamiento basándose en la cantidad de registros del archivo.

#### Configuración

```properties
# Umbral mínimo de registros para procesamiento Kafka (default: 300)
file.processing.kafka-threshold=300
```

#### Flujo de Decisión

```
┌────────────────────┐
│  Archivo Cargado   │
└─────────┬──────────┘
          │
          ▼
┌────────────────────┐
│ Contar Registros   │
│ (sin cargar todo)  │
└─────────┬──────────┘
          │
          ▼
    ┌─────────┐
    │ Count?  │
    └────┬────┘
         │
    ┌────┴────┐
    │         │
 < 300     >= 300
    │         │
    ▼         ▼
┌───────┐ ┌─────────┐
│ Flujo │ │ Kafka   │
│ Alt.  │ │ Process │
└───────┘ └─────────┘
```

#### Estados de Archivo

- **PENDING_ALTERNATIVE**: Archivo con registros < umbral, pendiente para flujo alternativo
- **PROCESSING**: Archivo cumple umbral, procesándose por Kafka
- **COMPLETED**: Procesamiento exitoso por Kafka
- **ERROR**: Error en procesamiento

#### Endpoint de Validación Previa

**POST** `/api/files/validate-threshold`

Permite validar un archivo antes del upload definitivo.

**Request**:
```http
POST /api/files/validate-threshold
Content-Type: multipart/form-data

file: archivo.xlsx
```

**Response**:
```json
{
  "recordCount": 250,
  "threshold": 300,
  "shouldUseKafka": false,
  "message": "Se detectaron 250 registros. Umbral configurado: 300. Procesamiento por flujo: ALTERNATIVE",
  "processingRoute": "ALTERNATIVE"
}
```

#### Ejemplo de Uso

```java
// Validar archivo antes de procesarlo
RecordCountValidationResponse validation = 
    fileProcessingComponent.validateRecordCountThreshold(file);

if (validation.isShouldUseKafka()) {
    // Procesar por Kafka
    logger.info("Archivo con " + validation.getRecordCount() + 
                " registros. Procesando por Kafka.");
} else {
    // Procesar por flujo alternativo
    logger.info("Archivo con " + validation.getRecordCount() + 
                " registros. Redirigir a flujo alternativo.");
}
```

#### Optimización de Conteo

El sistema cuenta registros **sin cargar** el archivo completo en memoria:

- **Excel (XLSX/XLS)**: Usa `getPhysicalNumberOfRows()` - O(1)
- **CSV/TXT**: Lee línea por línea sin almacenar contenido
- **Eficiente**: Archivos de 10k+ registros validados en < 2 segundos

---

### 2. Mecanismo de Reintentos con Dead Letter Queue

#### Descripción
Sistema robusto de reintentos con backoff exponencial para manejo de fallos temporales de Kafka, incluyendo Dead Letter Queue (DLQ) para mensajes que no se pueden procesar.

#### Configuración

```properties
# Número máximo de reintentos (default: 3)
kafka.retry.max-attempts=3

# Intervalo inicial de espera en ms (default: 1000ms = 1s)
kafka.retry.initial-interval=1000

# Multiplicador de backoff exponencial (default: 2.0)
# Intervalos: 1s → 2s → 4s
kafka.retry.multiplier=2.0

# Intervalo máximo de espera en ms (default: 10000ms = 10s)
kafka.retry.max-interval=10000

# Tópico de Dead Letter Queue para mensajes fallidos
kafka.topic.dead-letter=RegistrosDeadLetter
```

#### Estrategia de Backoff Exponencial

```
Intento 1: Envío inmediato
   ↓ (falla)
Espera: 1 segundo
   ↓
Intento 2: Reintento
   ↓ (falla)
Espera: 2 segundos (1s × 2.0)
   ↓
Intento 3: Reintento final
   ↓ (falla)
   ↓
Envío a DLQ (Dead Letter Queue)
```

#### Flujo de Reintentos

```java
try {
    // Intento 1
    kafkaTemplate.send(topic, message).get(5, TimeUnit.SECONDS);
    logger.info("Mensaje enviado exitosamente en intento 1");
    
} catch (Exception e) {
    // Espera 1s (backoff)
    try {
        // Intento 2
        kafkaTemplate.send(topic, message).get(5, TimeUnit.SECONDS);
        logger.info("Mensaje enviado exitosamente en intento 2");
        
    } catch (Exception e2) {
        // Espera 2s (backoff exponencial)
        try {
            // Intento 3 (final)
            kafkaTemplate.send(topic, message).get(5, TimeUnit.SECONDS);
            logger.info("Mensaje enviado exitosamente en intento 3");
            
        } catch (Exception e3) {
            // ENVÍO A DLQ
            logger.severe("Falló después de 3 intentos. Enviando a DLQ");
            publishToDeadLetterQueue(message, e3, 3);
        }
    }
}
```

#### Estructura de Mensaje en DLQ

Los mensajes enviados al Dead Letter Queue incluyen metadata completa:

```json
{
  "originalMessage": "{\"id\":123,\"data\":\"...\"}",
  "error": "Connection refused: localhost:9092",
  "stackTrace": "org.apache.kafka.common.errors.TimeoutException...",
  "timestamp": "2025-11-21T15:30:45",
  "attempts": 3
}
```

#### Logs de Reintentos

```
INFO: Intento 1 de envío a Kafka (registro procesado) - Topic: RegistrosProcesados
WARNING: Intento 1 fallido para registro procesado: Connection refused
INFO: Intento 2 de envío a Kafka (registro procesado) - Topic: RegistrosProcesados
WARNING: Intento 2 fallido para registro procesado: Connection timeout
INFO: Intento 3 de envío a Kafka (registro procesado) - Topic: RegistrosProcesados
WARNING: Intento 3 fallido para registro procesado: Broker unavailable
SEVERE: Falló después de 3 intentos (registro procesado). Enviando a Dead Letter Queue
INFO: Mensaje enviado a DLQ 'RegistrosDeadLetter' después de 3 intentos
```

#### Monitoreo de DLQ

**Consumidor de DLQ** (recomendado para implementar):

```java
@KafkaListener(topics = "RegistrosDeadLetter")
public void handleDLQMessage(String message) {
    // Parsear mensaje
    DLQMessage dlqMessage = gson.fromJson(message, DLQMessage.class);
    
    // Alertar equipo de soporte
    alertService.sendAlert("Mensaje en DLQ", dlqMessage);
    
    // Almacenar para análisis
    dlqRepository.save(dlqMessage);
    
    // Opcional: Reintentar después de X tiempo
    if (shouldRetry(dlqMessage)) {
        retryService.scheduleRetry(dlqMessage.getOriginalMessage());
    }
}
```

#### Métricas Recomendadas

```properties
# Contadores
- kafka.retry.attempts.total: Total de reintentos realizados
- kafka.dlq.messages.total: Total de mensajes en DLQ
- kafka.success.first_attempt: Mensajes exitosos en primer intento
- kafka.success.retry: Mensajes exitosos tras reintentos

# Distribución
- kafka.retry.distribution: Histograma de intentos (1, 2, 3)
- kafka.retry.latency: Tiempo total de procesamiento con reintentos
```

---

### 3. Nuevos Campos en FileRegister

Se agregaron campos adicionales al modelo `FileRegister` para soporte de las nuevas funcionalidades:

```java
public class FileRegister {
    // ... campos existentes ...
    
    // Nuevos campos para validación de umbral
    private String processingRoute;        // "KAFKA" o "ALTERNATIVE"
    private Integer recordCountThreshold;  // Umbral usado en validación
    
    // Nuevos campos para reintentos
    private Integer retryAttempts;         // Número de reintentos realizados
    private Boolean sentToDeadLetter;      // ¿Fue enviado a DLQ?
    private LocalDateTime lastRetryTime;   // Timestamp último intento
}
```

#### Ejemplo de Registro

```json
{
  "id": 123,
  "fileName": "datos_2025-11-21.xlsx",
  "recordCount": 450,
  "recordCountThreshold": 300,
  "processingRoute": "KAFKA",
  "status": "COMPLETED",
  "publishedCount": 450,
  "retryAttempts": 1,
  "sentToDeadLetter": false,
  "lastRetryTime": "2025-11-21T15:30:45"
}
```

---

### 4. Configuración por Ambiente

#### Desarrollo
```properties
file.processing.kafka-threshold=50
kafka.retry.max-attempts=2
kafka.retry.initial-interval=500
```

#### QA/Staging
```properties
file.processing.kafka-threshold=200
kafka.retry.max-attempts=3
kafka.retry.initial-interval=1000
```

#### Producción
```properties
file.processing.kafka-threshold=300
kafka.retry.max-attempts=3
kafka.retry.initial-interval=1000
kafka.retry.multiplier=2.0
kafka.retry.max-interval=10000
```

---

## 🔍 Troubleshooting - Nuevas Funcionalidades

### Problema: Archivos no se procesan por Kafka

**Síntoma**: Archivos quedan en estado `PENDING_ALTERNATIVE`

**Diagnóstico**:
```bash
# Verificar cantidad de registros del archivo
grep -c "^" archivo.csv  # CSV/TXT (excluir 1 por header)

# Verificar umbral configurado
grep "kafka-threshold" application.properties
```

**Solución**:
- Si el archivo debe procesarse por Kafka, ajustar umbral: `file.processing.kafka-threshold=100`
- Si el archivo es para flujo alternativo, implementar consumidor alternativo

---

### Problema: Mensajes en Dead Letter Queue

**Síntoma**: Logs muestran envíos a DLQ, mensajes no llegan a tópico principal

**Diagnóstico**:
```bash
# Verificar mensajes en DLQ
kafka-console-consumer --bootstrap-server localhost:9092 \
  --topic RegistrosDeadLetter \
  --from-beginning

# Verificar logs de reintentos
grep "Intento.*fallido" logs/application.log
```

**Causas Comunes**:
1. **Kafka no disponible**: Verificar conectividad
2. **Timeout muy corto**: Incrementar timeout en MessageProducer
3. **Mensaje muy grande**: Verificar `max.request.size`
4. **Broker saturado**: Escalar cluster de Kafka

**Solución**:
```properties
# Incrementar reintentos para ambiente inestable
kafka.retry.max-attempts=5
kafka.retry.initial-interval=2000

# Incrementar límite de mensajes
spring.kafka.producer.max-request-size=10485760
```

---

### Problema: Reintentos lentos

**Síntoma**: Procesamiento tarda mucho cuando hay fallos temporales

**Diagnóstico**:
```bash
# Verificar configuración de backoff
grep "kafka.retry" application.properties
```

**Solución**: Ajustar tiempos de backoff
```properties
# Reducir tiempos para fallos rápidos
kafka.retry.initial-interval=500
kafka.retry.multiplier=1.5
kafka.retry.max-interval=5000
```

---

## 📊 Métricas y Monitoreo

### Dashboards Recomendados

#### Dashboard de Validación de Umbral
```
- Archivos procesados por Kafka vs Alternativos (gráfico de barras)
- Distribución de tamaño de archivos (histograma)
- Tendencia de umbral: ¿necesita ajuste?
```

#### Dashboard de Reintentos
```
- Tasa de éxito primer intento: XX%
- Tasa de reintentos exitosos: XX%
- Mensajes en DLQ: XX (alarma si > 100)
- Latencia promedio con reintentos: XX ms
```

---

## 📞 Soporte

**Equipo**: Arquitectura Bancoldex  
**Email**: arquitectura@bancoldex.com  
**Documentación**: `/docs` en repositorio


---

**Última actualización**: 2025-11-21  
**Versión documento**: 2.0  
**Cambios**: Agregadas funcionalidades de validación de umbral de registros y mecanismo de reintentos con Dead Letter Queue

