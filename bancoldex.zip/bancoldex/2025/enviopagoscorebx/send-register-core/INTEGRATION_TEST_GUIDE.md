# Guía de Pruebas de Integración

## Nuevas Funcionalidades Implementadas

### 1. Validación de Umbral de Registros
### 2. Mecanismo de Reintentos con Dead Letter Queue (DLQ)

---

## 📋 Checklist de Pruebas de Integración

### Escenario 1: Validación de Umbral - Archivo Pequeño (< 300 registros)

**Objetivo**: Verificar que archivos con menos registros que el umbral se desvían al flujo alternativo

**Pasos**:
1. Configurar `file.processing.kafka-threshold=300` en `application.properties`
2. Preparar archivo Excel con 250 registros
3. Cargar archivo vía endpoint `POST /api/files/upload`
4. Verificar respuesta del servicio

**Resultado Esperado**:
```json
{
  "status": "PENDING_ALTERNATIVE",
  "recordCount": 250,
  "processingRoute": "ALTERNATIVE",
  "message": "Archivo con 250 registros. Umbral: 300. Redirigido a flujo alternativo."
}
```

**Verificaciones**:
- [ ] Estado del archivo en base de datos: `PENDING_ALTERNATIVE`
- [ ] Campo `processingRoute`: `ALTERNATIVE`
- [ ] Campo `recordCountThreshold`: `300`
- [ ] Campo `recordCount`: `250`
- [ ] NO se enviaron mensajes a Kafka topic `RegistrosProcesados`
- [ ] Log muestra: "Archivo con 250 registros. Umbral: 300. Proceso alternativo"

**Comando de verificación Kafka**:
```bash
# Verificar que NO hay mensajes nuevos en RegistrosProcesados
kafka-console-consumer --bootstrap-server localhost:9092 \
  --topic RegistrosProcesados \
  --from-beginning \
  --timeout-ms 5000
# No debe mostrar el archivo test.xlsx
```

---

### Escenario 2: Validación de Umbral - Archivo Grande (>= 300 registros)

**Objetivo**: Verificar que archivos con suficientes registros se procesan por Kafka

**Pasos**:
1. Configurar `file.processing.kafka-threshold=300` en `application.properties`
2. Preparar archivo Excel con 500 registros
3. Cargar archivo vía endpoint `POST /api/files/upload`
4. Verificar respuesta del servicio
5. Consumir mensajes de Kafka topic `RegistrosProcesados`

**Resultado Esperado**:
```json
{
  "status": "PROCESSING",
  "recordCount": 500,
  "processingRoute": "KAFKA",
  "publishedCount": 500,
  "message": "Archivo procesándose vía Kafka."
}
```

**Verificaciones**:
- [ ] Estado del archivo: `PROCESSING` → `COMPLETED`
- [ ] Campo `processingRoute`: `KAFKA`
- [ ] Campo `recordCountThreshold`: `300`
- [ ] Campo `recordCount`: `500`
- [ ] Campo `publishedCount`: `500`
- [ ] 500 mensajes enviados a topic `RegistrosProcesados`
- [ ] Log muestra: "Archivo con 500 registros. Umbral: 300. Procesando por Kafka"

**Comando de verificación Kafka**:
```bash
# Contar mensajes en topic
kafka-console-consumer --bootstrap-server localhost:9092 \
  --topic RegistrosProcesados \
  --from-beginning \
  --timeout-ms 10000 | wc -l
# Debe mostrar: 500
```

---

### Escenario 3: Endpoint de Validación Previa

**Objetivo**: Verificar que el endpoint `/api/files/validate-threshold` funciona correctamente

**Pasos**:
1. Preparar archivo Excel con 150 registros
2. Llamar endpoint `POST /api/files/validate-threshold` con MultipartFile
3. Verificar respuesta JSON

**Request**:
```http
POST http://localhost:8080/api/files/validate-threshold
Content-Type: multipart/form-data

file: test_150_records.xlsx
```

**Resultado Esperado**:
```json
{
  "recordCount": 150,
  "threshold": 300,
  "shouldUseKafka": false,
  "message": "Se detectaron 150 registros. Umbral configurado: 300. Procesamiento por flujo: ALTERNATIVE",
  "processingRoute": "ALTERNATIVE"
}
```

**Verificaciones**:
- [ ] Respuesta HTTP 200 OK
- [ ] Campo `shouldUseKafka`: `false`
- [ ] Campo `processingRoute`: `ALTERNATIVE`
- [ ] NO se creó registro en base de datos (solo validación)
- [ ] NO se enviaron mensajes a Kafka
- [ ] Archivo temporal fue eliminado después de validación

**Prueba adicional con archivo >= 300 registros**:
```json
{
  "recordCount": 450,
  "threshold": 300,
  "shouldUseKafka": true,
  "message": "Se detectaron 450 registros. Umbral configurado: 300. Procesamiento por flujo: KAFKA",
  "processingRoute": "KAFKA"
}
```

---

### Escenario 4: Reintentos - Kafka Temporalmente No Disponible

**Objetivo**: Verificar que el mecanismo de reintentos funciona cuando Kafka está caído temporalmente

**Pasos**:
1. Configurar reintentos:
```properties
kafka.retry.max-attempts=3
kafka.retry.initial-interval=1000
kafka.retry.multiplier=2.0
```
2. **Apagar Kafka** broker temporalmente
3. Cargar archivo con 400 registros
4. **Esperar 2 segundos** (primer reintento)
5. **Encender Kafka** broker
6. Observar logs y verificar éxito en reintentos

**Resultado Esperado - Logs**:
```
INFO: Intento 1 de envío a Kafka (registro procesado) - Topic: RegistrosProcesados
WARNING: Intento 1 fallido para registro procesado: org.apache.kafka.common.errors.TimeoutException
INFO: Intento 2 de envío a Kafka (registro procesado) - Topic: RegistrosProcesados
INFO: Mensaje enviado a Kafka exitosamente en intento 2
```

**Verificaciones**:
- [ ] Log muestra "Intento 1 fallido"
- [ ] Log muestra "Intento 2" con éxito
- [ ] Campo `retryAttempts` en FileRegister: `2`
- [ ] Campo `sentToDeadLetter`: `false`
- [ ] Mensajes llegaron correctamente a topic `RegistrosProcesados`
- [ ] Estado final del archivo: `COMPLETED`

**Timing esperado**:
- Intento 1: Inmediato → Falla (Kafka caído)
- Espera: 1 segundo (backoff)
- Intento 2: t=1s → Éxito (Kafka encendido)
- Total: ~1-2 segundos

---

### Escenario 5: Reintentos Agotados - Envío a Dead Letter Queue

**Objetivo**: Verificar que después de 3 intentos fallidos, el mensaje se envía al DLQ

**Pasos**:
1. Configurar reintentos:
```properties
kafka.retry.max-attempts=3
kafka.retry.initial-interval=1000
kafka.retry.multiplier=2.0
```
2. **Apagar Kafka** broker completamente
3. Cargar archivo con 350 registros
4. Esperar 10 segundos (todos los reintentos)
5. Verificar logs y topic DLQ

**Resultado Esperado - Logs**:
```
INFO: Intento 1 de envío a Kafka (registro procesado) - Topic: RegistrosProcesados
WARNING: Intento 1 fallido para registro procesado: Connection refused
INFO: Intento 2 de envío a Kafka (registro procesado) - Topic: RegistrosProcesados
WARNING: Intento 2 fallido para registro procesado: Connection refused
INFO: Intento 3 de envío a Kafka (registro procesado) - Topic: RegistrosProcesados
WARNING: Intento 3 fallido para registro procesado: Connection refused
SEVERE: Falló después de 3 intentos (registro procesado). Enviando a Dead Letter Queue
INFO: Mensaje enviado a DLQ 'RegistrosDeadLetter' después de 3 intentos
```

**Verificaciones en Base de Datos**:
- [ ] Campo `retryAttempts`: `3`
- [ ] Campo `sentToDeadLetter`: `true`
- [ ] Campo `lastRetryTime`: timestamp reciente
- [ ] Estado del archivo: `ERROR`

**Verificaciones en Kafka DLQ**:
```bash
# Consumir mensajes de Dead Letter Queue
kafka-console-consumer --bootstrap-server localhost:9092 \
  --topic RegistrosDeadLetter \
  --from-beginning
```

**Mensaje DLQ Esperado**:
```json
{
  "originalMessage": "{\"id\":123,\"fileName\":\"test.xlsx\",\"recordCount\":350,...}",
  "error": "org.apache.kafka.common.errors.TimeoutException: Connection refused",
  "stackTrace": "org.apache.kafka.common.errors.TimeoutException: ...\n\tat org.springframework...",
  "timestamp": "2025-11-21T15:30:45",
  "attempts": 3
}
```

- [ ] Mensaje contiene `originalMessage` con FileRegister completo
- [ ] Mensaje contiene `error` con descripción del error
- [ ] Mensaje contiene `stackTrace` completo
- [ ] Mensaje contiene `timestamp` actual
- [ ] Mensaje contiene `attempts: 3`

**Timing esperado**:
- Intento 1: Inmediato → Falla
- Espera: 1 segundo
- Intento 2: t=1s → Falla
- Espera: 2 segundos (2.0 × 1s)
- Intento 3: t=3s → Falla
- Envío a DLQ: t=3.5s
- Total: ~3-4 segundos

---

### Escenario 6: Configuración de Umbral Personalizado

**Objetivo**: Verificar que el umbral es configurable por ambiente

**Pasos**:
1. Modificar `application.properties`:
```properties
file.processing.kafka-threshold=100
```
2. Cargar archivo con 120 registros
3. Verificar que se procesa por Kafka (cumple umbral)
4. Modificar configuración:
```properties
file.processing.kafka-threshold=500
```
5. Reiniciar aplicación
6. Cargar archivo con 120 registros
7. Verificar que se desvía a flujo alternativo (no cumple umbral)

**Verificaciones - Paso 3 (threshold=100)**:
- [ ] Archivo con 120 registros procesado por Kafka
- [ ] `processingRoute`: `KAFKA`
- [ ] Mensajes en topic `RegistrosProcesados`

**Verificaciones - Paso 7 (threshold=500)**:
- [ ] Archivo con 120 registros desviado a alternativo
- [ ] `processingRoute`: `ALTERNATIVE`
- [ ] NO hay mensajes en Kafka

---

### Escenario 7: Procesamiento de Archivos Masivos (>10,000 registros)

**Objetivo**: Verificar que archivos grandes se procesan correctamente con reintentos

**Pasos**:
1. Preparar archivo Excel con 15,000 registros
2. Configurar Kafka con límite de mensajes:
```properties
spring.kafka.producer.max-request-size=10485760
```
3. Cargar archivo
4. Monitorear logs de reintentos
5. Verificar que todos los registros se publican exitosamente

**Resultado Esperado**:
```json
{
  "status": "COMPLETED",
  "recordCount": 15000,
  "publishedCount": 15000,
  "processingRoute": "KAFKA",
  "retryAttempts": 0
}
```

**Verificaciones**:
- [ ] Estado: `COMPLETED`
- [ ] `publishedCount`: `15000`
- [ ] `retryAttempts`: `0` (sin fallos)
- [ ] Todos los mensajes en topic `RegistrosProcesados`
- [ ] Tiempo de procesamiento razonable (< 2 minutos)

**Comando de verificación**:
```bash
# Contar mensajes
kafka-console-consumer --bootstrap-server localhost:9092 \
  --topic RegistrosProcesados \
  --from-beginning \
  --timeout-ms 60000 | wc -l
# Debe mostrar: 15000
```

---

### Escenario 8: Múltiples Archivos en Paralelo

**Objetivo**: Verificar que múltiples archivos se procesan correctamente en paralelo

**Pasos**:
1. Preparar 3 archivos:
   - Archivo A: 250 registros (< umbral)
   - Archivo B: 450 registros (> umbral)
   - Archivo C: 600 registros (> umbral)
2. Cargar los 3 archivos simultáneamente
3. Verificar que cada uno sigue la ruta correcta

**Verificaciones**:
- [ ] Archivo A: `processingRoute: ALTERNATIVE`, estado `PENDING_ALTERNATIVE`
- [ ] Archivo B: `processingRoute: KAFKA`, estado `COMPLETED`, 450 mensajes en Kafka
- [ ] Archivo C: `processingRoute: KAFKA`, estado `COMPLETED`, 600 mensajes en Kafka
- [ ] Total mensajes en Kafka: 1050 (450 + 600)
- [ ] Sin interferencias entre archivos

---

## 🧪 Scripts de Testing Automatizado

### Script: Preparar Archivo de Prueba

```python
import pandas as pd

def create_test_excel(filename, num_records):
    data = {
        'id': range(1, num_records + 1),
        'nombre': [f'Registro {i}' for i in range(1, num_records + 1)],
        'valor': [i * 100 for i in range(1, num_records + 1)]
    }
    df = pd.DataFrame(data)
    df.to_excel(filename, index=False)
    print(f"Archivo {filename} creado con {num_records} registros")

# Crear archivos de prueba
create_test_excel('test_150_records.xlsx', 150)
create_test_excel('test_300_records.xlsx', 300)
create_test_excel('test_500_records.xlsx', 500)
create_test_excel('test_15000_records.xlsx', 15000)
```

### Script: Subir Archivo y Verificar

```bash
#!/bin/bash

FILE=$1
EXPECTED_ROUTE=$2

# Upload file
RESPONSE=$(curl -X POST http://localhost:8080/api/files/upload \
  -H "Content-Type: multipart/form-data" \
  -F "file=@$FILE")

echo "Response: $RESPONSE"

# Extract processingRoute
ROUTE=$(echo $RESPONSE | jq -r '.processingRoute')

if [ "$ROUTE" == "$EXPECTED_ROUTE" ]; then
  echo "✅ TEST PASSED: Processing route is $ROUTE"
else
  echo "❌ TEST FAILED: Expected $EXPECTED_ROUTE, got $ROUTE"
fi
```

**Uso**:
```bash
./test_upload.sh test_150_records.xlsx ALTERNATIVE
./test_upload.sh test_500_records.xlsx KAFKA
```

### Script: Verificar Mensajes en Kafka

```bash
#!/bin/bash

TOPIC=$1
EXPECTED_COUNT=$2

# Count messages in topic
ACTUAL_COUNT=$(kafka-console-consumer --bootstrap-server localhost:9092 \
  --topic $TOPIC \
  --from-beginning \
  --timeout-ms 10000 | wc -l)

if [ "$ACTUAL_COUNT" -eq "$EXPECTED_COUNT" ]; then
  echo "✅ TEST PASSED: $ACTUAL_COUNT messages in $TOPIC"
else
  echo "❌ TEST FAILED: Expected $EXPECTED_COUNT, got $ACTUAL_COUNT"
fi
```

**Uso**:
```bash
./verify_kafka.sh RegistrosProcesados 500
./verify_kafka.sh RegistrosDeadLetter 0
```

---

## 📊 Métricas a Monitorear Durante Pruebas

### 1. Tiempo de Procesamiento
- **Métrica**: Tiempo desde upload hasta estado `COMPLETED`
- **Objetivo**: < 10 segundos para archivos de 1000 registros
- **Herramienta**: Logs con timestamps

### 2. Tasa de Reintentos
- **Métrica**: Porcentaje de mensajes que requieren reintentos
- **Objetivo**: < 5% en ambiente estable
- **Herramienta**: Contadores en logs

### 3. Mensajes en DLQ
- **Métrica**: Número de mensajes en Dead Letter Queue
- **Objetivo**: 0 en operación normal
- **Herramienta**: Kafka consumer count

### 4. Precisión de Umbral
- **Métrica**: Archivos correctamente clasificados (KAFKA vs ALTERNATIVE)
- **Objetivo**: 100% de precisión
- **Herramienta**: Query a base de datos

---

## ✅ Checklist Final de Validación

Antes de considerar las pruebas completas, verificar:

- [ ] **Escenario 1**: Archivos < 300 registros → flujo alternativo ✅
- [ ] **Escenario 2**: Archivos >= 300 registros → procesamiento Kafka ✅
- [ ] **Escenario 3**: Endpoint `/validate-threshold` funcional ✅
- [ ] **Escenario 4**: Reintentos exitosos cuando Kafka se recupera ✅
- [ ] **Escenario 5**: Mensajes en DLQ después de 3 fallos ✅
- [ ] **Escenario 6**: Umbral configurable por ambiente ✅
- [ ] **Escenario 7**: Archivos masivos (>10k registros) ✅
- [ ] **Escenario 8**: Múltiples archivos en paralelo ✅
- [ ] **Logs**: Todos los eventos registrados correctamente
- [ ] **Base de Datos**: Campos nuevos poblados correctamente
- [ ] **Kafka**: Topics con mensajes correctos
- [ ] **Performance**: Tiempos de respuesta aceptables
- [ ] **Configuración**: Variables de entorno funcionan en todos los ambientes

---

## 🚨 Problemas Comunes y Soluciones

### Problema: Archivos siempre van a flujo alternativo
**Causa**: Umbral configurado muy alto
**Solución**: Verificar `file.processing.kafka-threshold` en `application.properties`

### Problema: Reintentos no funcionan
**Causa**: RetryTemplate no configurado correctamente
**Solución**: Verificar `KafkaRetryConfig` y dependencias `spring-retry` en `pom.xml`

### Problema: Mensajes no llegan a DLQ
**Causa**: Topic `RegistrosDeadLetter` no existe
**Solución**: Crear topic manualmente:
```bash
kafka-topics --create \
  --bootstrap-server localhost:9092 \
  --topic RegistrosDeadLetter \
  --partitions 1 \
  --replication-factor 1
```

### Problema: Timeout en procesamiento de archivos grandes
**Causa**: `max.request.size` muy pequeño
**Solución**: Incrementar en `application.properties`:
```properties
spring.kafka.producer.max-request-size=10485760
```

---

## 📝 Registro de Pruebas

| Fecha | Escenario | Resultado | Notas |
|-------|-----------|-----------|-------|
| 2025-11-21 | Escenario 1 | ⏸️ Pendiente | |
| 2025-11-21 | Escenario 2 | ⏸️ Pendiente | |
| 2025-11-21 | Escenario 3 | ⏸️ Pendiente | |
| 2025-11-21 | Escenario 4 | ⏸️ Pendiente | |
| 2025-11-21 | Escenario 5 | ⏸️ Pendiente | |
| 2025-11-21 | Escenario 6 | ⏸️ Pendiente | |
| 2025-11-21 | Escenario 7 | ⏸️ Pendiente | |
| 2025-11-21 | Escenario 8 | ⏸️ Pendiente | |

---

**Última actualización**: 2025-11-21  
**Autor**: GitHub Copilot  
**Versión**: 1.0
