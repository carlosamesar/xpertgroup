# Diagramas de Arquitectura para Lucidchart - Send Register Core

## 📋 Índice

1. [Instrucciones de Importación](#instrucciones-de-importación)
2. [Diagrama de Contexto C4 (Nivel 1)](#diagrama-de-contexto-c4-nivel-1)
3. [Diagrama de Contenedores C4 (Nivel 2)](#diagrama-de-contenedores-c4-nivel-2)
4. [Diagrama de Componentes C4 (Nivel 3)](#diagrama-de-componentes-c4-nivel-3)
5. [Diagrama de Secuencia - Upload de Archivo](#diagrama-de-secuencia---upload-de-archivo)
6. [Diagrama de Secuencia - Procesamiento Programado](#diagrama-de-secuencia---procesamiento-programado)
7. [Diagrama de Secuencia - Polling de Estado](#diagrama-de-secuencia---polling-de-estado)
8. [Diagrama de Secuencia - Manejo de Errores](#diagrama-de-secuencia---manejo-de-errores)
9. [Diagrama de Estados](#diagrama-de-estados)
10. [Diagrama de Flujo de Archivos](#diagrama-de-flujo-de-archivos)
11. [Diagrama de APIs REST](#diagrama-de-apis-rest)

---

## 🔧 Instrucciones de Importación

### Opción 1: Importar a Lucidchart
1. Copia el código de cada diagrama (Mermaid o PlantUML)
2. En Lucidchart, ve a: **File → Import → Mermaid** o **PlantUML**
3. Pega el código y haz clic en "Import"
4. Personaliza colores y estilos según tu preferencia

### Opción 2: Usar Editor Online
- **Mermaid Live Editor**: https://mermaid.live/
- **PlantUML Editor**: https://www.plantuml.com/plantuml/uml/

### Opción 3: Copiar a draw.io
- **draw.io**: https://app.diagrams.net/
- Soporta importación directa de Mermaid

---

## 🏗️ Diagrama de Contexto C4 (Nivel 1)

### Formato Mermaid

```mermaid
C4Context
    title Contexto del Sistema - Send Register Core

    Person(cliente, "Sistemas Externos", "Productores de datos<br/>Envían archivos vía API REST")
    
    System(sendRegister, "Send Register Core", "Microservicio Spring Boot<br/>Procesa archivos y publica en Kafka<br/>Puerto: 8081")
    
    System_Ext(kafka, "Apache Kafka", "Message Broker<br/>Topics: RegistrosProcesados,<br/>RegistrosError")
    
    SystemDb_Ext(oracle, "Oracle Database", "Base de datos 19c<br/>Auditoría y tracking<br/>Tablas: file_register,<br/>log_file_register")
    
    Person(consumidor, "Sistemas Consumidores", "Sistemas Core (T24, AS400)<br/>Análisis y Reportería<br/>Microservicios")

    Rel(cliente, sendRegister, "Carga archivos", "REST API<br/>CSV, TXT, Excel")
    Rel(sendRegister, kafka, "Publica mensajes", "Kafka Producer<br/>JSON")
    Rel(sendRegister, oracle, "Persiste auditoría", "JDBC<br/>Hibernate")
    Rel(kafka, consumidor, "Consume mensajes", "Kafka Consumer")

    UpdateLayoutConfig($c4ShapeInRow="2", $c4BoundaryInRow="1")
```

### Formato PlantUML

```plantuml
@startuml
!include https://raw.githubusercontent.com/plantuml-stdlib/C4-PlantUML/master/C4_Context.puml

LAYOUT_WITH_LEGEND()

title Contexto del Sistema - Send Register Core

Person(cliente, "Sistemas Externos", "Productores de datos que envían archivos vía API REST")

System(sendRegister, "Send Register Core", "Microservicio Spring Boot que procesa archivos y publica en Kafka (Puerto: 8081)")

System_Ext(kafka, "Apache Kafka", "Message Broker con topics: RegistrosProcesados, RegistrosError")

SystemDb_Ext(oracle, "Oracle Database 19c", "Base de datos para auditoría y tracking (file_register, log_file_register)")

Person(consumidor, "Sistemas Consumidores", "Sistemas Core (T24, AS400), Análisis y Reportería, Microservicios")

Rel(cliente, sendRegister, "Carga archivos CSV/TXT/Excel", "REST API")
Rel(sendRegister, kafka, "Publica mensajes JSON", "Kafka Producer")
Rel(sendRegister, oracle, "Persiste auditoría", "JDBC/Hibernate")
Rel(kafka, consumidor, "Consume mensajes", "Kafka Consumer")

@enduml
```

---

## 🏗️ Diagrama de Contenedores C4 (Nivel 2)

### Formato Mermaid

```mermaid
C4Container
    title Contenedores - Send Register Core

    Person(cliente, "Cliente Externo", "Sistema que carga archivos")
    
    Container_Boundary(app, "Send Register Core Application") {
        Container(api, "REST API", "Spring Web MVC", "Endpoints para upload,<br/>status, validation, health")
        Container(processor, "File Processor", "Spring @Scheduled", "Procesa archivos cada 30s<br/>Parsea CSV/TXT/Excel")
        Container(service, "File Register Service", "Spring Service", "Gestión en memoria<br/>ConcurrentHashMap")
        Container(producer, "Message Producer", "Spring Kafka", "Publica a Kafka<br/>acks=all, retries=3")
    }
    
    ContainerDb(memory, "In-Memory Storage", "ConcurrentHashMap", "Tracking de archivos<br/>y estado de procesamiento")
    
    System_Ext(kafka, "Apache Kafka", "Message Broker")
    SystemDb_Ext(oracle, "Oracle DB", "Auditoría")
    
    Rel(cliente, api, "POST /api/files/upload", "HTTPS/JSON")
    Rel(cliente, api, "GET /api/files/{id}/status", "HTTPS/JSON")
    Rel(api, service, "save(), findById()", "Method calls")
    Rel(processor, service, "Query file status", "Method calls")
    Rel(processor, producer, "publishProcessedRegister()", "Method calls")
    Rel(service, memory, "Read/Write", "Thread-safe ops")
    Rel(producer, kafka, "Send JSON messages", "Kafka Protocol")
    Rel(processor, oracle, "Log audit trail", "JDBC")

    UpdateLayoutConfig($c4ShapeInRow="2", $c4BoundaryInRow="1")
```

### Formato PlantUML

```plantuml
@startuml
!include https://raw.githubusercontent.com/plantuml-stdlib/C4-PlantUML/master/C4_Container.puml

LAYOUT_WITH_LEGEND()

title Diagrama de Contenedores - Send Register Core

Person(cliente, "Cliente Externo", "Sistema que carga archivos")

System_Boundary(app, "Send Register Core Application") {
    Container(api, "REST API", "Spring Web MVC", "Endpoints: upload, status, validation, health")
    Container(processor, "File Processor", "Spring @Scheduled", "Procesa archivos cada 30s, parsea CSV/TXT/Excel")
    Container(service, "File Register Service", "Spring Service", "Gestión en memoria con ConcurrentHashMap")
    Container(producer, "Message Producer", "Spring Kafka", "Publica a Kafka (acks=all, retries=3)")
    ContainerDb(memory, "In-Memory Storage", "ConcurrentHashMap", "Tracking de archivos y estado")
}

System_Ext(kafka, "Apache Kafka", "Message Broker")
SystemDb_Ext(oracle, "Oracle Database", "Auditoría y logging")

Rel(cliente, api, "POST /upload, GET /status", "HTTPS/JSON")
Rel(api, service, "save(), findById()", "Method calls")
Rel(processor, service, "Query file status", "Method calls")
Rel(processor, producer, "publishProcessedRegister()", "Method calls")
Rel(service, memory, "Read/Write operations", "Thread-safe")
Rel(producer, kafka, "Send JSON messages", "Kafka Protocol")
Rel(processor, oracle, "Log audit trail", "JDBC")

@enduml
```

---

## 🏗️ Diagrama de Componentes C4 (Nivel 3)

### Formato Mermaid

```mermaid
graph TB
    subgraph "Presentation Layer"
        API[FileUploadController<br/>REST Endpoints]
    end
    
    subgraph "Application Layer"
        PROC[FileProcessingComponent<br/>@Scheduled Processor]
        SVC[InMemoryFileRegisterService<br/>File Management]
    end
    
    subgraph "Infrastructure Layer"
        PROD[MessageProducer<br/>Kafka Integration]
        MEM[(In-Memory Store<br/>ConcurrentHashMap)]
    end
    
    subgraph "External Systems"
        KAFKA[Apache Kafka<br/>Topics]
        FS[File System<br/>INPUT/PROCESSED/ERROR]
        ORACLE[(Oracle Database<br/>Audit Tables)]
    end
    
    API -->|save, findById| SVC
    API -->|validateThreshold| PROC
    PROC -->|scan files| FS
    PROC -->|update status| SVC
    PROC -->|publish messages| PROD
    SVC -->|read/write| MEM
    PROD -->|send| KAFKA
    PROC -->|move files| FS
    PROC -->|log audit| ORACLE
    
    style API fill:#4A90E2
    style PROC fill:#7ED321
    style SVC fill:#F5A623
    style PROD fill:#BD10E0
    style MEM fill:#B8E986
    style KAFKA fill:#50E3C2
    style FS fill:#F8E71C
    style ORACLE fill:#4A4A4A
```

### Formato PlantUML (Componentes Detallado)

```plantuml
@startuml
!include https://raw.githubusercontent.com/plantuml-stdlib/C4-PlantUML/master/C4_Component.puml

LAYOUT_WITH_LEGEND()

title Diagrama de Componentes - Send Register Core

Container_Boundary(presentation, "Presentation Layer") {
    Component(controller, "FileUploadController", "Spring @RestController", "POST /upload, GET /status, POST /validate-threshold, GET /health")
}

Container_Boundary(application, "Application Layer") {
    Component(processor, "FileProcessingComponent", "Spring @Component", "@Scheduled(30s): scan INPUT, parse files, publish to Kafka")
    Component(service, "InMemoryFileRegisterService", "Spring @Service", "CRUD operations, thread-safe with ConcurrentHashMap")
}

Container_Boundary(infrastructure, "Infrastructure Layer") {
    Component(producer, "MessageProducer", "Spring @Component", "KafkaTemplate: publish to RegistrosProcesados/RegistrosError")
    ComponentDb(memory, "In-Memory Store", "ConcurrentHashMap", "FileRegister tracking data")
}

Container_Boundary(parsers, "File Parsers") {
    Component(csvParser, "CSV Parser", "Apache Commons CSV", "CSVFormat.DEFAULT.withFirstRecordAsHeader()")
    Component(txtParser, "TXT Parser", "BufferedReader", "Pipe-delimited (|) parsing")
    Component(excelParser, "Excel Parser", "Apache POI", "XSSFWorkbook/HSSFWorkbook")
}

System_Ext(kafka, "Apache Kafka", "Message Broker")
System_Ext(fileSystem, "File System", "INPUT/PROCESSED/ERROR directories")
SystemDb_Ext(oracle, "Oracle Database", "file_register, log_file_register tables")

Rel(controller, service, "save(), findById(), countByStatus()", "Method calls")
Rel(controller, processor, "validateRecordCountThreshold()", "Method calls")
Rel(processor, service, "findByFileNameAndStatus(), save()", "Method calls")
Rel(processor, csvParser, "processCSVFile()", "Delegates parsing")
Rel(processor, txtParser, "processTXTFile()", "Delegates parsing")
Rel(processor, excelParser, "processExcelFile()", "Delegates parsing")
Rel(processor, producer, "publishProcessedRegister()", "Method calls")
Rel(processor, fileSystem, "Files.walk(), Files.move()", "File I/O")
Rel(service, memory, "Read/Write operations", "Thread-safe access")
Rel(producer, kafka, "KafkaTemplate.send()", "Kafka Protocol")
Rel(processor, oracle, "Audit logging", "JDBC")

@enduml
```

---

## 🔄 Diagrama de Secuencia - Upload de Archivo

### Formato Mermaid

```mermaid
sequenceDiagram
    actor Cliente
    participant API as FileUploadController
    participant Service as InMemoryFileRegisterService
    participant FS as File System
    
    Cliente->>+API: POST /api/files/upload<br/>(MultipartFile)
    
    API->>API: Validar archivo<br/>(extensión, tamaño, no vacío)
    
    alt Validación fallida
        API-->>Cliente: 400 Bad Request<br/>{error: "Invalid file"}
    end
    
    API->>Service: existsByFileNameAndStatus(fileName, "COMPLETED")
    Service-->>API: false
    
    alt Archivo ya procesado
        API-->>Cliente: 409 Conflict<br/>{error: "Already processed"}
    end
    
    API->>+FS: Guardar archivo en INPUT/
    FS-->>-API: Archivo guardado
    
    API->>+Service: save(FileRegister)<br/>status=PENDING
    Service-->>-API: FileRegister con trackingId
    
    API-->>-Cliente: 202 Accepted<br/>{trackingId: 123,<br/>status: "PENDING"}
    
    Note over Cliente,FS: El archivo queda en cola<br/>para procesamiento programado
```

### Formato PlantUML

```plantuml
@startuml
actor Cliente
participant "FileUploadController" as API
participant "InMemoryFileRegisterService" as Service
participant "File System" as FS

Cliente -> API: POST /api/files/upload\n(MultipartFile)
activate API

API -> API: Validar archivo\n(extensión, tamaño, no vacío)

alt Validación fallida
    API --> Cliente: 400 Bad Request\n{error: "Invalid file"}
end

API -> Service: existsByFileNameAndStatus(fileName, "COMPLETED")
Service --> API: false

alt Archivo ya procesado
    API --> Cliente: 409 Conflict\n{error: "Already processed"}
end

API -> FS: Guardar archivo en INPUT/
activate FS
FS --> API: Archivo guardado
deactivate FS

API -> Service: save(FileRegister)\nstatus=PENDING
activate Service
Service --> API: FileRegister con trackingId
deactivate Service

API --> Cliente: 202 Accepted\n{trackingId: 123,\nstatus: "PENDING"}
deactivate API

note over Cliente,FS
    El archivo queda en cola
    para procesamiento programado
end note

@enduml
```

---

## 🔄 Diagrama de Secuencia - Procesamiento Programado

### Formato Mermaid

```mermaid
sequenceDiagram
    participant Scheduler as @Scheduled Task
    participant Processor as FileProcessingComponent
    participant Service as InMemoryFileRegisterService
    participant Parser as File Parsers
    participant Producer as MessageProducer
    participant Kafka as Apache Kafka
    participant FS as File System
    
    Note over Scheduler: Cada 30 segundos
    
    Scheduler->>+Processor: processFilesScheduled()
    
    Processor->>FS: Escanear INPUT/ directory
    FS-->>Processor: List<File>
    
    loop Para cada archivo
        Processor->>Service: findByFileNameAndStatus(fileName, "PENDING")
        Service-->>Processor: FileRegister
        
        Processor->>Processor: validateRecordCountThreshold()
        
        alt Threshold no cumplido
            Processor->>Service: save(status=PENDING_ALTERNATIVE)
            Note over Processor,Service: No procesar por Kafka
        else Threshold cumplido
            Processor->>Service: save(status=PROCESSING)
            
            Processor->>Parser: Parse file (CSV/TXT/Excel)
            Parser-->>Processor: List<Map<String,String>>
            
            loop Para cada registro
                Processor->>Processor: Transform to JSON<br/>+ add metadata
                Processor->>Producer: publishProcessedRegister(json)
                Producer->>Kafka: send() to RegistrosProcesados
                Kafka-->>Producer: ack
            end
            
            Processor->>Service: save(status=COMPLETED,<br/>recordCount, publishedCount)
            Processor->>FS: Move INPUT/ → PROCESSED/
        end
    end
    
    Processor-->>-Scheduler: Processing complete
```

### Formato PlantUML

```plantuml
@startuml
participant "@Scheduled Task" as Scheduler
participant "FileProcessingComponent" as Processor
participant "InMemoryFileRegisterService" as Service
participant "File Parsers" as Parser
participant "MessageProducer" as Producer
participant "Apache Kafka" as Kafka
participant "File System" as FS

note over Scheduler: Cada 30 segundos

Scheduler -> Processor: processFilesScheduled()
activate Processor

Processor -> FS: Escanear INPUT/ directory
FS --> Processor: List<File>

loop Para cada archivo
    Processor -> Service: findByFileNameAndStatus(fileName, "PENDING")
    Service --> Processor: FileRegister
    
    Processor -> Processor: validateRecordCountThreshold()
    
    alt Threshold no cumplido
        Processor -> Service: save(status=PENDING_ALTERNATIVE)
        note over Processor,Service: No procesar por Kafka
    else Threshold cumplido
        Processor -> Service: save(status=PROCESSING)
        
        Processor -> Parser: Parse file (CSV/TXT/Excel)
        Parser --> Processor: List<Map<String,String>>
        
        loop Para cada registro
            Processor -> Processor: Transform to JSON\n+ add metadata
            Processor -> Producer: publishProcessedRegister(json)
            Producer -> Kafka: send() to RegistrosProcesados
            Kafka --> Producer: ack
        end
        
        Processor -> Service: save(status=COMPLETED,\nrecordCount, publishedCount)
        Processor -> FS: Move INPUT/ → PROCESSED/
    end
end

Processor --> Scheduler: Processing complete
deactivate Processor

@enduml
```

---

## 🔄 Diagrama de Secuencia - Polling de Estado

### Formato Mermaid

```mermaid
sequenceDiagram
    actor Cliente
    participant API as FileUploadController
    participant Service as InMemoryFileRegisterService
    
    Note over Cliente: Cliente hace polling<br/>cada 2-5 segundos
    
    loop Hasta COMPLETED o ERROR
        Cliente->>+API: GET /api/files/{trackingId}/status
        API->>+Service: findById(trackingId)
        Service-->>-API: Optional<FileRegister>
        
        alt FileRegister encontrado
            API-->>Cliente: 200 OK<br/>{trackingId, fileName,<br/>status, recordCount,<br/>processStartTime, ...}
        else No encontrado
            API-->>-Cliente: 404 Not Found<br/>{error: "Not found"}
        end
        
        Note over Cliente: Esperar 2-5 segundos
    end
    
    Note over Cliente: Status = COMPLETED<br/>Proceso finalizado
```

### Formato PlantUML

```plantuml
@startuml
actor Cliente
participant "FileUploadController" as API
participant "InMemoryFileRegisterService" as Service

note over Cliente: Cliente hace polling\ncada 2-5 segundos

loop Hasta COMPLETED o ERROR
    Cliente -> API: GET /api/files/{trackingId}/status
    activate API
    API -> Service: findById(trackingId)
    activate Service
    Service --> API: Optional<FileRegister>
    deactivate Service
    
    alt FileRegister encontrado
        API --> Cliente: 200 OK\n{trackingId, fileName,\nstatus, recordCount,\nprocessStartTime, ...}
    else No encontrado
        API --> Cliente: 404 Not Found\n{error: "Not found"}
    end
    deactivate API
    
    note over Cliente: Esperar 2-5 segundos
end

note over Cliente: Status = COMPLETED\nProceso finalizado

@enduml
```

---

## 🔄 Diagrama de Secuencia - Manejo de Errores

### Formato Mermaid

```mermaid
sequenceDiagram
    participant Processor as FileProcessingComponent
    participant Producer as MessageProducer
    participant KafkaOK as Kafka (OK Topic)
    participant KafkaError as Kafka (Error Topic)
    participant Service as InMemoryFileRegisterService
    participant FS as File System
    
    Processor->>Producer: publishProcessedRegister(json)
    Producer->>KafkaOK: send() to RegistrosProcesados
    
    KafkaOK--xProducer: ERROR (timeout/connection)
    
    Note over Producer: Auto-retry 3 veces
    
    loop Retry 1, 2, 3
        Producer->>KafkaOK: send() retry
        KafkaOK--xProducer: FAILED
    end
    
    Note over Producer: Todos los reintentos fallaron
    
    Producer->>Producer: Crear mensaje de error<br/>con detalles del fallo
    Producer->>KafkaError: send() to RegistrosError
    KafkaError-->>Producer: ack
    
    Producer-->>Processor: Error logged
    
    Processor->>Service: save(status=ERROR,<br/>errorMessage="Kafka publish failed")
    
    Processor->>FS: Move INPUT/ → ERROR/<br/>(agregar sufijo _ERROR)
    FS-->>Processor: Archivo movido
    
    Note over Processor,FS: Archivo requiere<br/>intervención manual
```

### Formato PlantUML

```plantuml
@startuml
participant "FileProcessingComponent" as Processor
participant "MessageProducer" as Producer
participant "Kafka (OK Topic)" as KafkaOK
participant "Kafka (Error Topic)" as KafkaError
participant "InMemoryFileRegisterService" as Service
participant "File System" as FS

Processor -> Producer: publishProcessedRegister(json)
Producer -> KafkaOK: send() to RegistrosProcesados

KafkaOK --> Producer: ERROR (timeout/connection)

note over Producer: Auto-retry 3 veces

loop Retry 1, 2, 3
    Producer -> KafkaOK: send() retry
    KafkaOK --> Producer: FAILED
end

note over Producer: Todos los reintentos fallaron

Producer -> Producer: Crear mensaje de error\ncon detalles del fallo
Producer -> KafkaError: send() to RegistrosError
KafkaError --> Producer: ack

Producer --> Processor: Error logged

Processor -> Service: save(status=ERROR,\nerrorMessage="Kafka publish failed")

Processor -> FS: Move INPUT/ → ERROR/\n(agregar sufijo _ERROR)
FS --> Processor: Archivo movido

note over Processor,FS
    Archivo requiere
    intervención manual
end note

@enduml
```

---

## 📊 Diagrama de Estados

### Formato Mermaid

```mermaid
stateDiagram-v2
    [*] --> PENDING: POST /upload o<br/>archivo copiado a INPUT/
    
    PENDING --> PROCESSING: @Scheduled task detecta archivo<br/>(cada 30s)
    
    PROCESSING --> COMPLETED: Todos los registros<br/>publicados exitosamente
    PROCESSING --> ERROR: Error en parsing<br/>o publicación Kafka
    PROCESSING --> PENDING_ALTERNATIVE: recordCount < threshold<br/>(default: 100 registros)
    
    PENDING_ALTERNATIVE --> PENDING: Corrección manual o<br/>cambio de umbral
    
    COMPLETED --> [*]: Archivo en PROCESSED/
    ERROR --> [*]: Archivo en ERROR/<br/>(requiere intervención)
    PENDING_ALTERNATIVE --> [*]: Requiere flujo alternativo
    
    note right of PENDING
        En cola para procesamiento
        Archivo en INPUT/
    end note
    
    note right of PROCESSING
        Parseando registros
        Publicando a Kafka
    end note
    
    note right of COMPLETED
        Procesamiento exitoso
        Archivo movido a PROCESSED/
        publishedCount = recordCount
    end note
    
    note right of ERROR
        Error durante procesamiento
        Archivo movido a ERROR/
        errorMessage registrado
    end note
    
    note right of PENDING_ALTERNATIVE
        Archivo muy pequeño
        No cumple umbral Kafka
        Requiere flujo alternativo
    end note
```

### Formato PlantUML

```plantuml
@startuml
[*] --> PENDING: POST /upload o\narchivo copiado a INPUT/

PENDING --> PROCESSING: @Scheduled task detecta archivo\n(cada 30s)

PROCESSING --> COMPLETED: Todos los registros\npublicados exitosamente
PROCESSING --> ERROR: Error en parsing\no publicación Kafka
PROCESSING --> PENDING_ALTERNATIVE: recordCount < threshold\n(default: 100 registros)

PENDING_ALTERNATIVE --> PENDING: Corrección manual o\ncambio de umbral

COMPLETED --> [*]: Archivo en PROCESSED/
ERROR --> [*]: Archivo en ERROR/\n(requiere intervención)
PENDING_ALTERNATIVE --> [*]: Requiere flujo alternativo

note right of PENDING
    En cola para procesamiento
    Archivo en INPUT/
end note

note right of PROCESSING
    Parseando registros
    Publicando a Kafka
end note

note right of COMPLETED
    Procesamiento exitoso
    Archivo movido a PROCESSED/
    publishedCount = recordCount
end note

note right of ERROR
    Error durante procesamiento
    Archivo movido a ERROR/
    errorMessage registrado
end note

note right of PENDING_ALTERNATIVE
    Archivo muy pequeño
    No cumple umbral Kafka
    Requiere flujo alternativo
end note

@enduml
```

---

## 📁 Diagrama de Flujo de Archivos

### Formato Mermaid

```mermaid
flowchart TD
    Start([Archivo Cargado]) --> Upload[POST /api/files/upload<br/>o copia manual]
    
    Upload --> Input[Archivo en INPUT/<br/>Status: PENDING]
    
    Input --> Scheduled{@Scheduled Task<br/>cada 30 segundos}
    
    Scheduled --> Validate{Validar umbral<br/>de registros}
    
    Validate -->|recordCount < threshold| Alternative[Status: PENDING_ALTERNATIVE<br/>Archivo permanece en INPUT/<br/>Requiere flujo alternativo]
    
    Validate -->|recordCount >= threshold| Process[Status: PROCESSING<br/>Parse + Transform + Publish]
    
    Process --> Success{¿Procesamiento<br/>exitoso?}
    
    Success -->|Sí| Completed[Status: COMPLETED<br/>Move a PROCESSED/]
    Success -->|No| ErrorState[Status: ERROR<br/>Move a ERROR/<br/>sufijo _ERROR]
    
    Completed --> End1([Fin - Éxito])
    ErrorState --> End2([Fin - Error])
    Alternative --> End3([Fin - Flujo Alternativo])
    
    style Input fill:#4A90E2
    style Process fill:#7ED321
    style Completed fill:#50E3C2
    style ErrorState fill:#D0021B
    style Alternative fill:#F5A623
```

### Formato PlantUML

```plantuml
@startuml
start

:Archivo Cargado;
:POST /api/files/upload
o copia manual;
:Archivo en INPUT/
Status: PENDING;

repeat
    :@Scheduled Task
    (cada 30 segundos);
    
    if (Validar umbral de registros) then (recordCount < threshold)
        :Status: PENDING_ALTERNATIVE
        Archivo permanece en INPUT/
        Requiere flujo alternativo;
        stop
    else (recordCount >= threshold)
        :Status: PROCESSING
        Parse + Transform + Publish;
        
        if (¿Procesamiento exitoso?) then (Sí)
            :Status: COMPLETED
            Move a PROCESSED/;
            stop
        else (No)
            :Status: ERROR
            Move a ERROR/
            (sufijo _ERROR);
            stop
        endif
    endif
    
repeat while (Más archivos en INPUT?)

@enduml
```

---

## 🔌 Diagrama de APIs REST

### Formato Mermaid

```mermaid
graph LR
    subgraph "REST API Endpoints"
        A[POST /api/files/upload]
        B[GET /api/files/:trackingId/status]
        C[POST /api/files/validate-threshold]
        D[GET /api/files/health]
    end
    
    subgraph "Request Details"
        A1[MultipartFile<br/>Extensions: xlsx, xls, csv, txt<br/>Max Size: 50MB]
        B1[Path Param: trackingId Long]
        C1[MultipartFile<br/>Pre-upload validation]
        D1[No params<br/>System health metrics]
    end
    
    subgraph "Response Codes"
        A2[202 Accepted<br/>400 Bad Request<br/>409 Conflict<br/>413 Payload Too Large<br/>500 Server Error]
        B2[200 OK<br/>404 Not Found<br/>500 Server Error]
        C2[200 OK<br/>400 Bad Request<br/>500 Server Error]
        D2[200 OK<br/>500 Server Error]
    end
    
    A --> A1 --> A2
    B --> B1 --> B2
    C --> C1 --> C2
    D --> D1 --> D2
    
    style A fill:#4A90E2
    style B fill:#7ED321
    style C fill:#F5A623
    style D fill:#BD10E0
```

### Formato PlantUML (API Rest Completo)

```plantuml
@startuml
!define ICONURL https://raw.githubusercontent.com/tupadr3/plantuml-icon-font-sprites/v2.4.0
!include ICONURL/common.puml
!include ICONURL/font-awesome-5/file_upload.puml
!include ICONURL/font-awesome-5/search.puml
!include ICONURL/font-awesome-5/check_circle.puml
!include ICONURL/font-awesome-5/heartbeat.puml

package "Send Register Core API" {
    
    interface "POST /api/files/upload" as Upload
    note left of Upload
        <b>Request:</b>
        - Content-Type: multipart/form-data
        - file: MultipartFile (Required)
        - Extensions: .xlsx, .xls, .csv, .txt
        - Max Size: 50MB
        
        <b>Response 202 Accepted:</b>
        {
            "trackingId": 12345,
            "fileName": "datos.csv",
            "fileSize": 1048576,
            "status": "PENDING",
            "message": "File uploaded successfully..."
        }
        
        <b>Errors:</b>
        400 - Bad Request (empty, invalid type)
        409 - Conflict (already processed)
        413 - Payload Too Large
        500 - Server Error
    end note
    
    interface "GET /api/files/{trackingId}/status" as Status
    note left of Status
        <b>Path Param:</b>
        - trackingId: Long (Required)
        
        <b>Response 200 OK:</b>
        {
            "trackingId": 12345,
            "fileName": "datos.csv",
            "status": "COMPLETED",
            "recordCount": 1500,
            "publishedCount": 1500,
            "processStartTime": "2024-11-27T10:30:00",
            "processEndTime": "2024-11-27T10:31:45",
            "errorMessage": null
        }
        
        <b>Estados:</b>
        - PENDING, PROCESSING, COMPLETED
        - ERROR, PENDING_ALTERNATIVE
        
        <b>Errors:</b>
        404 - Not Found
        500 - Server Error
    end note
    
    interface "POST /api/files/validate-threshold" as Validate
    note right of Validate
        <b>Request:</b>
        - Content-Type: multipart/form-data
        - file: MultipartFile (Required)
        
        <b>Response 200 OK:</b>
        {
            "recordCount": 1500,
            "threshold": 100,
            "shouldUseKafka": true,
            "processingRoute": "KAFKA",
            "message": "File meets threshold..."
        }
        
        <b>Routes:</b>
        - KAFKA: >= threshold
        - ALTERNATIVE: < threshold
        
        <b>Errors:</b>
        400 - Bad Request
        500 - Server Error
    end note
    
    interface "GET /api/files/health" as Health
    note right of Health
        <b>Response 200 OK:</b>
        {
            "status": "UP",
            "pendingFiles": 5,
            "processingFiles": 2,
            "completedFiles": 150,
            "errorFiles": 3,
            "filesInInputDirectory": 5,
            "diskSpaceAvailableMB": 102400,
            "lastProcessedFile": "datos_2024.csv",
            "lastProcessedTime": "2024-11-27T10:31:45",
            "timestamp": "2024-11-27T11:00:00"
        }
        
        <b>Errors:</b>
        500 - Server Error (status: "DOWN")
    end note
}

FA5_FILE_UPLOAD(uploadIcon,Upload,component)
FA5_SEARCH(statusIcon,Status,component)
FA5_CHECK_CIRCLE(validateIcon,Validate,component)
FA5_HEARTBEAT(healthIcon,Health,component)

@enduml
```

---

## 📝 Notas Finales para Lucidchart

### Mejores Prácticas

1. **Colores Sugeridos:**
   - Azul (#4A90E2): Controladores y APIs
   - Verde (#7ED321): Procesamiento y lógica
   - Naranja (#F5A623): Servicios y almacenamiento
   - Púrpura (#BD10E0): Integración externa (Kafka)
   - Gris (#4A4A4A): Base de datos
   - Rojo (#D0021B): Estados de error

2. **Iconografía:**
   - Usa íconos de FontAwesome para endpoints REST
   - Íconos de servidores para componentes de backend
   - Íconos de base de datos para Oracle y almacenamiento

3. **Agrupación:**
   - Agrupa componentes por capa (Presentation, Application, Infrastructure)
   - Usa contenedores/swimlanes para separar sistemas externos

4. **Flechas:**
   - Línea sólida: Comunicación síncrona
   - Línea punteada: Comunicación asíncrona
   - Flecha gruesa: Flujo principal de datos

### Personalización en Lucidchart

Después de importar:
1. Ajusta el layout automático (Auto Layout)
2. Cambia colores según tu paleta corporativa
3. Agrega logos de tecnologías (Spring Boot, Kafka, Oracle)
4. Exporta en alta resolución para documentación

---

**Generado**: 2024-11-27  
**Versión**: 1.0  
**Formato**: Mermaid + PlantUML  
**Microservicio**: Send Register Core 0.0.1-SNAPSHOT
