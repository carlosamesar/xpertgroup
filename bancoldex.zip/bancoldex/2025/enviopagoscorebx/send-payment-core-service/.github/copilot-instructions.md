# Send Payment Core Service - AI Coding Agent Instructions

## Architecture Overview

**Purpose**: Spring Boot 2.7.14 microservice bridging payment gateways (WOMPI, etc.) to Bancoldex Core systems (T24 and AS400) via Kafka. Processes payment confirmations asynchronously with automatic retry logic.

**Deployment**: WAR packaging for WebLogic (`ServletInitializer.java`, `weblogic.xml`), though Dockerfile uses embedded Tomcat.

### Core Data Flow
```
Gateway → Kafka (Confirmacionespasarela) → @KafkaListener → 
  Producer (PendientesValidacionCORE) → @Scheduled(10s) → 
    Process & Route (T24/AS400) → JWT Auth → API Core → Oracle DB
```

## Critical Architecture Patterns

### 1. Two-Stage Kafka Processing
- **Stage 1 (Immediate)**: `@KafkaListener` on `kafka.topic.confirm-payment` immediately republishes to `kafka.topic.pendiente-core-payment`
- **Stage 2 (Batched)**: `@Scheduled(fixedDelay=10000)` polls pending queue, processes with retries
- **Why**: Decouples fast reception from slow external API calls; prevents blocking listener thread

### 2. Manual Offset Management
`MessageConsumer.getKafkaConsumer()` seeks to committed offsets (`kafkaConsumer.committed()`), processes messages, then manually commits. Failed messages re-queue to `pendiente-core-payment` before committing offset. Prevents message loss while enabling retries.

### 3. Reference String Format (Critical)
Payment `reference` field is pipe-delimited with **6 segments**:
```
reference = "obligation|nit|timestamp|idChannel|idCore|tipoPago"
```
- `idCore = "3"` → T24 system (`buildT24JsonObjectRequest`)
- `idCore ≠ "3"` → AS400 system (`buildAS400JsonObjectRequest`)

**Validation**: `reference.split("\\|").length == 6` else message → `transaccionesError` topic

### 4. Idempotency via `stateCore`
`Event.stateCore` prevents duplicate processing:
- `null` or `1` → Process
- `2` → Already sent to Core, skip
- `3` → Permanent error, skip
Check in `SendInfoToCoreComponent.sendInfoToApiCore()` before processing

## Database Schema (Oracle)

**Tables**: `confirm_payment`, `log_confirm_payment`, `channel`, `gateway`  
**Connection**: JPA with Hibernate, schema from `spring.datasource.hikari.schema`  
**Sequences**: `@SequenceGenerator(name="SEQ", sequenceName="ID_SEQ")` for IDs

## External Dependencies

### JWT Authentication Flow
1. Call `RestTemplateService.getJwtToken()` first
2. POST `application.security.url/login?username=X&password=Y`
3. Extract `jwt` from `LoginResponse` → `PermisosRol[].rolNombre` validation
4. Use token in `Authorization: Bearer` header for Core API calls

### API Core Integration
- **T24**: POST to `com.bancoldex.apicore.url` + optional `urlCore` override from payload
- **AS400**: Same pattern, different payload structure
- **Response**: `ValidationResponse` with success indicator

## Build & Test Commands

```powershell
# Build (Maven wrapper included)
./mvnw clean package

# Skip tests during build
./mvnw clean package -DskipTests

# Run tests only
./mvnw test

# Run locally (requires Kafka + Oracle)
./mvnw spring-boot:run

# Docker build (multi-stage)
docker build -t send-payment-core-service .
```

**Note**: Tests use Mockito + JUnit 5 with `@ExtendWith(MockitoExtension.class)`. WireMock for external API mocking.

## Key Configuration Properties

```properties
# Kafka topics (env-specific)
kafka.topic.confirm-payment=Confirmacionespasarela
kafka.topic.error-payment=transaccionesError
kafka.topic.pendiente-core-payment=PendientesValidacionCORE

# Core API auth
com.bancoldex.security.user=orquestador.pagos
com.bancoldex.security.pwd=[encrypted]
com.bancoldex.security.rolname=Orquestador de pagos

# AS400 date override (testing)
com.bancoldex.psefecrec=20230912  # Use "default" for current date
```

## Code Conventions

- **Dependency Injection**: `@Autowired` field injection (legacy style, not constructor injection)
- **Logging**: `java.util.logging.Logger` with `Level.INFO`
- **JSON**: Kong Unirest `JSONObject` for parsing, not Jackson
- **DTOs**: Lombok `@Data`, `@Builder` for models
- **Repositories**: Spring Data JPA with `JpaRepository<Entity, ID>`

## Common Pitfalls

1. **Don't modify `reference` parsing** without updating both T24 and AS400 builders
2. **Always check `stateCore`** before re-processing events to avoid loops
3. **JWT tokens are not cached** - each scheduled run fetches new token (performance opportunity)
4. **Manual Kafka commits** - don't use auto-commit, it breaks retry logic
5. **WAR deployment** requires `ServletInitializer` extending `SpringBootServletInitializer`

## Testing Patterns

Mock external calls in this order:
```java
@Mock Environment env;  // Config properties
@Mock EventRepository eventRepository;  // DB queries
@Mock RestTemplateService restTemplateService;  // JWT + API calls
@Mock KafkaConsumer kafkaConsumerMock;  // Kafka message simulation
```

See `SendInfoToCoreComponentTest.java` for reference data format (JSON strings with all required fields).

---

**Further Reading**: See `DOCUMENTACION.md` for detailed Spanish documentation including sequence diagrams and error handling flows.
