# Documentación del Proyecto: Send Payment Core Service

## 📋 Índice
1. [Descripción General](#descripción-general)
2. [Arquitectura del Sistema](#arquitectura-del-sistema)
3. [Componentes Principales](#componentes-principales)
4. [Manejo de Colas Kafka](#manejo-de-colas-kafka)
5. [Flujo de Procesamiento](#flujo-de-procesamiento)
6. [Modelos de Datos](#modelos-de-datos)
7. [Configuración](#configuración)
8. [Integración con APIs Externas](#integración-con-apis-externas)
9. [Despliegue](#despliegue)

---

## 🎯 Descripción General

**Send Payment Core Service** es un microservicio desarrollado en Spring Boot 2.7.14 que actúa como intermediario entre las pasarelas de pago (gateways) y los sistemas Core de Bancoldex (T24 y AS400). 

### Propósito
- Recibir confirmaciones de pagos desde pasarelas de pago a través de Kafka
- Procesar y transformar la información según el sistema Core destino (T24 o AS400)
- Enviar las transacciones procesadas a los sistemas Core correspondientes
- Mantener un registro de auditoría de todas las transacciones

### Información Técnica
- **Versión**: 0.0.3-SNAPSHOT
- **Java**: 11
- **Spring Boot**: 2.7.14
- **Empaquetado**: WAR
- **Puerto**: 8080

---

## 🏗️ Arquitectura del Sistema

### Diagrama de Arquitectura

```
┌─────────────────────┐
│  Pasarelas de Pago  │
│     (WOMPI, etc)    │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────────────────────────────────────────────┐
│                    KAFKA CLUSTER                            │
│  ┌──────────────────┐  ┌─────────────────┐  ┌────────────┐ │
│  │ Confirmaciones   │  │ Pendientes      │  │ Errores    │ │
│  │ Pasarela         │  │ Validación CORE │  │            │ │
│  └──────────────────┘  └─────────────────┘  └────────────┘ │
└───────────┬─────────────────────┬───────────────────────────┘
            │                     │
            ▼                     ▼
┌─────────────────────────────────────────────────────────────┐
│          SEND PAYMENT CORE SERVICE                          │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  @KafkaListener (Confirmacionespasarela)             │   │
│  └──────────────────┬───────────────────────────────────┘   │
│                     │                                        │
│                     ▼                                        │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  MessageProducer → PendientesValidacionCORE          │   │
│  └──────────────────┬───────────────────────────────────┘   │
│                     │                                        │
│                     ▼                                        │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  @Scheduled (cada 10 segundos)                       │   │
│  │  - Consume PendientesValidacionCORE                  │   │
│  │  - Valida y transforma datos                         │   │
│  │  - Integración con Oracle DB                         │   │
│  └──────────────────┬───────────────────────────────────┘   │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│              API SEGURIDAD (JWT)                            │
└──────────────────┬──────────────────────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────────────────────┐
│              API CORE BANCOLDEX                             │
│  ┌──────────────────┐         ┌──────────────────┐         │
│  │    Core T24      │         │    Core AS400    │         │
│  └──────────────────┘         └──────────────────┘         │
└─────────────────────────────────────────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────────────────────┐
│              ORACLE DATABASE                                │
│  - confirm_payment (eventos)                                │
│  - log_confirm_payment (auditoría)                          │
│  - channel (canales)                                        │
│  - gateway (pasarelas)                                      │
└─────────────────────────────────────────────────────────────┘
```

---

## 🔧 Componentes Principales

### 1. SendPaymentCoreComponent
**Ubicación**: `component/SendPaymentCoreComponent.java`

**Responsabilidades**:
- Escuchar el tópico de confirmaciones de pasarela
- Reenviar mensajes al tópico de pendientes
- Ejecutar procesamiento periódico cada 10 segundos

**Características principales**:
```java
@KafkaListener(topics = "${kafka.topic.confirm-payment}")
public void listenConfirmTopic(String message)
```
- **Entrada**: Mensajes del tópico `Confirmacionespasarela`
- **Salida**: Mensajes al tópico `PendientesValidacionCORE`

```java
@Scheduled(fixedDelay = 10000)
public void sendInfoToApiCore()
```
- **Frecuencia**: Cada 10 segundos
- **Función**: Procesa mensajes pendientes y los envía al Core

### 2. SendInfoToCoreComponent
**Ubicación**: `component/SendInfoToCoreComponent.java`

**Responsabilidades principales**:

#### a) Procesamiento de Mensajes Kafka
```java
public void processMessagesKafka(KafkaConsumer<String, String> kafkaConsumer)
```
- Consume mensajes del tópico de pendientes
- Valida y procesa cada mensaje
- Gestiona commits manuales de offset
- Reintenta envíos fallidos

#### b) Construcción de Payloads para T24
```java
public JSONObject buildT24JsonObjectRequest(...)
```
**Estructura del JSON para T24**:
```json
{
  "idCliente": "NIT del cliente",
  "referencia": "Referencia de la transacción",
  "identificacionPago": "ID de referencia único",
  "idCredito": "Obligación/crédito",
  "tipoPago": "Tipo de pago",
  "fechaPago": "YYYYMMDD",
  "horaPago": "HH:MM",
  "valorPago": "Monto en centavos",
  "origenPago": "Canal de origen",
  "medioPago": "Pasarela de pago (ej: WOMPI)"
}
```

#### c) Construcción de Payloads para AS400
```java
public JSONObject buildAS400JsonObjectRequest(...)
```
**Estructura del JSON para AS400**:
```json
{
  "pseidapli": "ID de aplicación",
  "pseidtran": 0,
  "psefectra": "Fecha transacción (YYYYMMDD)",
  "psehortra": "Hora transacción (HHMMSS)",
  "psenitcli": "NIT del cliente",
  "psesuc": 105,
  "pselinea": 100,
  "psenoper": "Número de operación/obligación",
  "psefecrec": "Fecha recepción",
  "psehorrec": "Hora recepción",
  "psecanal": "Canal",
  "psevaltra": "Valor transacción en centavos",
  "psetipapl": "Tipo de aplicación/pago",
  "pseestado": 1,
  "pseresult": ""
}
```

#### d) Validación y Envío al Core
```java
public boolean sendInfoToApiCore(String elementData)
```
**Lógica**:
1. Parsea el mensaje JSON
2. Consulta el evento en la base de datos
3. Valida que no haya sido procesado (`stateCore != 2 && stateCore != 3`)
4. Construye el payload según el sistema Core destino
5. Obtiene token JWT de autenticación
6. Envía al API Core
7. Actualiza estado del evento (`stateCore = 2`) si es exitoso
8. Genera registro de auditoría en `log_confirm_payment`

### 3. RestTemplateService
**Ubicación**: `util/RestTemplateService.java`

**Funciones**:
- Obtención de token JWT desde API de seguridad
- Invocación de API Core con autenticación
- Manejo de respuestas HTTP

**Flujo de autenticación**:
```java
public String getJwtToken()
```
1. Construye URL con credenciales
2. Realiza POST a `/login`
3. Extrae JWT del rol específico: "Orquestador de pagos"
4. Retorna token para uso en llamadas al Core

---

## 🔄 Manejo de Colas Kafka

### Arquitectura de Colas

El servicio implementa un patrón de **procesamiento asíncrono con reintentos** utilizando tres tópicos Kafka:

```
┌──────────────────────────────────────────────────────────────┐
│                    FLUJO DE COLAS KAFKA                       │
└──────────────────────────────────────────────────────────────┘

1. Confirmacionespasarela (kafka.topic.confirm-payment)
   └─> Recibe confirmaciones de pasarelas de pago
   
2. PendientesValidacionCORE (kafka.topic.pendiente-core-payment)
   └─> Cola de procesamiento y reintentos
   
3. transaccionesError (kafka.topic.error-payment)
   └─> Cola de errores (reservada para implementación futura)
```

### Configuración de Kafka

#### Consumer Configuration
**Archivo**: `util/kafka/KafkaConsumerConfig.java`

```java
@Bean
public Properties consumerFactory() {
    Properties props = new Properties();
    props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, 
              env.getProperty("spring.kafka.bootstrap-servers"));
    props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, 
              StringDeserializer.class);
    props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, 
              StringDeserializer.class);
    props.put(ConsumerConfig.GROUP_ID_CONFIG, "EnviosPagosCore");
    props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);
    return props;
}
```

**Características clave**:
- **Group ID**: `EnviosPagosCore` - Garantiza procesamiento en grupo
- **Auto Commit**: `false` - Control manual de offsets para garantizar procesamiento exitoso
- **Deserialización**: `StringDeserializer` - Los mensajes se procesan como texto JSON

#### Producer Configuration
**Archivo**: `util/kafka/KafkaProducerConfig.java`

```java
@Bean
public ProducerFactory<String, String> producerFactory() {
    Map<String, Object> configProps = new HashMap<>();
    configProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, 
                    env.getProperty("spring.kafka.bootstrap-servers"));
    configProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, 
                    StringSerializer.class);
    configProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, 
                    StringSerializer.class);
    return new DefaultKafkaProducerFactory<>(configProps);
}
```

### MessageConsumer
**Archivo**: `util/kafka/MessageConsumer.java`

**Función**: Crear consumidores Kafka con gestión de offsets

```java
public KafkaConsumer<String, String> getKafkaConsumer(String topic)
```

**Proceso**:
1. Crea instancia de `KafkaConsumer`
2. Se suscribe al tópico especificado
3. Espera asignación de particiones (polling hasta obtenerlas)
4. Busca offsets comprometidos previamente
5. Posiciona el consumidor en el último offset procesado
6. Si no hay offsets previos, inicia desde el principio (`seekToBeginning`)

**Ventajas**:
- Garantiza no perder mensajes en reinicios del servicio
- Permite procesamiento desde la última posición conocida
- Evita duplicados al gestionar commits manualmente

### MessageProducer
**Archivo**: `util/kafka/MessageProducer.java`

**Función**: Enviar mensajes a tópicos Kafka

```java
public void sendMessage(String topic, String message) {
    kafkaTemplate.send(topic, message);
}
```

### Estrategia de Procesamiento

#### 1. Recepción Inicial (Listener)
```java
@KafkaListener(topics = "${kafka.topic.confirm-payment}")
public void listenConfirmTopic(String message) {
    messageProducer.sendMessage(
        env.getProperty("kafka.topic.pendiente-core-payment"), 
        message
    );
}
```
- Escucha activamente el tópico de confirmaciones
- Reenvía inmediatamente a cola de pendientes
- Desacopla la recepción del procesamiento pesado

#### 2. Procesamiento por Lotes (Scheduled)
```java
@Scheduled(fixedDelay = 10000)
public void sendInfoToApiCore() throws Exception {
    sendInfoToCoreComponent.processMessagesKafka(
        messageConsumer.getKafkaConsumer(
            env.getProperty("kafka.topic.pendiente-core-payment")
        )
    );
}
```
- Ejecuta cada 10 segundos
- Procesa mensajes en lotes
- Permite acumulación y procesamiento eficiente

#### 3. Procesamiento con Reintentos
```java
public void processMessagesKafka(KafkaConsumer<String, String> kafkaConsumer) {
    ConsumerRecords<String, String> records = 
        kafkaConsumer.poll(Duration.ofSeconds(10));
    
    Map<TopicPartition, OffsetAndMetadata> commitMap = new HashMap<>();
    
    for (ConsumerRecord<String, String> rec : records) {
        if(!sendInfoToApiCore(rec.value())) {
            // Si falla, reenvía a la misma cola para reintento
            messageProducer.sendMessage(
                env.getProperty("kafka.topic.pendiente-core-payment"),
                rec.value()
            );
        }
        // Commit manual del offset
        commitMap.put(
            new TopicPartition(rec.topic(), rec.partition()), 
            new OffsetAndMetadata(rec.offset() + 1)
        );
        kafkaConsumer.commitSync(commitMap);
    }
}
```

**Características del manejo de reintentos**:
- **Commit manual**: Solo después de procesar (exitoso o reintento encolado)
- **Reintento automático**: Mensajes fallidos vuelven a la cola
- **Sin pérdida de mensajes**: El commit garantiza que todo se procese
- **Idempotencia**: La validación de `stateCore` evita duplicados

### Gestión de Estados

El servicio utiliza el campo `stateCore` para controlar el procesamiento:

| Estado | Significado | Acción |
|--------|-------------|--------|
| `null` o `1` | Pendiente de procesar | Se procesa normalmente |
| `2` | Procesado exitosamente | Se omite (idempotencia) |
| `3` | Error permanente | Se omite (evita loops infinitos) |

```java
if((eventProcess.getStateCore() == null) || 
   (eventProcess.getStateCore() != 2 && eventProcess.getStateCore() != 3)) {
    // Procesar
} else {
    // Omitir - ya procesado
    response = true;
}
```

### Ventajas del Diseño de Colas

1. **Desacoplamiento**: La recepción es independiente del procesamiento
2. **Resilencia**: Reintentos automáticos sin pérdida de mensajes
3. **Escalabilidad**: Procesamiento por lotes optimiza recursos
4. **Auditabilidad**: Cada mensaje deja rastro en base de datos
5. **Idempotencia**: Evita procesamiento duplicado
6. **Control manual**: Commits explícitos garantizan consistencia

---

## 🌊 Flujo de Procesamiento

### Flujo Completo de un Pago

```
┌────────────────────────────────────────────────────────────────┐
│ FASE 1: RECEPCIÓN                                              │
└────────────────────────────────────────────────────────────────┘
  1. Pasarela de pago (WOMPI) envía confirmación
     └─> Tópico Kafka: "Confirmacionespasarela"
  
  2. @KafkaListener recibe mensaje
     └─> Valida formato JSON
     └─> Reenvía a "PendientesValidacionCORE"

┌────────────────────────────────────────────────────────────────┐
│ FASE 2: PROCESAMIENTO PROGRAMADO                               │
└────────────────────────────────────────────────────────────────┘
  3. Scheduler cada 10 segundos
     └─> Consume mensajes de "PendientesValidacionCORE"
     └─> Poll con timeout de 10 segundos
  
  4. Por cada mensaje:
     a) Parsea JSON del evento
     b) Consulta evento en tabla confirm_payment por ID
     c) Valida stateCore (debe ser null, 1, o diferente de 2/3)

┌────────────────────────────────────────────────────────────────┐
│ FASE 3: TRANSFORMACIÓN                                         │
└────────────────────────────────────────────────────────────────┘
  5. Extrae referencia del mensaje (formato: campo1|campo2|...|campo6)
     Componentes de la referencia:
     - [0]: Obligación (ID crédito)
     - [1]: NIT del cliente
     - [2]: (no usado en el código actual)
     - [3]: ID del canal
     - [4]: ID del Core (3=T24, otro=AS400)
     - [5]: Tipo de pago
  
  6. Determina sistema Core destino:
     └─> Si reference[4] == "3" → T24
     └─> Caso contrario → AS400
  
  7. Consulta datos relacionales:
     - Obtiene nombre del canal desde tabla "channel"
     - Obtiene nombre de gateway desde tabla "gateway"
  
  8. Construye payload específico:
     └─> buildT24JsonObjectRequest() para T24
     └─> buildAS400JsonObjectRequest() para AS400

┌────────────────────────────────────────────────────────────────┐
│ FASE 4: AUTENTICACIÓN                                          │
└────────────────────────────────────────────────────────────────┘
  9. Obtiene token JWT:
     └─> POST a API Seguridad con user/password
     └─> Busca rol "Orquestador de pagos"
     └─> Extrae JWT del rol

┌────────────────────────────────────────────────────────────────┐
│ FASE 5: ENVÍO AL CORE                                          │
└────────────────────────────────────────────────────────────────┘
  10. Invoca API Core:
      └─> POST con token Bearer
      └─> URL desde configuración o desde evento (urlCore)
      └─> Body: JSON construido en paso 8
  
  11. Evalúa respuesta:
      └─> HTTP 200: Éxito
      └─> Otro código: Error

┌────────────────────────────────────────────────────────────────┐
│ FASE 6: ACTUALIZACIÓN Y AUDITORÍA                              │
└────────────────────────────────────────────────────────────────┘
  12. Si éxito (HTTP 200):
      a) Actualiza evento:
         - stateCore = 2
      b) Crea registro en log_confirm_payment:
         - Copia todos los datos del evento
         - stateCore = 2
      c) Retorna true (no reintenta)
  
  13. Si error:
      a) Log del error
      b) Retorna false
      c) Mensaje se reenvía a "PendientesValidacionCORE"
      d) Se reintentará en siguiente ejecución programada

┌────────────────────────────────────────────────────────────────┐
│ FASE 7: COMMIT KAFKA                                           │
└────────────────────────────────────────────────────────────────┘
  14. Commit manual del offset:
      - Se ejecuta SIEMPRE (éxito o reintento)
      - Garantiza que el mensaje fue manejado
      - Evita reprocesar el mismo offset
```

### Ejemplo de Mensaje

**Entrada desde Kafka** (Confirmacionespasarela):
```json
{
  "id": 123456,
  "event": "transaction.updated",
  "idRef": "abc-123-xyz",
  "amount_in_cents": 5000000,
  "reference": "987654|900123456|canal|1|3|CUOTA",
  "customer_email": "cliente@example.com",
  "currency": "COP",
  "payment_method_type": "CARD",
  "status": "APPROVED",
  "timestamp": 1699704000,
  "sent_at": "2024-11-11T10:00:00Z"
}
```

**Transformación para T24**:
```json
{
  "idCliente": "900123456",
  "referencia": "abc-123-xyz",
  "identificacionPago": "abc-123-xyz",
  "idCredito": "987654",
  "tipoPago": "CUOTA",
  "fechaPago": "20241111",
  "horaPago": "10:00",
  "valorPago": 5000000,
  "origenPago": "Portal Web",
  "medioPago": "WOMPI"
}
```

**Transformación para AS400**:
```json
{
  "pseidapli": 123456,
  "pseidtran": 0,
  "psefectra": 20241111,
  "psehortra": 100000,
  "psenitcli": "900123456",
  "psesuc": 105,
  "pselinea": 100,
  "psenoper": "987654",
  "psefecrec": 20230912,
  "psehorrec": 100000,
  "psecanal": "1",
  "psevaltra": 5000000,
  "psetipapl": "CUOTA",
  "pseestado": 1,
  "pseresult": ""
}
```

---

## 💾 Modelos de Datos

### Entidades JPA

#### 1. Event
**Tabla**: `confirm_payment`
**Propósito**: Almacenar eventos de confirmación de pago

```java
@Entity
@Table(name = "confirm_payment")
public class Event {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ")
    private Long id;                    // ID autoincremental
    private String event;               // Tipo de evento
    private String idRef;               // ID de referencia único
    private String amount_in_cents;     // Monto en centavos
    private String reference;           // Referencia completa (formato pipe-separated)
    private String customer_email;      // Email del cliente
    private String currency;            // Moneda (COP)
    private String payment_method_type; // Tipo de método de pago
    private String redirect_url;        // URL de redirección
    private String status;              // Estado del pago
    private String shipping_address;    // Dirección de envío
    private String payment_link_id;     // ID del link de pago
    private String payment_source_id;   // ID de la fuente de pago
    private String environment;         // Ambiente (prod/test)
    private String checksum;            // Checksum de validación
    private String timestamp;           // Timestamp del evento
    private Date sent_at;               // Fecha de envío
    private String urlCore;             // URL del Core (opcional)
    private Integer stateCore = 1;      // Estado de procesamiento Core
}
```

**Estados de stateCore**:
- `1`: Pendiente de procesar
- `2`: Procesado exitosamente
- `3`: Error permanente

#### 2. LogEvent
**Tabla**: `log_confirm_payment`
**Propósito**: Registro de auditoría de eventos procesados

```java
@Entity
@Table(name = "log_confirm_payment")
public class LogEvent {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ")
    private Long id;
    private String event;
    private String idRef;
    @JoinColumn(name = "amount_in_cents")
    private String amountInCents;
    private String reference;
    @JoinColumn(name = "customer_email")
    private String customerEmail;
    // ... (mismos campos que Event con notación camelCase)
    private Integer stateCore = 1;
}
```

#### 3. Channel
**Tabla**: `channel`
**Propósito**: Catálogo de canales de origen de pago

```java
@Entity
@Table(name = "channel")
public class Channel {
    @Id
    private int id;
    @Column(name="NAME_CHANNEL")
    private String nameChannel;     // Nombre del canal (ej: "Portal Web")
    @Column(name="STATE_CHANNEL")
    private String stateChannel;    // Estado del canal (activo/inactivo)
}
```

#### 4. Gateway
**Tabla**: `gateway`
**Propósito**: Catálogo de pasarelas de pago

```java
@Entity
@Table(name = "gateway")
public class Gateway {
    @Id
    private int id;
    @Column(name="NAME_GATEWAY")
    private String nameGateway;     // Nombre de la pasarela (ej: "WOMPI")
}
```

### Repositorios

```java
public interface EventRepository extends JpaRepository<Event, Long> {
    Event getOneById(Long id);
    Optional<Event> findFirstByIdRef(String idRef);
}

public interface LogEventRepository extends JpaRepository<LogEvent, Long> {
}

public interface ChannelRepository extends JpaRepository<Channel, Integer> {
}

public interface GatewayRepository extends JpaRepository<Gateway, Integer> {
}
```

---

## ⚙️ Configuración

### application.properties

```properties
# ==================== SERVER ====================
server.port=8080

# ==================== KAFKA ====================
spring.kafka.bootstrap-servers=localhost:9092
spring.kafka.consumer.group-id=EnviosPagosCore

# Tópicos Kafka
kafka.topic.confirm-payment=Confirmacionespasarela
kafka.topic.error-payment=transaccionesError
kafka.topic.pendiente-core-payment=PendientesValidacionCORE

# ==================== API CORE ====================
com.bancoldex.apicore.url=http://localhost:8099/apicorebx-orquestador-svc/

# ==================== SEGURIDAD ====================
application.security.url=http://172.31.10.18:9503/apiseguridad
com.bancoldex.security.user=orquestador.pagos
com.bancoldex.security.pwd=bc028f45a230b22f79936ba4ce99cd9f
com.bancoldex.security.rolname=Orquestador de pagos

# ==================== AS400 ====================
# Fecha recepción para AS400 (YYYYMMDD)
# Si es "default" o vacío, usa fecha transacción
com.bancoldex.psefecrec=20230912

# ==================== DATABASE ====================
spring.datasource.url=jdbc:oracle:thin:@//host:1521/ORCLPDB1
spring.datasource.username=dev
spring.datasource.password=pass1234
spring.datasource.hikari.schema=DEV

# JPA/Hibernate
spring.jpa.hibernate.ddl-auto=none
spring.jpa.show-sql=false
spring.jpa.properties.hibernate.format_sql=true
spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.Oracle10gDialect

# Hikari Connection Pool
spring.datasource.hikari.maxLifeTime=600000
spring.datasource.hikari.minimum-idle=0
spring.datasource.hikari.initialization-fail-timeout=-1
spring.datasource.continue-on-error=true
```

### Variables de Entorno para Despliegue

El archivo `application.properties.token` utiliza reemplazo de tokens en el pipeline:

```properties
# Estas variables son reemplazadas en tiempo de despliegue
spring.kafka.bootstrap-servers=#{KAFKA_BOOTSTRAP_SERVERS}#
kafka.topic.confirm-payment=#{KAFKA_TOPIC_CONFIRM}#
kafka.topic.error-payment=#{KAFKA_TOPIC_ERROR}#
kafka.topic.pendiente-core-payment=#{KAFKA_TOPIC_PENDING}#

com.bancoldex.apicore.url=#{API_CORE_URL}#
application.security.url=#{API_SECURITY_URL}#
com.bancoldex.security.user=#{SECURITY_USER}#
com.bancoldex.security.pwd=#{SECURITY_PWD}#

spring.datasource.url=#{DB_URL}#
spring.datasource.username=#{DB_USERNAME}#
spring.datasource.password=#{DB_PASSWORD}#
spring.datasource.hikari.schema=#{DB_SCHEMA}#
```

---

## 🔗 Integración con APIs Externas

### 1. API de Seguridad

**Endpoint**: `/login`
**Método**: POST
**Propósito**: Obtener token JWT para autenticación

**Request**:
```
POST /login?username=orquestador.pagos&password=bc028f45a230b22f79936ba4ce99cd9f
```

**Response**:
```json
{
  "permisosRol": [
    {
      "rol": "Orquestador de pagos",
      "jwt": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
      "permisos": [...]
    }
  ]
}
```

**Uso en el código**:
```java
public String getJwtToken() {
    ResponseEntity<String> response = restTemplate.exchange(
        uri, HttpMethod.POST, headerList, String.class
    );
    return generatedJwt(response).orElse(null);
}
```

### 2. API Core Bancoldex

**Endpoint**: Variable (según configuración)
**Método**: POST
**Propósito**: Registrar transacción en sistema Core

**Request Headers**:
```
Authorization: Bearer {JWT_TOKEN}
Content-Type: application/json
```

**Request Body** (ejemplo T24):
```json
{
  "idCliente": "900123456",
  "referencia": "abc-123-xyz",
  "identificacionPago": "abc-123-xyz",
  "idCredito": "987654",
  "tipoPago": "CUOTA",
  "fechaPago": "20241111",
  "horaPago": "10:00",
  "valorPago": 5000000,
  "origenPago": "Portal Web",
  "medioPago": "WOMPI"
}
```

**Response esperada**:
```json
{
  "status": "success",
  "message": "Transacción registrada exitosamente",
  "transactionId": "TX-123456"
}
```

**Manejo de errores**:
```java
try {
    ResponseEntity<ValidationResponse> response = 
        callServiceApiCore(token, uri, jsonObject);
    
    if (response.getStatusCodeValue() == 200) {
        // Éxito
        generatedEvent(eventProcess);
    } else {
        // Error - se reintentará
        logger.log(Level.INFO, "Error del API-Core: " + 
                   response.getStatusCodeValue());
    }
} catch (HttpStatusCodeException ex) {
    // Extrae información de error del header x-app-err-id
    String errorMessageId = ex.getResponseHeaders()
                              .get("x-app-err-id")
                              .get(0);
    logger.log(Level.INFO, errorMessageId);
}
```

---

## 🚀 Despliegue

### Dockerfile

**Ubicación**: `dockerfile`

```dockerfile
# Etapa de construcción
FROM eclipse-temurin:11-jdk AS build
WORKDIR /app
COPY . .
RUN ./mvnw clean package -DskipTests

# Etapa final
FROM eclipse-temurin:11-jre
VOLUME /tmp
EXPOSE 8080
COPY --from=build /app/target/send-payment-core-service-0.0.3-SNAPSHOT.war /app.war
ENTRYPOINT ["java", "-jar", "/app.war"]
```

**Características**:
- **Multi-stage build**: Optimiza tamaño de imagen final
- **Base image**: Eclipse Temurin JDK 11
- **Puerto**: 8080
- **Empaquetado**: WAR ejecutable

### Pipeline CI/CD (Azure DevOps)

**Archivo**: `azure-pipelines.yml`

#### Etapas del Pipeline

**1. Reemplazo de Tokens**
```yaml
- task: replacetokens@5
  displayName: Replace tokens config
  inputs:
    rootDirectory: '$(System.DefaultWorkingDirectory)/$(DOCKERFILELOCATION)/src/main/resources'
    targetFiles: 'application.properties.token => application.properties'
```

**2. Compilación y Tests**
```yaml
- template: templates/compilation-tests.yml
  parameters:
    skipSonar: false  # Para dev y qa
```

**3. Construcción de Imagen Docker**
```yaml
- task: Docker@2
  displayName: Build an image
  inputs:
    command: 'build'
    Dockerfile: '$(DOCKERFILELOCATION)/dockerfile'
    repository: '$(REPOSITORYNAME)'
```

**4. Push a ECR (AWS)**
```yaml
- task: ECRPushImage@1
  inputs:
    awsCredentials: '$(AWSCREDENTIALS)'
    regionName: '$(REGIONNAME)'
    sourceImageName: '$(SOURCEIMAGENAME)'
    sourceImageTag: $(Build.BuildId)
    pushTag: '$(IMAGETAG)'
    repositoryName: '$(REPOSITORYNAME)'
```

**5. Preparación de Manifiestos Kubernetes**
```yaml
- task: replacetokens@5
  displayName: Replace tokens manifests
  inputs:
    rootDirectory: '$(System.DefaultWorkingDirectory)/manifests'
    targetFiles: '*.yml'
```

#### Ambientes

El pipeline se ejecuta según la rama:

| Rama | Ambiente | SonarQube |
|------|----------|-----------|
| `dev` | Desarrollo | ✓ |
| `qa` | QA | ✓ |
| `cert` | Certificación | ✗ |
| `main` | Producción | ✗ |

### Manifiestos Kubernetes

#### Deployment
**Archivo**: `manifests/deployment.yml`

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: send-payment-core-service
spec:
  replicas: #{REPLICAS}#
  selector:
    matchLabels:
      app: send-payment-core-service
  template:
    metadata:
      labels:
        app: send-payment-core-service
    spec:
      containers:
      - name: send-payment-core-service
        image: #{ECR_REPOSITORY}#:#{IMAGE_TAG}#
        ports:
        - containerPort: 8080
        env:
        - name: SPRING_PROFILES_ACTIVE
          value: "#{SPRING_PROFILE}#"
        resources:
          requests:
            memory: "#{MEMORY_REQUEST}#"
            cpu: "#{CPU_REQUEST}#"
          limits:
            memory: "#{MEMORY_LIMIT}#"
            cpu: "#{CPU_LIMIT}#"
```

#### Service
**Archivo**: `manifests/service.yml`

```yaml
apiVersion: v1
kind: Service
metadata:
  name: send-payment-core-service
spec:
  type: #{SERVICE_TYPE}#
  selector:
    app: send-payment-core-service
  ports:
  - protocol: TCP
    port: 80
    targetPort: 8080
```

### Comandos de Construcción Local

```bash
# Compilar con Maven
./mvnw clean package

# Construir imagen Docker
docker build -t send-payment-core-service:latest .

# Ejecutar contenedor
docker run -p 8080:8080 \
  -e SPRING_KAFKA_BOOTSTRAP_SERVERS=kafka:9092 \
  -e SPRING_DATASOURCE_URL=jdbc:oracle:thin:@//db:1521/ORCLPDB1 \
  send-payment-core-service:latest
```

---

## 📊 Dependencias Principales

### Spring Boot & Core
- `spring-boot-starter-web` (2.7.14)
- `spring-boot-starter-data-jpa`
- `spring-boot-starter-jdbc`
- `spring-kafka`

### Base de Datos
- `ojdbc10` (Oracle JDBC Driver 19.20.0.0)

### Mensajería
- `spring-kafka` (incluido en Spring Boot)

### Utilidades
- `lombok` - Reducción de boilerplate
- `gson` - Serialización JSON
- `guava` (31.0.1-jre) - Utilidades de Google
- `unirest-java` (3.14.5) - Cliente HTTP simplificado

### Testing
- `spring-boot-starter-test`
- `mockito-core` (4.5.1)
- `junit-jupiter` (5.8.2)
- `wiremock` (2.27.2)

---

## 🔍 Monitoreo y Logs

### Logging

El servicio utiliza `java.util.logging.Logger`:

```java
Logger logger = Logger.getLogger(ClassName.class.getName());
logger.log(Level.INFO, "Mensaje informativo");
logger.log(Level.SEVERE, "Error crítico");
```

**Niveles de log importantes**:
- `INFO`: Flujo normal, confirmaciones, datos procesados
- `SEVERE`: Errores críticos, excepciones

### Puntos de Log Clave

1. **Recepción de mensajes**:
```java
logger.log(Level.INFO, "Mensaje de confirmacion");
logger.log(Level.INFO, message);
```

2. **Procesamiento**:
```java
logger.log(Level.INFO, "Elemento Cola kafka " + elementData);
```

3. **Envío al Core**:
```java
logger.log(Level.INFO, "Envio a API-Core ::: " + jsonObject);
logger.log(Level.INFO, "Respuesta positiva de API-Core ::: " + response);
```

4. **Errores**:
```java
logger.log(Level.INFO, "Error del API-Core " + statusCode);
logger.log(Level.SEVERE, exception.getMessage());
```

### Métricas Recomendadas

Para producción, se recomienda implementar:

- **Micrometer**: Métricas de Spring Boot
- **Prometheus**: Recolección de métricas
- **Grafana**: Visualización
- **ELK Stack**: Agregación de logs

**Métricas clave a monitorear**:
- Mensajes consumidos por segundo
- Mensajes procesados exitosamente
- Mensajes con error (tasa de reintentos)
- Latencia de llamadas al API Core
- Tiempo de procesamiento por mensaje
- Tamaño de cola de pendientes

---

## 🔐 Seguridad

### Autenticación
- **JWT Token**: Obtenido desde API de Seguridad
- **Rol específico**: "Orquestador de pagos"
- **Renovación**: Se obtiene nuevo token en cada llamada al Core

### Credenciales
- Almacenadas en `application.properties`
- Reemplazadas por tokens en despliegue
- **Recomendación**: Migrar a secrets management (Azure Key Vault, AWS Secrets Manager)

### Base de Datos
- Conexión con usuario/contraseña
- Connection pooling con Hikari
- Schema específico por ambiente

---

## 🧪 Testing

### Estructura de Tests

El proyecto incluye tests para:

- **Componentes**: `SendPaymentCoreComponentTest`, `SendInfoToCoreComponentTest`
- **DTOs**: `LoginResponseDiffblueTest`, `PermisosRolDiffblueTest`
- **Modelos**: `EventDiffblueTest`, `LogEventDiffblueTest`
- **Utilidades**: `RestTemplateServiceTest`

### Ejecución de Tests

```bash
# Maven local
./mvnw test

# Con cobertura
./mvnw test jacoco:report

# En Docker (parte del build)
# Los tests se saltan con -DskipTests en el Dockerfile
```

---

## 📈 Mejoras Futuras Recomendadas

### 1. Manejo de Errores
- Implementar tópico de errores (`transaccionesError`)
- Dead Letter Queue (DLQ) para mensajes con múltiples fallos
- Política de reintentos con backoff exponencial

### 2. Observabilidad
- Integrar Spring Boot Actuator
- Métricas personalizadas con Micrometer
- Distributed tracing (Sleuth + Zipkin)

### 3. Seguridad
- Migrar credenciales a Secrets Manager
- Rotación automática de passwords
- Cifrado de datos sensibles en BD

### 4. Rendimiento
- Procesamiento paralelo de mensajes
- Batch inserts en base de datos
- Caché de consultas a catálogos (Channel, Gateway)

### 5. Resilencia
- Circuit breaker para llamadas al API Core (Resilience4j)
- Timeout configurables
- Health checks más robustos

---

## 📞 Contacto y Soporte

**Proyecto**: Send Payment Core Service
**Versión**: 0.0.3-SNAPSHOT
**Organización**: Bancoldex
**Año**: 2025

---

## 📝 Glosario

- **Core**: Sistemas centrales de Bancoldex (T24, AS400)
- **T24**: Sistema bancario core de Temenos
- **AS400**: Sistema legacy de IBM
- **Gateway**: Pasarela de pago (ej: WOMPI)
- **PSE**: Pagos Seguros en Línea
- **JWT**: JSON Web Token
- **Offset**: Posición en cola Kafka
- **Commit**: Confirmación de procesamiento de mensaje
- **Idempotencia**: Capacidad de ejecutar múltiples veces sin efectos duplicados

---

**Documento generado**: 2025-11-11
**Última actualización**: 2025-11-11
