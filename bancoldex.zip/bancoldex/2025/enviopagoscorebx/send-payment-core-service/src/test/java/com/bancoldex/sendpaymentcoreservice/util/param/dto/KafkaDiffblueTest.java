package com.bancoldex.sendpaymentcoreservice.util.param.dto;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class KafkaDiffblueTest {
    /**
     * Method under test: {@link Kafka#canEqual(Object)}
     */
    @Test
    void testCanEqual() {
        assertFalse((new Kafka("Kafka Confirm Topic", "Kafka Core Topic", "An error occurred")).canEqual("Other"));
    }

    /**
     * Method under test: {@link Kafka#canEqual(Object)}
     */
    @Test
    void testCanEqual2() {
        Kafka buildResult = Kafka.builder()
                .kafkaConfirmTopic("Kafka Confirm Topic")
                .kafkaCoreTopic("Kafka Core Topic")
                .kafkaErrorTopic("An error occurred")
                .build();
        assertTrue(buildResult.canEqual(Kafka.builder()
                .kafkaConfirmTopic("Kafka Confirm Topic")
                .kafkaCoreTopic("Kafka Core Topic")
                .kafkaErrorTopic("An error occurred")
                .build()));
    }

    /**
     * Methods under test:
     *
     * <ul>
     *   <li>{@link Kafka#Kafka()}
     *   <li>{@link Kafka#setKafkaConfirmTopic(String)}
     *   <li>{@link Kafka#setKafkaCoreTopic(String)}
     *   <li>{@link Kafka#setKafkaErrorTopic(String)}
     *   <li>{@link Kafka#toString()}
     *   <li>{@link Kafka#getKafkaConfirmTopic()}
     *   <li>{@link Kafka#getKafkaCoreTopic()}
     *   <li>{@link Kafka#getKafkaErrorTopic()}
     * </ul>
     */
    @Test
    void testConstructor() {
        Kafka actualKafka = new Kafka();
        actualKafka.setKafkaConfirmTopic("Kafka Confirm Topic");
        actualKafka.setKafkaCoreTopic("Kafka Core Topic");
        actualKafka.setKafkaErrorTopic("An error occurred");
        String actualToStringResult = actualKafka.toString();
        String actualKafkaConfirmTopic = actualKafka.getKafkaConfirmTopic();
        String actualKafkaCoreTopic = actualKafka.getKafkaCoreTopic();
        assertEquals("Kafka Confirm Topic", actualKafkaConfirmTopic);
        assertEquals("Kafka Core Topic", actualKafkaCoreTopic);
        assertEquals("An error occurred", actualKafka.getKafkaErrorTopic());
        assertEquals(
                "Kafka(kafkaConfirmTopic=Kafka Confirm Topic, kafkaCoreTopic=Kafka Core Topic, kafkaErrorTopic=An error"
                        + " occurred)",
                actualToStringResult);
    }

    /**
     * Methods under test:
     *
     * <ul>
     *   <li>{@link Kafka#Kafka(String, String, String)}
     *   <li>{@link Kafka#setKafkaConfirmTopic(String)}
     *   <li>{@link Kafka#setKafkaCoreTopic(String)}
     *   <li>{@link Kafka#setKafkaErrorTopic(String)}
     *   <li>{@link Kafka#toString()}
     *   <li>{@link Kafka#getKafkaConfirmTopic()}
     *   <li>{@link Kafka#getKafkaCoreTopic()}
     *   <li>{@link Kafka#getKafkaErrorTopic()}
     * </ul>
     */
    @Test
    void testConstructor2() {
        Kafka actualKafka = new Kafka("Kafka Confirm Topic", "Kafka Core Topic", "An error occurred");
        actualKafka.setKafkaConfirmTopic("Kafka Confirm Topic");
        actualKafka.setKafkaCoreTopic("Kafka Core Topic");
        actualKafka.setKafkaErrorTopic("An error occurred");
        String actualToStringResult = actualKafka.toString();
        String actualKafkaConfirmTopic = actualKafka.getKafkaConfirmTopic();
        String actualKafkaCoreTopic = actualKafka.getKafkaCoreTopic();
        assertEquals("Kafka Confirm Topic", actualKafkaConfirmTopic);
        assertEquals("Kafka Core Topic", actualKafkaCoreTopic);
        assertEquals("An error occurred", actualKafka.getKafkaErrorTopic());
        assertEquals(
                "Kafka(kafkaConfirmTopic=Kafka Confirm Topic, kafkaCoreTopic=Kafka Core Topic, kafkaErrorTopic=An error"
                        + " occurred)",
                actualToStringResult);
    }

    /**
     * Method under test: {@link Kafka#equals(Object)}
     */
    @Test
    void testEquals() {
        assertNotEquals(null, Kafka.builder()
                .kafkaConfirmTopic("Kafka Confirm Topic")
                .kafkaCoreTopic("Kafka Core Topic")
                .kafkaErrorTopic("An error occurred")
                .build());
        assertNotEquals("Different type to Kafka", Kafka.builder()
                .kafkaConfirmTopic("Kafka Confirm Topic")
                .kafkaCoreTopic("Kafka Core Topic")
                .kafkaErrorTopic("An error occurred")
                .build());
    }

    /**
     * Methods under test:
     *
     * <ul>
     *   <li>{@link Kafka#equals(Object)}
     *   <li>{@link Kafka#hashCode()}
     * </ul>
     */
    @Test
    void testEquals2() {
        Kafka buildResult = Kafka.builder()
                .kafkaConfirmTopic("Kafka Confirm Topic")
                .kafkaCoreTopic("Kafka Core Topic")
                .kafkaErrorTopic("An error occurred")
                .build();
        assertEquals(buildResult, buildResult);
        int expectedHashCodeResult = buildResult.hashCode();
        assertEquals(expectedHashCodeResult, buildResult.hashCode());
    }

    /**
     * Methods under test:
     *
     * <ul>
     *   <li>{@link Kafka#equals(Object)}
     *   <li>{@link Kafka#hashCode()}
     * </ul>
     */
    @Test
    void testEquals3() {
        Kafka buildResult = Kafka.builder()
                .kafkaConfirmTopic("Kafka Confirm Topic")
                .kafkaCoreTopic("Kafka Core Topic")
                .kafkaErrorTopic("An error occurred")
                .build();
        Kafka buildResult2 = Kafka.builder()
                .kafkaConfirmTopic("Kafka Confirm Topic")
                .kafkaCoreTopic("Kafka Core Topic")
                .kafkaErrorTopic("An error occurred")
                .build();
        assertEquals(buildResult, buildResult2);
        int expectedHashCodeResult = buildResult.hashCode();
        assertEquals(expectedHashCodeResult, buildResult2.hashCode());
    }

    /**
     * Method under test: {@link Kafka#equals(Object)}
     */
    @Test
    void testEquals4() {
        Kafka buildResult = Kafka.builder()
                .kafkaConfirmTopic("Kafka Core Topic")
                .kafkaCoreTopic("Kafka Core Topic")
                .kafkaErrorTopic("An error occurred")
                .build();
        assertNotEquals(buildResult,
                Kafka.builder()
                        .kafkaConfirmTopic("Kafka Confirm Topic")
                        .kafkaCoreTopic("Kafka Core Topic")
                        .kafkaErrorTopic("An error occurred")
                        .build());
    }

    /**
     * Method under test: {@link Kafka#equals(Object)}
     */
    @Test
    void testEquals5() {
        Kafka buildResult = Kafka.builder()
                .kafkaConfirmTopic(null)
                .kafkaCoreTopic("Kafka Core Topic")
                .kafkaErrorTopic("An error occurred")
                .build();
        assertNotEquals(buildResult,
                Kafka.builder()
                        .kafkaConfirmTopic("Kafka Confirm Topic")
                        .kafkaCoreTopic("Kafka Core Topic")
                        .kafkaErrorTopic("An error occurred")
                        .build());
    }

    /**
     * Method under test: {@link Kafka#equals(Object)}
     */
    @Test
    void testEquals6() {
        Kafka buildResult = Kafka.builder()
                .kafkaConfirmTopic("Kafka Confirm Topic")
                .kafkaCoreTopic("Kafka Confirm Topic")
                .kafkaErrorTopic("An error occurred")
                .build();
        assertNotEquals(buildResult,
                Kafka.builder()
                        .kafkaConfirmTopic("Kafka Confirm Topic")
                        .kafkaCoreTopic("Kafka Core Topic")
                        .kafkaErrorTopic("An error occurred")
                        .build());
    }

    /**
     * Method under test: {@link Kafka#equals(Object)}
     */
    @Test
    void testEquals7() {
        Kafka buildResult = Kafka.builder()
                .kafkaConfirmTopic("Kafka Confirm Topic")
                .kafkaCoreTopic(null)
                .kafkaErrorTopic("An error occurred")
                .build();
        assertNotEquals(buildResult,
                Kafka.builder()
                        .kafkaConfirmTopic("Kafka Confirm Topic")
                        .kafkaCoreTopic("Kafka Core Topic")
                        .kafkaErrorTopic("An error occurred")
                        .build());
    }

    /**
     * Method under test: {@link Kafka#equals(Object)}
     */
    @Test
    void testEquals8() {
        Kafka buildResult = Kafka.builder()
                .kafkaConfirmTopic("Kafka Confirm Topic")
                .kafkaCoreTopic("Kafka Core Topic")
                .kafkaErrorTopic("Kafka Confirm Topic")
                .build();
        assertNotEquals(buildResult,
                Kafka.builder()
                        .kafkaConfirmTopic("Kafka Confirm Topic")
                        .kafkaCoreTopic("Kafka Core Topic")
                        .kafkaErrorTopic("An error occurred")
                        .build());
    }

    /**
     * Method under test: {@link Kafka#equals(Object)}
     */
    @Test
    void testEquals9() {
        Kafka buildResult = Kafka.builder()
                .kafkaConfirmTopic("Kafka Confirm Topic")
                .kafkaCoreTopic("Kafka Core Topic")
                .kafkaErrorTopic(null)
                .build();
        assertNotEquals(buildResult,
                Kafka.builder()
                        .kafkaConfirmTopic("Kafka Confirm Topic")
                        .kafkaCoreTopic("Kafka Core Topic")
                        .kafkaErrorTopic("An error occurred")
                        .build());
    }

    /**
     * Methods under test:
     *
     * <ul>
     *   <li>{@link Kafka#equals(Object)}
     *   <li>{@link Kafka#hashCode()}
     * </ul>
     */
    @Test
    void testEquals10() {
        Kafka buildResult = Kafka.builder()
                .kafkaConfirmTopic(null)
                .kafkaCoreTopic("Kafka Core Topic")
                .kafkaErrorTopic("An error occurred")
                .build();
        Kafka buildResult2 = Kafka.builder()
                .kafkaConfirmTopic(null)
                .kafkaCoreTopic("Kafka Core Topic")
                .kafkaErrorTopic("An error occurred")
                .build();
        assertEquals(buildResult, buildResult2);
        int expectedHashCodeResult = buildResult.hashCode();
        assertEquals(expectedHashCodeResult, buildResult2.hashCode());
    }

    /**
     * Methods under test:
     *
     * <ul>
     *   <li>{@link Kafka#equals(Object)}
     *   <li>{@link Kafka#hashCode()}
     * </ul>
     */
    @Test
    void testEquals11() {
        Kafka buildResult = Kafka.builder()
                .kafkaConfirmTopic("Kafka Confirm Topic")
                .kafkaCoreTopic(null)
                .kafkaErrorTopic("An error occurred")
                .build();
        Kafka buildResult2 = Kafka.builder()
                .kafkaConfirmTopic("Kafka Confirm Topic")
                .kafkaCoreTopic(null)
                .kafkaErrorTopic("An error occurred")
                .build();
        assertEquals(buildResult, buildResult2);
        int expectedHashCodeResult = buildResult.hashCode();
        assertEquals(expectedHashCodeResult, buildResult2.hashCode());
    }

    /**
     * Methods under test:
     *
     * <ul>
     *   <li>{@link Kafka#equals(Object)}
     *   <li>{@link Kafka#hashCode()}
     * </ul>
     */
    @Test
    void testEquals12() {
        Kafka buildResult = Kafka.builder()
                .kafkaConfirmTopic("Kafka Confirm Topic")
                .kafkaCoreTopic("Kafka Core Topic")
                .kafkaErrorTopic(null)
                .build();
        Kafka buildResult2 = Kafka.builder()
                .kafkaConfirmTopic("Kafka Confirm Topic")
                .kafkaCoreTopic("Kafka Core Topic")
                .kafkaErrorTopic(null)
                .build();
        assertEquals(buildResult, buildResult2);
        int expectedHashCodeResult = buildResult.hashCode();
        assertEquals(expectedHashCodeResult, buildResult2.hashCode());
    }
}

