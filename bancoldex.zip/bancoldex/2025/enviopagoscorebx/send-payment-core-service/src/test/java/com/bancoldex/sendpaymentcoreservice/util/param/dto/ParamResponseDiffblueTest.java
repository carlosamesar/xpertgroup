package com.bancoldex.sendpaymentcoreservice.util.param.dto;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class ParamResponseDiffblueTest {
	/**
	 * Method under test: {@link ParamResponse#canEqual(Object)}
	 */
	@Test
	void testCanEqual() {
		assertFalse((new ParamResponse()).canEqual("Other"));
	}

	/**
	 * Method under test: {@link ParamResponse#canEqual(Object)}
	 */
	@Test
	void testCanEqual2() {
		ParamResponse.ParamResponseBuilder idResult = ParamResponse.builder().id(1L);
		ParamResponse buildResult = idResult.kafka(Kafka.builder().kafkaConfirmTopic("Kafka Confirm Topic")
				.kafkaCoreTopic("Kafka Core Topic").kafkaErrorTopic("An error occurred").build()).build();
		ParamResponse.ParamResponseBuilder idResult2 = ParamResponse.builder().id(1L);
		assertTrue(
				buildResult.canEqual(idResult2
						.kafka(Kafka.builder().kafkaConfirmTopic("Kafka Confirm Topic")
								.kafkaCoreTopic("Kafka Core Topic").kafkaErrorTopic("An error occurred").build())
						.build()));
	}

	/**
	 * Methods under test:
	 *
	 * <ul>
	 * <li>{@link ParamResponse#ParamResponse()}
	 * <li>{@link ParamResponse#setId(Long)}
	 * <li>{@link ParamResponse#setKafka(Kafka)}
	 * <li>{@link ParamResponse#toString()}
	 * <li>{@link ParamResponse#getId()}
	 * <li>{@link ParamResponse#getKafka()}
	 * </ul>
	 */
	@Test
	void testConstructor() {
		ParamResponse actualParamResponse = new ParamResponse();
		actualParamResponse.setId(1L);
		Kafka kafka = Kafka.builder().kafkaConfirmTopic("Kafka Confirm Topic").kafkaCoreTopic("Kafka Core Topic")
				.kafkaErrorTopic("An error occurred").build();
		actualParamResponse.setKafka(kafka);
		String actualToStringResult = actualParamResponse.toString();
		Long actualId = actualParamResponse.getId();
		Kafka actualKafka = actualParamResponse.getKafka();
		assertEquals(1L, actualId.longValue());
		assertSame(kafka, actualKafka);
		assertEquals(
				"ParamResponse(id=1, kafka=Kafka(kafkaConfirmTopic=Kafka Confirm Topic, kafkaCoreTopic=Kafka Core Topic,"
						+ " kafkaErrorTopic=An error occurred))",
				actualToStringResult);
	}

	/**
	 * Methods under test:
	 *
	 * <ul>
	 * <li>{@link ParamResponse#ParamResponse(Long, Kafka)}
	 * <li>{@link ParamResponse#setId(Long)}
	 * <li>{@link ParamResponse#setKafka(Kafka)}
	 * <li>{@link ParamResponse#toString()}
	 * <li>{@link ParamResponse#getId()}
	 * <li>{@link ParamResponse#getKafka()}
	 * </ul>
	 */
	@Test
	void testConstructor2() {
		Kafka kafka = Kafka.builder().kafkaConfirmTopic("Kafka Confirm Topic").kafkaCoreTopic("Kafka Core Topic")
				.kafkaErrorTopic("An error occurred").build();
		ParamResponse actualParamResponse = new ParamResponse(1L, kafka);
		actualParamResponse.setId(1L);
		Kafka kafka2 = Kafka.builder().kafkaConfirmTopic("Kafka Confirm Topic").kafkaCoreTopic("Kafka Core Topic")
				.kafkaErrorTopic("An error occurred").build();
		actualParamResponse.setKafka(kafka2);
		String actualToStringResult = actualParamResponse.toString();
		Long actualId = actualParamResponse.getId();
		Kafka actualKafka = actualParamResponse.getKafka();
		assertEquals(1L, actualId.longValue());
		assertSame(kafka2, actualKafka);
		assertEquals(kafka, actualKafka);
		assertEquals(
				"ParamResponse(id=1, kafka=Kafka(kafkaConfirmTopic=Kafka Confirm Topic, kafkaCoreTopic=Kafka Core Topic,"
						+ " kafkaErrorTopic=An error occurred))",
				actualToStringResult);
	}

	/**
	 * Method under test: {@link ParamResponse#equals(Object)}
	 */
	@Test
	void testEquals() {
		ParamResponse.ParamResponseBuilder idResult = ParamResponse.builder().id(1L);
		assertNotEquals(
				null, idResult
						.kafka(Kafka.builder().kafkaConfirmTopic("Kafka Confirm Topic")
								.kafkaCoreTopic("Kafka Core Topic").kafkaErrorTopic("An error occurred").build())
						.build());
	}

	/**
	 * Method under test: {@link ParamResponse#equals(Object)}
	 */
	@Test
	void testEquals2() {
		ParamResponse.ParamResponseBuilder idResult = ParamResponse.builder().id(1L);
		assertNotEquals(
				"Different type to ParamResponse", idResult
						.kafka(Kafka.builder().kafkaConfirmTopic("Kafka Confirm Topic")
								.kafkaCoreTopic("Kafka Core Topic").kafkaErrorTopic("An error occurred").build())
						.build());
	}

	/**
	 * Methods under test:
	 *
	 * <ul>
	 * <li>{@link ParamResponse#equals(Object)}
	 * <li>{@link ParamResponse#hashCode()}
	 * </ul>
	 */
	@Test
	void testEquals3() {
		ParamResponse.ParamResponseBuilder idResult = ParamResponse.builder().id(1L);
		ParamResponse buildResult = idResult.kafka(Kafka.builder().kafkaConfirmTopic("Kafka Confirm Topic")
				.kafkaCoreTopic("Kafka Core Topic").kafkaErrorTopic("An error occurred").build()).build();
		assertEquals(buildResult, buildResult);
		int expectedHashCodeResult = buildResult.hashCode();
		assertEquals(expectedHashCodeResult, buildResult.hashCode());
	}

	/**
	 * Methods under test:
	 *
	 * <ul>
	 * <li>{@link ParamResponse#equals(Object)}
	 * <li>{@link ParamResponse#hashCode()}
	 * </ul>
	 */
	@Test
	void testEquals4() {
		ParamResponse.ParamResponseBuilder idResult = ParamResponse.builder().id(1L);
		ParamResponse buildResult = idResult.kafka(Kafka.builder().kafkaConfirmTopic("Kafka Confirm Topic")
				.kafkaCoreTopic("Kafka Core Topic").kafkaErrorTopic("An error occurred").build()).build();
		ParamResponse.ParamResponseBuilder idResult2 = ParamResponse.builder().id(1L);
		ParamResponse buildResult2 = idResult2.kafka(Kafka.builder().kafkaConfirmTopic("Kafka Confirm Topic")
				.kafkaCoreTopic("Kafka Core Topic").kafkaErrorTopic("An error occurred").build()).build();
		assertEquals(buildResult, buildResult2);
		int expectedHashCodeResult = buildResult.hashCode();
		assertEquals(expectedHashCodeResult, buildResult2.hashCode());
	}

	/**
	 * Method under test: {@link ParamResponse#equals(Object)}
	 */
	@Test
	void testEquals5() {
		ParamResponse.ParamResponseBuilder idResult = ParamResponse.builder().id(2L);
		ParamResponse buildResult = idResult.kafka(Kafka.builder().kafkaConfirmTopic("Kafka Confirm Topic")
				.kafkaCoreTopic("Kafka Core Topic").kafkaErrorTopic("An error occurred").build()).build();
		ParamResponse.ParamResponseBuilder idResult2 = ParamResponse.builder().id(1L);
		assertNotEquals(buildResult,
				idResult2
						.kafka(Kafka.builder().kafkaConfirmTopic("Kafka Confirm Topic")
								.kafkaCoreTopic("Kafka Core Topic").kafkaErrorTopic("An error occurred").build())
						.build());
	}

	/**
	 * Method under test: {@link ParamResponse#equals(Object)}
	 */
	@Test
	void testEquals6() {
		ParamResponse.ParamResponseBuilder idResult = ParamResponse.builder().id(null);
		ParamResponse buildResult = idResult.kafka(Kafka.builder().kafkaConfirmTopic("Kafka Confirm Topic")
				.kafkaCoreTopic("Kafka Core Topic").kafkaErrorTopic("An error occurred").build()).build();
		ParamResponse.ParamResponseBuilder idResult2 = ParamResponse.builder().id(1L);
		assertNotEquals(buildResult,
				idResult2
						.kafka(Kafka.builder().kafkaConfirmTopic("Kafka Confirm Topic")
								.kafkaCoreTopic("Kafka Core Topic").kafkaErrorTopic("An error occurred").build())
						.build());
	}

	/**
	 * Method under test: {@link ParamResponse#equals(Object)}
	 */
	@Test
	void testEquals7() {
		ParamResponse.ParamResponseBuilder idResult = ParamResponse.builder().id(1L);
		ParamResponse buildResult = idResult.kafka(Kafka.builder().kafkaConfirmTopic("Kafka Core Topic")
				.kafkaCoreTopic("Kafka Core Topic").kafkaErrorTopic("An error occurred").build()).build();
		ParamResponse.ParamResponseBuilder idResult2 = ParamResponse.builder().id(1L);
		assertNotEquals(buildResult,
				idResult2
						.kafka(Kafka.builder().kafkaConfirmTopic("Kafka Confirm Topic")
								.kafkaCoreTopic("Kafka Core Topic").kafkaErrorTopic("An error occurred").build())
						.build());
	}

	/**
	 * Methods under test:
	 *
	 * <ul>
	 * <li>{@link ParamResponse#equals(Object)}
	 * <li>{@link ParamResponse#hashCode()}
	 * </ul>
	 */
	@Test
	void testEquals8() {
		ParamResponse.ParamResponseBuilder idResult = ParamResponse.builder().id(null);
		ParamResponse buildResult = idResult.kafka(Kafka.builder().kafkaConfirmTopic("Kafka Confirm Topic")
				.kafkaCoreTopic("Kafka Core Topic").kafkaErrorTopic("An error occurred").build()).build();
		ParamResponse.ParamResponseBuilder idResult2 = ParamResponse.builder().id(null);
		ParamResponse buildResult2 = idResult2.kafka(Kafka.builder().kafkaConfirmTopic("Kafka Confirm Topic")
				.kafkaCoreTopic("Kafka Core Topic").kafkaErrorTopic("An error occurred").build()).build();
		assertEquals(buildResult, buildResult2);
		int expectedHashCodeResult = buildResult.hashCode();
		assertEquals(expectedHashCodeResult, buildResult2.hashCode());
	}
}
