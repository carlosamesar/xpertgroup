package com.bancoldex.sendpaymentcoreservice.util;

import com.bancoldex.sendpaymentcoreservice.dto.LoginResponse;
import com.bancoldex.sendpaymentcoreservice.dto.PermisosRol;
import com.bancoldex.sendpaymentcoreservice.dto.ValidationResponse;
import com.google.gson.Gson;
import kong.unirest.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.core.env.Environment;
import org.springframework.http.*;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@ContextConfiguration(classes = RestTemplateService.class)
public class RestTemplateServiceTest {
    @Mock
    private RestTemplate restTemplate;
    @Mock
    private Environment env;
    @InjectMocks
    RestTemplateService restTemplateService = new RestTemplateService();

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void getValidateApiCore_whenGetIsCalled_shouldReturnEmpty() throws Exception {
        String token = UUID.randomUUID().toString();
        String uri = URI.create("http://localhost:8080").toString();

        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + token);
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> headerList = new HttpEntity<>("", headers);

        Optional<JSONObject> jsonObjectOptional = Optional.of(new JSONObject());
        when(restTemplate.exchange(uri, HttpMethod.POST, headerList, ValidationResponse.class)).thenReturn(new ResponseEntity<ValidationResponse>(HttpStatus.ACCEPTED));
        //when(restTemplateService.getValidateApiCore(token, uri)).thenReturn(jsonObjectOptional);
        Optional<ResponseEntity<ValidationResponse>> jsonObjectOptionalResult = restTemplateService.getCreateDataApiCore(token, uri, new JSONObject());
        assertTrue(jsonObjectOptionalResult.isEmpty());
    }

    @Test
    void getJwtToken_whenGetIsCalled_shouldReturnEmpty() {
        Mockito.when(env.getProperty("application.security.url")).thenReturn("/apiseguridad");
        Mockito.when(env.getProperty("com.bancoldex.security.user")).thenReturn("orquestador.pagos");
        Mockito.when(env.getProperty("com.bancoldex.security.pwd")).thenReturn("bc028f45a230b22f79936ba4ce99cd9f");

        Mockito.when(restTemplateService.getJwtToken()).thenReturn(null);
        assertNull(restTemplateService.getJwtToken());
    }

    @Test
    void getJwtToken_whenGetIsCalled_shouldReturnValue() {
        List<PermisosRol> permisosRolsList = new ArrayList<>();
        Optional<String> tokenGenerated = Optional.of(UUID.randomUUID().toString());

        permisosRolsList.add(PermisosRol.builder()
                .jwt(tokenGenerated.get())
                .rol("Orquestador de pagos")
                .fechaExpiracion("2023-12-31")
                .build());

        LoginResponse loginResponse = LoginResponse.builder().permisosRol(permisosRolsList).build();

        Gson gson = new Gson();
        String json = gson.toJson(loginResponse);
        ResponseEntity<String> stringResponseEntity = new ResponseEntity<>(json, HttpStatus.OK);
        when(env.getProperty("com.bancoldex.security.rolname")).thenReturn("Orquestador de pagos");
        Optional<String> token = restTemplateService.generatedJwt(stringResponseEntity);
        assertTrue(token.isPresent());

    }

    @Test
    void getJwtToken_whenGetIsCalled_shouldReturnEmptyToken() {
        List<PermisosRol> permisosRolsList = new ArrayList<>();
        Optional<String> tokenGenerated = Optional.of(UUID.randomUUID().toString());

        permisosRolsList.add(PermisosRol.builder()
                .jwt(tokenGenerated.get())
                .rol("Test Orquestador de pagos")
                .fechaExpiracion("2023-12-31")
                .build());

        LoginResponse loginResponse = LoginResponse.builder().permisosRol(permisosRolsList).build();

        Gson gson = new Gson();
        String json = gson.toJson(loginResponse);
        ResponseEntity<String> stringResponseEntity = new ResponseEntity<>(json, HttpStatus.OK);
        when(env.getProperty("com.bancoldex.security.rolname")).thenReturn("Orquestador de pagos");
        Optional<String> token = restTemplateService.generatedJwt(stringResponseEntity);
        assertTrue(token.isEmpty());

    }
}
