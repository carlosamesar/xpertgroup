package com.bancoldex.sendpaymentcoreservice.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.Date;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class LogEventDiffblueTest {
	/**
	 * Method under test: {@link LogEvent#canEqual(Object)}
	 */
	@Test
	void testCanEqual() {
		assertFalse((new LogEvent()).canEqual("Other"));
	}

	@Test
	void testBuilder() {
		LogEvent buildResult = LogEvent.builder().amountInCents("100").customerEmail("@email").checksum("100")
				.environment("env").id(1L).idRef("222").build();
		assertTrue(buildResult.canEqual(LogEvent.builder().amountInCents("100").customerEmail("@email").checksum("100")
				.environment("env").id(1L).idRef("222").build()));
	}

	/**
	 * Method under test: {@link LogEvent#canEqual(Object)}
	 */
	@Test
	void testCanEqual2() {
		LogEvent logEvent = new LogEvent();
		logEvent.setAmountInCents("10");
		logEvent.setChecksum("Checksum");
		logEvent.setCurrency("GBP");
		logEvent.setCustomerEmail("jane.doe@example.org");
		logEvent.setEnvironment("Environment");
		logEvent.setEvent("Event");
		logEvent.setId(1L);
		logEvent.setIdRef("Id Ref");
		logEvent.setPaymentLinkId("Payment link id");
		logEvent.setPaymentMethodType("Payment method type");
		logEvent.setPaymentSourceId("Payment source id");
		logEvent.setRedirectUrl("https://example.org/example");
		logEvent.setReference("Reference");
		logEvent.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent.setShippingAddress("42 Main St");
		logEvent.setStateCore(1);
		logEvent.setStatus("Status");
		logEvent.setTimestamp("Timestamp");
		logEvent.setUrlCore("https://example.org/example");

		LogEvent logEvent2 = new LogEvent();
		logEvent2.setAmountInCents("10");
		logEvent2.setChecksum("Checksum");
		logEvent2.setCurrency("GBP");
		logEvent2.setCustomerEmail("jane.doe@example.org");
		logEvent2.setEnvironment("Environment");
		logEvent2.setEvent("Event");
		logEvent2.setId(1L);
		logEvent2.setIdRef("Id Ref");
		logEvent2.setPaymentLinkId("Payment link id");
		logEvent2.setPaymentMethodType("Payment method type");
		logEvent2.setPaymentSourceId("Payment source id");
		logEvent2.setRedirectUrl("https://example.org/example");
		logEvent2.setReference("Reference");
		logEvent2.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent2.setShippingAddress("42 Main St");
		logEvent2.setStateCore(1);
		logEvent2.setStatus("Status");
		logEvent2.setTimestamp("Timestamp");
		logEvent2.setUrlCore("https://example.org/example");
		assertTrue(logEvent.canEqual(logEvent2));
	}

	/**
	 * Methods under test:
	 *
	 * <ul>
	 * <li>{@link LogEvent#LogEvent()}
	 * <li>{@link LogEvent#setAmount_in_cents(String)}
	 * <li>{@link LogEvent#setChecksum(String)}
	 * <li>{@link LogEvent#setCurrency(String)}
	 * <li>{@link LogEvent#setCustomer_email(String)}
	 * <li>{@link LogEvent#setEnvironment(String)}
	 * <li>{@link LogEvent#setEvent(String)}
	 * <li>{@link LogEvent#setId(Long)}
	 * <li>{@link LogEvent#setIdRef(String)}
	 * <li>{@link LogEvent#setPayment_link_id(String)}
	 * <li>{@link LogEvent#setPayment_method_type(String)}
	 * <li>{@link LogEvent#setPayment_source_id(String)}
	 * <li>{@link LogEvent#setRedirect_url(String)}
	 * <li>{@link LogEvent#setReference(String)}
	 * <li>{@link LogEvent#setSent_at(Date)}
	 * <li>{@link LogEvent#setShipping_address(String)}
	 * <li>{@link LogEvent#setStateCore(Integer)}
	 * <li>{@link LogEvent#setStatus(String)}
	 * <li>{@link LogEvent#setTimestamp(String)}
	 * <li>{@link LogEvent#setUrlCore(String)}
	 * <li>{@link LogEvent#toString()}
	 * <li>{@link LogEvent#getAmount_in_cents()}
	 * <li>{@link LogEvent#getChecksum()}
	 * <li>{@link LogEvent#getCurrency()}
	 * <li>{@link LogEvent#getCustomer_email()}
	 * <li>{@link LogEvent#getEnvironment()}
	 * <li>{@link LogEvent#getEvent()}
	 * <li>{@link LogEvent#getId()}
	 * <li>{@link LogEvent#getIdRef()}
	 * <li>{@link LogEvent#getPayment_link_id()}
	 * <li>{@link LogEvent#getPayment_method_type()}
	 * <li>{@link LogEvent#getPayment_source_id()}
	 * <li>{@link LogEvent#getRedirect_url()}
	 * <li>{@link LogEvent#getReference()}
	 * <li>{@link LogEvent#getSent_at()}
	 * <li>{@link LogEvent#getShipping_address()}
	 * <li>{@link LogEvent#getStateCore()}
	 * <li>{@link LogEvent#getStatus()}
	 * <li>{@link LogEvent#getTimestamp()}
	 * <li>{@link LogEvent#getUrlCore()}
	 * </ul>
	 */
	@Test
	void testConstructor() {
		LogEvent actualLogEvent = new LogEvent();
		actualLogEvent.setAmountInCents("10");
		actualLogEvent.setChecksum("Checksum");
		actualLogEvent.setCurrency("GBP");
		actualLogEvent.setCustomerEmail("jane.doe@example.org");
		actualLogEvent.setEnvironment("Environment");
		actualLogEvent.setEvent("Event");
		actualLogEvent.setId(1L);
		actualLogEvent.setIdRef("Id Ref");
		actualLogEvent.setPaymentLinkId("Payment link id");
		actualLogEvent.setPaymentMethodType("Payment method type");
		actualLogEvent.setPaymentSourceId("Payment source id");
		actualLogEvent.setRedirectUrl("https://example.org/example");
		actualLogEvent.setReference("Reference");
		Date sent_at = Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant());
		actualLogEvent.setSentAt(sent_at);
		actualLogEvent.setShippingAddress("42 Main St");
		actualLogEvent.setStateCore(1);
		actualLogEvent.setStatus("Status");
		actualLogEvent.setTimestamp("Timestamp");
		actualLogEvent.setUrlCore("https://example.org/example");
		actualLogEvent.toString();
		String actualAmount_in_cents = actualLogEvent.getAmountInCents();
		String actualChecksum = actualLogEvent.getChecksum();
		String actualCurrency = actualLogEvent.getCurrency();
		String actualCustomer_email = actualLogEvent.getCustomerEmail();
		String actualEnvironment = actualLogEvent.getEnvironment();
		String actualEvent = actualLogEvent.getEvent();
		Long actualId = actualLogEvent.getId();
		String actualIdRef = actualLogEvent.getIdRef();
		String actualPayment_link_id = actualLogEvent.getPaymentLinkId();
		String actualPayment_method_type = actualLogEvent.getPaymentMethodType();
		String actualPayment_source_id = actualLogEvent.getPaymentSourceId();
		String actualRedirect_url = actualLogEvent.getRedirectUrl();
		String actualReference = actualLogEvent.getReference();
		Date actualSent_at = actualLogEvent.getSentAt();
		String actualShipping_address = actualLogEvent.getShippingAddress();
		Integer actualStateCore = actualLogEvent.getStateCore();
		String actualStatus = actualLogEvent.getStatus();
		String actualTimestamp = actualLogEvent.getTimestamp();
		String actualUrlCore = actualLogEvent.getUrlCore();
		assertEquals("10", actualAmount_in_cents);
		assertEquals("Checksum", actualChecksum);
		assertEquals("GBP", actualCurrency);
		assertEquals("jane.doe@example.org", actualCustomer_email);
		assertEquals("Environment", actualEnvironment);
		assertEquals("Event", actualEvent);
		assertEquals(1L, actualId.longValue());
		assertEquals("Id Ref", actualIdRef);
		assertEquals("Payment link id", actualPayment_link_id);
		assertEquals("Payment method type", actualPayment_method_type);
		assertEquals("Payment source id", actualPayment_source_id);
		assertEquals("https://example.org/example", actualRedirect_url);
		assertEquals("Reference", actualReference);
		assertSame(sent_at, actualSent_at);
		assertEquals("42 Main St", actualShipping_address);
		assertEquals(1, actualStateCore.intValue());
		assertEquals("Status", actualStatus);
		assertEquals("Timestamp", actualTimestamp);
		assertEquals("https://example.org/example", actualUrlCore);
	}

	/**
	 * Methods under test:
	 *
	 * <ul>
	 * <li>{@link LogEvent#LogEvent(Long, String, String, String, String, String, String, String, String, String, String, String, String, String, String, String, Date, String, Integer)}
	 * <li>{@link LogEvent#setAmount_in_cents(String)}
	 * <li>{@link LogEvent#setChecksum(String)}
	 * <li>{@link LogEvent#setCurrency(String)}
	 * <li>{@link LogEvent#setCustomer_email(String)}
	 * <li>{@link LogEvent#setEnvironment(String)}
	 * <li>{@link LogEvent#setEvent(String)}
	 * <li>{@link LogEvent#setId(Long)}
	 * <li>{@link LogEvent#setIdRef(String)}
	 * <li>{@link LogEvent#setPayment_link_id(String)}
	 * <li>{@link LogEvent#setPayment_method_type(String)}
	 * <li>{@link LogEvent#setPayment_source_id(String)}
	 * <li>{@link LogEvent#setRedirect_url(String)}
	 * <li>{@link LogEvent#setReference(String)}
	 * <li>{@link LogEvent#setSent_at(Date)}
	 * <li>{@link LogEvent#setShipping_address(String)}
	 * <li>{@link LogEvent#setStateCore(Integer)}
	 * <li>{@link LogEvent#setStatus(String)}
	 * <li>{@link LogEvent#setTimestamp(String)}
	 * <li>{@link LogEvent#setUrlCore(String)}
	 * <li>{@link LogEvent#toString()}
	 * <li>{@link LogEvent#getAmount_in_cents()}
	 * <li>{@link LogEvent#getChecksum()}
	 * <li>{@link LogEvent#getCurrency()}
	 * <li>{@link LogEvent#getCustomer_email()}
	 * <li>{@link LogEvent#getEnvironment()}
	 * <li>{@link LogEvent#getEvent()}
	 * <li>{@link LogEvent#getId()}
	 * <li>{@link LogEvent#getIdRef()}
	 * <li>{@link LogEvent#getPayment_link_id()}
	 * <li>{@link LogEvent#getPayment_method_type()}
	 * <li>{@link LogEvent#getPayment_source_id()}
	 * <li>{@link LogEvent#getRedirect_url()}
	 * <li>{@link LogEvent#getReference()}
	 * <li>{@link LogEvent#getSent_at()}
	 * <li>{@link LogEvent#getShipping_address()}
	 * <li>{@link LogEvent#getStateCore()}
	 * <li>{@link LogEvent#getStatus()}
	 * <li>{@link LogEvent#getTimestamp()}
	 * <li>{@link LogEvent#getUrlCore()}
	 * </ul>
	 */
	@Test
	void testConstructor2() {
		LogEvent actualLogEvent = new LogEvent(1L, "Event", "Id Ref", "10", "Reference", "jane.doe@example.org", "GBP",
				"Payment method type", "https://example.org/example", "Status", "42 Main St", "Payment link id",
				"Payment source id", "Environment", "Checksum", "Timestamp",
				Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()),
				"https://example.org/example", 1);
		actualLogEvent.setAmountInCents("10");
		actualLogEvent.setChecksum("Checksum");
		actualLogEvent.setCurrency("GBP");
		actualLogEvent.setCustomerEmail("jane.doe@example.org");
		actualLogEvent.setEnvironment("Environment");
		actualLogEvent.setEvent("Event");
		actualLogEvent.setId(1L);
		actualLogEvent.setIdRef("Id Ref");
		actualLogEvent.setPaymentLinkId("Payment link id");
		actualLogEvent.setPaymentMethodType("Payment method type");
		actualLogEvent.setPaymentSourceId("Payment source id");
		actualLogEvent.setRedirectUrl("https://example.org/example");
		actualLogEvent.setReference("Reference");
		Date sent_at = Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant());
		actualLogEvent.setSentAt(sent_at);
		actualLogEvent.setShippingAddress("42 Main St");
		actualLogEvent.setStateCore(1);
		actualLogEvent.setStatus("Status");
		actualLogEvent.setTimestamp("Timestamp");
		actualLogEvent.setUrlCore("https://example.org/example");
		actualLogEvent.toString();
		String actualAmount_in_cents = actualLogEvent.getAmountInCents();
		String actualChecksum = actualLogEvent.getChecksum();
		String actualCurrency = actualLogEvent.getCurrency();
		String actualCustomer_email = actualLogEvent.getCustomerEmail();
		String actualEnvironment = actualLogEvent.getEnvironment();
		String actualEvent = actualLogEvent.getEvent();
		Long actualId = actualLogEvent.getId();
		String actualIdRef = actualLogEvent.getIdRef();
		String actualPayment_link_id = actualLogEvent.getPaymentLinkId();
		String actualPayment_method_type = actualLogEvent.getPaymentMethodType();
		String actualPayment_source_id = actualLogEvent.getPaymentSourceId();
		String actualRedirect_url = actualLogEvent.getRedirectUrl();
		String actualReference = actualLogEvent.getReference();
		Date actualSent_at = actualLogEvent.getSentAt();
		String actualShipping_address = actualLogEvent.getShippingAddress();
		Integer actualStateCore = actualLogEvent.getStateCore();
		String actualStatus = actualLogEvent.getStatus();
		String actualTimestamp = actualLogEvent.getTimestamp();
		String actualUrlCore = actualLogEvent.getUrlCore();
		assertEquals("10", actualAmount_in_cents);
		assertEquals("Checksum", actualChecksum);
		assertEquals("GBP", actualCurrency);
		assertEquals("jane.doe@example.org", actualCustomer_email);
		assertEquals("Environment", actualEnvironment);
		assertEquals("Event", actualEvent);
		assertEquals(1L, actualId.longValue());
		assertEquals("Id Ref", actualIdRef);
		assertEquals("Payment link id", actualPayment_link_id);
		assertEquals("Payment method type", actualPayment_method_type);
		assertEquals("Payment source id", actualPayment_source_id);
		assertEquals("https://example.org/example", actualRedirect_url);
		assertEquals("Reference", actualReference);
		assertSame(sent_at, actualSent_at);
		assertEquals("42 Main St", actualShipping_address);
		assertEquals(1, actualStateCore.intValue());
		assertEquals("Status", actualStatus);
		assertEquals("Timestamp", actualTimestamp);
		assertEquals("https://example.org/example", actualUrlCore);
	}

	/**
	 * Methods under test:
	 *
	 * <ul>
	 * <li>{@link LogEvent#equals(Object)}
	 * <li>{@link LogEvent#hashCode()}
	 * </ul>
	 */
	@Test
	void testEquals3() {
		LogEvent logEvent = new LogEvent();
		logEvent.setAmountInCents("10");
		logEvent.setChecksum("Checksum");
		logEvent.setCurrency("GBP");
		logEvent.setCustomerEmail("jane.doe@example.org");
		logEvent.setEnvironment("Environment");
		logEvent.setEvent("Event");
		logEvent.setId(1L);
		logEvent.setIdRef("Id Ref");
		logEvent.setPaymentLinkId("Payment link id");
		logEvent.setPaymentMethodType("Payment method type");
		logEvent.setPaymentSourceId("Payment source id");
		logEvent.setRedirectUrl("https://example.org/example");
		logEvent.setReference("Reference");
		logEvent.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent.setShippingAddress("42 Main St");
		logEvent.setStateCore(1);
		logEvent.setStatus("Status");
		logEvent.setTimestamp("Timestamp");
		logEvent.setUrlCore("https://example.org/example");
		assertEquals(logEvent, logEvent);
		int expectedHashCodeResult = logEvent.hashCode();
		assertEquals(expectedHashCodeResult, logEvent.hashCode());
	}

	/**
	 * Methods under test:
	 *
	 * <ul>
	 * <li>{@link LogEvent#equals(Object)}
	 * <li>{@link LogEvent#hashCode()}
	 * </ul>
	 */
	@Test
	void testEquals4() {
		LogEvent logEvent = new LogEvent();
		logEvent.setAmountInCents("10");
		logEvent.setChecksum("Checksum");
		logEvent.setCurrency("GBP");
		logEvent.setCustomerEmail("jane.doe@example.org");
		logEvent.setEnvironment("Environment");
		logEvent.setEvent("Event");
		logEvent.setId(1L);
		logEvent.setIdRef("Id Ref");
		logEvent.setPaymentLinkId("Payment link id");
		logEvent.setPaymentMethodType("Payment method type");
		logEvent.setPaymentSourceId("Payment source id");
		logEvent.setRedirectUrl("https://example.org/example");
		logEvent.setReference("Reference");
		logEvent.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent.setShippingAddress("42 Main St");
		logEvent.setStateCore(1);
		logEvent.setStatus("Status");
		logEvent.setTimestamp("Timestamp");
		logEvent.setUrlCore("https://example.org/example");

		LogEvent logEvent2 = new LogEvent();
		logEvent2.setAmountInCents("10");
		logEvent2.setChecksum("Checksum");
		logEvent2.setCurrency("GBP");
		logEvent2.setCustomerEmail("jane.doe@example.org");
		logEvent2.setEnvironment("Environment");
		logEvent2.setEvent("Event");
		logEvent2.setId(1L);
		logEvent2.setIdRef("Id Ref");
		logEvent2.setPaymentLinkId("Payment link id");
		logEvent2.setPaymentMethodType("Payment method type");
		logEvent2.setPaymentSourceId("Payment source id");
		logEvent2.setRedirectUrl("https://example.org/example");
		logEvent2.setReference("Reference");
		logEvent2.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent2.setShippingAddress("42 Main St");
		logEvent2.setStateCore(1);
		logEvent2.setStatus("Status");
		logEvent2.setTimestamp("Timestamp");
		logEvent2.setUrlCore("https://example.org/example");
		assertEquals(logEvent, logEvent2);
		int expectedHashCodeResult = logEvent.hashCode();
		assertEquals(expectedHashCodeResult, logEvent2.hashCode());
	}

	/**
	 * Method under test: {@link LogEvent#equals(Object)}
	 */
	@Test
	void testEquals5() {
		LogEvent logEvent = new LogEvent();
		logEvent.setAmountInCents("Event");
		logEvent.setChecksum("Checksum");
		logEvent.setCurrency("GBP");
		logEvent.setCustomerEmail("jane.doe@example.org");
		logEvent.setEnvironment("Environment");
		logEvent.setEvent("Event");
		logEvent.setId(1L);
		logEvent.setIdRef("Id Ref");
		logEvent.setPaymentLinkId("Payment link id");
		logEvent.setPaymentMethodType("Payment method type");
		logEvent.setPaymentSourceId("Payment source id");
		logEvent.setRedirectUrl("https://example.org/example");
		logEvent.setReference("Reference");
		logEvent.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent.setShippingAddress("42 Main St");
		logEvent.setStateCore(1);
		logEvent.setStatus("Status");
		logEvent.setTimestamp("Timestamp");
		logEvent.setUrlCore("https://example.org/example");

		LogEvent logEvent2 = new LogEvent();
		logEvent2.setAmountInCents("10");
		logEvent2.setChecksum("Checksum");
		logEvent2.setCurrency("GBP");
		logEvent2.setCustomerEmail("jane.doe@example.org");
		logEvent2.setEnvironment("Environment");
		logEvent2.setEvent("Event");
		logEvent2.setId(1L);
		logEvent2.setIdRef("Id Ref");
		logEvent2.setPaymentLinkId("Payment link id");
		logEvent2.setPaymentMethodType("Payment method type");
		logEvent2.setPaymentSourceId("Payment source id");
		logEvent2.setRedirectUrl("https://example.org/example");
		logEvent2.setReference("Reference");
		logEvent2.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent2.setShippingAddress("42 Main St");
		logEvent2.setStateCore(1);
		logEvent2.setStatus("Status");
		logEvent2.setTimestamp("Timestamp");
		logEvent2.setUrlCore("https://example.org/example");
		assertNotEquals(logEvent, logEvent2);
	}

	/**
	 * Method under test: {@link LogEvent#equals(Object)}
	 */
	@Test
	void testEquals6() {
		LogEvent logEvent = new LogEvent();
		logEvent.setAmountInCents(null);
		logEvent.setChecksum("Checksum");
		logEvent.setCurrency("GBP");
		logEvent.setCustomerEmail("jane.doe@example.org");
		logEvent.setEnvironment("Environment");
		logEvent.setEvent("Event");
		logEvent.setId(1L);
		logEvent.setIdRef("Id Ref");
		logEvent.setPaymentLinkId("Payment link id");
		logEvent.setPaymentMethodType("Payment method type");
		logEvent.setPaymentSourceId("Payment source id");
		logEvent.setRedirectUrl("https://example.org/example");
		logEvent.setReference("Reference");
		logEvent.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent.setShippingAddress("42 Main St");
		logEvent.setStateCore(1);
		logEvent.setStatus("Status");
		logEvent.setTimestamp("Timestamp");
		logEvent.setUrlCore("https://example.org/example");

		LogEvent logEvent2 = new LogEvent();
		logEvent2.setAmountInCents("10");
		logEvent2.setChecksum("Checksum");
		logEvent2.setCurrency("GBP");
		logEvent2.setCustomerEmail("jane.doe@example.org");
		logEvent2.setEnvironment("Environment");
		logEvent2.setEvent("Event");
		logEvent2.setId(1L);
		logEvent2.setIdRef("Id Ref");
		logEvent2.setPaymentLinkId("Payment link id");
		logEvent2.setPaymentMethodType("Payment method type");
		logEvent2.setPaymentSourceId("Payment source id");
		logEvent2.setRedirectUrl("https://example.org/example");
		logEvent2.setReference("Reference");
		logEvent2.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent2.setShippingAddress("42 Main St");
		logEvent2.setStateCore(1);
		logEvent2.setStatus("Status");
		logEvent2.setTimestamp("Timestamp");
		logEvent2.setUrlCore("https://example.org/example");
		assertNotEquals(logEvent, logEvent2);
	}

	/**
	 * Method under test: {@link LogEvent#equals(Object)}
	 */
	@Test
	void testEquals7() {
		LogEvent logEvent = new LogEvent();
		logEvent.setAmountInCents("10");
		logEvent.setChecksum("Event");
		logEvent.setCurrency("GBP");
		logEvent.setCustomerEmail("jane.doe@example.org");
		logEvent.setEnvironment("Environment");
		logEvent.setEvent("Event");
		logEvent.setId(1L);
		logEvent.setIdRef("Id Ref");
		logEvent.setPaymentLinkId("Payment link id");
		logEvent.setPaymentMethodType("Payment method type");
		logEvent.setPaymentSourceId("Payment source id");
		logEvent.setRedirectUrl("https://example.org/example");
		logEvent.setReference("Reference");
		logEvent.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent.setShippingAddress("42 Main St");
		logEvent.setStateCore(1);
		logEvent.setStatus("Status");
		logEvent.setTimestamp("Timestamp");
		logEvent.setUrlCore("https://example.org/example");

		LogEvent logEvent2 = new LogEvent();
		logEvent2.setAmountInCents("10");
		logEvent2.setChecksum("Checksum");
		logEvent2.setCurrency("GBP");
		logEvent2.setCustomerEmail("jane.doe@example.org");
		logEvent2.setEnvironment("Environment");
		logEvent2.setEvent("Event");
		logEvent2.setId(1L);
		logEvent2.setIdRef("Id Ref");
		logEvent2.setPaymentLinkId("Payment link id");
		logEvent2.setPaymentMethodType("Payment method type");
		logEvent2.setPaymentSourceId("Payment source id");
		logEvent2.setRedirectUrl("https://example.org/example");
		logEvent2.setReference("Reference");
		logEvent2.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent2.setShippingAddress("42 Main St");
		logEvent2.setStateCore(1);
		logEvent2.setStatus("Status");
		logEvent2.setTimestamp("Timestamp");
		logEvent2.setUrlCore("https://example.org/example");
		assertNotEquals(logEvent, logEvent2);
	}

	/**
	 * Method under test: {@link LogEvent#equals(Object)}
	 */
	@Test
	void testEquals8() {
		LogEvent logEvent = new LogEvent();
		logEvent.setAmountInCents("10");
		logEvent.setChecksum(null);
		logEvent.setCurrency("GBP");
		logEvent.setCustomerEmail("jane.doe@example.org");
		logEvent.setEnvironment("Environment");
		logEvent.setEvent("Event");
		logEvent.setId(1L);
		logEvent.setIdRef("Id Ref");
		logEvent.setPaymentLinkId("Payment link id");
		logEvent.setPaymentMethodType("Payment method type");
		logEvent.setPaymentSourceId("Payment source id");
		logEvent.setRedirectUrl("https://example.org/example");
		logEvent.setReference("Reference");
		logEvent.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent.setShippingAddress("42 Main St");
		logEvent.setStateCore(1);
		logEvent.setStatus("Status");
		logEvent.setTimestamp("Timestamp");
		logEvent.setUrlCore("https://example.org/example");

		LogEvent logEvent2 = new LogEvent();
		logEvent2.setAmountInCents("10");
		logEvent2.setChecksum("Checksum");
		logEvent2.setCurrency("GBP");
		logEvent2.setCustomerEmail("jane.doe@example.org");
		logEvent2.setEnvironment("Environment");
		logEvent2.setEvent("Event");
		logEvent2.setId(1L);
		logEvent2.setIdRef("Id Ref");
		logEvent2.setPaymentLinkId("Payment link id");
		logEvent2.setPaymentMethodType("Payment method type");
		logEvent2.setPaymentSourceId("Payment source id");
		logEvent2.setRedirectUrl("https://example.org/example");
		logEvent2.setReference("Reference");
		logEvent2.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent2.setShippingAddress("42 Main St");
		logEvent2.setStateCore(1);
		logEvent2.setStatus("Status");
		logEvent2.setTimestamp("Timestamp");
		logEvent2.setUrlCore("https://example.org/example");
		assertNotEquals(logEvent, logEvent2);
	}

	/**
	 * Method under test: {@link LogEvent#equals(Object)}
	 */
	@Test
	void testEquals9() {
		LogEvent logEvent = new LogEvent();
		logEvent.setAmountInCents("10");
		logEvent.setChecksum("Checksum");
		logEvent.setCurrency("USD");
		logEvent.setCustomerEmail("jane.doe@example.org");
		logEvent.setEnvironment("Environment");
		logEvent.setEvent("Event");
		logEvent.setId(1L);
		logEvent.setIdRef("Id Ref");
		logEvent.setPaymentLinkId("Payment link id");
		logEvent.setPaymentMethodType("Payment method type");
		logEvent.setPaymentSourceId("Payment source id");
		logEvent.setRedirectUrl("https://example.org/example");
		logEvent.setReference("Reference");
		logEvent.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent.setShippingAddress("42 Main St");
		logEvent.setStateCore(1);
		logEvent.setStatus("Status");
		logEvent.setTimestamp("Timestamp");
		logEvent.setUrlCore("https://example.org/example");

		LogEvent logEvent2 = new LogEvent();
		logEvent2.setAmountInCents("10");
		logEvent2.setChecksum("Checksum");
		logEvent2.setCurrency("GBP");
		logEvent2.setCustomerEmail("jane.doe@example.org");
		logEvent2.setEnvironment("Environment");
		logEvent2.setEvent("Event");
		logEvent2.setId(1L);
		logEvent2.setIdRef("Id Ref");
		logEvent2.setPaymentLinkId("Payment link id");
		logEvent2.setPaymentMethodType("Payment method type");
		logEvent2.setPaymentSourceId("Payment source id");
		logEvent2.setRedirectUrl("https://example.org/example");
		logEvent2.setReference("Reference");
		logEvent2.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent2.setShippingAddress("42 Main St");
		logEvent2.setStateCore(1);
		logEvent2.setStatus("Status");
		logEvent2.setTimestamp("Timestamp");
		logEvent2.setUrlCore("https://example.org/example");
		assertNotEquals(logEvent, logEvent2);
	}

	/**
	 * Method under test: {@link LogEvent#equals(Object)}
	 */
	@Test
	void testEquals10() {
		LogEvent logEvent = new LogEvent();
		logEvent.setAmountInCents("10");
		logEvent.setChecksum("Checksum");
		logEvent.setCurrency(null);
		logEvent.setCustomerEmail("jane.doe@example.org");
		logEvent.setEnvironment("Environment");
		logEvent.setEvent("Event");
		logEvent.setId(1L);
		logEvent.setIdRef("Id Ref");
		logEvent.setPaymentLinkId("Payment link id");
		logEvent.setPaymentMethodType("Payment method type");
		logEvent.setPaymentSourceId("Payment source id");
		logEvent.setRedirectUrl("https://example.org/example");
		logEvent.setReference("Reference");
		logEvent.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent.setShippingAddress("42 Main St");
		logEvent.setStateCore(1);
		logEvent.setStatus("Status");
		logEvent.setTimestamp("Timestamp");
		logEvent.setUrlCore("https://example.org/example");

		LogEvent logEvent2 = new LogEvent();
		logEvent2.setAmountInCents("10");
		logEvent2.setChecksum("Checksum");
		logEvent2.setCurrency("GBP");
		logEvent2.setCustomerEmail("jane.doe@example.org");
		logEvent2.setEnvironment("Environment");
		logEvent2.setEvent("Event");
		logEvent2.setId(1L);
		logEvent2.setIdRef("Id Ref");
		logEvent2.setPaymentLinkId("Payment link id");
		logEvent2.setPaymentMethodType("Payment method type");
		logEvent2.setPaymentSourceId("Payment source id");
		logEvent2.setRedirectUrl("https://example.org/example");
		logEvent2.setReference("Reference");
		logEvent2.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent2.setShippingAddress("42 Main St");
		logEvent2.setStateCore(1);
		logEvent2.setStatus("Status");
		logEvent2.setTimestamp("Timestamp");
		logEvent2.setUrlCore("https://example.org/example");
		assertNotEquals(logEvent, logEvent2);
	}

	/**
	 * Method under test: {@link LogEvent#equals(Object)}
	 */
	@Test
	void testEquals11() {
		LogEvent logEvent = new LogEvent();
		logEvent.setAmountInCents("10");
		logEvent.setChecksum("Checksum");
		logEvent.setCurrency("GBP");
		logEvent.setCustomerEmail("john.smith@example.org");
		logEvent.setEnvironment("Environment");
		logEvent.setEvent("Event");
		logEvent.setId(1L);
		logEvent.setIdRef("Id Ref");
		logEvent.setPaymentLinkId("Payment link id");
		logEvent.setPaymentMethodType("Payment method type");
		logEvent.setPaymentSourceId("Payment source id");
		logEvent.setRedirectUrl("https://example.org/example");
		logEvent.setReference("Reference");
		logEvent.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent.setShippingAddress("42 Main St");
		logEvent.setStateCore(1);
		logEvent.setStatus("Status");
		logEvent.setTimestamp("Timestamp");
		logEvent.setUrlCore("https://example.org/example");

		LogEvent logEvent2 = new LogEvent();
		logEvent2.setAmountInCents("10");
		logEvent2.setChecksum("Checksum");
		logEvent2.setCurrency("GBP");
		logEvent2.setCustomerEmail("jane.doe@example.org");
		logEvent2.setEnvironment("Environment");
		logEvent2.setEvent("Event");
		logEvent2.setId(1L);
		logEvent2.setIdRef("Id Ref");
		logEvent2.setPaymentLinkId("Payment link id");
		logEvent2.setPaymentMethodType("Payment method type");
		logEvent2.setPaymentSourceId("Payment source id");
		logEvent2.setRedirectUrl("https://example.org/example");
		logEvent2.setReference("Reference");
		logEvent2.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent2.setShippingAddress("42 Main St");
		logEvent2.setStateCore(1);
		logEvent2.setStatus("Status");
		logEvent2.setTimestamp("Timestamp");
		logEvent2.setUrlCore("https://example.org/example");
		assertNotEquals(logEvent, logEvent2);
	}

	/**
	 * Method under test: {@link LogEvent#equals(Object)}
	 */
	@Test
	void testEquals12() {
		LogEvent logEvent = new LogEvent();
		logEvent.setAmountInCents("10");
		logEvent.setChecksum("Checksum");
		logEvent.setCurrency("GBP");
		logEvent.setCustomerEmail(null);
		logEvent.setEnvironment("Environment");
		logEvent.setEvent("Event");
		logEvent.setId(1L);
		logEvent.setIdRef("Id Ref");
		logEvent.setPaymentLinkId("Payment link id");
		logEvent.setPaymentMethodType("Payment method type");
		logEvent.setPaymentSourceId("Payment source id");
		logEvent.setRedirectUrl("https://example.org/example");
		logEvent.setReference("Reference");
		logEvent.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent.setShippingAddress("42 Main St");
		logEvent.setStateCore(1);
		logEvent.setStatus("Status");
		logEvent.setTimestamp("Timestamp");
		logEvent.setUrlCore("https://example.org/example");

		LogEvent logEvent2 = new LogEvent();
		logEvent2.setAmountInCents("10");
		logEvent2.setChecksum("Checksum");
		logEvent2.setCurrency("GBP");
		logEvent2.setCustomerEmail("jane.doe@example.org");
		logEvent2.setEnvironment("Environment");
		logEvent2.setEvent("Event");
		logEvent2.setId(1L);
		logEvent2.setIdRef("Id Ref");
		logEvent2.setPaymentLinkId("Payment link id");
		logEvent2.setPaymentMethodType("Payment method type");
		logEvent2.setPaymentSourceId("Payment source id");
		logEvent2.setRedirectUrl("https://example.org/example");
		logEvent2.setReference("Reference");
		logEvent2.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent2.setShippingAddress("42 Main St");
		logEvent2.setStateCore(1);
		logEvent2.setStatus("Status");
		logEvent2.setTimestamp("Timestamp");
		logEvent2.setUrlCore("https://example.org/example");
		assertNotEquals(logEvent, logEvent2);
	}

	/**
	 * Method under test: {@link LogEvent#equals(Object)}
	 */
	@Test
	void testEquals13() {
		LogEvent logEvent = new LogEvent();
		logEvent.setAmountInCents("10");
		logEvent.setChecksum("Checksum");
		logEvent.setCurrency("GBP");
		logEvent.setCustomerEmail("jane.doe@example.org");
		logEvent.setEnvironment("Event");
		logEvent.setEvent("Event");
		logEvent.setId(1L);
		logEvent.setIdRef("Id Ref");
		logEvent.setPaymentLinkId("Payment link id");
		logEvent.setPaymentMethodType("Payment method type");
		logEvent.setPaymentSourceId("Payment source id");
		logEvent.setRedirectUrl("https://example.org/example");
		logEvent.setReference("Reference");
		logEvent.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent.setShippingAddress("42 Main St");
		logEvent.setStateCore(1);
		logEvent.setStatus("Status");
		logEvent.setTimestamp("Timestamp");
		logEvent.setUrlCore("https://example.org/example");

		LogEvent logEvent2 = new LogEvent();
		logEvent2.setAmountInCents("10");
		logEvent2.setChecksum("Checksum");
		logEvent2.setCurrency("GBP");
		logEvent2.setCustomerEmail("jane.doe@example.org");
		logEvent2.setEnvironment("Environment");
		logEvent2.setEvent("Event");
		logEvent2.setId(1L);
		logEvent2.setIdRef("Id Ref");
		logEvent2.setPaymentLinkId("Payment link id");
		logEvent2.setPaymentMethodType("Payment method type");
		logEvent2.setPaymentSourceId("Payment source id");
		logEvent2.setRedirectUrl("https://example.org/example");
		logEvent2.setReference("Reference");
		logEvent2.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent2.setShippingAddress("42 Main St");
		logEvent2.setStateCore(1);
		logEvent2.setStatus("Status");
		logEvent2.setTimestamp("Timestamp");
		logEvent2.setUrlCore("https://example.org/example");
		assertNotEquals(logEvent, logEvent2);
	}

	/**
	 * Method under test: {@link LogEvent#equals(Object)}
	 */
	@Test
	void testEquals14() {
		LogEvent logEvent = new LogEvent();
		logEvent.setAmountInCents("10");
		logEvent.setChecksum("Checksum");
		logEvent.setCurrency("GBP");
		logEvent.setCustomerEmail("jane.doe@example.org");
		logEvent.setEnvironment(null);
		logEvent.setEvent("Event");
		logEvent.setId(1L);
		logEvent.setIdRef("Id Ref");
		logEvent.setPaymentLinkId("Payment link id");
		logEvent.setPaymentMethodType("Payment method type");
		logEvent.setPaymentSourceId("Payment source id");
		logEvent.setRedirectUrl("https://example.org/example");
		logEvent.setReference("Reference");
		logEvent.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent.setShippingAddress("42 Main St");
		logEvent.setStateCore(1);
		logEvent.setStatus("Status");
		logEvent.setTimestamp("Timestamp");
		logEvent.setUrlCore("https://example.org/example");

		LogEvent logEvent2 = new LogEvent();
		logEvent2.setAmountInCents("10");
		logEvent2.setChecksum("Checksum");
		logEvent2.setCurrency("GBP");
		logEvent2.setCustomerEmail("jane.doe@example.org");
		logEvent2.setEnvironment("Environment");
		logEvent2.setEvent("Event");
		logEvent2.setId(1L);
		logEvent2.setIdRef("Id Ref");
		logEvent2.setPaymentLinkId("Payment link id");
		logEvent2.setPaymentMethodType("Payment method type");
		logEvent2.setPaymentSourceId("Payment source id");
		logEvent2.setRedirectUrl("https://example.org/example");
		logEvent2.setReference("Reference");
		logEvent2.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent2.setShippingAddress("42 Main St");
		logEvent2.setStateCore(1);
		logEvent2.setStatus("Status");
		logEvent2.setTimestamp("Timestamp");
		logEvent2.setUrlCore("https://example.org/example");
		assertNotEquals(logEvent, logEvent2);
	}

	/**
	 * Method under test: {@link LogEvent#equals(Object)}
	 */
	@Test
	void testEquals15() {
		LogEvent logEvent = new LogEvent();
		logEvent.setAmountInCents("10");
		logEvent.setChecksum("Checksum");
		logEvent.setCurrency("GBP");
		logEvent.setCustomerEmail("jane.doe@example.org");
		logEvent.setEnvironment("Environment");
		logEvent.setEvent("Id Ref");
		logEvent.setId(1L);
		logEvent.setIdRef("Id Ref");
		logEvent.setPaymentLinkId("Payment link id");
		logEvent.setPaymentMethodType("Payment method type");
		logEvent.setPaymentSourceId("Payment source id");
		logEvent.setRedirectUrl("https://example.org/example");
		logEvent.setReference("Reference");
		logEvent.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent.setShippingAddress("42 Main St");
		logEvent.setStateCore(1);
		logEvent.setStatus("Status");
		logEvent.setTimestamp("Timestamp");
		logEvent.setUrlCore("https://example.org/example");

		LogEvent logEvent2 = new LogEvent();
		logEvent2.setAmountInCents("10");
		logEvent2.setChecksum("Checksum");
		logEvent2.setCurrency("GBP");
		logEvent2.setCustomerEmail("jane.doe@example.org");
		logEvent2.setEnvironment("Environment");
		logEvent2.setEvent("Event");
		logEvent2.setId(1L);
		logEvent2.setIdRef("Id Ref");
		logEvent2.setPaymentLinkId("Payment link id");
		logEvent2.setPaymentMethodType("Payment method type");
		logEvent2.setPaymentSourceId("Payment source id");
		logEvent2.setRedirectUrl("https://example.org/example");
		logEvent2.setReference("Reference");
		logEvent2.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent2.setShippingAddress("42 Main St");
		logEvent2.setStateCore(1);
		logEvent2.setStatus("Status");
		logEvent2.setTimestamp("Timestamp");
		logEvent2.setUrlCore("https://example.org/example");
		assertNotEquals(logEvent, logEvent2);
	}

	/**
	 * Method under test: {@link LogEvent#equals(Object)}
	 */
	@Test
	void testEquals16() {
		LogEvent logEvent = new LogEvent();
		logEvent.setAmountInCents("10");
		logEvent.setChecksum("Checksum");
		logEvent.setCurrency("GBP");
		logEvent.setCustomerEmail("jane.doe@example.org");
		logEvent.setEnvironment("Environment");
		logEvent.setEvent(null);
		logEvent.setId(1L);
		logEvent.setIdRef("Id Ref");
		logEvent.setPaymentLinkId("Payment link id");
		logEvent.setPaymentMethodType("Payment method type");
		logEvent.setPaymentSourceId("Payment source id");
		logEvent.setRedirectUrl("https://example.org/example");
		logEvent.setReference("Reference");
		logEvent.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent.setShippingAddress("42 Main St");
		logEvent.setStateCore(1);
		logEvent.setStatus("Status");
		logEvent.setTimestamp("Timestamp");
		logEvent.setUrlCore("https://example.org/example");

		LogEvent logEvent2 = new LogEvent();
		logEvent2.setAmountInCents("10");
		logEvent2.setChecksum("Checksum");
		logEvent2.setCurrency("GBP");
		logEvent2.setCustomerEmail("jane.doe@example.org");
		logEvent2.setEnvironment("Environment");
		logEvent2.setEvent("Event");
		logEvent2.setId(1L);
		logEvent2.setIdRef("Id Ref");
		logEvent2.setPaymentLinkId("Payment link id");
		logEvent2.setPaymentMethodType("Payment method type");
		logEvent2.setPaymentSourceId("Payment source id");
		logEvent2.setRedirectUrl("https://example.org/example");
		logEvent2.setReference("Reference");
		logEvent2.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent2.setShippingAddress("42 Main St");
		logEvent2.setStateCore(1);
		logEvent2.setStatus("Status");
		logEvent2.setTimestamp("Timestamp");
		logEvent2.setUrlCore("https://example.org/example");
		assertNotEquals(logEvent, logEvent2);
	}

	/**
	 * Method under test: {@link LogEvent#equals(Object)}
	 */
	@Test
	void testEquals17() {
		LogEvent logEvent = new LogEvent();
		logEvent.setAmountInCents("10");
		logEvent.setChecksum("Checksum");
		logEvent.setCurrency("GBP");
		logEvent.setCustomerEmail("jane.doe@example.org");
		logEvent.setEnvironment("Environment");
		logEvent.setEvent("Event");
		logEvent.setId(2L);
		logEvent.setIdRef("Id Ref");
		logEvent.setPaymentLinkId("Payment link id");
		logEvent.setPaymentMethodType("Payment method type");
		logEvent.setPaymentSourceId("Payment source id");
		logEvent.setRedirectUrl("https://example.org/example");
		logEvent.setReference("Reference");
		logEvent.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent.setShippingAddress("42 Main St");
		logEvent.setStateCore(1);
		logEvent.setStatus("Status");
		logEvent.setTimestamp("Timestamp");
		logEvent.setUrlCore("https://example.org/example");

		LogEvent logEvent2 = new LogEvent();
		logEvent2.setAmountInCents("10");
		logEvent2.setChecksum("Checksum");
		logEvent2.setCurrency("GBP");
		logEvent2.setCustomerEmail("jane.doe@example.org");
		logEvent2.setEnvironment("Environment");
		logEvent2.setEvent("Event");
		logEvent2.setId(1L);
		logEvent2.setIdRef("Id Ref");
		logEvent2.setPaymentLinkId("Payment link id");
		logEvent2.setPaymentMethodType("Payment method type");
		logEvent2.setPaymentSourceId("Payment source id");
		logEvent2.setRedirectUrl("https://example.org/example");
		logEvent2.setReference("Reference");
		logEvent2.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent2.setShippingAddress("42 Main St");
		logEvent2.setStateCore(1);
		logEvent2.setStatus("Status");
		logEvent2.setTimestamp("Timestamp");
		logEvent2.setUrlCore("https://example.org/example");
		assertNotEquals(logEvent, logEvent2);
	}

	/**
	 * Method under test: {@link LogEvent#equals(Object)}
	 */
	@Test
	void testEquals18() {
		LogEvent logEvent = new LogEvent();
		logEvent.setAmountInCents("10");
		logEvent.setChecksum("Checksum");
		logEvent.setCurrency("GBP");
		logEvent.setCustomerEmail("jane.doe@example.org");
		logEvent.setEnvironment("Environment");
		logEvent.setEvent("Event");
		logEvent.setId(null);
		logEvent.setIdRef("Id Ref");
		logEvent.setPaymentLinkId("Payment link id");
		logEvent.setPaymentMethodType("Payment method type");
		logEvent.setPaymentSourceId("Payment source id");
		logEvent.setRedirectUrl("https://example.org/example");
		logEvent.setReference("Reference");
		logEvent.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent.setShippingAddress("42 Main St");
		logEvent.setStateCore(1);
		logEvent.setStatus("Status");
		logEvent.setTimestamp("Timestamp");
		logEvent.setUrlCore("https://example.org/example");

		LogEvent logEvent2 = new LogEvent();
		logEvent2.setAmountInCents("10");
		logEvent2.setChecksum("Checksum");
		logEvent2.setCurrency("GBP");
		logEvent2.setCustomerEmail("jane.doe@example.org");
		logEvent2.setEnvironment("Environment");
		logEvent2.setEvent("Event");
		logEvent2.setId(1L);
		logEvent2.setIdRef("Id Ref");
		logEvent2.setPaymentLinkId("Payment link id");
		logEvent2.setPaymentMethodType("Payment method type");
		logEvent2.setPaymentSourceId("Payment source id");
		logEvent2.setRedirectUrl("https://example.org/example");
		logEvent2.setReference("Reference");
		logEvent2.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent2.setShippingAddress("42 Main St");
		logEvent2.setStateCore(1);
		logEvent2.setStatus("Status");
		logEvent2.setTimestamp("Timestamp");
		logEvent2.setUrlCore("https://example.org/example");
		assertNotEquals(logEvent, logEvent2);
	}

	/**
	 * Method under test: {@link LogEvent#equals(Object)}
	 */
	@Test
	void testEquals19() {
		LogEvent logEvent = new LogEvent();
		logEvent.setAmountInCents("10");
		logEvent.setChecksum("Checksum");
		logEvent.setCurrency("GBP");
		logEvent.setCustomerEmail("jane.doe@example.org");
		logEvent.setEnvironment("Environment");
		logEvent.setEvent("Event");
		logEvent.setId(1L);
		logEvent.setIdRef("Event");
		logEvent.setPaymentLinkId("Payment link id");
		logEvent.setPaymentMethodType("Payment method type");
		logEvent.setPaymentSourceId("Payment source id");
		logEvent.setRedirectUrl("https://example.org/example");
		logEvent.setReference("Reference");
		logEvent.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent.setShippingAddress("42 Main St");
		logEvent.setStateCore(1);
		logEvent.setStatus("Status");
		logEvent.setTimestamp("Timestamp");
		logEvent.setUrlCore("https://example.org/example");

		LogEvent logEvent2 = new LogEvent();
		logEvent2.setAmountInCents("10");
		logEvent2.setChecksum("Checksum");
		logEvent2.setCurrency("GBP");
		logEvent2.setCustomerEmail("jane.doe@example.org");
		logEvent2.setEnvironment("Environment");
		logEvent2.setEvent("Event");
		logEvent2.setId(1L);
		logEvent2.setIdRef("Id Ref");
		logEvent2.setPaymentLinkId("Payment link id");
		logEvent2.setPaymentMethodType("Payment method type");
		logEvent2.setPaymentSourceId("Payment source id");
		logEvent2.setRedirectUrl("https://example.org/example");
		logEvent2.setReference("Reference");
		logEvent2.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent2.setShippingAddress("42 Main St");
		logEvent2.setStateCore(1);
		logEvent2.setStatus("Status");
		logEvent2.setTimestamp("Timestamp");
		logEvent2.setUrlCore("https://example.org/example");
		assertNotEquals(logEvent, logEvent2);
	}

	/**
	 * Method under test: {@link LogEvent#equals(Object)}
	 */
	@Test
	void testEquals20() {
		LogEvent logEvent = new LogEvent();
		logEvent.setAmountInCents("10");
		logEvent.setChecksum("Checksum");
		logEvent.setCurrency("GBP");
		logEvent.setCustomerEmail("jane.doe@example.org");
		logEvent.setEnvironment("Environment");
		logEvent.setEvent("Event");
		logEvent.setId(1L);
		logEvent.setIdRef(null);
		logEvent.setPaymentLinkId("Payment link id");
		logEvent.setPaymentMethodType("Payment method type");
		logEvent.setPaymentSourceId("Payment source id");
		logEvent.setRedirectUrl("https://example.org/example");
		logEvent.setReference("Reference");
		logEvent.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent.setShippingAddress("42 Main St");
		logEvent.setStateCore(1);
		logEvent.setStatus("Status");
		logEvent.setTimestamp("Timestamp");
		logEvent.setUrlCore("https://example.org/example");

		LogEvent logEvent2 = new LogEvent();
		logEvent2.setAmountInCents("10");
		logEvent2.setChecksum("Checksum");
		logEvent2.setCurrency("GBP");
		logEvent2.setCustomerEmail("jane.doe@example.org");
		logEvent2.setEnvironment("Environment");
		logEvent2.setEvent("Event");
		logEvent2.setId(1L);
		logEvent2.setIdRef("Id Ref");
		logEvent2.setPaymentLinkId("Payment link id");
		logEvent2.setPaymentMethodType("Payment method type");
		logEvent2.setPaymentSourceId("Payment source id");
		logEvent2.setRedirectUrl("https://example.org/example");
		logEvent2.setReference("Reference");
		logEvent2.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent2.setShippingAddress("42 Main St");
		logEvent2.setStateCore(1);
		logEvent2.setStatus("Status");
		logEvent2.setTimestamp("Timestamp");
		logEvent2.setUrlCore("https://example.org/example");
		assertNotEquals(logEvent, logEvent2);
	}

	/**
	 * Method under test: {@link LogEvent#equals(Object)}
	 */
	@Test
	void testEquals21() {
		LogEvent logEvent = new LogEvent();
		logEvent.setAmountInCents("10");
		logEvent.setChecksum("Checksum");
		logEvent.setCurrency("GBP");
		logEvent.setCustomerEmail("jane.doe@example.org");
		logEvent.setEnvironment("Environment");
		logEvent.setEvent("Event");
		logEvent.setId(1L);
		logEvent.setIdRef("Id Ref");
		logEvent.setPaymentLinkId("Event");
		logEvent.setPaymentMethodType("Payment method type");
		logEvent.setPaymentSourceId("Payment source id");
		logEvent.setRedirectUrl("https://example.org/example");
		logEvent.setReference("Reference");
		logEvent.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent.setShippingAddress("42 Main St");
		logEvent.setStateCore(1);
		logEvent.setStatus("Status");
		logEvent.setTimestamp("Timestamp");
		logEvent.setUrlCore("https://example.org/example");

		LogEvent logEvent2 = new LogEvent();
		logEvent2.setAmountInCents("10");
		logEvent2.setChecksum("Checksum");
		logEvent2.setCurrency("GBP");
		logEvent2.setCustomerEmail("jane.doe@example.org");
		logEvent2.setEnvironment("Environment");
		logEvent2.setEvent("Event");
		logEvent2.setId(1L);
		logEvent2.setIdRef("Id Ref");
		logEvent2.setPaymentLinkId("Payment link id");
		logEvent2.setPaymentMethodType("Payment method type");
		logEvent2.setPaymentSourceId("Payment source id");
		logEvent2.setRedirectUrl("https://example.org/example");
		logEvent2.setReference("Reference");
		logEvent2.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent2.setShippingAddress("42 Main St");
		logEvent2.setStateCore(1);
		logEvent2.setStatus("Status");
		logEvent2.setTimestamp("Timestamp");
		logEvent2.setUrlCore("https://example.org/example");
		assertNotEquals(logEvent, logEvent2);
	}

	/**
	 * Method under test: {@link LogEvent#equals(Object)}
	 */
	@Test
	void testEquals22() {
		LogEvent logEvent = new LogEvent();
		logEvent.setAmountInCents("10");
		logEvent.setChecksum("Checksum");
		logEvent.setCurrency("GBP");
		logEvent.setCustomerEmail("jane.doe@example.org");
		logEvent.setEnvironment("Environment");
		logEvent.setEvent("Event");
		logEvent.setId(1L);
		logEvent.setIdRef("Id Ref");
		logEvent.setPaymentLinkId(null);
		logEvent.setPaymentMethodType("Payment method type");
		logEvent.setPaymentSourceId("Payment source id");
		logEvent.setRedirectUrl("https://example.org/example");
		logEvent.setReference("Reference");
		logEvent.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent.setShippingAddress("42 Main St");
		logEvent.setStateCore(1);
		logEvent.setStatus("Status");
		logEvent.setTimestamp("Timestamp");
		logEvent.setUrlCore("https://example.org/example");

		LogEvent logEvent2 = new LogEvent();
		logEvent2.setAmountInCents("10");
		logEvent2.setChecksum("Checksum");
		logEvent2.setCurrency("GBP");
		logEvent2.setCustomerEmail("jane.doe@example.org");
		logEvent2.setEnvironment("Environment");
		logEvent2.setEvent("Event");
		logEvent2.setId(1L);
		logEvent2.setIdRef("Id Ref");
		logEvent2.setPaymentLinkId("Payment link id");
		logEvent2.setPaymentMethodType("Payment method type");
		logEvent2.setPaymentSourceId("Payment source id");
		logEvent2.setRedirectUrl("https://example.org/example");
		logEvent2.setReference("Reference");
		logEvent2.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent2.setShippingAddress("42 Main St");
		logEvent2.setStateCore(1);
		logEvent2.setStatus("Status");
		logEvent2.setTimestamp("Timestamp");
		logEvent2.setUrlCore("https://example.org/example");
		assertNotEquals(logEvent, logEvent2);
	}

	/**
	 * Method under test: {@link LogEvent#equals(Object)}
	 */
	@Test
	void testEquals23() {
		LogEvent logEvent = new LogEvent();
		logEvent.setAmountInCents("10");
		logEvent.setChecksum("Checksum");
		logEvent.setCurrency("GBP");
		logEvent.setCustomerEmail("jane.doe@example.org");
		logEvent.setEnvironment("Environment");
		logEvent.setEvent("Event");
		logEvent.setId(1L);
		logEvent.setIdRef("Id Ref");
		logEvent.setPaymentLinkId("Payment link id");
		logEvent.setPaymentMethodType("Event");
		logEvent.setPaymentSourceId("Payment source id");
		logEvent.setRedirectUrl("https://example.org/example");
		logEvent.setReference("Reference");
		logEvent.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent.setShippingAddress("42 Main St");
		logEvent.setStateCore(1);
		logEvent.setStatus("Status");
		logEvent.setTimestamp("Timestamp");
		logEvent.setUrlCore("https://example.org/example");

		LogEvent logEvent2 = new LogEvent();
		logEvent2.setAmountInCents("10");
		logEvent2.setChecksum("Checksum");
		logEvent2.setCurrency("GBP");
		logEvent2.setCustomerEmail("jane.doe@example.org");
		logEvent2.setEnvironment("Environment");
		logEvent2.setEvent("Event");
		logEvent2.setId(1L);
		logEvent2.setIdRef("Id Ref");
		logEvent2.setPaymentLinkId("Payment link id");
		logEvent2.setPaymentMethodType("Payment method type");
		logEvent2.setPaymentSourceId("Payment source id");
		logEvent2.setRedirectUrl("https://example.org/example");
		logEvent2.setReference("Reference");
		logEvent2.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent2.setShippingAddress("42 Main St");
		logEvent2.setStateCore(1);
		logEvent2.setStatus("Status");
		logEvent2.setTimestamp("Timestamp");
		logEvent2.setUrlCore("https://example.org/example");
		assertNotEquals(logEvent, logEvent2);
	}

	/**
	 * Method under test: {@link LogEvent#equals(Object)}
	 */
	@Test
	void testEquals24() {
		LogEvent logEvent = new LogEvent();
		logEvent.setAmountInCents("10");
		logEvent.setChecksum("Checksum");
		logEvent.setCurrency("GBP");
		logEvent.setCustomerEmail("jane.doe@example.org");
		logEvent.setEnvironment("Environment");
		logEvent.setEvent("Event");
		logEvent.setId(1L);
		logEvent.setIdRef("Id Ref");
		logEvent.setPaymentLinkId("Payment link id");
		logEvent.setPaymentMethodType(null);
		logEvent.setPaymentSourceId("Payment source id");
		logEvent.setRedirectUrl("https://example.org/example");
		logEvent.setReference("Reference");
		logEvent.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent.setShippingAddress("42 Main St");
		logEvent.setStateCore(1);
		logEvent.setStatus("Status");
		logEvent.setTimestamp("Timestamp");
		logEvent.setUrlCore("https://example.org/example");

		LogEvent logEvent2 = new LogEvent();
		logEvent2.setAmountInCents("10");
		logEvent2.setChecksum("Checksum");
		logEvent2.setCurrency("GBP");
		logEvent2.setCustomerEmail("jane.doe@example.org");
		logEvent2.setEnvironment("Environment");
		logEvent2.setEvent("Event");
		logEvent2.setId(1L);
		logEvent2.setIdRef("Id Ref");
		logEvent2.setPaymentLinkId("Payment link id");
		logEvent2.setPaymentMethodType("Payment method type");
		logEvent2.setPaymentSourceId("Payment source id");
		logEvent2.setRedirectUrl("https://example.org/example");
		logEvent2.setReference("Reference");
		logEvent2.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent2.setShippingAddress("42 Main St");
		logEvent2.setStateCore(1);
		logEvent2.setStatus("Status");
		logEvent2.setTimestamp("Timestamp");
		logEvent2.setUrlCore("https://example.org/example");
		assertNotEquals(logEvent, logEvent2);
	}

	/**
	 * Method under test: {@link LogEvent#equals(Object)}
	 */
	@Test
	void testEquals25() {
		LogEvent logEvent = new LogEvent();
		logEvent.setAmountInCents("10");
		logEvent.setChecksum("Checksum");
		logEvent.setCurrency("GBP");
		logEvent.setCustomerEmail("jane.doe@example.org");
		logEvent.setEnvironment("Environment");
		logEvent.setEvent("Event");
		logEvent.setId(1L);
		logEvent.setIdRef("Id Ref");
		logEvent.setPaymentLinkId("Payment link id");
		logEvent.setPaymentMethodType("Payment method type");
		logEvent.setPaymentSourceId("Event");
		logEvent.setRedirectUrl("https://example.org/example");
		logEvent.setReference("Reference");
		logEvent.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent.setShippingAddress("42 Main St");
		logEvent.setStateCore(1);
		logEvent.setStatus("Status");
		logEvent.setTimestamp("Timestamp");
		logEvent.setUrlCore("https://example.org/example");

		LogEvent logEvent2 = new LogEvent();
		logEvent2.setAmountInCents("10");
		logEvent2.setChecksum("Checksum");
		logEvent2.setCurrency("GBP");
		logEvent2.setCustomerEmail("jane.doe@example.org");
		logEvent2.setEnvironment("Environment");
		logEvent2.setEvent("Event");
		logEvent2.setId(1L);
		logEvent2.setIdRef("Id Ref");
		logEvent2.setPaymentLinkId("Payment link id");
		logEvent2.setPaymentMethodType("Payment method type");
		logEvent2.setPaymentSourceId("Payment source id");
		logEvent2.setRedirectUrl("https://example.org/example");
		logEvent2.setReference("Reference");
		logEvent2.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent2.setShippingAddress("42 Main St");
		logEvent2.setStateCore(1);
		logEvent2.setStatus("Status");
		logEvent2.setTimestamp("Timestamp");
		logEvent2.setUrlCore("https://example.org/example");
		assertNotEquals(logEvent, logEvent2);
	}

	/**
	 * Method under test: {@link LogEvent#equals(Object)}
	 */
	@Test
	void testEquals26() {
		LogEvent logEvent = new LogEvent();
		logEvent.setAmountInCents("10");
		logEvent.setChecksum("Checksum");
		logEvent.setCurrency("GBP");
		logEvent.setCustomerEmail("jane.doe@example.org");
		logEvent.setEnvironment("Environment");
		logEvent.setEvent("Event");
		logEvent.setId(1L);
		logEvent.setIdRef("Id Ref");
		logEvent.setPaymentLinkId("Payment link id");
		logEvent.setPaymentMethodType("Payment method type");
		logEvent.setPaymentSourceId(null);
		logEvent.setRedirectUrl("https://example.org/example");
		logEvent.setReference("Reference");
		logEvent.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent.setShippingAddress("42 Main St");
		logEvent.setStateCore(1);
		logEvent.setStatus("Status");
		logEvent.setTimestamp("Timestamp");
		logEvent.setUrlCore("https://example.org/example");

		LogEvent logEvent2 = new LogEvent();
		logEvent2.setAmountInCents("10");
		logEvent2.setChecksum("Checksum");
		logEvent2.setCurrency("GBP");
		logEvent2.setCustomerEmail("jane.doe@example.org");
		logEvent2.setEnvironment("Environment");
		logEvent2.setEvent("Event");
		logEvent2.setId(1L);
		logEvent2.setIdRef("Id Ref");
		logEvent2.setPaymentLinkId("Payment link id");
		logEvent2.setPaymentMethodType("Payment method type");
		logEvent2.setPaymentSourceId("Payment source id");
		logEvent2.setRedirectUrl("https://example.org/example");
		logEvent2.setReference("Reference");
		logEvent2.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent2.setShippingAddress("42 Main St");
		logEvent2.setStateCore(1);
		logEvent2.setStatus("Status");
		logEvent2.setTimestamp("Timestamp");
		logEvent2.setUrlCore("https://example.org/example");
		assertNotEquals(logEvent, logEvent2);
	}

	/**
	 * Method under test: {@link LogEvent#equals(Object)}
	 */
	@Test
	void testEquals27() {
		LogEvent logEvent = new LogEvent();
		logEvent.setAmountInCents("10");
		logEvent.setChecksum("Checksum");
		logEvent.setCurrency("GBP");
		logEvent.setCustomerEmail("jane.doe@example.org");
		logEvent.setEnvironment("Environment");
		logEvent.setEvent("Event");
		logEvent.setId(1L);
		logEvent.setIdRef("Id Ref");
		logEvent.setPaymentLinkId("Payment link id");
		logEvent.setPaymentMethodType("Payment method type");
		logEvent.setPaymentSourceId("Payment source id");
		logEvent.setRedirectUrl("Event");
		logEvent.setReference("Reference");
		logEvent.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent.setShippingAddress("42 Main St");
		logEvent.setStateCore(1);
		logEvent.setStatus("Status");
		logEvent.setTimestamp("Timestamp");
		logEvent.setUrlCore("https://example.org/example");

		LogEvent logEvent2 = new LogEvent();
		logEvent2.setAmountInCents("10");
		logEvent2.setChecksum("Checksum");
		logEvent2.setCurrency("GBP");
		logEvent2.setCustomerEmail("jane.doe@example.org");
		logEvent2.setEnvironment("Environment");
		logEvent2.setEvent("Event");
		logEvent2.setId(1L);
		logEvent2.setIdRef("Id Ref");
		logEvent2.setPaymentLinkId("Payment link id");
		logEvent2.setPaymentMethodType("Payment method type");
		logEvent2.setPaymentSourceId("Payment source id");
		logEvent2.setRedirectUrl("https://example.org/example");
		logEvent2.setReference("Reference");
		logEvent2.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent2.setShippingAddress("42 Main St");
		logEvent2.setStateCore(1);
		logEvent2.setStatus("Status");
		logEvent2.setTimestamp("Timestamp");
		logEvent2.setUrlCore("https://example.org/example");
		assertNotEquals(logEvent, logEvent2);
	}

	/**
	 * Method under test: {@link LogEvent#equals(Object)}
	 */
	@Test
	void testEquals28() {
		LogEvent logEvent = new LogEvent();
		logEvent.setAmountInCents("10");
		logEvent.setChecksum("Checksum");
		logEvent.setCurrency("GBP");
		logEvent.setCustomerEmail("jane.doe@example.org");
		logEvent.setEnvironment("Environment");
		logEvent.setEvent("Event");
		logEvent.setId(1L);
		logEvent.setIdRef("Id Ref");
		logEvent.setPaymentLinkId("Payment link id");
		logEvent.setPaymentMethodType("Payment method type");
		logEvent.setPaymentSourceId("Payment source id");
		logEvent.setRedirectUrl(null);
		logEvent.setReference("Reference");
		logEvent.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent.setShippingAddress("42 Main St");
		logEvent.setStateCore(1);
		logEvent.setStatus("Status");
		logEvent.setTimestamp("Timestamp");
		logEvent.setUrlCore("https://example.org/example");

		LogEvent logEvent2 = new LogEvent();
		logEvent2.setAmountInCents("10");
		logEvent2.setChecksum("Checksum");
		logEvent2.setCurrency("GBP");
		logEvent2.setCustomerEmail("jane.doe@example.org");
		logEvent2.setEnvironment("Environment");
		logEvent2.setEvent("Event");
		logEvent2.setId(1L);
		logEvent2.setIdRef("Id Ref");
		logEvent2.setPaymentLinkId("Payment link id");
		logEvent2.setPaymentMethodType("Payment method type");
		logEvent2.setPaymentSourceId("Payment source id");
		logEvent2.setRedirectUrl("https://example.org/example");
		logEvent2.setReference("Reference");
		logEvent2.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent2.setShippingAddress("42 Main St");
		logEvent2.setStateCore(1);
		logEvent2.setStatus("Status");
		logEvent2.setTimestamp("Timestamp");
		logEvent2.setUrlCore("https://example.org/example");
		assertNotEquals(logEvent, logEvent2);
	}

	/**
	 * Method under test: {@link LogEvent#equals(Object)}
	 */
	@Test
	void testEquals29() {
		LogEvent logEvent = new LogEvent();
		logEvent.setAmountInCents("10");
		logEvent.setChecksum("Checksum");
		logEvent.setCurrency("GBP");
		logEvent.setCustomerEmail("jane.doe@example.org");
		logEvent.setEnvironment("Environment");
		logEvent.setEvent("Event");
		logEvent.setId(1L);
		logEvent.setIdRef("Id Ref");
		logEvent.setPaymentLinkId("Payment link id");
		logEvent.setPaymentMethodType("Payment method type");
		logEvent.setPaymentSourceId("Payment source id");
		logEvent.setRedirectUrl("https://example.org/example");
		logEvent.setReference("Event");
		logEvent.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent.setShippingAddress("42 Main St");
		logEvent.setStateCore(1);
		logEvent.setStatus("Status");
		logEvent.setTimestamp("Timestamp");
		logEvent.setUrlCore("https://example.org/example");

		LogEvent logEvent2 = new LogEvent();
		logEvent2.setAmountInCents("10");
		logEvent2.setChecksum("Checksum");
		logEvent2.setCurrency("GBP");
		logEvent2.setCustomerEmail("jane.doe@example.org");
		logEvent2.setEnvironment("Environment");
		logEvent2.setEvent("Event");
		logEvent2.setId(1L);
		logEvent2.setIdRef("Id Ref");
		logEvent2.setPaymentLinkId("Payment link id");
		logEvent2.setPaymentMethodType("Payment method type");
		logEvent2.setPaymentSourceId("Payment source id");
		logEvent2.setRedirectUrl("https://example.org/example");
		logEvent2.setReference("Reference");
		logEvent2.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent2.setShippingAddress("42 Main St");
		logEvent2.setStateCore(1);
		logEvent2.setStatus("Status");
		logEvent2.setTimestamp("Timestamp");
		logEvent2.setUrlCore("https://example.org/example");
		assertNotEquals(logEvent, logEvent2);
	}

	/**
	 * Method under test: {@link LogEvent#equals(Object)}
	 */
	@Test
	void testEquals30() {
		LogEvent logEvent = new LogEvent();
		logEvent.setAmountInCents("10");
		logEvent.setChecksum("Checksum");
		logEvent.setCurrency("GBP");
		logEvent.setCustomerEmail("jane.doe@example.org");
		logEvent.setEnvironment("Environment");
		logEvent.setEvent("Event");
		logEvent.setId(1L);
		logEvent.setIdRef("Id Ref");
		logEvent.setPaymentLinkId("Payment link id");
		logEvent.setPaymentMethodType("Payment method type");
		logEvent.setPaymentSourceId("Payment source id");
		logEvent.setRedirectUrl("https://example.org/example");
		logEvent.setReference(null);
		logEvent.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent.setShippingAddress("42 Main St");
		logEvent.setStateCore(1);
		logEvent.setStatus("Status");
		logEvent.setTimestamp("Timestamp");
		logEvent.setUrlCore("https://example.org/example");

		LogEvent logEvent2 = new LogEvent();
		logEvent2.setAmountInCents("10");
		logEvent2.setChecksum("Checksum");
		logEvent2.setCurrency("GBP");
		logEvent2.setCustomerEmail("jane.doe@example.org");
		logEvent2.setEnvironment("Environment");
		logEvent2.setEvent("Event");
		logEvent2.setId(1L);
		logEvent2.setIdRef("Id Ref");
		logEvent2.setPaymentLinkId("Payment link id");
		logEvent2.setPaymentMethodType("Payment method type");
		logEvent2.setPaymentSourceId("Payment source id");
		logEvent2.setRedirectUrl("https://example.org/example");
		logEvent2.setReference("Reference");
		logEvent2.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent2.setShippingAddress("42 Main St");
		logEvent2.setStateCore(1);
		logEvent2.setStatus("Status");
		logEvent2.setTimestamp("Timestamp");
		logEvent2.setUrlCore("https://example.org/example");
		assertNotEquals(logEvent, logEvent2);
	}

	/**
	 * Method under test: {@link LogEvent#equals(Object)}
	 */
	@Test
	void testEquals31() {
		LogEvent logEvent = new LogEvent();
		logEvent.setAmountInCents("10");
		logEvent.setChecksum("Checksum");
		logEvent.setCurrency("GBP");
		logEvent.setCustomerEmail("jane.doe@example.org");
		logEvent.setEnvironment("Environment");
		logEvent.setEvent("Event");
		logEvent.setId(1L);
		logEvent.setIdRef("Id Ref");
		logEvent.setPaymentLinkId("Payment link id");
		logEvent.setPaymentMethodType("Payment method type");
		logEvent.setPaymentSourceId("Payment source id");
		logEvent.setRedirectUrl("https://example.org/example");
		logEvent.setReference("Reference");
		logEvent.setSentAt(Date.from(LocalDate.now().atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent.setShippingAddress("42 Main St");
		logEvent.setStateCore(1);
		logEvent.setStatus("Status");
		logEvent.setTimestamp("Timestamp");
		logEvent.setUrlCore("https://example.org/example");

		LogEvent logEvent2 = new LogEvent();
		logEvent2.setAmountInCents("10");
		logEvent2.setChecksum("Checksum");
		logEvent2.setCurrency("GBP");
		logEvent2.setCustomerEmail("jane.doe@example.org");
		logEvent2.setEnvironment("Environment");
		logEvent2.setEvent("Event");
		logEvent2.setId(1L);
		logEvent2.setIdRef("Id Ref");
		logEvent2.setPaymentLinkId("Payment link id");
		logEvent2.setPaymentMethodType("Payment method type");
		logEvent2.setPaymentSourceId("Payment source id");
		logEvent2.setRedirectUrl("https://example.org/example");
		logEvent2.setReference("Reference");
		logEvent2.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent2.setShippingAddress("42 Main St");
		logEvent2.setStateCore(1);
		logEvent2.setStatus("Status");
		logEvent2.setTimestamp("Timestamp");
		logEvent2.setUrlCore("https://example.org/example");
		assertNotEquals(logEvent, logEvent2);
	}

	/**
	 * Method under test: {@link LogEvent#equals(Object)}
	 */
	@Test
	void testEquals32() {
		LogEvent logEvent = new LogEvent();
		logEvent.setAmountInCents("10");
		logEvent.setChecksum("Checksum");
		logEvent.setCurrency("GBP");
		logEvent.setCustomerEmail("jane.doe@example.org");
		logEvent.setEnvironment("Environment");
		logEvent.setEvent("Event");
		logEvent.setId(1L);
		logEvent.setIdRef("Id Ref");
		logEvent.setPaymentLinkId("Payment link id");
		logEvent.setPaymentMethodType("Payment method type");
		logEvent.setPaymentSourceId("Payment source id");
		logEvent.setRedirectUrl("https://example.org/example");
		logEvent.setReference("Reference");
		logEvent.setSentAt(null);
		logEvent.setShippingAddress("42 Main St");
		logEvent.setStateCore(1);
		logEvent.setStatus("Status");
		logEvent.setTimestamp("Timestamp");
		logEvent.setUrlCore("https://example.org/example");

		LogEvent logEvent2 = new LogEvent();
		logEvent2.setAmountInCents("10");
		logEvent2.setChecksum("Checksum");
		logEvent2.setCurrency("GBP");
		logEvent2.setCustomerEmail("jane.doe@example.org");
		logEvent2.setEnvironment("Environment");
		logEvent2.setEvent("Event");
		logEvent2.setId(1L);
		logEvent2.setIdRef("Id Ref");
		logEvent2.setPaymentLinkId("Payment link id");
		logEvent2.setPaymentMethodType("Payment method type");
		logEvent2.setPaymentSourceId("Payment source id");
		logEvent2.setRedirectUrl("https://example.org/example");
		logEvent2.setReference("Reference");
		logEvent2.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent2.setShippingAddress("42 Main St");
		logEvent2.setStateCore(1);
		logEvent2.setStatus("Status");
		logEvent2.setTimestamp("Timestamp");
		logEvent2.setUrlCore("https://example.org/example");
		assertNotEquals(logEvent, logEvent2);
	}

	/**
	 * Method under test: {@link LogEvent#equals(Object)}
	 */
	@Test
	void testEquals33() {
		LogEvent logEvent = new LogEvent();
		logEvent.setAmountInCents("10");
		logEvent.setChecksum("Checksum");
		logEvent.setCurrency("GBP");
		logEvent.setCustomerEmail("jane.doe@example.org");
		logEvent.setEnvironment("Environment");
		logEvent.setEvent("Event");
		logEvent.setId(1L);
		logEvent.setIdRef("Id Ref");
		logEvent.setPaymentLinkId("Payment link id");
		logEvent.setPaymentMethodType("Payment method type");
		logEvent.setPaymentSourceId("Payment source id");
		logEvent.setRedirectUrl("https://example.org/example");
		logEvent.setReference("Reference");
		logEvent.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent.setShippingAddress("17 High St");
		logEvent.setStateCore(1);
		logEvent.setStatus("Status");
		logEvent.setTimestamp("Timestamp");
		logEvent.setUrlCore("https://example.org/example");

		LogEvent logEvent2 = new LogEvent();
		logEvent2.setAmountInCents("10");
		logEvent2.setChecksum("Checksum");
		logEvent2.setCurrency("GBP");
		logEvent2.setCustomerEmail("jane.doe@example.org");
		logEvent2.setEnvironment("Environment");
		logEvent2.setEvent("Event");
		logEvent2.setId(1L);
		logEvent2.setIdRef("Id Ref");
		logEvent2.setPaymentLinkId("Payment link id");
		logEvent2.setPaymentMethodType("Payment method type");
		logEvent2.setPaymentSourceId("Payment source id");
		logEvent2.setRedirectUrl("https://example.org/example");
		logEvent2.setReference("Reference");
		logEvent2.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent2.setShippingAddress("42 Main St");
		logEvent2.setStateCore(1);
		logEvent2.setStatus("Status");
		logEvent2.setTimestamp("Timestamp");
		logEvent2.setUrlCore("https://example.org/example");
		assertNotEquals(logEvent, logEvent2);
	}

	/**
	 * Method under test: {@link LogEvent#equals(Object)}
	 */
	@Test
	void testEquals34() {
		LogEvent logEvent = new LogEvent();
		logEvent.setAmountInCents("10");
		logEvent.setChecksum("Checksum");
		logEvent.setCurrency("GBP");
		logEvent.setCustomerEmail("jane.doe@example.org");
		logEvent.setEnvironment("Environment");
		logEvent.setEvent("Event");
		logEvent.setId(1L);
		logEvent.setIdRef("Id Ref");
		logEvent.setPaymentLinkId("Payment link id");
		logEvent.setPaymentMethodType("Payment method type");
		logEvent.setPaymentSourceId("Payment source id");
		logEvent.setRedirectUrl("https://example.org/example");
		logEvent.setReference("Reference");
		logEvent.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent.setShippingAddress(null);
		logEvent.setStateCore(1);
		logEvent.setStatus("Status");
		logEvent.setTimestamp("Timestamp");
		logEvent.setUrlCore("https://example.org/example");

		LogEvent logEvent2 = new LogEvent();
		logEvent2.setAmountInCents("10");
		logEvent2.setChecksum("Checksum");
		logEvent2.setCurrency("GBP");
		logEvent2.setCustomerEmail("jane.doe@example.org");
		logEvent2.setEnvironment("Environment");
		logEvent2.setEvent("Event");
		logEvent2.setId(1L);
		logEvent2.setIdRef("Id Ref");
		logEvent2.setPaymentLinkId("Payment link id");
		logEvent2.setPaymentMethodType("Payment method type");
		logEvent2.setPaymentSourceId("Payment source id");
		logEvent2.setRedirectUrl("https://example.org/example");
		logEvent2.setReference("Reference");
		logEvent2.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent2.setShippingAddress("42 Main St");
		logEvent2.setStateCore(1);
		logEvent2.setStatus("Status");
		logEvent2.setTimestamp("Timestamp");
		logEvent2.setUrlCore("https://example.org/example");
		assertNotEquals(logEvent, logEvent2);
	}

	/**
	 * Method under test: {@link LogEvent#equals(Object)}
	 */
	@Test
	void testEquals35() {
		LogEvent logEvent = new LogEvent();
		logEvent.setAmountInCents("10");
		logEvent.setChecksum("Checksum");
		logEvent.setCurrency("GBP");
		logEvent.setCustomerEmail("jane.doe@example.org");
		logEvent.setEnvironment("Environment");
		logEvent.setEvent("Event");
		logEvent.setId(1L);
		logEvent.setIdRef("Id Ref");
		logEvent.setPaymentLinkId("Payment link id");
		logEvent.setPaymentMethodType("Payment method type");
		logEvent.setPaymentSourceId("Payment source id");
		logEvent.setRedirectUrl("https://example.org/example");
		logEvent.setReference("Reference");
		logEvent.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent.setShippingAddress("42 Main St");
		logEvent.setStateCore(3);
		logEvent.setStatus("Status");
		logEvent.setTimestamp("Timestamp");
		logEvent.setUrlCore("https://example.org/example");

		LogEvent logEvent2 = new LogEvent();
		logEvent2.setAmountInCents("10");
		logEvent2.setChecksum("Checksum");
		logEvent2.setCurrency("GBP");
		logEvent2.setCustomerEmail("jane.doe@example.org");
		logEvent2.setEnvironment("Environment");
		logEvent2.setEvent("Event");
		logEvent2.setId(1L);
		logEvent2.setIdRef("Id Ref");
		logEvent2.setPaymentLinkId("Payment link id");
		logEvent2.setPaymentMethodType("Payment method type");
		logEvent2.setPaymentSourceId("Payment source id");
		logEvent2.setRedirectUrl("https://example.org/example");
		logEvent2.setReference("Reference");
		logEvent2.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent2.setShippingAddress("42 Main St");
		logEvent2.setStateCore(1);
		logEvent2.setStatus("Status");
		logEvent2.setTimestamp("Timestamp");
		logEvent2.setUrlCore("https://example.org/example");
		assertNotEquals(logEvent, logEvent2);
	}

	/**
	 * Method under test: {@link LogEvent#equals(Object)}
	 */
	@Test
	void testEquals36() {
		LogEvent logEvent = new LogEvent();
		logEvent.setAmountInCents("10");
		logEvent.setChecksum("Checksum");
		logEvent.setCurrency("GBP");
		logEvent.setCustomerEmail("jane.doe@example.org");
		logEvent.setEnvironment("Environment");
		logEvent.setEvent("Event");
		logEvent.setId(1L);
		logEvent.setIdRef("Id Ref");
		logEvent.setPaymentLinkId("Payment link id");
		logEvent.setPaymentMethodType("Payment method type");
		logEvent.setPaymentSourceId("Payment source id");
		logEvent.setRedirectUrl("https://example.org/example");
		logEvent.setReference("Reference");
		logEvent.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent.setShippingAddress("42 Main St");
		logEvent.setStateCore(null);
		logEvent.setStatus("Status");
		logEvent.setTimestamp("Timestamp");
		logEvent.setUrlCore("https://example.org/example");

		LogEvent logEvent2 = new LogEvent();
		logEvent2.setAmountInCents("10");
		logEvent2.setChecksum("Checksum");
		logEvent2.setCurrency("GBP");
		logEvent2.setCustomerEmail("jane.doe@example.org");
		logEvent2.setEnvironment("Environment");
		logEvent2.setEvent("Event");
		logEvent2.setId(1L);
		logEvent2.setIdRef("Id Ref");
		logEvent2.setPaymentLinkId("Payment link id");
		logEvent2.setPaymentMethodType("Payment method type");
		logEvent2.setPaymentSourceId("Payment source id");
		logEvent2.setRedirectUrl("https://example.org/example");
		logEvent2.setReference("Reference");
		logEvent2.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent2.setShippingAddress("42 Main St");
		logEvent2.setStateCore(1);
		logEvent2.setStatus("Status");
		logEvent2.setTimestamp("Timestamp");
		logEvent2.setUrlCore("https://example.org/example");
		assertNotEquals(logEvent, logEvent2);
	}

	/**
	 * Method under test: {@link LogEvent#equals(Object)}
	 */
	@Test
	void testEquals37() {
		LogEvent logEvent = new LogEvent();
		logEvent.setAmountInCents("10");
		logEvent.setChecksum("Checksum");
		logEvent.setCurrency("GBP");
		logEvent.setCustomerEmail("jane.doe@example.org");
		logEvent.setEnvironment("Environment");
		logEvent.setEvent("Event");
		logEvent.setId(1L);
		logEvent.setIdRef("Id Ref");
		logEvent.setPaymentLinkId("Payment link id");
		logEvent.setPaymentMethodType("Payment method type");
		logEvent.setPaymentSourceId("Payment source id");
		logEvent.setRedirectUrl("https://example.org/example");
		logEvent.setReference("Reference");
		logEvent.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent.setShippingAddress("42 Main St");
		logEvent.setStateCore(1);
		logEvent.setStatus("Event");
		logEvent.setTimestamp("Timestamp");
		logEvent.setUrlCore("https://example.org/example");

		LogEvent logEvent2 = new LogEvent();
		logEvent2.setAmountInCents("10");
		logEvent2.setChecksum("Checksum");
		logEvent2.setCurrency("GBP");
		logEvent2.setCustomerEmail("jane.doe@example.org");
		logEvent2.setEnvironment("Environment");
		logEvent2.setEvent("Event");
		logEvent2.setId(1L);
		logEvent2.setIdRef("Id Ref");
		logEvent2.setPaymentLinkId("Payment link id");
		logEvent2.setPaymentMethodType("Payment method type");
		logEvent2.setPaymentSourceId("Payment source id");
		logEvent2.setRedirectUrl("https://example.org/example");
		logEvent2.setReference("Reference");
		logEvent2.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent2.setShippingAddress("42 Main St");
		logEvent2.setStateCore(1);
		logEvent2.setStatus("Status");
		logEvent2.setTimestamp("Timestamp");
		logEvent2.setUrlCore("https://example.org/example");
		assertNotEquals(logEvent, logEvent2);
	}

	/**
	 * Method under test: {@link LogEvent#equals(Object)}
	 */
	@Test
	void testEquals38() {
		LogEvent logEvent = new LogEvent();
		logEvent.setAmountInCents("10");
		logEvent.setChecksum("Checksum");
		logEvent.setCurrency("GBP");
		logEvent.setCustomerEmail("jane.doe@example.org");
		logEvent.setEnvironment("Environment");
		logEvent.setEvent("Event");
		logEvent.setId(1L);
		logEvent.setIdRef("Id Ref");
		logEvent.setPaymentLinkId("Payment link id");
		logEvent.setPaymentMethodType("Payment method type");
		logEvent.setPaymentSourceId("Payment source id");
		logEvent.setRedirectUrl("https://example.org/example");
		logEvent.setReference("Reference");
		logEvent.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent.setShippingAddress("42 Main St");
		logEvent.setStateCore(1);
		logEvent.setStatus(null);
		logEvent.setTimestamp("Timestamp");
		logEvent.setUrlCore("https://example.org/example");

		LogEvent logEvent2 = new LogEvent();
		logEvent2.setAmountInCents("10");
		logEvent2.setChecksum("Checksum");
		logEvent2.setCurrency("GBP");
		logEvent2.setCustomerEmail("jane.doe@example.org");
		logEvent2.setEnvironment("Environment");
		logEvent2.setEvent("Event");
		logEvent2.setId(1L);
		logEvent2.setIdRef("Id Ref");
		logEvent2.setPaymentLinkId("Payment link id");
		logEvent2.setPaymentMethodType("Payment method type");
		logEvent2.setPaymentSourceId("Payment source id");
		logEvent2.setRedirectUrl("https://example.org/example");
		logEvent2.setReference("Reference");
		logEvent2.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent2.setShippingAddress("42 Main St");
		logEvent2.setStateCore(1);
		logEvent2.setStatus("Status");
		logEvent2.setTimestamp("Timestamp");
		logEvent2.setUrlCore("https://example.org/example");
		assertNotEquals(logEvent, logEvent2);
	}

	/**
	 * Method under test: {@link LogEvent#equals(Object)}
	 */
	@Test
	void testEquals39() {
		LogEvent logEvent = new LogEvent();
		logEvent.setAmountInCents("10");
		logEvent.setChecksum("Checksum");
		logEvent.setCurrency("GBP");
		logEvent.setCustomerEmail("jane.doe@example.org");
		logEvent.setEnvironment("Environment");
		logEvent.setEvent("Event");
		logEvent.setId(1L);
		logEvent.setIdRef("Id Ref");
		logEvent.setPaymentLinkId("Payment link id");
		logEvent.setPaymentMethodType("Payment method type");
		logEvent.setPaymentSourceId("Payment source id");
		logEvent.setRedirectUrl("https://example.org/example");
		logEvent.setReference("Reference");
		logEvent.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent.setShippingAddress("42 Main St");
		logEvent.setStateCore(1);
		logEvent.setStatus("Status");
		logEvent.setTimestamp("Event");
		logEvent.setUrlCore("https://example.org/example");

		LogEvent logEvent2 = new LogEvent();
		logEvent2.setAmountInCents("10");
		logEvent2.setChecksum("Checksum");
		logEvent2.setCurrency("GBP");
		logEvent2.setCustomerEmail("jane.doe@example.org");
		logEvent2.setEnvironment("Environment");
		logEvent2.setEvent("Event");
		logEvent2.setId(1L);
		logEvent2.setIdRef("Id Ref");
		logEvent2.setPaymentLinkId("Payment link id");
		logEvent2.setPaymentMethodType("Payment method type");
		logEvent2.setPaymentSourceId("Payment source id");
		logEvent2.setRedirectUrl("https://example.org/example");
		logEvent2.setReference("Reference");
		logEvent2.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent2.setShippingAddress("42 Main St");
		logEvent2.setStateCore(1);
		logEvent2.setStatus("Status");
		logEvent2.setTimestamp("Timestamp");
		logEvent2.setUrlCore("https://example.org/example");
		assertNotEquals(logEvent, logEvent2);
	}

	/**
	 * Method under test: {@link LogEvent#equals(Object)}
	 */
	@Test
	void testEquals40() {
		LogEvent logEvent = new LogEvent();
		logEvent.setAmountInCents("10");
		logEvent.setChecksum("Checksum");
		logEvent.setCurrency("GBP");
		logEvent.setCustomerEmail("jane.doe@example.org");
		logEvent.setEnvironment("Environment");
		logEvent.setEvent("Event");
		logEvent.setId(1L);
		logEvent.setIdRef("Id Ref");
		logEvent.setPaymentLinkId("Payment link id");
		logEvent.setPaymentMethodType("Payment method type");
		logEvent.setPaymentSourceId("Payment source id");
		logEvent.setRedirectUrl("https://example.org/example");
		logEvent.setReference("Reference");
		logEvent.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent.setShippingAddress("42 Main St");
		logEvent.setStateCore(1);
		logEvent.setStatus("Status");
		logEvent.setTimestamp(null);
		logEvent.setUrlCore("https://example.org/example");

		LogEvent logEvent2 = new LogEvent();
		logEvent2.setAmountInCents("10");
		logEvent2.setChecksum("Checksum");
		logEvent2.setCurrency("GBP");
		logEvent2.setCustomerEmail("jane.doe@example.org");
		logEvent2.setEnvironment("Environment");
		logEvent2.setEvent("Event");
		logEvent2.setId(1L);
		logEvent2.setIdRef("Id Ref");
		logEvent2.setPaymentLinkId("Payment link id");
		logEvent2.setPaymentMethodType("Payment method type");
		logEvent2.setPaymentSourceId("Payment source id");
		logEvent2.setRedirectUrl("https://example.org/example");
		logEvent2.setReference("Reference");
		logEvent2.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent2.setShippingAddress("42 Main St");
		logEvent2.setStateCore(1);
		logEvent2.setStatus("Status");
		logEvent2.setTimestamp("Timestamp");
		logEvent2.setUrlCore("https://example.org/example");
		assertNotEquals(logEvent, logEvent2);
	}

	/**
	 * Method under test: {@link LogEvent#equals(Object)}
	 */
	@Test
	void testEquals41() {
		LogEvent logEvent = new LogEvent();
		logEvent.setAmountInCents("10");
		logEvent.setChecksum("Checksum");
		logEvent.setCurrency("GBP");
		logEvent.setCustomerEmail("jane.doe@example.org");
		logEvent.setEnvironment("Environment");
		logEvent.setEvent("Event");
		logEvent.setId(1L);
		logEvent.setIdRef("Id Ref");
		logEvent.setPaymentLinkId("Payment link id");
		logEvent.setPaymentMethodType("Payment method type");
		logEvent.setPaymentSourceId("Payment source id");
		logEvent.setRedirectUrl("https://example.org/example");
		logEvent.setReference("Reference");
		logEvent.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent.setShippingAddress("42 Main St");
		logEvent.setStateCore(1);
		logEvent.setStatus("Status");
		logEvent.setTimestamp("Timestamp");
		logEvent.setUrlCore("Event");

		LogEvent logEvent2 = new LogEvent();
		logEvent2.setAmountInCents("10");
		logEvent2.setChecksum("Checksum");
		logEvent2.setCurrency("GBP");
		logEvent2.setCustomerEmail("jane.doe@example.org");
		logEvent2.setEnvironment("Environment");
		logEvent2.setEvent("Event");
		logEvent2.setId(1L);
		logEvent2.setIdRef("Id Ref");
		logEvent2.setPaymentLinkId("Payment link id");
		logEvent2.setPaymentMethodType("Payment method type");
		logEvent2.setPaymentSourceId("Payment source id");
		logEvent2.setRedirectUrl("https://example.org/example");
		logEvent2.setReference("Reference");
		logEvent2.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent2.setShippingAddress("42 Main St");
		logEvent2.setStateCore(1);
		logEvent2.setStatus("Status");
		logEvent2.setTimestamp("Timestamp");
		logEvent2.setUrlCore("https://example.org/example");
		assertNotEquals(logEvent, logEvent2);
	}

	/**
	 * Method under test: {@link LogEvent#equals(Object)}
	 */
	@Test
	void testEquals42() {
		LogEvent logEvent = new LogEvent();
		logEvent.setAmountInCents("10");
		logEvent.setChecksum("Checksum");
		logEvent.setCurrency("GBP");
		logEvent.setCustomerEmail("jane.doe@example.org");
		logEvent.setEnvironment("Environment");
		logEvent.setEvent("Event");
		logEvent.setId(1L);
		logEvent.setIdRef("Id Ref");
		logEvent.setPaymentLinkId("Payment link id");
		logEvent.setPaymentMethodType("Payment method type");
		logEvent.setPaymentSourceId("Payment source id");
		logEvent.setRedirectUrl("https://example.org/example");
		logEvent.setReference("Reference");
		logEvent.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent.setShippingAddress("42 Main St");
		logEvent.setStateCore(1);
		logEvent.setStatus("Status");
		logEvent.setTimestamp("Timestamp");
		logEvent.setUrlCore(null);

		LogEvent logEvent2 = new LogEvent();
		logEvent2.setAmountInCents("10");
		logEvent2.setChecksum("Checksum");
		logEvent2.setCurrency("GBP");
		logEvent2.setCustomerEmail("jane.doe@example.org");
		logEvent2.setEnvironment("Environment");
		logEvent2.setEvent("Event");
		logEvent2.setId(1L);
		logEvent2.setIdRef("Id Ref");
		logEvent2.setPaymentLinkId("Payment link id");
		logEvent2.setPaymentMethodType("Payment method type");
		logEvent2.setPaymentSourceId("Payment source id");
		logEvent2.setRedirectUrl("https://example.org/example");
		logEvent2.setReference("Reference");
		logEvent2.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent2.setShippingAddress("42 Main St");
		logEvent2.setStateCore(1);
		logEvent2.setStatus("Status");
		logEvent2.setTimestamp("Timestamp");
		logEvent2.setUrlCore("https://example.org/example");
		assertNotEquals(logEvent, logEvent2);
	}

	@ParameterizedTest
	@CsvSource({ "null", "Different type to Event", "null", "Different type to Event" })
	void testNotEquals(String value) {
		LogEvent logEvent = new LogEvent();
		logEvent.setAmountInCents("10");
		logEvent.setChecksum("Checksum");
		logEvent.setCurrency("GBP");
		logEvent.setCustomerEmail("jane.doe@example.org");
		logEvent.setEnvironment("Environment");
		logEvent.setEvent("Event");
		logEvent.setId(1L);
		logEvent.setIdRef("Id Ref");
		logEvent.setPaymentLinkId("Payment link id");
		logEvent.setPaymentMethodType("Payment method type");
		logEvent.setPaymentSourceId("Payment source id");
		logEvent.setRedirectUrl("https://example.org/example");
		logEvent.setReference("Reference");
		logEvent.setSentAt(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		logEvent.setShippingAddress("42 Main St");
		logEvent.setStateCore(1);
		logEvent.setStatus("Status");
		logEvent.setTimestamp("Timestamp");
		logEvent.setUrlCore("https://example.org/example");
		assertNotEquals(value, logEvent);
	}

}
