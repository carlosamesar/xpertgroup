package com.bancoldex.sendpaymentcoreservice.util.kafka;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.TopicPartition;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class MessageConsumerTest {

	@InjectMocks
	private MessageConsumer messageConsumer;

	@Mock
	private KafkaConsumerConfig kafkaConsumerConfig;

	@Mock
	private KafkaConsumer<String, String> kafkaConsumer;

	@Test
	public void testGetKafkaConsumer() {

		KafkaConsumer<String, String> mockConsumer = Mockito.mock(KafkaConsumer.class);
		KafkaConsumerConfig mockKafkaConsumerConfig = Mockito.mock(KafkaConsumerConfig.class);

		when(mockKafkaConsumerConfig.kafkaConsumer()).thenReturn(mockConsumer);

		Set<TopicPartition> partitions = new HashSet<>();
		partitions.add(new TopicPartition("testTopic", 0));

		when(mockConsumer.assignment()).thenReturn(partitions);
		when(mockConsumer.committed(Mockito.anySet())).thenReturn(Collections.emptyMap());

		MessageConsumer messageConsumer = new MessageConsumer();
		messageConsumer.kafkaConsumer = mockKafkaConsumerConfig;

		KafkaConsumer<String, String> resultConsumer = messageConsumer.getKafkaConsumer("testTopic");

		assertNotNull(resultConsumer);
		verify(mockConsumer).subscribe(Collections.singletonList("testTopic"));
		verify(mockConsumer, atLeastOnce()).assignment();
		verify(mockConsumer, atLeastOnce()).committed(partitions);

		// Aquí puedes agregar más aserciones según sea necesario
	}
}