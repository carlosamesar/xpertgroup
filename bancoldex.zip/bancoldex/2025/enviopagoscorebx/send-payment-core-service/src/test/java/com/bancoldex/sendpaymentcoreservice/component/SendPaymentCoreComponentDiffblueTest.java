package com.bancoldex.sendpaymentcoreservice.component;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.bancoldex.sendpaymentcoreservice.util.kafka.MessageConsumer;
import com.bancoldex.sendpaymentcoreservice.util.kafka.MessageProducer;

@ContextConfiguration(classes = { SendPaymentCoreComponent.class })
@ExtendWith(SpringExtension.class)
class SendPaymentCoreComponentDiffblueTest {
	@MockBean
	private Environment environment;

	@MockBean
	private MessageConsumer messageConsumer;

	@MockBean
	private MessageProducer messageProducer;

	@MockBean
	private SendInfoToCoreComponent sendInfoToCoreComponent;

	@Autowired
	private SendPaymentCoreComponent sendPaymentCoreComponent;

	@Mock
	private KafkaConsumer<String, String> mockConsumer;

	/**
	 * Method under test:
	 * {@link SendPaymentCoreComponent#listenConfirmTopic(String)}
	 */
	@Test
	void testListenConfirmTopic() {
		when(environment.getProperty(Mockito.<String>any())).thenReturn("Property");
		doNothing().when(messageProducer).sendMessage(Mockito.<String>any(), Mockito.<String>any());
		sendPaymentCoreComponent.listenConfirmTopic("Not all who wander are lost");
		verify(environment, atLeastOnce()).getProperty(Mockito.<String>any());
		verify(messageProducer, atLeastOnce()).sendMessage(Mockito.<String>any(), Mockito.<String>any());
	}


	/**
	 * Method under test: {@link SendPaymentCoreComponent#sendInfoToApiCore()}
	 */
	//@Test
	void testSendInfoToApiCore2() throws Exception {
		when(environment.getProperty(Mockito.<String>any())).thenReturn("Property");
		when(messageConsumer.getKafkaConsumer(Mockito.any())).thenReturn(mockConsumer);
		doThrow(new ParseException("kafka.topic.pendiente-core-payment", 1)).when(sendInfoToCoreComponent)
				.sendInfoToApiCore(Mockito.any());
		assertThrows(ParseException.class, () -> sendPaymentCoreComponent.sendInfoToApiCore());
		verify(environment, atLeastOnce()).getProperty(Mockito.any());
		verify(messageConsumer, atLeastOnce()).getKafkaConsumer(Mockito.any());
	}
}
