package com.bancoldex.sendpaymentcoreservice;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableAutoConfiguration
@ComponentScan("com.bancoldex.sendpaymentcoreservice")
public class SpringTestConfig {

}
