package com.bancoldex.sendpaymentcoreservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.builder.SpringApplicationBuilder;

import static org.junit.jupiter.api.Assertions.assertSame;

class ServletInitializerTest {
    /**
     * Method under test: {@link ServletInitializer#configure(SpringApplicationBuilder)}
     */
    @Test
    void testConfigure() {
        ServletInitializer servletInitializer = new ServletInitializer();
        Class<Object> forNameResult = Object.class;
        SpringApplicationBuilder application = new SpringApplicationBuilder(forNameResult);
        assertSame(application, servletInitializer.configure(application));
    }
}

