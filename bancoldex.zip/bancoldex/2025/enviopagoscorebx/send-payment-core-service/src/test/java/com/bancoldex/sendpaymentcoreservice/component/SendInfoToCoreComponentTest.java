package com.bancoldex.sendpaymentcoreservice.component;


import com.bancoldex.sendpaymentcoreservice.dto.ValidationResponse;
import com.bancoldex.sendpaymentcoreservice.model.Channel;
import com.bancoldex.sendpaymentcoreservice.model.Event;
import com.bancoldex.sendpaymentcoreservice.model.Gateway;
import com.bancoldex.sendpaymentcoreservice.model.LogEvent;
import com.bancoldex.sendpaymentcoreservice.repository.ChannelRepository;
import com.bancoldex.sendpaymentcoreservice.repository.EventRepository;
import com.bancoldex.sendpaymentcoreservice.repository.GatewayRepository;
import com.bancoldex.sendpaymentcoreservice.repository.LogEventRepository;
import com.bancoldex.sendpaymentcoreservice.util.RestTemplateService;
import com.bancoldex.sendpaymentcoreservice.util.kafka.MessageConsumer;
import com.bancoldex.sendpaymentcoreservice.util.kafka.MessageProducer;
import kong.unirest.json.JSONException;
import kong.unirest.json.JSONObject;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.consumer.OffsetAndMetadata;
import org.apache.kafka.common.TopicPartition;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.env.Environment;
import org.springframework.http.*;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.web.client.HttpStatusCodeException;

import java.text.ParseException;
import java.time.Duration;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ContextConfiguration(classes = {SendInfoToCoreComponent.class})
@ExtendWith(MockitoExtension.class)
class SendInfoToCoreComponentTest {


    @Mock
    private Logger loggerMock;

    @Mock
    private JSONObject jsonElementDataMock;


    @InjectMocks
    private SendInfoToCoreComponent sendInfoToCoreComponentUnderTest;

    @Mock
    private SendInfoToCoreComponent sendInfoToCoreComponentMock;

    @Mock
    private KafkaConsumer<String, String> kafkaConsumerMock;

    @Mock
    private ConsumerRecords<String, String> consumerRecordsMock;


    @Mock
    private MessageProducer messageProducerMock;

    @InjectMocks
    private MessageConsumer messageConsumer;

    @Mock
    private Environment env;

    @Mock
    private RestTemplateService restTemplateService;

    @Mock
    private EventRepository eventRepository;

    @Mock
    private LogEventRepository logEventRepository;

    @Mock
    private ChannelRepository channelRepository;

    @Mock
    private GatewayRepository gatewayRepository;

    private final String ELEMENT_DATA = "{\"timestamp\":\"1721174389\",\"id\":313,\"idRef\":\"168480-1697202862-80414\",\"amount_in_cents\":\"1000000\",\"reference\":\"333333333|123465798|1697145508775|1|1|0\",\"customer_email\":\"diego.correa@xpertgroup.co\",\"currency\":\"COP\",\"payment_method_type\":\"PSE\",\"redirect_url\":\"http://localhost:4200\",\"status\":\"APPROVED\",\"sent_at\":\"Oct 13, 2023, 8:14:22 AM\",\"urlCore\":\"http://localhost:8099/apicorebx-orquestador-svc/\",\"stateCore\":1}";

    private final String ELEMENT_DATA_T24_CORE = "{\"timestamp\":\"1721174389\",\"id\":313,\"idRef\":\"168480-1697202862-80414\",\"amount_in_cents\":\"1000000\",\"reference\":\"333333333|123465798|1697145508775|1|3|0\",\"customer_email\":\"diego.correa@xpertgroup.co\",\"currency\":\"COP\",\"payment_method_type\":\"PSE\",\"redirect_url\":\"http://localhost:4200\",\"status\":\"APPROVED\",\"sent_at\":\"Oct 13, 2023, 8:14:22 AM\",\"urlCore\":\"http://localhost:8099/api.pagos.creditos.AA/v1/credito/AA16109NVFF8/aplicar-pago/\",\"stateCore\":1}";

    private final String ELEMENT_DATA_INVALID_REF = "{\"timestamp\":\"1721174389\",\"id\":313,\"idRef\":\"168480-1697202862-80414\",\"amount_in_cents\":\"1000000\",\"reference\":\"333\",\"customer_email\":\"diego.correa@xpertgroup.co\",\"currency\":\"COP\",\"payment_method_type\":\"PSE\",\"redirect_url\":\"http://localhost:4200\",\"status\":\"APPROVED\",\"sent_at\":\"Oct 13, 2023, 8:14:22 AM\",\"urlCore\":\"http://localhost:8099/apicorebx-orquestador-svc/\",\"stateCore\":1}";

    private final String ELEMENT_DATA_NOT_REF = "{\"timestamp\":\"1721174389\",\"id\":313,\"idRef\":\"168480-1697202862-80414\",\"amount_in_cents\":\"1000000\",\"reference2\":\"333\",\"customer_email\":\"diego.correa@xpertgroup.co\",\"currency\":\"COP\",\"payment_method_type\":\"PSE\",\"redirect_url\":\"http://localhost:4200\",\"status\":\"APPROVED\",\"sent_at\":\"Oct 13, 2023, 8:14:22 AM\",\"urlCore\":\"http://localhost:8099/apicorebx-orquestador-svc/\",\"stateCore\":1}";

    private final String ELEMENT_DATA_NOT_DATE = "{\"timestamp\":\"1721174389\",\"id\":313,\"idRef\":\"168480-1697202862-80414\",\"amount_in_cents\":\"1000000\",\"reference2\":\"333\",\"customer_email\":\"diego.correa@xpertgroup.co\",\"currency\":\"COP\",\"payment_method_type\":\"PSE\",\"redirect_url\":\"http://localhost:4200\",\"status\":\"APPROVED\",\"sent_at2\":\"Oct 13, 2023, 8:14:22 AM\",\"urlCore\":\"http://localhost:8099/apicorebx-orquestador-svc/\",\"stateCore\":1}";

    private final String ELEMENT_DATA_RESPONSE = "{\"id\":313,\"pseIdApli\":313,\"pseIdTran\":168480,\"pseFecTra\":20231006,\"pseHorTra\":7249,\"pseNitCli\":5579950,\"pseSuc\":105,\"pseLinea\":100,\"pseNoPer\":10132100,\"pseFecRec\":20231006,\"pseHorRec\":7249,\"pseCanal\":1,\"pseValTra\":3004576,\"pseTipApl\":0,\"pseEstado\":6,\"pseFecPro\":20231006,\"pseHorPro\":152254,\"pseResult\":\"                                                  \"}";

    private final Event eventValid = Event.builder()
            .id(313L)
            .stateCore(1)
            .idRef("313")
            .build();

    private final Event eventInValid = Event.builder()
            .id(313L)
            .stateCore(6)
            .idRef("313")
            .build();


    @Test
    void callSendApiCore_IsEmpty() throws Exception {
        Mockito.when(restTemplateService.getCreateDataApiCore(any(), any(), any())).thenReturn(Optional.empty());
        Optional<ResponseEntity<ValidationResponse>> jsonObjectOptional = sendInfoToCoreComponentUnderTest.callCreateDataApiCore(Optional.of(new JSONObject(ELEMENT_DATA)), new JSONObject(ELEMENT_DATA));
        assertTrue(jsonObjectOptional.isEmpty());
    }

    @Test
    void callSendApiCore_IsValid() throws Exception {
        Mockito.when(restTemplateService.getCreateDataApiCore(any(), any(), any())).thenReturn(Optional.of(new ResponseEntity<ValidationResponse>(HttpStatus.OK)));
        Optional<ResponseEntity<ValidationResponse>> jsonObjectOptional = sendInfoToCoreComponentUnderTest.callCreateDataApiCore(Optional.of(new JSONObject(ELEMENT_DATA)), new JSONObject(ELEMENT_DATA));

        assertTrue(jsonObjectOptional.isPresent());
    }

    @Test
    void callSendApiCore_IsValid_BadRequest() throws Exception {
        Mockito.when(restTemplateService.getCreateDataApiCore(any(), any(), any())).thenReturn(Optional.of(new ResponseEntity<ValidationResponse>(HttpStatus.INTERNAL_SERVER_ERROR)));
        Optional<ResponseEntity<ValidationResponse>> jsonObjectOptional = sendInfoToCoreComponentUnderTest.callCreateDataApiCore(Optional.of(new JSONObject(ELEMENT_DATA)), new JSONObject(ELEMENT_DATA));

        assertTrue(jsonObjectOptional.isPresent());
    }

    @Test
    void generatedEvent_IsStatusInValid() {
        JSONObject jsonElementData = new JSONObject(ELEMENT_DATA_RESPONSE);

        Optional<Void> optionalGeneratedEvent = sendInfoToCoreComponentUnderTest.generatedEvent(eventInValid);
        assertTrue(optionalGeneratedEvent.isEmpty());
    }

    @Test
    void generatedEvent_IsStatusValid() {

        Optional<Void> optionalGeneratedEvent = sendInfoToCoreComponentUnderTest.generatedEvent(eventValid);
        assertTrue(optionalGeneratedEvent.isEmpty());

        verify(eventRepository).save(any(Event.class));
        verify(logEventRepository).save(any(LogEvent.class));
    }

    @Test
    void testSendInfoToApiCore_IsListEmpty() {
        assertFalse(sendInfoToCoreComponentUnderTest.sendInfoToApiCore(""));
    }

    @Test
    void testSendInfoToApiCore_IsListValid_CallSendApiCoreValid() throws Exception {
        callSendApiCore_IsValid();
        generatedEvent_IsStatusValid();
        when(env.getProperty("com.bancoldex.psefecrec")).thenReturn("default");
        when(eventRepository.getOneById(any())).thenReturn(eventInValid);
        when(eventRepository.findFirstByIdRef(any())).thenReturn(Optional.of(eventInValid));
        boolean responseTest = sendInfoToCoreComponentUnderTest.sendInfoToApiCore(ELEMENT_DATA);
        assertTrue(responseTest);
    }

    @Test
    void testSendInfoToApiCoreT24_IsListValid_CallSendApiCoreValid() throws Exception {
        callSendApiCore_IsValid();
        generatedEvent_IsStatusValid();
        Channel channel = Channel.builder()
                .id(1)
                .nameChannel("Portal Autogestión")
                .build();
        Gateway gateway = Gateway.builder()
                .id(1)
                .nameGateway("WOMPI")
                .build();

        JSONObject jsonElementData = new JSONObject(ELEMENT_DATA_RESPONSE);
        when(eventRepository.getOneById(jsonElementData.getLong("id"))).thenReturn(eventInValid);
        when(eventRepository.findFirstByIdRef(eventInValid.getIdRef())).thenReturn(Optional.of(eventInValid));
        when(channelRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(channel));
        when(gatewayRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(gateway));

        boolean responseTest = sendInfoToCoreComponentUnderTest.sendInfoToApiCore(ELEMENT_DATA_T24_CORE);
        assertTrue(responseTest);
    }
    @Test
    void testSendInfoToApiCore_IsListValid_CallSendApiCoreIsEmpty() throws Exception {
        callSendApiCore_IsEmpty();
        generatedEvent_IsStatusValid();
        JSONObject jsonElementData = new JSONObject(ELEMENT_DATA_RESPONSE);
        when(eventRepository.getOneById(jsonElementData.getLong("id"))).thenReturn(eventValid);
        when(eventRepository.findFirstByIdRef(eventValid.getIdRef())).thenReturn(Optional.of(eventValid));
        boolean responseTest = sendInfoToCoreComponentUnderTest.sendInfoToApiCore(ELEMENT_DATA);
        assertTrue(responseTest);
    }

    @Test
    void callSendApiCore_IsInValidReference() throws Exception {
        JSONObject jsonElementData = new JSONObject(ELEMENT_DATA_RESPONSE);
        when(eventRepository.getOneById(jsonElementData.getLong("id"))).thenReturn(eventInValid);
        when(eventRepository.findFirstByIdRef(eventInValid.getIdRef())).thenReturn(Optional.of(eventInValid));
        boolean responseTest = sendInfoToCoreComponentUnderTest.sendInfoToApiCore(ELEMENT_DATA_INVALID_REF);
        assertFalse(responseTest);
    }

    @Test
    void callSendApiCore_IsNotReference() throws Exception {
        JSONObject jsonElementData = new JSONObject(ELEMENT_DATA_RESPONSE);
        when(eventRepository.getOneById(jsonElementData.getLong("id"))).thenReturn(eventInValid);
        when(eventRepository.findFirstByIdRef(eventInValid.getIdRef())).thenReturn(Optional.of(eventInValid));
        boolean responseTest = sendInfoToCoreComponentUnderTest.sendInfoToApiCore(ELEMENT_DATA_NOT_REF);
        assertFalse(responseTest);
    }


}
