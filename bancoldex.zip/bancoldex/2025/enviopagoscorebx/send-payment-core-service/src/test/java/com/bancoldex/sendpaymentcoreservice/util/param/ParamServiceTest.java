package com.bancoldex.sendpaymentcoreservice.util.param;

import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.env.Environment;
import org.springframework.web.client.RestTemplate;

import com.bancoldex.sendpaymentcoreservice.util.param.dto.ParamResponse;

@ExtendWith(MockitoExtension.class)
class ParamServiceTest {

	@InjectMocks
	private ParamService paramService;

	@Mock
	private Environment env;

	@Mock
	private RestTemplate restTemplate;

	@Test
	void testGetParams() {
		String application = "testApplication";

		when(env.getProperty("application")).thenReturn(application);

		ParamResponse actualResponse = paramService.getParams();

		assertNull(actualResponse);

		verify(env, times(1)).getProperty("application");
	}
}
