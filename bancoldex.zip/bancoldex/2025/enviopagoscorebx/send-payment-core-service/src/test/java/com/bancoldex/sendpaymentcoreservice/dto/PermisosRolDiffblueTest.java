package com.bancoldex.sendpaymentcoreservice.dto;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class PermisosRolDiffblueTest {
	/**
	 * Method under test: {@link PermisosRol#canEqual(Object)}
	 */
	@Test
	void testCanEqual() {
		assertFalse((new PermisosRol("Fecha Expiracion", "Jwt", "Rol")).canEqual("Other"));
	}

	@Test
	void testBuilder() {
		PermisosRol buildResult = PermisosRol.builder().fechaExpiracion("2022").jwt("jwt").build();
		assertTrue(buildResult.canEqual(PermisosRol.builder().fechaExpiracion("2022").jwt("jwt").build()));
	}

	/**
	 * Method under test: {@link PermisosRol#canEqual(Object)}
	 */
	@Test
	void testCanEqual2() {
		PermisosRol buildResult = PermisosRol.builder().fechaExpiracion("Fecha Expiracion").jwt("Jwt").rol("Rol")
				.build();
		assertTrue(buildResult
				.canEqual(PermisosRol.builder().fechaExpiracion("Fecha Expiracion").jwt("Jwt").rol("Rol").build()));
	}

	/**
	 * Methods under test:
	 *
	 * <ul>
	 * <li>{@link PermisosRol#PermisosRol()}
	 * <li>{@link PermisosRol#setFechaExpiracion(String)}
	 * <li>{@link PermisosRol#setJwt(String)}
	 * <li>{@link PermisosRol#setRol(String)}
	 * <li>{@link PermisosRol#toString()}
	 * <li>{@link PermisosRol#getFechaExpiracion()}
	 * <li>{@link PermisosRol#getJwt()}
	 * <li>{@link PermisosRol#getRol()}
	 * </ul>
	 */
	@Test
	void testConstructor() {
		PermisosRol actualPermisosRol = new PermisosRol();
		actualPermisosRol.setFechaExpiracion("Fecha Expiracion");
		actualPermisosRol.setJwt("Jwt");
		actualPermisosRol.setRol("Rol");
		String actualToStringResult = actualPermisosRol.toString();
		String actualFechaExpiracion = actualPermisosRol.getFechaExpiracion();
		String actualJwt = actualPermisosRol.getJwt();
		assertEquals("Fecha Expiracion", actualFechaExpiracion);
		assertEquals("Jwt", actualJwt);
		assertEquals("Rol", actualPermisosRol.getRol());
		assertEquals("PermisosRol(fechaExpiracion=Fecha Expiracion, jwt=Jwt, rol=Rol)", actualToStringResult);
	}

	/**
	 * Methods under test:
	 *
	 * <ul>
	 * <li>{@link PermisosRol#PermisosRol(String, String, String)}
	 * <li>{@link PermisosRol#setFechaExpiracion(String)}
	 * <li>{@link PermisosRol#setJwt(String)}
	 * <li>{@link PermisosRol#setRol(String)}
	 * <li>{@link PermisosRol#toString()}
	 * <li>{@link PermisosRol#getFechaExpiracion()}
	 * <li>{@link PermisosRol#getJwt()}
	 * <li>{@link PermisosRol#getRol()}
	 * </ul>
	 */
	@Test
	void testConstructor2() {
		PermisosRol actualPermisosRol = new PermisosRol("Fecha Expiracion", "Jwt", "Rol");
		actualPermisosRol.setFechaExpiracion("Fecha Expiracion");
		actualPermisosRol.setJwt("Jwt");
		actualPermisosRol.setRol("Rol");
		String actualToStringResult = actualPermisosRol.toString();
		String actualFechaExpiracion = actualPermisosRol.getFechaExpiracion();
		String actualJwt = actualPermisosRol.getJwt();
		assertEquals("Fecha Expiracion", actualFechaExpiracion);
		assertEquals("Jwt", actualJwt);
		assertEquals("Rol", actualPermisosRol.getRol());
		assertEquals("PermisosRol(fechaExpiracion=Fecha Expiracion, jwt=Jwt, rol=Rol)", actualToStringResult);
	}

	/**
	 * Method under test: {@link PermisosRol#equals(Object)}
	 */
	@Test
	void testEquals() {
		assertNotEquals(null, PermisosRol.builder().fechaExpiracion("Fecha Expiracion").jwt("Jwt").rol("Rol").build());
		assertNotEquals("Different type to PermisosRol",
				PermisosRol.builder().fechaExpiracion("Fecha Expiracion").jwt("Jwt").rol("Rol").build());
	}

	/**
	 * Methods under test:
	 *
	 * <ul>
	 * <li>{@link PermisosRol#equals(Object)}
	 * <li>{@link PermisosRol#hashCode()}
	 * </ul>
	 */
	@Test
	void testEquals2() {
		PermisosRol buildResult = PermisosRol.builder().fechaExpiracion("Fecha Expiracion").jwt("Jwt").rol("Rol")
				.build();
		assertEquals(buildResult, buildResult);
		int expectedHashCodeResult = buildResult.hashCode();
		assertEquals(expectedHashCodeResult, buildResult.hashCode());
	}

	/**
	 * Method under test: {@link PermisosRol#equals(Object)}
	 */
	@Test
	void testEquals3() {
		PermisosRol buildResult = PermisosRol.builder().fechaExpiracion("Jwt").jwt("Jwt").rol("Rol").build();
		assertNotEquals(buildResult,
				PermisosRol.builder().fechaExpiracion("Fecha Expiracion").jwt("Jwt").rol("Rol").build());
	}

	/**
	 * Method under test: {@link PermisosRol#equals(Object)}
	 */
	@Test
	void testEquals4() {
		PermisosRol buildResult = PermisosRol.builder().fechaExpiracion(null).jwt("Jwt").rol("Rol").build();
		assertNotEquals(buildResult,
				PermisosRol.builder().fechaExpiracion("Fecha Expiracion").jwt("Jwt").rol("Rol").build());
	}

	/**
	 * Method under test: {@link PermisosRol#equals(Object)}
	 */
	@Test
	void testEquals5() {
		PermisosRol buildResult = PermisosRol.builder().fechaExpiracion("Fecha Expiracion").jwt("Fecha Expiracion")
				.rol("Rol").build();
		assertNotEquals(buildResult,
				PermisosRol.builder().fechaExpiracion("Fecha Expiracion").jwt("Jwt").rol("Rol").build());
	}

	/**
	 * Method under test: {@link PermisosRol#equals(Object)}
	 */
	@Test
	void testEquals6() {
		PermisosRol buildResult = PermisosRol.builder().fechaExpiracion("Fecha Expiracion").jwt(null).rol("Rol")
				.build();
		assertNotEquals(buildResult,
				PermisosRol.builder().fechaExpiracion("Fecha Expiracion").jwt("Jwt").rol("Rol").build());
	}

	/**
	 * Method under test: {@link PermisosRol#equals(Object)}
	 */
	@Test
	void testEquals7() {
		PermisosRol buildResult = PermisosRol.builder().fechaExpiracion("Fecha Expiracion").jwt("Jwt")
				.rol("Fecha Expiracion").build();
		assertNotEquals(buildResult,
				PermisosRol.builder().fechaExpiracion("Fecha Expiracion").jwt("Jwt").rol("Rol").build());
	}

	/**
	 * Method under test: {@link PermisosRol#equals(Object)}
	 */
	@Test
	void testEquals8() {
		PermisosRol buildResult = PermisosRol.builder().fechaExpiracion("Fecha Expiracion").jwt("Jwt").rol(null)
				.build();
		assertNotEquals(buildResult,
				PermisosRol.builder().fechaExpiracion("Fecha Expiracion").jwt("Jwt").rol("Rol").build());
	}

	/**
	 * Methods under test:
	 *
	 * <ul>
	 * <li>{@link PermisosRol#equals(Object)}
	 * <li>{@link PermisosRol#hashCode()}
	 * </ul>
	 */
	@Test
	void testEquals9() {
		PermisosRol buildResult = PermisosRol.builder().fechaExpiracion(null).jwt("Jwt").rol("Rol").build();
		PermisosRol buildResult2 = PermisosRol.builder().fechaExpiracion(null).jwt("Jwt").rol("Rol").build();
		assertEquals(buildResult, buildResult2);
		int expectedHashCodeResult = buildResult.hashCode();
		assertEquals(expectedHashCodeResult, buildResult2.hashCode());
	}

	/**
	 * Methods under test:
	 *
	 * <ul>
	 * <li>{@link PermisosRol#equals(Object)}
	 * <li>{@link PermisosRol#hashCode()}
	 * </ul>
	 */
	@Test
	void testEquals10() {
		PermisosRol buildResult = PermisosRol.builder().fechaExpiracion("Fecha Expiracion").jwt(null).rol("Rol")
				.build();
		PermisosRol buildResult2 = PermisosRol.builder().fechaExpiracion("Fecha Expiracion").jwt(null).rol("Rol")
				.build();
		assertEquals(buildResult, buildResult2);
		int expectedHashCodeResult = buildResult.hashCode();
		assertEquals(expectedHashCodeResult, buildResult2.hashCode());
	}

	/**
	 * Methods under test:
	 *
	 * <ul>
	 * <li>{@link PermisosRol#equals(Object)}
	 * <li>{@link PermisosRol#hashCode()}
	 * </ul>
	 */
	@Test
	void testEquals11() {
		PermisosRol buildResult = PermisosRol.builder().fechaExpiracion("Fecha Expiracion").jwt("Jwt").rol(null)
				.build();
		PermisosRol buildResult2 = PermisosRol.builder().fechaExpiracion("Fecha Expiracion").jwt("Jwt").rol(null)
				.build();
		assertEquals(buildResult, buildResult2);
		int expectedHashCodeResult = buildResult.hashCode();
		assertEquals(expectedHashCodeResult, buildResult2.hashCode());
	}
}
