package com.bancoldex.sendpaymentcoreservice.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.Date;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class EventDiffblueTest {
	/**
	 * Method under test: {@link Event#canEqual(Object)}
	 */
	@Test
	void testCanEqual() {
		assertFalse((new Event()).canEqual("Other"));
	}

	@Test
	void testBuilder() {
		Event buildResult = Event.builder().amount_in_cents("100").customer_email("@email").checksum("100")
				.environment("env").id(1L).idRef("222").build();
		assertTrue(buildResult.canEqual(Event.builder().amount_in_cents("100").customer_email("@email").checksum("100")
				.environment("env").id(1L).idRef("222").build()));
	}

	/**
	 * Method under test: {@link Event#canEqual(Object)}
	 */
	@Test
	void testCanEqual2() {
		Event event = new Event();
		event.setAmount_in_cents("10");
		event.setChecksum("Checksum");
		event.setCurrency("GBP");
		event.setCustomer_email("jane.doe@example.org");
		event.setEnvironment("Environment");
		event.setEvent("Event");
		event.setId(1L);
		event.setIdRef("Id Ref");
		event.setPayment_link_id("Payment link id");
		event.setPayment_method_type("Payment method type");
		event.setPayment_source_id("Payment source id");
		event.setRedirect_url("https://example.org/example");
		event.setReference("Reference");
		event.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event.setShipping_address("42 Main St");
		event.setStateCore(1);
		event.setStatus("Status");
		event.setTimestamp("Timestamp");
		event.setUrlCore("https://example.org/example");

		Event event2 = new Event();
		event2.setAmount_in_cents("10");
		event2.setChecksum("Checksum");
		event2.setCurrency("GBP");
		event2.setCustomer_email("jane.doe@example.org");
		event2.setEnvironment("Environment");
		event2.setEvent("Event");
		event2.setId(1L);
		event2.setIdRef("Id Ref");
		event2.setPayment_link_id("Payment link id");
		event2.setPayment_method_type("Payment method type");
		event2.setPayment_source_id("Payment source id");
		event2.setRedirect_url("https://example.org/example");
		event2.setReference("Reference");
		event2.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event2.setShipping_address("42 Main St");
		event2.setStateCore(1);
		event2.setStatus("Status");
		event2.setTimestamp("Timestamp");
		event2.setUrlCore("https://example.org/example");
		assertTrue(event.canEqual(event2));
	}

	/**
	 * Methods under test:
	 *
	 * <ul>
	 * <li>{@link Event#Event()}
	 * <li>{@link Event#setAmount_in_cents(String)}
	 * <li>{@link Event#setChecksum(String)}
	 * <li>{@link Event#setCurrency(String)}
	 * <li>{@link Event#setCustomer_email(String)}
	 * <li>{@link Event#setEnvironment(String)}
	 * <li>{@link Event#setEvent(String)}
	 * <li>{@link Event#setId(Long)}
	 * <li>{@link Event#setIdRef(String)}
	 * <li>{@link Event#setPayment_link_id(String)}
	 * <li>{@link Event#setPayment_method_type(String)}
	 * <li>{@link Event#setPayment_source_id(String)}
	 * <li>{@link Event#setRedirect_url(String)}
	 * <li>{@link Event#setReference(String)}
	 * <li>{@link Event#setSent_at(Date)}
	 * <li>{@link Event#setShipping_address(String)}
	 * <li>{@link Event#setStateCore(Integer)}
	 * <li>{@link Event#setStatus(String)}
	 * <li>{@link Event#setTimestamp(String)}
	 * <li>{@link Event#setUrlCore(String)}
	 * <li>{@link Event#toString()}
	 * <li>{@link Event#getAmount_in_cents()}
	 * <li>{@link Event#getChecksum()}
	 * <li>{@link Event#getCurrency()}
	 * <li>{@link Event#getCustomer_email()}
	 * <li>{@link Event#getEnvironment()}
	 * <li>{@link Event#getEvent()}
	 * <li>{@link Event#getId()}
	 * <li>{@link Event#getIdRef()}
	 * <li>{@link Event#getPayment_link_id()}
	 * <li>{@link Event#getPayment_method_type()}
	 * <li>{@link Event#getPayment_source_id()}
	 * <li>{@link Event#getRedirect_url()}
	 * <li>{@link Event#getReference()}
	 * <li>{@link Event#getSent_at()}
	 * <li>{@link Event#getShipping_address()}
	 * <li>{@link Event#getStateCore()}
	 * <li>{@link Event#getStatus()}
	 * <li>{@link Event#getTimestamp()}
	 * <li>{@link Event#getUrlCore()}
	 * </ul>
	 */
	@Test
	void testConstructor() {
		Event actualEvent = new Event();
		actualEvent.setAmount_in_cents("10");
		actualEvent.setChecksum("Checksum");
		actualEvent.setCurrency("GBP");
		actualEvent.setCustomer_email("jane.doe@example.org");
		actualEvent.setEnvironment("Environment");
		actualEvent.setEvent("Event");
		actualEvent.setId(1L);
		actualEvent.setIdRef("Id Ref");
		actualEvent.setPayment_link_id("Payment link id");
		actualEvent.setPayment_method_type("Payment method type");
		actualEvent.setPayment_source_id("Payment source id");
		actualEvent.setRedirect_url("https://example.org/example");
		actualEvent.setReference("Reference");
		Date sent_at = Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant());
		actualEvent.setSent_at(sent_at);
		actualEvent.setShipping_address("42 Main St");
		actualEvent.setStateCore(1);
		actualEvent.setStatus("Status");
		actualEvent.setTimestamp("Timestamp");
		actualEvent.setUrlCore("https://example.org/example");
		actualEvent.toString();
		String actualAmount_in_cents = actualEvent.getAmount_in_cents();
		String actualChecksum = actualEvent.getChecksum();
		String actualCurrency = actualEvent.getCurrency();
		String actualCustomer_email = actualEvent.getCustomer_email();
		String actualEnvironment = actualEvent.getEnvironment();
		String actualEvent2 = actualEvent.getEvent();
		Long actualId = actualEvent.getId();
		String actualIdRef = actualEvent.getIdRef();
		String actualPayment_link_id = actualEvent.getPayment_link_id();
		String actualPayment_method_type = actualEvent.getPayment_method_type();
		String actualPayment_source_id = actualEvent.getPayment_source_id();
		String actualRedirect_url = actualEvent.getRedirect_url();
		String actualReference = actualEvent.getReference();
		Date actualSent_at = actualEvent.getSent_at();
		String actualShipping_address = actualEvent.getShipping_address();
		Integer actualStateCore = actualEvent.getStateCore();
		String actualStatus = actualEvent.getStatus();
		String actualTimestamp = actualEvent.getTimestamp();
		String actualUrlCore = actualEvent.getUrlCore();
		assertEquals("10", actualAmount_in_cents);
		assertEquals("Checksum", actualChecksum);
		assertEquals("GBP", actualCurrency);
		assertEquals("jane.doe@example.org", actualCustomer_email);
		assertEquals("Environment", actualEnvironment);
		assertEquals("Event", actualEvent2);
		assertEquals(1L, actualId.longValue());
		assertEquals("Id Ref", actualIdRef);
		assertEquals("Payment link id", actualPayment_link_id);
		assertEquals("Payment method type", actualPayment_method_type);
		assertEquals("Payment source id", actualPayment_source_id);
		assertEquals("https://example.org/example", actualRedirect_url);
		assertEquals("Reference", actualReference);
		assertSame(sent_at, actualSent_at);
		assertEquals("42 Main St", actualShipping_address);
		assertEquals(1, actualStateCore.intValue());
		assertEquals("Status", actualStatus);
		assertEquals("Timestamp", actualTimestamp);
		assertEquals("https://example.org/example", actualUrlCore);
	}

	/**
	 * Methods under test:
	 *
	 * <ul>
	 * <li>{@link Event#Event(Long, String, String, String, String, String, String, String, String, String, String, String, String, String, String, String, Date, String, Integer)}
	 * <li>{@link Event#setAmount_in_cents(String)}
	 * <li>{@link Event#setChecksum(String)}
	 * <li>{@link Event#setCurrency(String)}
	 * <li>{@link Event#setCustomer_email(String)}
	 * <li>{@link Event#setEnvironment(String)}
	 * <li>{@link Event#setEvent(String)}
	 * <li>{@link Event#setId(Long)}
	 * <li>{@link Event#setIdRef(String)}
	 * <li>{@link Event#setPayment_link_id(String)}
	 * <li>{@link Event#setPayment_method_type(String)}
	 * <li>{@link Event#setPayment_source_id(String)}
	 * <li>{@link Event#setRedirect_url(String)}
	 * <li>{@link Event#setReference(String)}
	 * <li>{@link Event#setSent_at(Date)}
	 * <li>{@link Event#setShipping_address(String)}
	 * <li>{@link Event#setStateCore(Integer)}
	 * <li>{@link Event#setStatus(String)}
	 * <li>{@link Event#setTimestamp(String)}
	 * <li>{@link Event#setUrlCore(String)}
	 * <li>{@link Event#toString()}
	 * <li>{@link Event#getAmount_in_cents()}
	 * <li>{@link Event#getChecksum()}
	 * <li>{@link Event#getCurrency()}
	 * <li>{@link Event#getCustomer_email()}
	 * <li>{@link Event#getEnvironment()}
	 * <li>{@link Event#getEvent()}
	 * <li>{@link Event#getId()}
	 * <li>{@link Event#getIdRef()}
	 * <li>{@link Event#getPayment_link_id()}
	 * <li>{@link Event#getPayment_method_type()}
	 * <li>{@link Event#getPayment_source_id()}
	 * <li>{@link Event#getRedirect_url()}
	 * <li>{@link Event#getReference()}
	 * <li>{@link Event#getSent_at()}
	 * <li>{@link Event#getShipping_address()}
	 * <li>{@link Event#getStateCore()}
	 * <li>{@link Event#getStatus()}
	 * <li>{@link Event#getTimestamp()}
	 * <li>{@link Event#getUrlCore()}
	 * </ul>
	 */
	@Test
	void testConstructor2() {
		Event actualEvent = new Event(1L, "Event", "Id Ref", "10", "Reference", "jane.doe@example.org", "GBP",
				"Payment method type", "https://example.org/example", "Status", "42 Main St", "Payment link id",
				"Payment source id", "Environment", "Checksum", "Timestamp",
				Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()),
				"https://example.org/example", 1);
		actualEvent.setAmount_in_cents("10");
		actualEvent.setChecksum("Checksum");
		actualEvent.setCurrency("GBP");
		actualEvent.setCustomer_email("jane.doe@example.org");
		actualEvent.setEnvironment("Environment");
		actualEvent.setEvent("Event");
		actualEvent.setId(1L);
		actualEvent.setIdRef("Id Ref");
		actualEvent.setPayment_link_id("Payment link id");
		actualEvent.setPayment_method_type("Payment method type");
		actualEvent.setPayment_source_id("Payment source id");
		actualEvent.setRedirect_url("https://example.org/example");
		actualEvent.setReference("Reference");
		Date sent_at = Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant());
		actualEvent.setSent_at(sent_at);
		actualEvent.setShipping_address("42 Main St");
		actualEvent.setStateCore(1);
		actualEvent.setStatus("Status");
		actualEvent.setTimestamp("Timestamp");
		actualEvent.setUrlCore("https://example.org/example");
		actualEvent.toString();
		String actualAmount_in_cents = actualEvent.getAmount_in_cents();
		String actualChecksum = actualEvent.getChecksum();
		String actualCurrency = actualEvent.getCurrency();
		String actualCustomer_email = actualEvent.getCustomer_email();
		String actualEnvironment = actualEvent.getEnvironment();
		String actualEvent2 = actualEvent.getEvent();
		Long actualId = actualEvent.getId();
		String actualIdRef = actualEvent.getIdRef();
		String actualPayment_link_id = actualEvent.getPayment_link_id();
		String actualPayment_method_type = actualEvent.getPayment_method_type();
		String actualPayment_source_id = actualEvent.getPayment_source_id();
		String actualRedirect_url = actualEvent.getRedirect_url();
		String actualReference = actualEvent.getReference();
		Date actualSent_at = actualEvent.getSent_at();
		String actualShipping_address = actualEvent.getShipping_address();
		Integer actualStateCore = actualEvent.getStateCore();
		String actualStatus = actualEvent.getStatus();
		String actualTimestamp = actualEvent.getTimestamp();
		String actualUrlCore = actualEvent.getUrlCore();
		assertEquals("10", actualAmount_in_cents);
		assertEquals("Checksum", actualChecksum);
		assertEquals("GBP", actualCurrency);
		assertEquals("jane.doe@example.org", actualCustomer_email);
		assertEquals("Environment", actualEnvironment);
		assertEquals("Event", actualEvent2);
		assertEquals(1L, actualId.longValue());
		assertEquals("Id Ref", actualIdRef);
		assertEquals("Payment link id", actualPayment_link_id);
		assertEquals("Payment method type", actualPayment_method_type);
		assertEquals("Payment source id", actualPayment_source_id);
		assertEquals("https://example.org/example", actualRedirect_url);
		assertEquals("Reference", actualReference);
		assertSame(sent_at, actualSent_at);
		assertEquals("42 Main St", actualShipping_address);
		assertEquals(1, actualStateCore.intValue());
		assertEquals("Status", actualStatus);
		assertEquals("Timestamp", actualTimestamp);
		assertEquals("https://example.org/example", actualUrlCore);
	}

	/**
	 * Method under test: {@link Event#equals(Object)}
	 */

	@ParameterizedTest
	@CsvSource({ "null", "Different type to Event", "null", "Different type to Event" })
	void testNotEquals(String value) {
		Event event = new Event();
		event.setAmount_in_cents("10");
		event.setChecksum("Checksum");
		event.setCurrency("GBP");
		event.setCustomer_email("jane.doe@example.org");
		event.setEnvironment("Environment");
		event.setEvent("Event");
		event.setId(1L);
		event.setIdRef("Id Ref");
		event.setPayment_link_id("Payment link id");
		event.setPayment_method_type("Payment method type");
		event.setPayment_source_id("Payment source id");
		event.setRedirect_url("https://example.org/example");
		event.setReference("Reference");
		event.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event.setShipping_address("42 Main St");
		event.setStateCore(1);
		event.setStatus("Status");
		event.setTimestamp("Timestamp");
		event.setUrlCore("https://example.org/example");
		assertNotEquals(value, event);
	}

	/**
	 * Methods under test:
	 *
	 * <ul>
	 * <li>{@link Event#equals(Object)}
	 * <li>{@link Event#hashCode()}
	 * </ul>
	 */
	@Test
	void testEquals3() {
		Event event = new Event();
		event.setAmount_in_cents("10");
		event.setChecksum("Checksum");
		event.setCurrency("GBP");
		event.setCustomer_email("jane.doe@example.org");
		event.setEnvironment("Environment");
		event.setEvent("Event");
		event.setId(1L);
		event.setIdRef("Id Ref");
		event.setPayment_link_id("Payment link id");
		event.setPayment_method_type("Payment method type");
		event.setPayment_source_id("Payment source id");
		event.setRedirect_url("https://example.org/example");
		event.setReference("Reference");
		event.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event.setShipping_address("42 Main St");
		event.setStateCore(1);
		event.setStatus("Status");
		event.setTimestamp("Timestamp");
		event.setUrlCore("https://example.org/example");
		assertEquals(event, event);
		int expectedHashCodeResult = event.hashCode();
		assertEquals(expectedHashCodeResult, event.hashCode());
	}

	/**
	 * Methods under test:
	 *
	 * <ul>
	 * <li>{@link Event#equals(Object)}
	 * <li>{@link Event#hashCode()}
	 * </ul>
	 */
	@Test
	void testEquals4() {
		Event event = new Event();
		event.setAmount_in_cents("10");
		event.setChecksum("Checksum");
		event.setCurrency("GBP");
		event.setCustomer_email("jane.doe@example.org");
		event.setEnvironment("Environment");
		event.setEvent("Event");
		event.setId(1L);
		event.setIdRef("Id Ref");
		event.setPayment_link_id("Payment link id");
		event.setPayment_method_type("Payment method type");
		event.setPayment_source_id("Payment source id");
		event.setRedirect_url("https://example.org/example");
		event.setReference("Reference");
		event.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event.setShipping_address("42 Main St");
		event.setStateCore(1);
		event.setStatus("Status");
		event.setTimestamp("Timestamp");
		event.setUrlCore("https://example.org/example");

		Event event2 = new Event();
		event2.setAmount_in_cents("10");
		event2.setChecksum("Checksum");
		event2.setCurrency("GBP");
		event2.setCustomer_email("jane.doe@example.org");
		event2.setEnvironment("Environment");
		event2.setEvent("Event");
		event2.setId(1L);
		event2.setIdRef("Id Ref");
		event2.setPayment_link_id("Payment link id");
		event2.setPayment_method_type("Payment method type");
		event2.setPayment_source_id("Payment source id");
		event2.setRedirect_url("https://example.org/example");
		event2.setReference("Reference");
		event2.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event2.setShipping_address("42 Main St");
		event2.setStateCore(1);
		event2.setStatus("Status");
		event2.setTimestamp("Timestamp");
		event2.setUrlCore("https://example.org/example");
		assertEquals(event, event2);
		int expectedHashCodeResult = event.hashCode();
		assertEquals(expectedHashCodeResult, event2.hashCode());
	}

	/**
	 * Method under test: {@link Event#equals(Object)}
	 */
	@Test
	void testEquals5() {
		Event event = new Event();
		event.setAmount_in_cents("Event");
		event.setChecksum("Checksum");
		event.setCurrency("GBP");
		event.setCustomer_email("jane.doe@example.org");
		event.setEnvironment("Environment");
		event.setEvent("Event");
		event.setId(1L);
		event.setIdRef("Id Ref");
		event.setPayment_link_id("Payment link id");
		event.setPayment_method_type("Payment method type");
		event.setPayment_source_id("Payment source id");
		event.setRedirect_url("https://example.org/example");
		event.setReference("Reference");
		event.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event.setShipping_address("42 Main St");
		event.setStateCore(1);
		event.setStatus("Status");
		event.setTimestamp("Timestamp");
		event.setUrlCore("https://example.org/example");

		Event event2 = new Event();
		event2.setAmount_in_cents("10");
		event2.setChecksum("Checksum");
		event2.setCurrency("GBP");
		event2.setCustomer_email("jane.doe@example.org");
		event2.setEnvironment("Environment");
		event2.setEvent("Event");
		event2.setId(1L);
		event2.setIdRef("Id Ref");
		event2.setPayment_link_id("Payment link id");
		event2.setPayment_method_type("Payment method type");
		event2.setPayment_source_id("Payment source id");
		event2.setRedirect_url("https://example.org/example");
		event2.setReference("Reference");
		event2.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event2.setShipping_address("42 Main St");
		event2.setStateCore(1);
		event2.setStatus("Status");
		event2.setTimestamp("Timestamp");
		event2.setUrlCore("https://example.org/example");
		assertNotEquals(event, event2);
	}

	/**
	 * Method under test: {@link Event#equals(Object)}
	 */
	@Test
	void testEquals6() {
		Event event = new Event();
		event.setAmount_in_cents(null);
		event.setChecksum("Checksum");
		event.setCurrency("GBP");
		event.setCustomer_email("jane.doe@example.org");
		event.setEnvironment("Environment");
		event.setEvent("Event");
		event.setId(1L);
		event.setIdRef("Id Ref");
		event.setPayment_link_id("Payment link id");
		event.setPayment_method_type("Payment method type");
		event.setPayment_source_id("Payment source id");
		event.setRedirect_url("https://example.org/example");
		event.setReference("Reference");
		event.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event.setShipping_address("42 Main St");
		event.setStateCore(1);
		event.setStatus("Status");
		event.setTimestamp("Timestamp");
		event.setUrlCore("https://example.org/example");

		Event event2 = new Event();
		event2.setAmount_in_cents("10");
		event2.setChecksum("Checksum");
		event2.setCurrency("GBP");
		event2.setCustomer_email("jane.doe@example.org");
		event2.setEnvironment("Environment");
		event2.setEvent("Event");
		event2.setId(1L);
		event2.setIdRef("Id Ref");
		event2.setPayment_link_id("Payment link id");
		event2.setPayment_method_type("Payment method type");
		event2.setPayment_source_id("Payment source id");
		event2.setRedirect_url("https://example.org/example");
		event2.setReference("Reference");
		event2.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event2.setShipping_address("42 Main St");
		event2.setStateCore(1);
		event2.setStatus("Status");
		event2.setTimestamp("Timestamp");
		event2.setUrlCore("https://example.org/example");
		assertNotEquals(event, event2);
	}

	/**
	 * Method under test: {@link Event#equals(Object)}
	 */
	@Test
	void testEquals7() {
		Event event = new Event();
		event.setAmount_in_cents("10");
		event.setChecksum("Event");
		event.setCurrency("GBP");
		event.setCustomer_email("jane.doe@example.org");
		event.setEnvironment("Environment");
		event.setEvent("Event");
		event.setId(1L);
		event.setIdRef("Id Ref");
		event.setPayment_link_id("Payment link id");
		event.setPayment_method_type("Payment method type");
		event.setPayment_source_id("Payment source id");
		event.setRedirect_url("https://example.org/example");
		event.setReference("Reference");
		event.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event.setShipping_address("42 Main St");
		event.setStateCore(1);
		event.setStatus("Status");
		event.setTimestamp("Timestamp");
		event.setUrlCore("https://example.org/example");

		Event event2 = new Event();
		event2.setAmount_in_cents("10");
		event2.setChecksum("Checksum");
		event2.setCurrency("GBP");
		event2.setCustomer_email("jane.doe@example.org");
		event2.setEnvironment("Environment");
		event2.setEvent("Event");
		event2.setId(1L);
		event2.setIdRef("Id Ref");
		event2.setPayment_link_id("Payment link id");
		event2.setPayment_method_type("Payment method type");
		event2.setPayment_source_id("Payment source id");
		event2.setRedirect_url("https://example.org/example");
		event2.setReference("Reference");
		event2.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event2.setShipping_address("42 Main St");
		event2.setStateCore(1);
		event2.setStatus("Status");
		event2.setTimestamp("Timestamp");
		event2.setUrlCore("https://example.org/example");
		assertNotEquals(event, event2);
	}

	/**
	 * Method under test: {@link Event#equals(Object)}
	 */
	@Test
	void testEquals8() {
		Event event = new Event();
		event.setAmount_in_cents("10");
		event.setChecksum(null);
		event.setCurrency("GBP");
		event.setCustomer_email("jane.doe@example.org");
		event.setEnvironment("Environment");
		event.setEvent("Event");
		event.setId(1L);
		event.setIdRef("Id Ref");
		event.setPayment_link_id("Payment link id");
		event.setPayment_method_type("Payment method type");
		event.setPayment_source_id("Payment source id");
		event.setRedirect_url("https://example.org/example");
		event.setReference("Reference");
		event.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event.setShipping_address("42 Main St");
		event.setStateCore(1);
		event.setStatus("Status");
		event.setTimestamp("Timestamp");
		event.setUrlCore("https://example.org/example");

		Event event2 = new Event();
		event2.setAmount_in_cents("10");
		event2.setChecksum("Checksum");
		event2.setCurrency("GBP");
		event2.setCustomer_email("jane.doe@example.org");
		event2.setEnvironment("Environment");
		event2.setEvent("Event");
		event2.setId(1L);
		event2.setIdRef("Id Ref");
		event2.setPayment_link_id("Payment link id");
		event2.setPayment_method_type("Payment method type");
		event2.setPayment_source_id("Payment source id");
		event2.setRedirect_url("https://example.org/example");
		event2.setReference("Reference");
		event2.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event2.setShipping_address("42 Main St");
		event2.setStateCore(1);
		event2.setStatus("Status");
		event2.setTimestamp("Timestamp");
		event2.setUrlCore("https://example.org/example");
		assertNotEquals(event, event2);
	}

	/**
	 * Method under test: {@link Event#equals(Object)}
	 */
	@Test
	void testEquals9() {
		Event event = new Event();
		event.setAmount_in_cents("10");
		event.setChecksum("Checksum");
		event.setCurrency("USD");
		event.setCustomer_email("jane.doe@example.org");
		event.setEnvironment("Environment");
		event.setEvent("Event");
		event.setId(1L);
		event.setIdRef("Id Ref");
		event.setPayment_link_id("Payment link id");
		event.setPayment_method_type("Payment method type");
		event.setPayment_source_id("Payment source id");
		event.setRedirect_url("https://example.org/example");
		event.setReference("Reference");
		event.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event.setShipping_address("42 Main St");
		event.setStateCore(1);
		event.setStatus("Status");
		event.setTimestamp("Timestamp");
		event.setUrlCore("https://example.org/example");

		Event event2 = new Event();
		event2.setAmount_in_cents("10");
		event2.setChecksum("Checksum");
		event2.setCurrency("GBP");
		event2.setCustomer_email("jane.doe@example.org");
		event2.setEnvironment("Environment");
		event2.setEvent("Event");
		event2.setId(1L);
		event2.setIdRef("Id Ref");
		event2.setPayment_link_id("Payment link id");
		event2.setPayment_method_type("Payment method type");
		event2.setPayment_source_id("Payment source id");
		event2.setRedirect_url("https://example.org/example");
		event2.setReference("Reference");
		event2.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event2.setShipping_address("42 Main St");
		event2.setStateCore(1);
		event2.setStatus("Status");
		event2.setTimestamp("Timestamp");
		event2.setUrlCore("https://example.org/example");
		assertNotEquals(event, event2);
	}

	/**
	 * Method under test: {@link Event#equals(Object)}
	 */
	@Test
	void testEquals10() {
		Event event = new Event();
		event.setAmount_in_cents("10");
		event.setChecksum("Checksum");
		event.setCurrency(null);
		event.setCustomer_email("jane.doe@example.org");
		event.setEnvironment("Environment");
		event.setEvent("Event");
		event.setId(1L);
		event.setIdRef("Id Ref");
		event.setPayment_link_id("Payment link id");
		event.setPayment_method_type("Payment method type");
		event.setPayment_source_id("Payment source id");
		event.setRedirect_url("https://example.org/example");
		event.setReference("Reference");
		event.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event.setShipping_address("42 Main St");
		event.setStateCore(1);
		event.setStatus("Status");
		event.setTimestamp("Timestamp");
		event.setUrlCore("https://example.org/example");

		Event event2 = new Event();
		event2.setAmount_in_cents("10");
		event2.setChecksum("Checksum");
		event2.setCurrency("GBP");
		event2.setCustomer_email("jane.doe@example.org");
		event2.setEnvironment("Environment");
		event2.setEvent("Event");
		event2.setId(1L);
		event2.setIdRef("Id Ref");
		event2.setPayment_link_id("Payment link id");
		event2.setPayment_method_type("Payment method type");
		event2.setPayment_source_id("Payment source id");
		event2.setRedirect_url("https://example.org/example");
		event2.setReference("Reference");
		event2.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event2.setShipping_address("42 Main St");
		event2.setStateCore(1);
		event2.setStatus("Status");
		event2.setTimestamp("Timestamp");
		event2.setUrlCore("https://example.org/example");
		assertNotEquals(event, event2);
	}

	/**
	 * Method under test: {@link Event#equals(Object)}
	 */
	@Test
	void testEquals11() {
		Event event = new Event();
		event.setAmount_in_cents("10");
		event.setChecksum("Checksum");
		event.setCurrency("GBP");
		event.setCustomer_email("john.smith@example.org");
		event.setEnvironment("Environment");
		event.setEvent("Event");
		event.setId(1L);
		event.setIdRef("Id Ref");
		event.setPayment_link_id("Payment link id");
		event.setPayment_method_type("Payment method type");
		event.setPayment_source_id("Payment source id");
		event.setRedirect_url("https://example.org/example");
		event.setReference("Reference");
		event.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event.setShipping_address("42 Main St");
		event.setStateCore(1);
		event.setStatus("Status");
		event.setTimestamp("Timestamp");
		event.setUrlCore("https://example.org/example");

		Event event2 = new Event();
		event2.setAmount_in_cents("10");
		event2.setChecksum("Checksum");
		event2.setCurrency("GBP");
		event2.setCustomer_email("jane.doe@example.org");
		event2.setEnvironment("Environment");
		event2.setEvent("Event");
		event2.setId(1L);
		event2.setIdRef("Id Ref");
		event2.setPayment_link_id("Payment link id");
		event2.setPayment_method_type("Payment method type");
		event2.setPayment_source_id("Payment source id");
		event2.setRedirect_url("https://example.org/example");
		event2.setReference("Reference");
		event2.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event2.setShipping_address("42 Main St");
		event2.setStateCore(1);
		event2.setStatus("Status");
		event2.setTimestamp("Timestamp");
		event2.setUrlCore("https://example.org/example");
		assertNotEquals(event, event2);
	}

	/**
	 * Method under test: {@link Event#equals(Object)}
	 */
	@Test
	void testEquals12() {
		Event event = new Event();
		event.setAmount_in_cents("10");
		event.setChecksum("Checksum");
		event.setCurrency("GBP");
		event.setCustomer_email(null);
		event.setEnvironment("Environment");
		event.setEvent("Event");
		event.setId(1L);
		event.setIdRef("Id Ref");
		event.setPayment_link_id("Payment link id");
		event.setPayment_method_type("Payment method type");
		event.setPayment_source_id("Payment source id");
		event.setRedirect_url("https://example.org/example");
		event.setReference("Reference");
		event.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event.setShipping_address("42 Main St");
		event.setStateCore(1);
		event.setStatus("Status");
		event.setTimestamp("Timestamp");
		event.setUrlCore("https://example.org/example");

		Event event2 = new Event();
		event2.setAmount_in_cents("10");
		event2.setChecksum("Checksum");
		event2.setCurrency("GBP");
		event2.setCustomer_email("jane.doe@example.org");
		event2.setEnvironment("Environment");
		event2.setEvent("Event");
		event2.setId(1L);
		event2.setIdRef("Id Ref");
		event2.setPayment_link_id("Payment link id");
		event2.setPayment_method_type("Payment method type");
		event2.setPayment_source_id("Payment source id");
		event2.setRedirect_url("https://example.org/example");
		event2.setReference("Reference");
		event2.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event2.setShipping_address("42 Main St");
		event2.setStateCore(1);
		event2.setStatus("Status");
		event2.setTimestamp("Timestamp");
		event2.setUrlCore("https://example.org/example");
		assertNotEquals(event, event2);
	}

	/**
	 * Method under test: {@link Event#equals(Object)}
	 */
	@Test
	void testEquals13() {
		Event event = new Event();
		event.setAmount_in_cents("10");
		event.setChecksum("Checksum");
		event.setCurrency("GBP");
		event.setCustomer_email("jane.doe@example.org");
		event.setEnvironment("Event");
		event.setEvent("Event");
		event.setId(1L);
		event.setIdRef("Id Ref");
		event.setPayment_link_id("Payment link id");
		event.setPayment_method_type("Payment method type");
		event.setPayment_source_id("Payment source id");
		event.setRedirect_url("https://example.org/example");
		event.setReference("Reference");
		event.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event.setShipping_address("42 Main St");
		event.setStateCore(1);
		event.setStatus("Status");
		event.setTimestamp("Timestamp");
		event.setUrlCore("https://example.org/example");

		Event event2 = new Event();
		event2.setAmount_in_cents("10");
		event2.setChecksum("Checksum");
		event2.setCurrency("GBP");
		event2.setCustomer_email("jane.doe@example.org");
		event2.setEnvironment("Environment");
		event2.setEvent("Event");
		event2.setId(1L);
		event2.setIdRef("Id Ref");
		event2.setPayment_link_id("Payment link id");
		event2.setPayment_method_type("Payment method type");
		event2.setPayment_source_id("Payment source id");
		event2.setRedirect_url("https://example.org/example");
		event2.setReference("Reference");
		event2.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event2.setShipping_address("42 Main St");
		event2.setStateCore(1);
		event2.setStatus("Status");
		event2.setTimestamp("Timestamp");
		event2.setUrlCore("https://example.org/example");
		assertNotEquals(event, event2);
	}

	/**
	 * Method under test: {@link Event#equals(Object)}
	 */
	@Test
	void testEquals14() {
		Event event = new Event();
		event.setAmount_in_cents("10");
		event.setChecksum("Checksum");
		event.setCurrency("GBP");
		event.setCustomer_email("jane.doe@example.org");
		event.setEnvironment(null);
		event.setEvent("Event");
		event.setId(1L);
		event.setIdRef("Id Ref");
		event.setPayment_link_id("Payment link id");
		event.setPayment_method_type("Payment method type");
		event.setPayment_source_id("Payment source id");
		event.setRedirect_url("https://example.org/example");
		event.setReference("Reference");
		event.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event.setShipping_address("42 Main St");
		event.setStateCore(1);
		event.setStatus("Status");
		event.setTimestamp("Timestamp");
		event.setUrlCore("https://example.org/example");

		Event event2 = new Event();
		event2.setAmount_in_cents("10");
		event2.setChecksum("Checksum");
		event2.setCurrency("GBP");
		event2.setCustomer_email("jane.doe@example.org");
		event2.setEnvironment("Environment");
		event2.setEvent("Event");
		event2.setId(1L);
		event2.setIdRef("Id Ref");
		event2.setPayment_link_id("Payment link id");
		event2.setPayment_method_type("Payment method type");
		event2.setPayment_source_id("Payment source id");
		event2.setRedirect_url("https://example.org/example");
		event2.setReference("Reference");
		event2.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event2.setShipping_address("42 Main St");
		event2.setStateCore(1);
		event2.setStatus("Status");
		event2.setTimestamp("Timestamp");
		event2.setUrlCore("https://example.org/example");
		assertNotEquals(event, event2);
	}

	/**
	 * Method under test: {@link Event#equals(Object)}
	 */
	@Test
	void testEquals15() {
		Event event = new Event();
		event.setAmount_in_cents("10");
		event.setChecksum("Checksum");
		event.setCurrency("GBP");
		event.setCustomer_email("jane.doe@example.org");
		event.setEnvironment("Environment");
		event.setEvent("Id Ref");
		event.setId(1L);
		event.setIdRef("Id Ref");
		event.setPayment_link_id("Payment link id");
		event.setPayment_method_type("Payment method type");
		event.setPayment_source_id("Payment source id");
		event.setRedirect_url("https://example.org/example");
		event.setReference("Reference");
		event.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event.setShipping_address("42 Main St");
		event.setStateCore(1);
		event.setStatus("Status");
		event.setTimestamp("Timestamp");
		event.setUrlCore("https://example.org/example");

		Event event2 = new Event();
		event2.setAmount_in_cents("10");
		event2.setChecksum("Checksum");
		event2.setCurrency("GBP");
		event2.setCustomer_email("jane.doe@example.org");
		event2.setEnvironment("Environment");
		event2.setEvent("Event");
		event2.setId(1L);
		event2.setIdRef("Id Ref");
		event2.setPayment_link_id("Payment link id");
		event2.setPayment_method_type("Payment method type");
		event2.setPayment_source_id("Payment source id");
		event2.setRedirect_url("https://example.org/example");
		event2.setReference("Reference");
		event2.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event2.setShipping_address("42 Main St");
		event2.setStateCore(1);
		event2.setStatus("Status");
		event2.setTimestamp("Timestamp");
		event2.setUrlCore("https://example.org/example");
		assertNotEquals(event, event2);
	}

	/**
	 * Method under test: {@link Event#equals(Object)}
	 */
	@Test
	void testEquals16() {
		Event event = new Event();
		event.setAmount_in_cents("10");
		event.setChecksum("Checksum");
		event.setCurrency("GBP");
		event.setCustomer_email("jane.doe@example.org");
		event.setEnvironment("Environment");
		event.setEvent(null);
		event.setId(1L);
		event.setIdRef("Id Ref");
		event.setPayment_link_id("Payment link id");
		event.setPayment_method_type("Payment method type");
		event.setPayment_source_id("Payment source id");
		event.setRedirect_url("https://example.org/example");
		event.setReference("Reference");
		event.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event.setShipping_address("42 Main St");
		event.setStateCore(1);
		event.setStatus("Status");
		event.setTimestamp("Timestamp");
		event.setUrlCore("https://example.org/example");

		Event event2 = new Event();
		event2.setAmount_in_cents("10");
		event2.setChecksum("Checksum");
		event2.setCurrency("GBP");
		event2.setCustomer_email("jane.doe@example.org");
		event2.setEnvironment("Environment");
		event2.setEvent("Event");
		event2.setId(1L);
		event2.setIdRef("Id Ref");
		event2.setPayment_link_id("Payment link id");
		event2.setPayment_method_type("Payment method type");
		event2.setPayment_source_id("Payment source id");
		event2.setRedirect_url("https://example.org/example");
		event2.setReference("Reference");
		event2.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event2.setShipping_address("42 Main St");
		event2.setStateCore(1);
		event2.setStatus("Status");
		event2.setTimestamp("Timestamp");
		event2.setUrlCore("https://example.org/example");
		assertNotEquals(event, event2);
	}

	/**
	 * Method under test: {@link Event#equals(Object)}
	 */
	@Test
	void testEquals17() {
		Event event = new Event();
		event.setAmount_in_cents("10");
		event.setChecksum("Checksum");
		event.setCurrency("GBP");
		event.setCustomer_email("jane.doe@example.org");
		event.setEnvironment("Environment");
		event.setEvent("Event");
		event.setId(2L);
		event.setIdRef("Id Ref");
		event.setPayment_link_id("Payment link id");
		event.setPayment_method_type("Payment method type");
		event.setPayment_source_id("Payment source id");
		event.setRedirect_url("https://example.org/example");
		event.setReference("Reference");
		event.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event.setShipping_address("42 Main St");
		event.setStateCore(1);
		event.setStatus("Status");
		event.setTimestamp("Timestamp");
		event.setUrlCore("https://example.org/example");

		Event event2 = new Event();
		event2.setAmount_in_cents("10");
		event2.setChecksum("Checksum");
		event2.setCurrency("GBP");
		event2.setCustomer_email("jane.doe@example.org");
		event2.setEnvironment("Environment");
		event2.setEvent("Event");
		event2.setId(1L);
		event2.setIdRef("Id Ref");
		event2.setPayment_link_id("Payment link id");
		event2.setPayment_method_type("Payment method type");
		event2.setPayment_source_id("Payment source id");
		event2.setRedirect_url("https://example.org/example");
		event2.setReference("Reference");
		event2.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event2.setShipping_address("42 Main St");
		event2.setStateCore(1);
		event2.setStatus("Status");
		event2.setTimestamp("Timestamp");
		event2.setUrlCore("https://example.org/example");
		assertNotEquals(event, event2);
	}

	/**
	 * Method under test: {@link Event#equals(Object)}
	 */
	@Test
	void testEquals18() {
		Event event = new Event();
		event.setAmount_in_cents("10");
		event.setChecksum("Checksum");
		event.setCurrency("GBP");
		event.setCustomer_email("jane.doe@example.org");
		event.setEnvironment("Environment");
		event.setEvent("Event");
		event.setId(null);
		event.setIdRef("Id Ref");
		event.setPayment_link_id("Payment link id");
		event.setPayment_method_type("Payment method type");
		event.setPayment_source_id("Payment source id");
		event.setRedirect_url("https://example.org/example");
		event.setReference("Reference");
		event.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event.setShipping_address("42 Main St");
		event.setStateCore(1);
		event.setStatus("Status");
		event.setTimestamp("Timestamp");
		event.setUrlCore("https://example.org/example");

		Event event2 = new Event();
		event2.setAmount_in_cents("10");
		event2.setChecksum("Checksum");
		event2.setCurrency("GBP");
		event2.setCustomer_email("jane.doe@example.org");
		event2.setEnvironment("Environment");
		event2.setEvent("Event");
		event2.setId(1L);
		event2.setIdRef("Id Ref");
		event2.setPayment_link_id("Payment link id");
		event2.setPayment_method_type("Payment method type");
		event2.setPayment_source_id("Payment source id");
		event2.setRedirect_url("https://example.org/example");
		event2.setReference("Reference");
		event2.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event2.setShipping_address("42 Main St");
		event2.setStateCore(1);
		event2.setStatus("Status");
		event2.setTimestamp("Timestamp");
		event2.setUrlCore("https://example.org/example");
		assertNotEquals(event, event2);
	}

	/**
	 * Method under test: {@link Event#equals(Object)}
	 */
	@Test
	void testEquals19() {
		Event event = new Event();
		event.setAmount_in_cents("10");
		event.setChecksum("Checksum");
		event.setCurrency("GBP");
		event.setCustomer_email("jane.doe@example.org");
		event.setEnvironment("Environment");
		event.setEvent("Event");
		event.setId(1L);
		event.setIdRef("Event");
		event.setPayment_link_id("Payment link id");
		event.setPayment_method_type("Payment method type");
		event.setPayment_source_id("Payment source id");
		event.setRedirect_url("https://example.org/example");
		event.setReference("Reference");
		event.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event.setShipping_address("42 Main St");
		event.setStateCore(1);
		event.setStatus("Status");
		event.setTimestamp("Timestamp");
		event.setUrlCore("https://example.org/example");

		Event event2 = new Event();
		event2.setAmount_in_cents("10");
		event2.setChecksum("Checksum");
		event2.setCurrency("GBP");
		event2.setCustomer_email("jane.doe@example.org");
		event2.setEnvironment("Environment");
		event2.setEvent("Event");
		event2.setId(1L);
		event2.setIdRef("Id Ref");
		event2.setPayment_link_id("Payment link id");
		event2.setPayment_method_type("Payment method type");
		event2.setPayment_source_id("Payment source id");
		event2.setRedirect_url("https://example.org/example");
		event2.setReference("Reference");
		event2.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event2.setShipping_address("42 Main St");
		event2.setStateCore(1);
		event2.setStatus("Status");
		event2.setTimestamp("Timestamp");
		event2.setUrlCore("https://example.org/example");
		assertNotEquals(event, event2);
	}

	/**
	 * Method under test: {@link Event#equals(Object)}
	 */
	@Test
	void testEquals20() {
		Event event = new Event();
		event.setAmount_in_cents("10");
		event.setChecksum("Checksum");
		event.setCurrency("GBP");
		event.setCustomer_email("jane.doe@example.org");
		event.setEnvironment("Environment");
		event.setEvent("Event");
		event.setId(1L);
		event.setIdRef(null);
		event.setPayment_link_id("Payment link id");
		event.setPayment_method_type("Payment method type");
		event.setPayment_source_id("Payment source id");
		event.setRedirect_url("https://example.org/example");
		event.setReference("Reference");
		event.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event.setShipping_address("42 Main St");
		event.setStateCore(1);
		event.setStatus("Status");
		event.setTimestamp("Timestamp");
		event.setUrlCore("https://example.org/example");

		Event event2 = new Event();
		event2.setAmount_in_cents("10");
		event2.setChecksum("Checksum");
		event2.setCurrency("GBP");
		event2.setCustomer_email("jane.doe@example.org");
		event2.setEnvironment("Environment");
		event2.setEvent("Event");
		event2.setId(1L);
		event2.setIdRef("Id Ref");
		event2.setPayment_link_id("Payment link id");
		event2.setPayment_method_type("Payment method type");
		event2.setPayment_source_id("Payment source id");
		event2.setRedirect_url("https://example.org/example");
		event2.setReference("Reference");
		event2.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event2.setShipping_address("42 Main St");
		event2.setStateCore(1);
		event2.setStatus("Status");
		event2.setTimestamp("Timestamp");
		event2.setUrlCore("https://example.org/example");
		assertNotEquals(event, event2);
	}

	/**
	 * Method under test: {@link Event#equals(Object)}
	 */
	@Test
	void testEquals21() {
		Event event = new Event();
		event.setAmount_in_cents("10");
		event.setChecksum("Checksum");
		event.setCurrency("GBP");
		event.setCustomer_email("jane.doe@example.org");
		event.setEnvironment("Environment");
		event.setEvent("Event");
		event.setId(1L);
		event.setIdRef("Id Ref");
		event.setPayment_link_id("Event");
		event.setPayment_method_type("Payment method type");
		event.setPayment_source_id("Payment source id");
		event.setRedirect_url("https://example.org/example");
		event.setReference("Reference");
		event.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event.setShipping_address("42 Main St");
		event.setStateCore(1);
		event.setStatus("Status");
		event.setTimestamp("Timestamp");
		event.setUrlCore("https://example.org/example");

		Event event2 = new Event();
		event2.setAmount_in_cents("10");
		event2.setChecksum("Checksum");
		event2.setCurrency("GBP");
		event2.setCustomer_email("jane.doe@example.org");
		event2.setEnvironment("Environment");
		event2.setEvent("Event");
		event2.setId(1L);
		event2.setIdRef("Id Ref");
		event2.setPayment_link_id("Payment link id");
		event2.setPayment_method_type("Payment method type");
		event2.setPayment_source_id("Payment source id");
		event2.setRedirect_url("https://example.org/example");
		event2.setReference("Reference");
		event2.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event2.setShipping_address("42 Main St");
		event2.setStateCore(1);
		event2.setStatus("Status");
		event2.setTimestamp("Timestamp");
		event2.setUrlCore("https://example.org/example");
		assertNotEquals(event, event2);
	}

	/**
	 * Method under test: {@link Event#equals(Object)}
	 */
	@Test
	void testEquals22() {
		Event event = new Event();
		event.setAmount_in_cents("10");
		event.setChecksum("Checksum");
		event.setCurrency("GBP");
		event.setCustomer_email("jane.doe@example.org");
		event.setEnvironment("Environment");
		event.setEvent("Event");
		event.setId(1L);
		event.setIdRef("Id Ref");
		event.setPayment_link_id(null);
		event.setPayment_method_type("Payment method type");
		event.setPayment_source_id("Payment source id");
		event.setRedirect_url("https://example.org/example");
		event.setReference("Reference");
		event.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event.setShipping_address("42 Main St");
		event.setStateCore(1);
		event.setStatus("Status");
		event.setTimestamp("Timestamp");
		event.setUrlCore("https://example.org/example");

		Event event2 = new Event();
		event2.setAmount_in_cents("10");
		event2.setChecksum("Checksum");
		event2.setCurrency("GBP");
		event2.setCustomer_email("jane.doe@example.org");
		event2.setEnvironment("Environment");
		event2.setEvent("Event");
		event2.setId(1L);
		event2.setIdRef("Id Ref");
		event2.setPayment_link_id("Payment link id");
		event2.setPayment_method_type("Payment method type");
		event2.setPayment_source_id("Payment source id");
		event2.setRedirect_url("https://example.org/example");
		event2.setReference("Reference");
		event2.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event2.setShipping_address("42 Main St");
		event2.setStateCore(1);
		event2.setStatus("Status");
		event2.setTimestamp("Timestamp");
		event2.setUrlCore("https://example.org/example");
		assertNotEquals(event, event2);
	}

	/**
	 * Method under test: {@link Event#equals(Object)}
	 */
	@Test
	void testEquals23() {
		Event event = new Event();
		event.setAmount_in_cents("10");
		event.setChecksum("Checksum");
		event.setCurrency("GBP");
		event.setCustomer_email("jane.doe@example.org");
		event.setEnvironment("Environment");
		event.setEvent("Event");
		event.setId(1L);
		event.setIdRef("Id Ref");
		event.setPayment_link_id("Payment link id");
		event.setPayment_method_type("Event");
		event.setPayment_source_id("Payment source id");
		event.setRedirect_url("https://example.org/example");
		event.setReference("Reference");
		event.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event.setShipping_address("42 Main St");
		event.setStateCore(1);
		event.setStatus("Status");
		event.setTimestamp("Timestamp");
		event.setUrlCore("https://example.org/example");

		Event event2 = new Event();
		event2.setAmount_in_cents("10");
		event2.setChecksum("Checksum");
		event2.setCurrency("GBP");
		event2.setCustomer_email("jane.doe@example.org");
		event2.setEnvironment("Environment");
		event2.setEvent("Event");
		event2.setId(1L);
		event2.setIdRef("Id Ref");
		event2.setPayment_link_id("Payment link id");
		event2.setPayment_method_type("Payment method type");
		event2.setPayment_source_id("Payment source id");
		event2.setRedirect_url("https://example.org/example");
		event2.setReference("Reference");
		event2.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event2.setShipping_address("42 Main St");
		event2.setStateCore(1);
		event2.setStatus("Status");
		event2.setTimestamp("Timestamp");
		event2.setUrlCore("https://example.org/example");
		assertNotEquals(event, event2);
	}

	/**
	 * Method under test: {@link Event#equals(Object)}
	 */
	@Test
	void testEquals24() {
		Event event = new Event();
		event.setAmount_in_cents("10");
		event.setChecksum("Checksum");
		event.setCurrency("GBP");
		event.setCustomer_email("jane.doe@example.org");
		event.setEnvironment("Environment");
		event.setEvent("Event");
		event.setId(1L);
		event.setIdRef("Id Ref");
		event.setPayment_link_id("Payment link id");
		event.setPayment_method_type(null);
		event.setPayment_source_id("Payment source id");
		event.setRedirect_url("https://example.org/example");
		event.setReference("Reference");
		event.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event.setShipping_address("42 Main St");
		event.setStateCore(1);
		event.setStatus("Status");
		event.setTimestamp("Timestamp");
		event.setUrlCore("https://example.org/example");

		Event event2 = new Event();
		event2.setAmount_in_cents("10");
		event2.setChecksum("Checksum");
		event2.setCurrency("GBP");
		event2.setCustomer_email("jane.doe@example.org");
		event2.setEnvironment("Environment");
		event2.setEvent("Event");
		event2.setId(1L);
		event2.setIdRef("Id Ref");
		event2.setPayment_link_id("Payment link id");
		event2.setPayment_method_type("Payment method type");
		event2.setPayment_source_id("Payment source id");
		event2.setRedirect_url("https://example.org/example");
		event2.setReference("Reference");
		event2.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event2.setShipping_address("42 Main St");
		event2.setStateCore(1);
		event2.setStatus("Status");
		event2.setTimestamp("Timestamp");
		event2.setUrlCore("https://example.org/example");
		assertNotEquals(event, event2);
	}

	/**
	 * Method under test: {@link Event#equals(Object)}
	 */
	@Test
	void testEquals25() {
		Event event = new Event();
		event.setAmount_in_cents("10");
		event.setChecksum("Checksum");
		event.setCurrency("GBP");
		event.setCustomer_email("jane.doe@example.org");
		event.setEnvironment("Environment");
		event.setEvent("Event");
		event.setId(1L);
		event.setIdRef("Id Ref");
		event.setPayment_link_id("Payment link id");
		event.setPayment_method_type("Payment method type");
		event.setPayment_source_id("Event");
		event.setRedirect_url("https://example.org/example");
		event.setReference("Reference");
		event.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event.setShipping_address("42 Main St");
		event.setStateCore(1);
		event.setStatus("Status");
		event.setTimestamp("Timestamp");
		event.setUrlCore("https://example.org/example");

		Event event2 = new Event();
		event2.setAmount_in_cents("10");
		event2.setChecksum("Checksum");
		event2.setCurrency("GBP");
		event2.setCustomer_email("jane.doe@example.org");
		event2.setEnvironment("Environment");
		event2.setEvent("Event");
		event2.setId(1L);
		event2.setIdRef("Id Ref");
		event2.setPayment_link_id("Payment link id");
		event2.setPayment_method_type("Payment method type");
		event2.setPayment_source_id("Payment source id");
		event2.setRedirect_url("https://example.org/example");
		event2.setReference("Reference");
		event2.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event2.setShipping_address("42 Main St");
		event2.setStateCore(1);
		event2.setStatus("Status");
		event2.setTimestamp("Timestamp");
		event2.setUrlCore("https://example.org/example");
		assertNotEquals(event, event2);
	}

	/**
	 * Method under test: {@link Event#equals(Object)}
	 */
	@Test
	void testEquals26() {
		Event event = new Event();
		event.setAmount_in_cents("10");
		event.setChecksum("Checksum");
		event.setCurrency("GBP");
		event.setCustomer_email("jane.doe@example.org");
		event.setEnvironment("Environment");
		event.setEvent("Event");
		event.setId(1L);
		event.setIdRef("Id Ref");
		event.setPayment_link_id("Payment link id");
		event.setPayment_method_type("Payment method type");
		event.setPayment_source_id(null);
		event.setRedirect_url("https://example.org/example");
		event.setReference("Reference");
		event.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event.setShipping_address("42 Main St");
		event.setStateCore(1);
		event.setStatus("Status");
		event.setTimestamp("Timestamp");
		event.setUrlCore("https://example.org/example");

		Event event2 = new Event();
		event2.setAmount_in_cents("10");
		event2.setChecksum("Checksum");
		event2.setCurrency("GBP");
		event2.setCustomer_email("jane.doe@example.org");
		event2.setEnvironment("Environment");
		event2.setEvent("Event");
		event2.setId(1L);
		event2.setIdRef("Id Ref");
		event2.setPayment_link_id("Payment link id");
		event2.setPayment_method_type("Payment method type");
		event2.setPayment_source_id("Payment source id");
		event2.setRedirect_url("https://example.org/example");
		event2.setReference("Reference");
		event2.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event2.setShipping_address("42 Main St");
		event2.setStateCore(1);
		event2.setStatus("Status");
		event2.setTimestamp("Timestamp");
		event2.setUrlCore("https://example.org/example");
		assertNotEquals(event, event2);
	}

	/**
	 * Method under test: {@link Event#equals(Object)}
	 */
	@Test
	void testEquals27() {
		Event event = new Event();
		event.setAmount_in_cents("10");
		event.setChecksum("Checksum");
		event.setCurrency("GBP");
		event.setCustomer_email("jane.doe@example.org");
		event.setEnvironment("Environment");
		event.setEvent("Event");
		event.setId(1L);
		event.setIdRef("Id Ref");
		event.setPayment_link_id("Payment link id");
		event.setPayment_method_type("Payment method type");
		event.setPayment_source_id("Payment source id");
		event.setRedirect_url("Event");
		event.setReference("Reference");
		event.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event.setShipping_address("42 Main St");
		event.setStateCore(1);
		event.setStatus("Status");
		event.setTimestamp("Timestamp");
		event.setUrlCore("https://example.org/example");

		Event event2 = new Event();
		event2.setAmount_in_cents("10");
		event2.setChecksum("Checksum");
		event2.setCurrency("GBP");
		event2.setCustomer_email("jane.doe@example.org");
		event2.setEnvironment("Environment");
		event2.setEvent("Event");
		event2.setId(1L);
		event2.setIdRef("Id Ref");
		event2.setPayment_link_id("Payment link id");
		event2.setPayment_method_type("Payment method type");
		event2.setPayment_source_id("Payment source id");
		event2.setRedirect_url("https://example.org/example");
		event2.setReference("Reference");
		event2.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event2.setShipping_address("42 Main St");
		event2.setStateCore(1);
		event2.setStatus("Status");
		event2.setTimestamp("Timestamp");
		event2.setUrlCore("https://example.org/example");
		assertNotEquals(event, event2);
	}

	/**
	 * Method under test: {@link Event#equals(Object)}
	 */
	@Test
	void testEquals28() {
		Event event = new Event();
		event.setAmount_in_cents("10");
		event.setChecksum("Checksum");
		event.setCurrency("GBP");
		event.setCustomer_email("jane.doe@example.org");
		event.setEnvironment("Environment");
		event.setEvent("Event");
		event.setId(1L);
		event.setIdRef("Id Ref");
		event.setPayment_link_id("Payment link id");
		event.setPayment_method_type("Payment method type");
		event.setPayment_source_id("Payment source id");
		event.setRedirect_url(null);
		event.setReference("Reference");
		event.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event.setShipping_address("42 Main St");
		event.setStateCore(1);
		event.setStatus("Status");
		event.setTimestamp("Timestamp");
		event.setUrlCore("https://example.org/example");

		Event event2 = new Event();
		event2.setAmount_in_cents("10");
		event2.setChecksum("Checksum");
		event2.setCurrency("GBP");
		event2.setCustomer_email("jane.doe@example.org");
		event2.setEnvironment("Environment");
		event2.setEvent("Event");
		event2.setId(1L);
		event2.setIdRef("Id Ref");
		event2.setPayment_link_id("Payment link id");
		event2.setPayment_method_type("Payment method type");
		event2.setPayment_source_id("Payment source id");
		event2.setRedirect_url("https://example.org/example");
		event2.setReference("Reference");
		event2.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event2.setShipping_address("42 Main St");
		event2.setStateCore(1);
		event2.setStatus("Status");
		event2.setTimestamp("Timestamp");
		event2.setUrlCore("https://example.org/example");
		assertNotEquals(event, event2);
	}

	/**
	 * Method under test: {@link Event#equals(Object)}
	 */
	@Test
	void testEquals29() {
		Event event = new Event();
		event.setAmount_in_cents("10");
		event.setChecksum("Checksum");
		event.setCurrency("GBP");
		event.setCustomer_email("jane.doe@example.org");
		event.setEnvironment("Environment");
		event.setEvent("Event");
		event.setId(1L);
		event.setIdRef("Id Ref");
		event.setPayment_link_id("Payment link id");
		event.setPayment_method_type("Payment method type");
		event.setPayment_source_id("Payment source id");
		event.setRedirect_url("https://example.org/example");
		event.setReference("Event");
		event.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event.setShipping_address("42 Main St");
		event.setStateCore(1);
		event.setStatus("Status");
		event.setTimestamp("Timestamp");
		event.setUrlCore("https://example.org/example");

		Event event2 = new Event();
		event2.setAmount_in_cents("10");
		event2.setChecksum("Checksum");
		event2.setCurrency("GBP");
		event2.setCustomer_email("jane.doe@example.org");
		event2.setEnvironment("Environment");
		event2.setEvent("Event");
		event2.setId(1L);
		event2.setIdRef("Id Ref");
		event2.setPayment_link_id("Payment link id");
		event2.setPayment_method_type("Payment method type");
		event2.setPayment_source_id("Payment source id");
		event2.setRedirect_url("https://example.org/example");
		event2.setReference("Reference");
		event2.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event2.setShipping_address("42 Main St");
		event2.setStateCore(1);
		event2.setStatus("Status");
		event2.setTimestamp("Timestamp");
		event2.setUrlCore("https://example.org/example");
		assertNotEquals(event, event2);
	}

	/**
	 * Method under test: {@link Event#equals(Object)}
	 */
	@Test
	void testEquals30() {
		Event event = new Event();
		event.setAmount_in_cents("10");
		event.setChecksum("Checksum");
		event.setCurrency("GBP");
		event.setCustomer_email("jane.doe@example.org");
		event.setEnvironment("Environment");
		event.setEvent("Event");
		event.setId(1L);
		event.setIdRef("Id Ref");
		event.setPayment_link_id("Payment link id");
		event.setPayment_method_type("Payment method type");
		event.setPayment_source_id("Payment source id");
		event.setRedirect_url("https://example.org/example");
		event.setReference(null);
		event.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event.setShipping_address("42 Main St");
		event.setStateCore(1);
		event.setStatus("Status");
		event.setTimestamp("Timestamp");
		event.setUrlCore("https://example.org/example");

		Event event2 = new Event();
		event2.setAmount_in_cents("10");
		event2.setChecksum("Checksum");
		event2.setCurrency("GBP");
		event2.setCustomer_email("jane.doe@example.org");
		event2.setEnvironment("Environment");
		event2.setEvent("Event");
		event2.setId(1L);
		event2.setIdRef("Id Ref");
		event2.setPayment_link_id("Payment link id");
		event2.setPayment_method_type("Payment method type");
		event2.setPayment_source_id("Payment source id");
		event2.setRedirect_url("https://example.org/example");
		event2.setReference("Reference");
		event2.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event2.setShipping_address("42 Main St");
		event2.setStateCore(1);
		event2.setStatus("Status");
		event2.setTimestamp("Timestamp");
		event2.setUrlCore("https://example.org/example");
		assertNotEquals(event, event2);
	}

	/**
	 * Method under test: {@link Event#equals(Object)}
	 */
	@Test
	void testEquals31() {
		Event event = new Event();
		event.setAmount_in_cents("10");
		event.setChecksum("Checksum");
		event.setCurrency("GBP");
		event.setCustomer_email("jane.doe@example.org");
		event.setEnvironment("Environment");
		event.setEvent("Event");
		event.setId(1L);
		event.setIdRef("Id Ref");
		event.setPayment_link_id("Payment link id");
		event.setPayment_method_type("Payment method type");
		event.setPayment_source_id("Payment source id");
		event.setRedirect_url("https://example.org/example");
		event.setReference("Reference");
		event.setSent_at(Date.from(LocalDate.now().atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event.setShipping_address("42 Main St");
		event.setStateCore(1);
		event.setStatus("Status");
		event.setTimestamp("Timestamp");
		event.setUrlCore("https://example.org/example");

		Event event2 = new Event();
		event2.setAmount_in_cents("10");
		event2.setChecksum("Checksum");
		event2.setCurrency("GBP");
		event2.setCustomer_email("jane.doe@example.org");
		event2.setEnvironment("Environment");
		event2.setEvent("Event");
		event2.setId(1L);
		event2.setIdRef("Id Ref");
		event2.setPayment_link_id("Payment link id");
		event2.setPayment_method_type("Payment method type");
		event2.setPayment_source_id("Payment source id");
		event2.setRedirect_url("https://example.org/example");
		event2.setReference("Reference");
		event2.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event2.setShipping_address("42 Main St");
		event2.setStateCore(1);
		event2.setStatus("Status");
		event2.setTimestamp("Timestamp");
		event2.setUrlCore("https://example.org/example");
		assertNotEquals(event, event2);
	}

	/**
	 * Method under test: {@link Event#equals(Object)}
	 */
	@Test
	void testEquals32() {
		Event event = new Event();
		event.setAmount_in_cents("10");
		event.setChecksum("Checksum");
		event.setCurrency("GBP");
		event.setCustomer_email("jane.doe@example.org");
		event.setEnvironment("Environment");
		event.setEvent("Event");
		event.setId(1L);
		event.setIdRef("Id Ref");
		event.setPayment_link_id("Payment link id");
		event.setPayment_method_type("Payment method type");
		event.setPayment_source_id("Payment source id");
		event.setRedirect_url("https://example.org/example");
		event.setReference("Reference");
		event.setSent_at(null);
		event.setShipping_address("42 Main St");
		event.setStateCore(1);
		event.setStatus("Status");
		event.setTimestamp("Timestamp");
		event.setUrlCore("https://example.org/example");

		Event event2 = new Event();
		event2.setAmount_in_cents("10");
		event2.setChecksum("Checksum");
		event2.setCurrency("GBP");
		event2.setCustomer_email("jane.doe@example.org");
		event2.setEnvironment("Environment");
		event2.setEvent("Event");
		event2.setId(1L);
		event2.setIdRef("Id Ref");
		event2.setPayment_link_id("Payment link id");
		event2.setPayment_method_type("Payment method type");
		event2.setPayment_source_id("Payment source id");
		event2.setRedirect_url("https://example.org/example");
		event2.setReference("Reference");
		event2.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event2.setShipping_address("42 Main St");
		event2.setStateCore(1);
		event2.setStatus("Status");
		event2.setTimestamp("Timestamp");
		event2.setUrlCore("https://example.org/example");
		assertNotEquals(event, event2);
	}

	/**
	 * Method under test: {@link Event#equals(Object)}
	 */
	@Test
	void testEquals33() {
		Event event = new Event();
		event.setAmount_in_cents("10");
		event.setChecksum("Checksum");
		event.setCurrency("GBP");
		event.setCustomer_email("jane.doe@example.org");
		event.setEnvironment("Environment");
		event.setEvent("Event");
		event.setId(1L);
		event.setIdRef("Id Ref");
		event.setPayment_link_id("Payment link id");
		event.setPayment_method_type("Payment method type");
		event.setPayment_source_id("Payment source id");
		event.setRedirect_url("https://example.org/example");
		event.setReference("Reference");
		event.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event.setShipping_address("17 High St");
		event.setStateCore(1);
		event.setStatus("Status");
		event.setTimestamp("Timestamp");
		event.setUrlCore("https://example.org/example");

		Event event2 = new Event();
		event2.setAmount_in_cents("10");
		event2.setChecksum("Checksum");
		event2.setCurrency("GBP");
		event2.setCustomer_email("jane.doe@example.org");
		event2.setEnvironment("Environment");
		event2.setEvent("Event");
		event2.setId(1L);
		event2.setIdRef("Id Ref");
		event2.setPayment_link_id("Payment link id");
		event2.setPayment_method_type("Payment method type");
		event2.setPayment_source_id("Payment source id");
		event2.setRedirect_url("https://example.org/example");
		event2.setReference("Reference");
		event2.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event2.setShipping_address("42 Main St");
		event2.setStateCore(1);
		event2.setStatus("Status");
		event2.setTimestamp("Timestamp");
		event2.setUrlCore("https://example.org/example");
		assertNotEquals(event, event2);
	}

	/**
	 * Method under test: {@link Event#equals(Object)}
	 */
	@Test
	void testEquals34() {
		Event event = new Event();
		event.setAmount_in_cents("10");
		event.setChecksum("Checksum");
		event.setCurrency("GBP");
		event.setCustomer_email("jane.doe@example.org");
		event.setEnvironment("Environment");
		event.setEvent("Event");
		event.setId(1L);
		event.setIdRef("Id Ref");
		event.setPayment_link_id("Payment link id");
		event.setPayment_method_type("Payment method type");
		event.setPayment_source_id("Payment source id");
		event.setRedirect_url("https://example.org/example");
		event.setReference("Reference");
		event.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event.setShipping_address(null);
		event.setStateCore(1);
		event.setStatus("Status");
		event.setTimestamp("Timestamp");
		event.setUrlCore("https://example.org/example");

		Event event2 = new Event();
		event2.setAmount_in_cents("10");
		event2.setChecksum("Checksum");
		event2.setCurrency("GBP");
		event2.setCustomer_email("jane.doe@example.org");
		event2.setEnvironment("Environment");
		event2.setEvent("Event");
		event2.setId(1L);
		event2.setIdRef("Id Ref");
		event2.setPayment_link_id("Payment link id");
		event2.setPayment_method_type("Payment method type");
		event2.setPayment_source_id("Payment source id");
		event2.setRedirect_url("https://example.org/example");
		event2.setReference("Reference");
		event2.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event2.setShipping_address("42 Main St");
		event2.setStateCore(1);
		event2.setStatus("Status");
		event2.setTimestamp("Timestamp");
		event2.setUrlCore("https://example.org/example");
		assertNotEquals(event, event2);
	}

	/**
	 * Method under test: {@link Event#equals(Object)}
	 */
	@Test
	void testEquals35() {
		Event event = new Event();
		event.setAmount_in_cents("10");
		event.setChecksum("Checksum");
		event.setCurrency("GBP");
		event.setCustomer_email("jane.doe@example.org");
		event.setEnvironment("Environment");
		event.setEvent("Event");
		event.setId(1L);
		event.setIdRef("Id Ref");
		event.setPayment_link_id("Payment link id");
		event.setPayment_method_type("Payment method type");
		event.setPayment_source_id("Payment source id");
		event.setRedirect_url("https://example.org/example");
		event.setReference("Reference");
		event.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event.setShipping_address("42 Main St");
		event.setStateCore(3);
		event.setStatus("Status");
		event.setTimestamp("Timestamp");
		event.setUrlCore("https://example.org/example");

		Event event2 = new Event();
		event2.setAmount_in_cents("10");
		event2.setChecksum("Checksum");
		event2.setCurrency("GBP");
		event2.setCustomer_email("jane.doe@example.org");
		event2.setEnvironment("Environment");
		event2.setEvent("Event");
		event2.setId(1L);
		event2.setIdRef("Id Ref");
		event2.setPayment_link_id("Payment link id");
		event2.setPayment_method_type("Payment method type");
		event2.setPayment_source_id("Payment source id");
		event2.setRedirect_url("https://example.org/example");
		event2.setReference("Reference");
		event2.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event2.setShipping_address("42 Main St");
		event2.setStateCore(1);
		event2.setStatus("Status");
		event2.setTimestamp("Timestamp");
		event2.setUrlCore("https://example.org/example");
		assertNotEquals(event, event2);
	}

	/**
	 * Method under test: {@link Event#equals(Object)}
	 */
	@Test
	void testEquals36() {
		Event event = new Event();
		event.setAmount_in_cents("10");
		event.setChecksum("Checksum");
		event.setCurrency("GBP");
		event.setCustomer_email("jane.doe@example.org");
		event.setEnvironment("Environment");
		event.setEvent("Event");
		event.setId(1L);
		event.setIdRef("Id Ref");
		event.setPayment_link_id("Payment link id");
		event.setPayment_method_type("Payment method type");
		event.setPayment_source_id("Payment source id");
		event.setRedirect_url("https://example.org/example");
		event.setReference("Reference");
		event.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event.setShipping_address("42 Main St");
		event.setStateCore(null);
		event.setStatus("Status");
		event.setTimestamp("Timestamp");
		event.setUrlCore("https://example.org/example");

		Event event2 = new Event();
		event2.setAmount_in_cents("10");
		event2.setChecksum("Checksum");
		event2.setCurrency("GBP");
		event2.setCustomer_email("jane.doe@example.org");
		event2.setEnvironment("Environment");
		event2.setEvent("Event");
		event2.setId(1L);
		event2.setIdRef("Id Ref");
		event2.setPayment_link_id("Payment link id");
		event2.setPayment_method_type("Payment method type");
		event2.setPayment_source_id("Payment source id");
		event2.setRedirect_url("https://example.org/example");
		event2.setReference("Reference");
		event2.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event2.setShipping_address("42 Main St");
		event2.setStateCore(1);
		event2.setStatus("Status");
		event2.setTimestamp("Timestamp");
		event2.setUrlCore("https://example.org/example");
		assertNotEquals(event, event2);
	}

	/**
	 * Method under test: {@link Event#equals(Object)}
	 */
	@Test
	void testEquals37() {
		Event event = new Event();
		event.setAmount_in_cents("10");
		event.setChecksum("Checksum");
		event.setCurrency("GBP");
		event.setCustomer_email("jane.doe@example.org");
		event.setEnvironment("Environment");
		event.setEvent("Event");
		event.setId(1L);
		event.setIdRef("Id Ref");
		event.setPayment_link_id("Payment link id");
		event.setPayment_method_type("Payment method type");
		event.setPayment_source_id("Payment source id");
		event.setRedirect_url("https://example.org/example");
		event.setReference("Reference");
		event.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event.setShipping_address("42 Main St");
		event.setStateCore(1);
		event.setStatus("Event");
		event.setTimestamp("Timestamp");
		event.setUrlCore("https://example.org/example");

		Event event2 = new Event();
		event2.setAmount_in_cents("10");
		event2.setChecksum("Checksum");
		event2.setCurrency("GBP");
		event2.setCustomer_email("jane.doe@example.org");
		event2.setEnvironment("Environment");
		event2.setEvent("Event");
		event2.setId(1L);
		event2.setIdRef("Id Ref");
		event2.setPayment_link_id("Payment link id");
		event2.setPayment_method_type("Payment method type");
		event2.setPayment_source_id("Payment source id");
		event2.setRedirect_url("https://example.org/example");
		event2.setReference("Reference");
		event2.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event2.setShipping_address("42 Main St");
		event2.setStateCore(1);
		event2.setStatus("Status");
		event2.setTimestamp("Timestamp");
		event2.setUrlCore("https://example.org/example");
		assertNotEquals(event, event2);
	}

	/**
	 * Method under test: {@link Event#equals(Object)}
	 */
	@Test
	void testEquals38() {
		Event event = new Event();
		event.setAmount_in_cents("10");
		event.setChecksum("Checksum");
		event.setCurrency("GBP");
		event.setCustomer_email("jane.doe@example.org");
		event.setEnvironment("Environment");
		event.setEvent("Event");
		event.setId(1L);
		event.setIdRef("Id Ref");
		event.setPayment_link_id("Payment link id");
		event.setPayment_method_type("Payment method type");
		event.setPayment_source_id("Payment source id");
		event.setRedirect_url("https://example.org/example");
		event.setReference("Reference");
		event.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event.setShipping_address("42 Main St");
		event.setStateCore(1);
		event.setStatus(null);
		event.setTimestamp("Timestamp");
		event.setUrlCore("https://example.org/example");

		Event event2 = new Event();
		event2.setAmount_in_cents("10");
		event2.setChecksum("Checksum");
		event2.setCurrency("GBP");
		event2.setCustomer_email("jane.doe@example.org");
		event2.setEnvironment("Environment");
		event2.setEvent("Event");
		event2.setId(1L);
		event2.setIdRef("Id Ref");
		event2.setPayment_link_id("Payment link id");
		event2.setPayment_method_type("Payment method type");
		event2.setPayment_source_id("Payment source id");
		event2.setRedirect_url("https://example.org/example");
		event2.setReference("Reference");
		event2.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event2.setShipping_address("42 Main St");
		event2.setStateCore(1);
		event2.setStatus("Status");
		event2.setTimestamp("Timestamp");
		event2.setUrlCore("https://example.org/example");
		assertNotEquals(event, event2);
	}

	/**
	 * Method under test: {@link Event#equals(Object)}
	 */
	@Test
	void testEquals39() {
		Event event = new Event();
		event.setAmount_in_cents("10");
		event.setChecksum("Checksum");
		event.setCurrency("GBP");
		event.setCustomer_email("jane.doe@example.org");
		event.setEnvironment("Environment");
		event.setEvent("Event");
		event.setId(1L);
		event.setIdRef("Id Ref");
		event.setPayment_link_id("Payment link id");
		event.setPayment_method_type("Payment method type");
		event.setPayment_source_id("Payment source id");
		event.setRedirect_url("https://example.org/example");
		event.setReference("Reference");
		event.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event.setShipping_address("42 Main St");
		event.setStateCore(1);
		event.setStatus("Status");
		event.setTimestamp("Event");
		event.setUrlCore("https://example.org/example");

		Event event2 = new Event();
		event2.setAmount_in_cents("10");
		event2.setChecksum("Checksum");
		event2.setCurrency("GBP");
		event2.setCustomer_email("jane.doe@example.org");
		event2.setEnvironment("Environment");
		event2.setEvent("Event");
		event2.setId(1L);
		event2.setIdRef("Id Ref");
		event2.setPayment_link_id("Payment link id");
		event2.setPayment_method_type("Payment method type");
		event2.setPayment_source_id("Payment source id");
		event2.setRedirect_url("https://example.org/example");
		event2.setReference("Reference");
		event2.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event2.setShipping_address("42 Main St");
		event2.setStateCore(1);
		event2.setStatus("Status");
		event2.setTimestamp("Timestamp");
		event2.setUrlCore("https://example.org/example");
		assertNotEquals(event, event2);
	}

	/**
	 * Method under test: {@link Event#equals(Object)}
	 */
	@Test
	void testEquals40() {
		Event event = new Event();
		event.setAmount_in_cents("10");
		event.setChecksum("Checksum");
		event.setCurrency("GBP");
		event.setCustomer_email("jane.doe@example.org");
		event.setEnvironment("Environment");
		event.setEvent("Event");
		event.setId(1L);
		event.setIdRef("Id Ref");
		event.setPayment_link_id("Payment link id");
		event.setPayment_method_type("Payment method type");
		event.setPayment_source_id("Payment source id");
		event.setRedirect_url("https://example.org/example");
		event.setReference("Reference");
		event.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event.setShipping_address("42 Main St");
		event.setStateCore(1);
		event.setStatus("Status");
		event.setTimestamp(null);
		event.setUrlCore("https://example.org/example");

		Event event2 = new Event();
		event2.setAmount_in_cents("10");
		event2.setChecksum("Checksum");
		event2.setCurrency("GBP");
		event2.setCustomer_email("jane.doe@example.org");
		event2.setEnvironment("Environment");
		event2.setEvent("Event");
		event2.setId(1L);
		event2.setIdRef("Id Ref");
		event2.setPayment_link_id("Payment link id");
		event2.setPayment_method_type("Payment method type");
		event2.setPayment_source_id("Payment source id");
		event2.setRedirect_url("https://example.org/example");
		event2.setReference("Reference");
		event2.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event2.setShipping_address("42 Main St");
		event2.setStateCore(1);
		event2.setStatus("Status");
		event2.setTimestamp("Timestamp");
		event2.setUrlCore("https://example.org/example");
		assertNotEquals(event, event2);
	}

	/**
	 * Method under test: {@link Event#equals(Object)}
	 */
	@Test
	void testEquals41() {
		Event event = new Event();
		event.setAmount_in_cents("10");
		event.setChecksum("Checksum");
		event.setCurrency("GBP");
		event.setCustomer_email("jane.doe@example.org");
		event.setEnvironment("Environment");
		event.setEvent("Event");
		event.setId(1L);
		event.setIdRef("Id Ref");
		event.setPayment_link_id("Payment link id");
		event.setPayment_method_type("Payment method type");
		event.setPayment_source_id("Payment source id");
		event.setRedirect_url("https://example.org/example");
		event.setReference("Reference");
		event.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event.setShipping_address("42 Main St");
		event.setStateCore(1);
		event.setStatus("Status");
		event.setTimestamp("Timestamp");
		event.setUrlCore("Event");

		Event event2 = new Event();
		event2.setAmount_in_cents("10");
		event2.setChecksum("Checksum");
		event2.setCurrency("GBP");
		event2.setCustomer_email("jane.doe@example.org");
		event2.setEnvironment("Environment");
		event2.setEvent("Event");
		event2.setId(1L);
		event2.setIdRef("Id Ref");
		event2.setPayment_link_id("Payment link id");
		event2.setPayment_method_type("Payment method type");
		event2.setPayment_source_id("Payment source id");
		event2.setRedirect_url("https://example.org/example");
		event2.setReference("Reference");
		event2.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event2.setShipping_address("42 Main St");
		event2.setStateCore(1);
		event2.setStatus("Status");
		event2.setTimestamp("Timestamp");
		event2.setUrlCore("https://example.org/example");
		assertNotEquals(event, event2);
	}

	/**
	 * Method under test: {@link Event#equals(Object)}
	 */
	@Test
	void testEquals42() {
		Event event = new Event();
		event.setAmount_in_cents("10");
		event.setChecksum("Checksum");
		event.setCurrency("GBP");
		event.setCustomer_email("jane.doe@example.org");
		event.setEnvironment("Environment");
		event.setEvent("Event");
		event.setId(1L);
		event.setIdRef("Id Ref");
		event.setPayment_link_id("Payment link id");
		event.setPayment_method_type("Payment method type");
		event.setPayment_source_id("Payment source id");
		event.setRedirect_url("https://example.org/example");
		event.setReference("Reference");
		event.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event.setShipping_address("42 Main St");
		event.setStateCore(1);
		event.setStatus("Status");
		event.setTimestamp("Timestamp");
		event.setUrlCore(null);

		Event event2 = new Event();
		event2.setAmount_in_cents("10");
		event2.setChecksum("Checksum");
		event2.setCurrency("GBP");
		event2.setCustomer_email("jane.doe@example.org");
		event2.setEnvironment("Environment");
		event2.setEvent("Event");
		event2.setId(1L);
		event2.setIdRef("Id Ref");
		event2.setPayment_link_id("Payment link id");
		event2.setPayment_method_type("Payment method type");
		event2.setPayment_source_id("Payment source id");
		event2.setRedirect_url("https://example.org/example");
		event2.setReference("Reference");
		event2.setSent_at(Date.from(LocalDate.of(1970, 1, 1).atStartOfDay().atZone(ZoneOffset.UTC).toInstant()));
		event2.setShipping_address("42 Main St");
		event2.setStateCore(1);
		event2.setStatus("Status");
		event2.setTimestamp("Timestamp");
		event2.setUrlCore("https://example.org/example");
		assertNotEquals(event, event2);
	}
}
