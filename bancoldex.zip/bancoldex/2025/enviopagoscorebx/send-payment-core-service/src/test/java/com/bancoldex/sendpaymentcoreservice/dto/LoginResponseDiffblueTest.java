package com.bancoldex.sendpaymentcoreservice.dto;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class LoginResponseDiffblueTest {
	/**
	 * Method under test: {@link LoginResponse#canEqual(Object)}
	 */
	@Test
	void testCanEqual() {
		assertFalse((new LoginResponse()).canEqual("Other"));
	}

	@Test
	void testValidationResponse() {
		List<PermisosRol> listPermisos = new ArrayList<>();
		PermisosRol permiso = new PermisosRol();
		permiso.setJwt("jwt");
		permiso.setRol("rol");
		listPermisos.add(permiso);

		LoginResponse loginResponse = LoginResponse.builder().permisosRol(listPermisos).build();

		Assertions.assertIterableEquals(listPermisos, loginResponse.getPermisosRol());
	}

	/**
	 * Method under test: {@link LoginResponse#canEqual(Object)}
	 */
	@Test
	void testCanEqual2() {
		LoginResponse.LoginResponseBuilder builderResult = LoginResponse.builder();
		LoginResponse buildResult = builderResult.permisosRol(new ArrayList<>()).build();
		LoginResponse.LoginResponseBuilder builderResult2 = LoginResponse.builder();
		assertTrue(buildResult.canEqual(builderResult2.permisosRol(new ArrayList<>()).build()));
	}

	/**
	 * Methods under test:
	 *
	 * <ul>
	 * <li>{@link LoginResponse#LoginResponse()}
	 * <li>{@link LoginResponse#setPermisosRol(List)}
	 * <li>{@link LoginResponse#toString()}
	 * <li>{@link LoginResponse#getPermisosRol()}
	 * </ul>
	 */
	@Test
	void testConstructor() {
		LoginResponse actualLoginResponse = new LoginResponse();
		ArrayList<PermisosRol> permisosRol = new ArrayList<>();
		actualLoginResponse.setPermisosRol(permisosRol);
		String actualToStringResult = actualLoginResponse.toString();
		assertSame(permisosRol, actualLoginResponse.getPermisosRol());
		assertEquals("LoginResponse(permisosRol=[])", actualToStringResult);
	}

	/**
	 * Methods under test:
	 *
	 * <ul>
	 * <li>{@link LoginResponse#LoginResponse(List)}
	 * <li>{@link LoginResponse#setPermisosRol(List)}
	 * <li>{@link LoginResponse#toString()}
	 * <li>{@link LoginResponse#getPermisosRol()}
	 * </ul>
	 */
	@Test
	void testConstructor2() {
		ArrayList<PermisosRol> permisosRol = new ArrayList<>();
		LoginResponse actualLoginResponse = new LoginResponse(permisosRol);
		ArrayList<PermisosRol> permisosRol2 = new ArrayList<>();
		actualLoginResponse.setPermisosRol(permisosRol2);
		String actualToStringResult = actualLoginResponse.toString();
		List<PermisosRol> actualPermisosRol = actualLoginResponse.getPermisosRol();
		assertSame(permisosRol2, actualPermisosRol);
		assertEquals(permisosRol, actualPermisosRol);
		assertEquals("LoginResponse(permisosRol=[])", actualToStringResult);
	}

	/**
	 * Method under test: {@link LoginResponse#equals(Object)}
	 */
	@Test
	void testEquals() {
		LoginResponse.LoginResponseBuilder builderResult = LoginResponse.builder();
		assertNotEquals(null, builderResult.permisosRol(new ArrayList<>()).build());
	}

	/**
	 * Method under test: {@link LoginResponse#equals(Object)}
	 */
	@Test
	void testEquals2() {
		LoginResponse.LoginResponseBuilder builderResult = LoginResponse.builder();
		assertNotEquals("Different type to LoginResponse", builderResult.permisosRol(new ArrayList<>()).build());
	}

	/**
	 * Methods under test:
	 *
	 * <ul>
	 * <li>{@link LoginResponse#equals(Object)}
	 * <li>{@link LoginResponse#hashCode()}
	 * </ul>
	 */
	@Test
	void testEquals3() {
		LoginResponse.LoginResponseBuilder builderResult = LoginResponse.builder();
		LoginResponse buildResult = builderResult.permisosRol(new ArrayList<>()).build();
		assertEquals(buildResult, buildResult);
		int expectedHashCodeResult = buildResult.hashCode();
		assertEquals(expectedHashCodeResult, buildResult.hashCode());
	}

	/**
	 * Methods under test:
	 *
	 * <ul>
	 * <li>{@link LoginResponse#equals(Object)}
	 * <li>{@link LoginResponse#hashCode()}
	 * </ul>
	 */
	@Test
	void testEquals4() {
		LoginResponse.LoginResponseBuilder builderResult = LoginResponse.builder();
		LoginResponse buildResult = builderResult.permisosRol(new ArrayList<>()).build();
		LoginResponse.LoginResponseBuilder builderResult2 = LoginResponse.builder();
		LoginResponse buildResult2 = builderResult2.permisosRol(new ArrayList<>()).build();
		assertEquals(buildResult, buildResult2);
		int expectedHashCodeResult = buildResult.hashCode();
		assertEquals(expectedHashCodeResult, buildResult2.hashCode());
	}

	/**
	 * Method under test: {@link LoginResponse#equals(Object)}
	 */
	@Test
	void testEquals5() {
		ArrayList<PermisosRol> permisosRol = new ArrayList<>();
		permisosRol.add(PermisosRol.builder().fechaExpiracion("Fecha Expiracion").jwt("Jwt").rol("Rol").build());
		LoginResponse buildResult = LoginResponse.builder().permisosRol(permisosRol).build();
		LoginResponse.LoginResponseBuilder builderResult = LoginResponse.builder();
		assertNotEquals(buildResult, builderResult.permisosRol(new ArrayList<>()).build());
	}

	@Test
	void testToString() {
		ArrayList<PermisosRol> permisosRol = new ArrayList<>();
		permisosRol.add(PermisosRol.builder().fechaExpiracion("Fecha Expiracion").jwt("Jwt").rol("Rol").build());
		String buildResult = LoginResponse.builder().permisosRol(permisosRol).build().toString();
		LoginResponse.LoginResponseBuilder builderResult = LoginResponse.builder();
		assertNotEquals(buildResult, builderResult.permisosRol(new ArrayList<>()).build().toString());
	}
}
