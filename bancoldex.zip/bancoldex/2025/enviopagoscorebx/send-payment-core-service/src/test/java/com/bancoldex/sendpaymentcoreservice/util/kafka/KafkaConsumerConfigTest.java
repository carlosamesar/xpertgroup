package com.bancoldex.sendpaymentcoreservice.util.kafka;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;

import java.util.Properties;

import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest
@SpringBootConfiguration
@ExtendWith(MockitoExtension.class)
@ContextConfiguration(classes = KafkaConsumerConfig.class)
@TestPropertySource(properties = {
        "spring.kafka.bootstrap-servers=localhost:9092",
})
public class KafkaConsumerConfigTest {

    @Mock
    private Environment env;

    @InjectMocks
    KafkaConsumerConfig kafkaConsumerConfig;

    @BeforeEach
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        Mockito.when(env.getProperty("spring.kafka.bootstrap-servers")).thenReturn("localhost:9092");
    }

    @Test
    void kafkaConsumer_IsConsumerFactoryValid() {
        Properties properties = kafkaConsumerConfig.consumerFactory();
        assertEquals(properties.getProperty("bootstrap.servers"), "localhost:9092");
    }

    @Configuration
    static class Config {
        @Bean
        public static PropertySourcesPlaceholderConfigurer propertiesResolver() {
            return new PropertySourcesPlaceholderConfigurer();
        }
    }
}