package com.bancoldex.sendpaymentcoreservice.dto;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import org.junit.jupiter.api.Test;

class ValidationResponseTest {
	@Test
	void testValidationResponse() {
		String[] errors = { "Error 1", "Error 2" };
		ValidationResponse validationResponse = ValidationResponse.builder().errors(errors).build();

		assertArrayEquals(errors, validationResponse.getErrors());
	}

	@Test
	void testCanEqual() {
		assertFalse((new ValidationResponse()).canEqual("Other"));
	}

	@Test
	void testConstructor() {
		String[] errors = { "Error 1", "Error 2" };
		ValidationResponse validationResponse = new ValidationResponse();
		validationResponse.setErrors(errors);

		assertArrayEquals(errors, validationResponse.getErrors());
	}

	@Test
	void builderNull() {
		String[] errors = { "Error 1", "Error 2" };
		ValidationResponse.ValidationResponseBuilder builderResult = ValidationResponse.builder();
		assertNotEquals(null, builderResult.errors(errors).build());
	}

	@Test
	void differentBuilder() {
		String[] errors = { "Error 1", "Error 2" };
		ValidationResponse.ValidationResponseBuilder builderResult = ValidationResponse.builder();
		assertNotEquals("Different Type", builderResult.errors(errors).build().toString());
	}

	@Test
	void builderEquals() {
		String[] errors = { "Error 1", "Error 2" };
		ValidationResponse.ValidationResponseBuilder builderResult = ValidationResponse.builder();
		ValidationResponse buildResult = builderResult.errors(errors).build();
		assertEquals(buildResult, buildResult);
		int expectedHashCodeResult = buildResult.hashCode();
		assertEquals(expectedHashCodeResult, buildResult.hashCode());
	}

	@Test
	void noEqualsBuilder() {
		String[] errors = { "Error 1", "Error 2", "Error 3" };
		String[] errors2 = {};
		ValidationResponse buildResult = ValidationResponse.builder().errors(errors).build();
		ValidationResponse.ValidationResponseBuilder builderResult = ValidationResponse.builder();
		assertNotEquals(buildResult, builderResult.errors(errors2).build());
	}
}
