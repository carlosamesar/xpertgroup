package com.bancoldex.sendpaymentcoreservice.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "log_confirm_payment")
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class LogEvent {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ")
	@SequenceGenerator(name = "SEQ", sequenceName = "ID_SEQ", allocationSize = 1)
	private Long id;
	private String event;
	private String idRef;
	@JoinColumn(name = "amount_in_cents")
	private String amountInCents;
	private String reference;
	@JoinColumn(name = "customer_email")
	private String customerEmail;
	private String currency;
	@JoinColumn(name = "payment_method_type")
	private String paymentMethodType;
	@JoinColumn(name = "redirect_url")
	private String redirectUrl;
	private String status;
	@JoinColumn(name = "shipping_address")
	private String shippingAddress;
	@JoinColumn(name = "payment_link_id")
	private String paymentLinkId;
	@JoinColumn(name = "payment_source_id")
	private String paymentSourceId;
	private String environment;
	private String checksum;
	private String timestamp;
	@JoinColumn(name = "sent_at")
	private Date sentAt;
	private String urlCore;
	private Integer stateCore = 1;

}
