package com.bancoldex.sendpaymentcoreservice.util.kafka;

import java.time.Duration;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.consumer.OffsetAndMetadata;
import org.apache.kafka.common.TopicPartition;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class MessageConsumer {

	@Autowired
	public KafkaConsumerConfig kafkaConsumer;

	public KafkaConsumer<String, String> getKafkaConsumer(String topic) {

		Logger logger = Logger.getLogger(MessageConsumer.class.getName());

		List<String> listElementFromTopic = new ArrayList<>();
		KafkaConsumer<String, String> kafkaConsumer1 = kafkaConsumer.kafkaConsumer();
		kafkaConsumer1.subscribe(Arrays.asList(topic));

		Set<TopicPartition> assignedPartitions = kafkaConsumer1.assignment();
		while (assignedPartitions.isEmpty()) {
			kafkaConsumer1.poll(Duration.ofSeconds(10));
			assignedPartitions = kafkaConsumer1.assignment();
		}

		Map<TopicPartition, OffsetAndMetadata> committedOffsets = kafkaConsumer1.committed(assignedPartitions);
		for (TopicPartition partition : assignedPartitions) {
			OffsetAndMetadata offsetAndMetadata = committedOffsets.get(partition);
			if (offsetAndMetadata != null) {
				kafkaConsumer1.seek(partition, offsetAndMetadata.offset());
			} else {
				kafkaConsumer1.seekToBeginning(Arrays.asList(partition));
			}
		}

		return kafkaConsumer1;
	}
}
