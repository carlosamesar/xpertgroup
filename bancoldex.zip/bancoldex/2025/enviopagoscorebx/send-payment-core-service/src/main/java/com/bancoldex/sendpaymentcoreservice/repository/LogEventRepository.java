package com.bancoldex.sendpaymentcoreservice.repository;

import com.bancoldex.sendpaymentcoreservice.model.LogEvent;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LogEventRepository extends JpaRepository<LogEvent, String> {

    LogEvent getOneById(Long id);

}
