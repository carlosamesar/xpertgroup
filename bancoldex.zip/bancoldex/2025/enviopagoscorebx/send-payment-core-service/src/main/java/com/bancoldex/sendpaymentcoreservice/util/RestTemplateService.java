package com.bancoldex.sendpaymentcoreservice.util;


import com.bancoldex.sendpaymentcoreservice.dto.LoginResponse;
import com.bancoldex.sendpaymentcoreservice.dto.PermisosRol;
import com.bancoldex.sendpaymentcoreservice.dto.ValidationResponse;
import com.google.gson.Gson;
import kong.unirest.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;

@Component
public class RestTemplateService {

    @Autowired
    private Environment env;

    @Autowired
    RestTemplate restTemplate;

    public String getJwtToken() {
        Logger logger = Logger.getLogger(RestTemplateService.class.getName());

        try{
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<String> headerList = new HttpEntity<>("paramters", headers);

            String uri = env.getProperty("application.security.url") + "/login?username="
                    + env.getProperty("com.bancoldex.security.user") + "&password="
                    + env.getProperty("com.bancoldex.security.pwd");

            ResponseEntity<String> requestRestTemplate =
                    restTemplate.exchange(
                            uri,
                            HttpMethod.POST,
                            new HttpEntity<>(headerList, headers),
                            String.class
                    );
            return generatedJwt(requestRestTemplate).isPresent() ? generatedJwt(requestRestTemplate).get() : null;
        }
        catch (Exception e) {
            logger.log(Level.INFO, e.getMessage());
        }
        return null;
    }

    public Optional<String> generatedJwt(ResponseEntity<String> stringResponseEntity) {
        Gson gson = new Gson();

        LoginResponse loginresponse = gson.fromJson(stringResponseEntity.getBody(), LoginResponse.class);

        if (loginresponse != null && stringResponseEntity.getStatusCodeValue() == HttpStatus.OK.value())
            for (PermisosRol objectPermiso : loginresponse.getPermisosRol()) {
                if (objectPermiso.getRol().equals(env.getProperty("com.bancoldex.security.rolname"))) {
                    return Optional.of(objectPermiso.getJwt());
                }
            }

        return Optional.empty();
    }

    public Optional<ResponseEntity<ValidationResponse>> getCreateDataApiCore(String token, String uri, JSONObject jsonObject) {
        Logger logger = Logger.getLogger(RestTemplateService.class.getName());
        try{
            logger.log(Level.INFO, "Envio a API-Core ::: " + jsonObject);
            ResponseEntity<ValidationResponse> gatewayDataResponse = callServiceApiCore(token, uri, jsonObject);
            if (gatewayDataResponse.getBody() != null) {
                logger.log(Level.INFO, "Respuesta positiva de API-Core ::: " + gatewayDataResponse.getBody());
                return Optional.of(gatewayDataResponse);
            }else {
                logger.log(Level.INFO, "Respuesta negativa de API-Core ::: " + gatewayDataResponse);
            }
        }
        catch (Exception e) {
            logger.log(Level.SEVERE, e.getMessage());
        }
        return Optional.empty();
    }
    public ResponseEntity<ValidationResponse> callServiceApiCore(String token, String uri, JSONObject jsonObject) throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + token);
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> headerList = new HttpEntity<>(jsonObject.toString(), headers);
        return restTemplate.exchange(uri, HttpMethod.POST, headerList, ValidationResponse.class);
    }
}