package com.bancoldex.sendpaymentcoreservice.util.param;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.bancoldex.sendpaymentcoreservice.util.param.dto.ParamResponse;

import kong.unirest.json.JSONObject;

@Component
public class ParamService {

	@Autowired
	private Environment env;

	public ParamResponse getParams() {

		JSONObject request = new JSONObject();
		request.put("application", env.getProperty("application"));

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> headerList = new HttpEntity<>(request.toString(), headers);
		try {
			String uri = "http://localhost:8082/api/param/getParamByApp";
			RestTemplate restTemplate = new RestTemplateBuilder().build();

			return restTemplate.exchange(uri, HttpMethod.POST, headerList, ParamResponse.class).getBody();
		} catch (Exception e) {
			return null;
		}
	}
}
