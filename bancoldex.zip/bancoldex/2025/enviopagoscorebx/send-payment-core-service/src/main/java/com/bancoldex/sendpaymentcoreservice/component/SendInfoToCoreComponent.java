package com.bancoldex.sendpaymentcoreservice.component;

import java.security.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.bancoldex.sendpaymentcoreservice.model.Channel;
import com.bancoldex.sendpaymentcoreservice.model.Gateway;
import com.bancoldex.sendpaymentcoreservice.repository.ChannelRepository;
import com.bancoldex.sendpaymentcoreservice.repository.GatewayRepository;
import com.bancoldex.sendpaymentcoreservice.util.RestTemplateService;
import com.bancoldex.sendpaymentcoreservice.util.kafka.MessageProducer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.consumer.OffsetAndMetadata;
import org.apache.kafka.common.TopicPartition;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpStatusCodeException;

import com.bancoldex.sendpaymentcoreservice.dto.ValidationResponse;
import com.bancoldex.sendpaymentcoreservice.model.Event;
import com.bancoldex.sendpaymentcoreservice.model.LogEvent;
import com.bancoldex.sendpaymentcoreservice.repository.EventRepository;
import com.bancoldex.sendpaymentcoreservice.repository.LogEventRepository;

import kong.unirest.json.JSONObject;

@Component
public class SendInfoToCoreComponent {

	@Autowired
	private Environment env;

	@Autowired
	private EventRepository eventRepository;

	@Autowired
	private LogEventRepository logEventRepository;

	@Autowired
	private ChannelRepository channelRepository;

	@Autowired
	private GatewayRepository gatewayRepository;

	@Autowired
	private RestTemplateService restTemplateService;

	@Autowired
	private MessageProducer messageProducer;


	public Optional<ResponseEntity<ValidationResponse>> callCreateDataApiCore(Optional<JSONObject> jsonElementData, JSONObject jsonElementRequest) throws Exception {
		String uri = Boolean.TRUE.equals(validateJson(jsonElementRequest, "urlCore"))
				? jsonElementRequest.getString("urlCore")
				: env.getProperty("com.bancoldex.apicore.url");
		return restTemplateService.getCreateDataApiCore(restTemplateService.getJwtToken(), uri, jsonElementData.get());
	}

	public JSONObject buildT24JsonObjectRequest(JSONObject jsonElementData,String nit, String obligation, String tipoPago, String idChannel, int medio, LocalDateTime dateTime){

		//get Origen pago BY id from CHANNEL
		Optional<Channel> channel = channelRepository.findById(Integer.parseInt(idChannel));
		String origenPago =  channel.isPresent() ? channel.get().getNameChannel() : "";
		//get Medio pago BY id from GATEWAY
		Optional<Gateway> gateway = gatewayRepository.findById(medio);
		String medioPago =  gateway.isPresent() ? gateway.get().getNameGateway() : "WOMPI";

		return new JSONObject()
				.put("idCliente",nit) //ok
				.put("referencia", jsonElementData.getString("reference"))//ok
				.put("identificacionPago",  jsonElementData.getString("idRef") ) //id_reference
				.put("idCredito", obligation ) //ok
				.put("tipoPago", tipoPago)
				.put("fechaPago", dateTime.getYear() + String.format("%02d", dateTime.getMonthValue()) + String.format("%02d", dateTime.getDayOfMonth())) //psefecrec
				.put("horaPago", dateTime.getHour() + ":" + dateTime.getMinute()) //psehorrec
				.put("valorPago", jsonElementData.getLong("amount_in_cents")) //#.00
				.put("origenPago", origenPago) //psevaltra
				.put("medioPago", medioPago);


	}

	public JSONObject buildAS400JsonObjectRequest(JSONObject jsonElementData,String nit, String obligation, String idChannel,LocalDateTime dateTime, String tipoPago){

		Long dateTransaction = Long.parseLong(dateTime.getYear() + "" + String.format("%02d",dateTime.getMonthValue()) + String.format("%02d",dateTime.getDayOfMonth()));

		Long psefecrec = dateTransaction;

		//env.getProperty("com.bancoldex.psefecrec").equals("default") && !env.getProperty("com.bancoldex.psefecrec").equals("") ? env.getProperty("com.bancoldex.psefecrec") : dateTransaction

		if(!env.getProperty("com.bancoldex.psefecrec").equals("default") && !env.getProperty("com.bancoldex.psefecrec").equals("") && env.getProperty("com.bancoldex.psefecrec") != null){
			psefecrec = Long.parseLong(env.getProperty("com.bancoldex.psefecrec"));
		}



		return new JSONObject()
				.put("pseidapli", jsonElementData.getLong("id"))
				.put("pseidtran", 0)
				.put("psefectra", dateTransaction )
				.put("psehortra", Long.parseLong(dateTime.getHour() + "" + dateTime.getMinute() + "" + dateTime.getSecond()))
				.put("psenitcli", nit)
				.put("psesuc", 105)
				.put("pselinea", 100)
				.put("psenoper", obligation)
				.put("psefecrec", psefecrec)
				.put("psehorrec", Long.parseLong(dateTime.getHour() + "" + dateTime.getMinute() + "" + dateTime.getSecond()))
				.put("psecanal", idChannel)
				.put("psevaltra", jsonElementData.getLong("amount_in_cents"))
				.put("psetipapl", tipoPago) //tipo de pago.
				.put("pseestado", 1)
				.put("pseresult", "");
	}

	public Optional<JSONObject> buildJsonObjectRequest(JSONObject jsonElementData, Logger logger) throws ParseException {
//		JSONObject jsonObjectRequest = new JSONObject();

		try {

			if (Boolean.TRUE.equals(validateJson(jsonElementData, "sent_at"))){
				Instant date = Instant.ofEpochSecond(jsonElementData.getLong("timestamp"));
				LocalDateTime dateTime = LocalDateTime.ofInstant(date, ZoneId.systemDefault());

				if (Boolean.TRUE.equals(validateJson(jsonElementData, "reference"))) {

					String[] reference = jsonElementData.getString("reference").split("\\|");
					if (reference.length == 6) {
						String obligation = reference[0];//idCredito
						String nit = reference[1]; //ok
						String idChannel = reference[3];
						String idCore = reference[4];
						String tipoPago = reference[5];
						int medio = 1;

						/*Json Object Request for T24*/
						if(idCore.equals("3")){
							return Optional.of(buildT24JsonObjectRequest(jsonElementData, nit, obligation,tipoPago, idChannel, medio, dateTime));
						}
						/*End T24 JOR*/
						return Optional.of(buildAS400JsonObjectRequest(jsonElementData, nit, obligation, idChannel, dateTime, tipoPago));
					} else {
						logger.log(Level.INFO, "La referencia no tiene un formato valido");
					}
				} else {
					logger.log(Level.INFO, "No se encontro referencia");
				}
			} else {
				logger.log(Level.INFO, "No existe la fecha o tiene un formato incorrecto.");
			}
		} catch (Exception ex) {
			logger.log(Level.INFO, ex.getMessage());
		}
		return Optional.empty();
	}

	public Optional<Void> generatedEvent(Event event){

		event.setStateCore(2);
		eventRepository.save(event);

		LogEvent logEvent = LogEvent.builder().idRef(event.getIdRef())
				.amountInCents(event.getAmount_in_cents()).reference(event.getReference())
				.customerEmail(event.getCustomer_email()).currency(event.getCurrency())
				.paymentMethodType(event.getPayment_method_type())
				.redirectUrl(event.getRedirect_url()).status(event.getStatus())
				.shippingAddress(event.getShipping_address())
				.paymentLinkId(event.getPayment_link_id()).paymentSourceId(event.getPayment_source_id())
				.sentAt(event.getSent_at()).urlCore(event.getUrlCore()).stateCore(2).build();
		logEventRepository.save(logEvent);
		return Optional.empty();
	}


	public void processMessagesKafka(KafkaConsumer<String, String> kafkaConsumer) throws Exception {

		ConsumerRecords<String, String> records = kafkaConsumer.poll(Duration.ofSeconds(10));

		Map<TopicPartition, OffsetAndMetadata> commitMap = new HashMap<>();

		for (ConsumerRecord<String, String> rec : records) {
			if(!sendInfoToApiCore(rec.value())) {
				messageProducer.sendMessage(env.getProperty("kafka.topic.pendiente-core-payment"),rec.value());
			}
			commitMap.put(new TopicPartition(rec.topic(), rec.partition()), new OffsetAndMetadata(rec.offset() + 1));
			kafkaConsumer.commitSync(commitMap);
		}

	}

	public boolean sendInfoToApiCore(String elementData) {
		boolean response = false;
		Logger logger = Logger.getLogger(SendInfoToCoreComponent.class.getName());

		//validations

		//end validations
		try {
			JSONObject jsonElementData = new JSONObject(elementData);
			logger.log(Level.INFO, "Elemento Cola kafka "+elementData);
			Event event = eventRepository.getOneById(jsonElementData.getLong("id"));
			Optional<Event> optionalEvent = eventRepository.findFirstByIdRef(event.getIdRef());
			Event eventProcess = optionalEvent.get();

			if((eventProcess.getStateCore() == null) || (eventProcess.getStateCore() != 2 && eventProcess.getStateCore() != 3)) {
				Optional<JSONObject> jsonObjectRequest = buildJsonObjectRequest(jsonElementData, logger); // metodo core validation
				if (jsonObjectRequest.isPresent()){

					Optional<ResponseEntity<ValidationResponse>> gatewayDataResponse = callCreateDataApiCore(jsonObjectRequest, jsonElementData); //envio al api core
					if (logger.isLoggable(Level.INFO)) {
						logger.log(Level.INFO, gatewayDataResponse.toString());
					}
					if(gatewayDataResponse.isPresent()){
						if (gatewayDataResponse.get().getStatusCodeValue() == 200) {
							generatedEvent(eventProcess);
							response = true;
						} else {
							logger.log(Level.INFO, "Error del API-Core "+gatewayDataResponse.get().getStatusCodeValue()+" ::: " + gatewayDataResponse);
						}
					} else {
						logger.log(Level.INFO, "No se encontró información en el destino");
					}
				}
			}
			else {
				response = true;
			}

		} catch (HttpStatusCodeException ex) {
			HttpHeaders headersHttp = ex.getResponseHeaders();
			if (headersHttp != null) {
				List<String> header = headersHttp.get("x-app-err-id");
				String errorMessageId = "";
				if (header != null && !header.isEmpty()) {
					errorMessageId = header.get(0);
				}
				logger.log(Level.INFO, errorMessageId);
				logger.log(Level.INFO, ex.getResponseBodyAsString());
			}
		}
		catch (Exception e) {
			logger.log(Level.INFO, e.getMessage());
		}
		return response;
	}

	private Boolean validateJson(JSONObject jsonObject, String key) {
		try {
			jsonObject.getString(key);
			return true;
		} catch (Exception e) {
			return false;
		}
	}
}
