package com.bancoldex.sendpaymentcoreservice.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "confirm_payment")
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class Event {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ")
	@SequenceGenerator(name = "SEQ", sequenceName = "ID_SEQ", allocationSize = 1)
	private Long id;
	private String event;
	private String idRef;
	private String amount_in_cents;
	private String reference;
	private String customer_email;
	private String currency;
	private String payment_method_type;
	private String redirect_url;
	private String status;
	private String shipping_address;
	private String payment_link_id;
	private String payment_source_id;
	private String environment;
	private String checksum;
	private String timestamp;
	private Date sent_at;
	private String urlCore;
	private Integer stateCore = 1;

}
