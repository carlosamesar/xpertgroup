package com.bancoldex.sendpaymentcoreservice.component;

import com.bancoldex.sendpaymentcoreservice.util.kafka.MessageConsumer;
import com.bancoldex.sendpaymentcoreservice.util.kafka.MessageProducer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.text.ParseException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.logging.Level;
import java.util.logging.Logger;

@Component
@EnableScheduling
public class SendPaymentCoreComponent {

    @Autowired
    private MessageProducer messageProducer;

    @Autowired
    private SendInfoToCoreComponent sendInfoToCoreComponent;

    @Autowired
    private Environment env;

    @Autowired
    private MessageConsumer messageConsumer;

    @KafkaListener(topics = "${kafka.topic.confirm-payment}")
    public void listenConfirmTopic(String message){
        Logger logger
                = Logger.getLogger(
                SendPaymentCoreComponent.class.getName());
        logger.log(Level.INFO, "Mensaje de confirmacion");
        logger.log(Level.INFO, message);
        messageProducer.sendMessage(env.getProperty("kafka.topic.pendiente-core-payment"), message);
    }

    @Scheduled(fixedDelay = 10000)
    public void sendInfoToApiCore() throws Exception {
        sendInfoToCoreComponent.processMessagesKafka(messageConsumer.getKafkaConsumer(env.getProperty("kafka.topic.pendiente-core-payment")));
    }
}
