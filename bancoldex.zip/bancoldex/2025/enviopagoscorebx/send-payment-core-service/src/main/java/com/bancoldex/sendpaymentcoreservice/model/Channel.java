package com.bancoldex.sendpaymentcoreservice.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "channel")
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class Channel {

    @Id
    private int id;
    @Column(name="NAME_CHANNEL")
    private String nameChannel;
    @Column(name="STATE_CHANNEL")
    private String stateChannel;
}
