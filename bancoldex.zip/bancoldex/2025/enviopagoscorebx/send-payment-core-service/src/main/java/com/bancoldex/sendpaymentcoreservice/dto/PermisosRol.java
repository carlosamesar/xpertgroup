package com.bancoldex.sendpaymentcoreservice.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PermisosRol {
    private String fechaExpiracion;
    private String jwt;
    private String rol;
}
