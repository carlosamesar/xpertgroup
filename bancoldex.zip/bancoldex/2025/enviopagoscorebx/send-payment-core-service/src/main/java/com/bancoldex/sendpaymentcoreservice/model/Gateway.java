package com.bancoldex.sendpaymentcoreservice.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "gateway")
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class Gateway {

    @Id
    private int id;
    @Column(name="NAME_GATEWAY")
    private String nameGateway;
}
