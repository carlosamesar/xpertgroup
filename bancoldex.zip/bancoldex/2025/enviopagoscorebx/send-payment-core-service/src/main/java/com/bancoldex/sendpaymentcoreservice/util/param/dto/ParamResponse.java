package com.bancoldex.sendpaymentcoreservice.util.param.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;



@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ParamResponse {
    private Long id;
    private Kafka kafka;
}

