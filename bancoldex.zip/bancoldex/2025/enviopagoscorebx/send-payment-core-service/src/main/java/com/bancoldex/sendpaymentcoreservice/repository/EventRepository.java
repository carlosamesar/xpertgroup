package com.bancoldex.sendpaymentcoreservice.repository;

import com.bancoldex.sendpaymentcoreservice.model.Event;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface EventRepository extends JpaRepository<Event, String> {

    Event getOneById(Long id);

    Optional<Event> findFirstByIdRef(String idRef);


}
