# 🔍 INFORME DE VALIDACIÓN - Send Register Core vs Send Payment Core Service

## ❌ PROBLEMAS IDENTIFICADOS

### 1. **pom.xml - Dependencias NO conformes**

#### ❌ Dependencias EXTRA (NO están en proyecto base):
```xml
<!-- ELIMINAR -->
<dependency>
    <groupId>org.apache.commons</groupId>
    <artifactId>commons-csv</artifactId>
    <version>1.10.0</version>
</dependency>

<!-- ELIMINAR -->
<dependency>
    <groupId>commons-io</groupId>
    <artifactId>commons-io</artifactId>
    <version>2.11.0</version>
</dependency>

<!-- ELIMINAR -->
<dependency>
    <groupId>org.springframework.kafka</groupId>
    <artifactId>spring-kafka-test</artifactId>
    <scope>test</scope>
</dependency>

<!-- ELIMINAR -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-tomcat</artifactId>
    <scope>provided</scope>
</dependency>

<!-- ELIMINAR -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-validation</artifactId>
</dependency>
```

#### ⚠️ Dependencias con SCOPE incorrecto:
```xml
<!-- mockito-core NO debe tener scope en proyecto base -->
<dependency>
    <groupId>org.mockito</groupId>
    <artifactId>mockito-core</artifactId>
    <version>4.5.1</version>
    <!-- REMOVER: <scope>test</scope> -->
</dependency>

<!-- junit-jupiter NO debe tener scope en proyecto base -->
<dependency>
    <groupId>org.junit.jupiter</groupId>
    <artifactId>junit-jupiter</artifactId>
    <version>5.8.2</version>
    <!-- REMOVER: <scope>test</scope> -->
</dependency>

<!-- mockito-junit-jupiter NO debe tener scope en proyecto base -->
<dependency>
    <groupId>org.mockito</groupId>
    <artifactId>mockito-junit-jupiter</artifactId>
    <version>4.5.1</version>
    <!-- REMOVER: <scope>test</scope> -->
</dependency>
```

---

### 2. **SendRegisterCoreApplication.java - Anotación NO conforme**

#### ❌ Anotación EXTRA:
```java
@EnableScheduling  // NO EXISTE EN PROYECTO BASE - ELIMINAR
```

**Proyecto Base:**
```java
@SpringBootApplication
public class SendPaymentCoreServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(SendPaymentCoreServiceApplication.class, args);
    }

    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
}
```

**Corrección Requerida:**
- ELIMINAR `@EnableScheduling`
- El @Scheduled funciona sin necesidad de habilitarlo explícitamente en Spring Boot 2.7.14

---

### 3. **KafkaProducerConfig.java - Configuración EXTRA**

#### ❌ Propiedades NO presentes en proyecto base:
```java
configProps.put(ProducerConfig.ACKS_CONFIG, "all");  // ELIMINAR
configProps.put(ProducerConfig.RETRIES_CONFIG, 3);   // ELIMINAR
configProps.put(ProducerConfig.COMPRESSION_TYPE_CONFIG, "snappy");  // ELIMINAR
```

**Proyecto Base (CORRECTO):**
```java
@Bean
public ProducerFactory<String, String> producerFactory() {
    Map<String, Object> configProps = new HashMap<>();
    configProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, env.getProperty("spring.kafka.bootstrap-servers"));
    configProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
    configProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
    return new DefaultKafkaProducerFactory<>(configProps);
}
```

---

### 4. **FileProcessingComponent.java - Dependencias Incorrectas**

#### ❌ Usa librerías NO presentes en proyecto base:
```java
import org.apache.commons.csv.CSVFormat;          // ELIMINAR
import org.apache.commons.csv.CSVParser;          // ELIMINAR
import org.apache.commons.csv.CSVRecord;          // ELIMINAR
import org.apache.commons.io.FilenameUtils;       // ELIMINAR
```

**Problema**: El proyecto base NO usa Apache Commons CSV ni Commons IO.

**Solución**: Implementar parseo de CSV manualmente usando:
- `BufferedReader` + `FileReader`
- `String.split()` para delimitadores
- Lógica propia para headers

---

### 5. **application.properties - Propiedades EXTRA**

#### ❌ Propiedades NO presentes en proyecto base:
```properties
# ELIMINAR - No está en proyecto base
file.processing.input-directory=C:/bancoldex/input
file.processing.processed-directory=C:/bancoldex/processed
file.processing.error-directory=C:/bancoldex/error
file.processing.allowed-extensions=csv,txt

# REVISAR - Formato diferente en proyecto base
logging.level.root=INFO
logging.level.com.bancoldex.sendregistercore=INFO
logging.level.org.springframework.kafka=WARN
logging.pattern.console=%d{yyyy-MM-dd HH:mm:ss} - %msg%n
```

**Proyecto Base** usa logging mínimo, sin configuraciones explícitas de pattern.

---

### 6. **Modelos JPA - Diferencias**

#### ⚠️ Verificar nombres de secuencias:
Proyecto base usa formato: `SEQ` con `@SequenceGenerator(name="SEQ", sequenceName="ID_SEQ")`

Nuevo proyecto usa: `FILE_REGISTER_SEQ`, `LOG_FILE_REGISTER_SEQ`

**Recomendación**: Mantener nombres específicos ya que son tablas diferentes.

---

### 7. **Archivos EXTRA - NO existen en proyecto base**

#### ❌ Documentación excesiva:
- `RESUMEN_PROYECTO.md` - NO existe en base
- `VERIFICACION.md` - NO existe en base
- `samples/` directorio completo - NO existe en base
- `database/schema.sql` - NO existe en base (puede ser útil mantener)

**Proyecto Base** solo tiene:
- `DOCUMENTACION.md`
- `README.md` (implícito)

---

## ✅ PLAN DE REFACTORIZACIÓN

### Paso 1: Limpiar pom.xml
- Eliminar 5 dependencias extra
- Remover `<scope>test</scope>` de 3 dependencias

### Paso 2: Corregir SendRegisterCoreApplication.java
- Eliminar `@EnableScheduling`

### Paso 3: Refactorizar FileProcessingComponent
- Eliminar uso de Apache Commons CSV
- Implementar parseo manual con BufferedReader
- Eliminar uso de Commons IO FilenameUtils
- Implementar lógica propia para extensiones

### Paso 4: Simplificar KafkaProducerConfig
- Eliminar 3 propiedades de configuración extra

### Paso 5: Limpiar application.properties
- Mantener solo propiedades equivalentes al proyecto base
- Eliminar configuraciones de logging custom

### Paso 6: Eliminar archivos extras
- Mover o eliminar documentación redundante
- Considerar mantener database/schema.sql por utilidad

---

## 🎯 OBJETIVO

Dejar el proyecto **100% conforme** con:
- Mismas dependencias (solo las del base)
- Mismo estilo de configuración
- Mismas prácticas de código
- Sin librerías externas que no estén en el base

---

## ⚠️ IMPACTO

**ALTO**: Se requiere refactorizar FileProcessingComponent completamente para eliminar dependencia de Apache Commons CSV.

**Estimación**: 
- Cambios en 6 archivos principales
- Reescritura de lógica de parseo CSV/TXT
- Tests afectados que deben ajustarse

---

**Fecha**: 2024-11-15  
**Estado**: PENDIENTE DE APROBACIÓN PARA REFACTORIZACIÓN
