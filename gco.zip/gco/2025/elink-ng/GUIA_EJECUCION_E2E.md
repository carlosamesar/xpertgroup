# 🚀 Guía de Ejecución - Pruebas E2E Validador Multicanal

## 📋 Tabla de Contenidos

1. [Prerequisitos](#prerequisitos)
2. [Instalación](#instalación)
3. [Comandos de Ejecución](#comandos-de-ejecución)
4. [Modos de Ejecución](#modos-de-ejecución)
5. [Interpretación de Resultados](#interpretación-de-resultados)
6. [Troubleshooting](#troubleshooting)
7. [Integración CI/CD](#integración-cicd)

---

## ✅ Prerequisitos

### Software Requerido
- **Node.js**: v12.x o superior
- **npm**: v6.x o superior
- **Angular CLI**: v7.3.9
- **Java**: JDK 8 (para backend, solo en modo integración)
- **Chrome/Chromium**: Última versión estable
- **Git**: Para control de versiones

### Verificar Instalaciones
```powershell
node --version          # Debe mostrar v12.x.x
npm --version           # Debe mostrar v6.x.x
npx ng version          # Debe mostrar Angular CLI 7.3.9
```

---

## 📦 Instalación

### 1. Clonar Repositorio (si aplica)
```powershell
cd c:\resources\xpert\gco\2025\elink-ng
```

### 2. Instalar Dependencias
```powershell
npm install
```

### 3. Actualizar WebDriver (Protractor)
```powershell
npx webdriver-manager update
```

### 4. Verificar Configuración
```powershell
# Verificar que existan los archivos de configuración
Get-ChildItem e2e\protractor*.conf.js
# Debe listar: protractor.conf.js, protractor-ci.conf.js, protractor-mock.conf.js
```

---

## 🎯 Comandos de Ejecución

### Comandos Principales

#### 1. **Pruebas con Mocks** (Recomendado para Desarrollo)
```powershell
npm run e2e:mock
```
- ✅ **Uso**: Desarrollo local sin backend
- ✅ **Tiempo**: ~3-5 minutos
- ✅ **Dependencias**: Ninguna (usa mocks)

#### 2. **Pruebas en Modo CI/CD** (Headless)
```powershell
npm run e2e:ci
```
- ✅ **Uso**: Pipelines de CI/CD
- ✅ **Tiempo**: ~4-6 minutos
- ✅ **Características**: Sin ventana de navegador, screenshots en fallo

#### 3. **Todas las Pruebas del Validador**
```powershell
npm run e2e:validador
```
- ✅ **Uso**: Suite completa (58 specs)
- ✅ **Tiempo**: ~6-8 minutos
- ✅ **Backend**: Requerido (modo integración)

### Comandos por Suite Específica

#### Suite de Búsqueda (15 specs)
```powershell
npm run e2e:buscar
```
**Cobertura:**
- Validación de formulario
- Filtros de búsqueda
- Selección de referencias
- Grid ag-grid
- Mensajes de error

#### Suite de Atributos (13 specs)
```powershell
npm run e2e:atributos
```
**Cobertura:**
- Modal de atributos
- Tabs de canales
- Tooltips informativos
- Validación de estados (OK/No OK)
- Navegación entre atributos

#### Suite de Fecha de Lanzamiento (21 specs)
```powershell
npm run e2e:fecha
```
**Cobertura:**
- Modal de asignación de fechas
- Validación de formulario
- Selección de canales
- Guardado y actualización
- Estados de activación

#### Suite de Flujo Completo (9 specs)
```powershell
npm run e2e:flujo
```
**Cobertura:**
- Flujos end-to-end completos
- Búsqueda → Atributos → Fecha
- Escenarios de éxito/fallo
- Validación integral

### Comandos de Utilidad

#### Cobertura de Pruebas Unitarias
```powershell
npm run test:coverage
```
**Salida:** Reporte HTML en `coverage/index.html`

#### Pruebas E2E Estándar
```powershell
npm run e2e
```
**Uso:** Configuración por defecto (todas las pruebas E2E del proyecto)

---

## 🔧 Modos de Ejecución

### Modo 1: **Desarrollo con Mocks** (Sin Backend)

**Configuración:**
- Archivo: `src/environments/environment.e2e.ts`
- Flag: `useMocks: true`

**Características:**
- ✅ No requiere backend corriendo
- ✅ Datos predefinidos en `e2e/src/mocks/referencia-mock.data.ts`
- ✅ Delay de red simulado (300ms)
- ✅ Ideal para desarrollo frontend aislado

**Ejecución:**
```powershell
npm run e2e:mock
```

**Datos Mock Disponibles:**
- 5 referencias de prueba
- 3 escenarios detallados de atributos
- Estados: OK, No OK, Datos incompletos
- Canales: GcoGT, GMX, GHN, Marketplace Principal

### Modo 2: **Integración con Backend Real**

**Configuración:**
- Archivo: `src/environments/environment.ts`
- Flag: `useMocks: false` (por defecto)

**Prerequisitos:**
1. Backend `siconline-vtex-services` corriendo en `localhost:8080`
2. Base de datos PostgreSQL disponible
3. Autenticación configurada

**Ejecución:**
```powershell
# Primero, iniciar backend (en otra terminal)
cd c:\resources\xpert\gco\2025\siconline-vtex-services
mvnw.cmd spring-boot:run

# Luego, ejecutar pruebas
npm run e2e:validador
```

### Modo 3: **CI/CD (Headless)**

**Configuración:**
- Archivo: `e2e/protractor-ci.conf.js`
- Chrome: Modo headless (sin interfaz gráfica)

**Características:**
- ✅ Ejecución en servidor sin pantalla
- ✅ Screenshots automáticos en fallo (`e2e/screenshots/`)
- ✅ Timeouts extendidos (60s)
- ✅ Logs detallados

**Ejecución:**
```powershell
npm run e2e:ci
```

**Integración GitHub Actions:**
- Workflow: `.github/workflows/e2e-tests.yml`
- Trigger: Push a `main`, `develop`, `feature/validador-multicanal`
- Artifacts: Screenshots y logs (7 días retención)

---

## 📊 Interpretación de Resultados

### Salida Exitosa
```
Executed 58 of 58 specs SUCCESS in 4 mins 32 secs.

✅ buscar-referencia.e2e-spec.ts (15 specs) - PASSED
✅ modal-atributos.e2e-spec.ts (13 specs) - PASSED
✅ modal-fecha-lanzamiento.e2e-spec.ts (21 specs) - PASSED
✅ flujo-completo.e2e-spec.ts (9 specs) - PASSED
```

### Salida con Errores
```
Executed 58 of 58 specs (3 FAILED) in 5 mins 12 secs.

❌ modal-fecha-lanzamiento.e2e-spec.ts
  - Debería guardar fecha de lanzamiento correctamente (FAILED)
    Expected: 200
    Actual: 500
```

**Acciones:**
1. Revisar logs en consola
2. Verificar screenshots en `e2e/screenshots/`
3. Ejecutar spec individual: `npm run e2e:fecha`
4. Revisar trace en `e2e/logs/` (si configurado)

### Métricas de Calidad

| Métrica | Objetivo | Crítico |
|---------|----------|---------|
| **Specs Pasados** | 100% | < 95% |
| **Tiempo Ejecución** | < 5 min | > 8 min |
| **Cobertura** | > 80% | < 60% |
| **Flaky Tests** | 0 | > 2 |

---

## 🐛 Troubleshooting

### Problema 1: WebDriver Desactualizado
**Error:**
```
SessionNotCreatedError: session not created: This version of ChromeDriver only supports Chrome version 90
```

**Solución:**
```powershell
npx webdriver-manager update --standalone false --gecko false
```

### Problema 2: Puerto 4200 Ocupado
**Error:**
```
Port 4200 is already in use.
```

**Solución:**
```powershell
# Opción 1: Matar proceso
netstat -ano | findstr :4200
taskkill /PID <PID> /F

# Opción 2: Usar puerto diferente
ng serve --port 4201
# Actualizar e2e/protractor.conf.js -> baseUrl
```

### Problema 3: Timeouts en Pruebas
**Error:**
```
Error: Timeout - Async callback was not invoked within timeout specified by jasmine.DEFAULT_TIMEOUT_INTERVAL
```

**Solución:**
```typescript
// En e2e/protractor.conf.js o protractor-ci.conf.js
jasmineNodeOpts: {
  defaultTimeoutInterval: 90000 // Aumentar a 90 segundos
}
```

### Problema 4: Backend No Disponible (Modo Integración)
**Error:**
```
Failed to load resource: net::ERR_CONNECTION_REFUSED
```

**Solución:**
```powershell
# Verificar que backend esté corriendo
Invoke-WebRequest -Uri http://localhost:8080/commerce/referencia/health

# Si no está corriendo, iniciar backend
cd c:\resources\xpert\gco\2025\siconline-vtex-services
mvnw.cmd spring-boot:run
```

### Problema 5: Mocks No Se Activan
**Error:**
```
HttpErrorResponse: 404 Not Found
```

**Solución:**
```typescript
// Verificar src/environments/environment.e2e.ts
export const environment = {
  useMocks: true,  // ⬅️ DEBE estar en true
  // ...
};

// Verificar src/app/shared/shared.module.ts
{
  provide: ValidadorReferenciaService,
  useClass: environment.useMocks ? ValidadorReferenciaMockService : ValidadorReferenciaService
}
```

### Problema 6: Screenshots No Se Generan
**Solución:**
```powershell
# Crear directorio si no existe
mkdir e2e\screenshots

# Verificar permisos de escritura
Get-Acl e2e\screenshots
```

### Problema 7: Errores de Compilación TypeScript
**Error:**
```
ERROR in src/app/shared/service/validador-referencia.service.mock.ts
Cannot find module '@angular/common/http'
```

**Solución:**
```powershell
# Reinstalar dependencias
Remove-Item -Recurse -Force node_modules
npm install
```

---

## 🔄 Integración CI/CD

### GitHub Actions

**Archivo:** `.github/workflows/e2e-tests.yml`

**Triggers:**
- Push a `main`, `develop`, `feature/validador-multicanal`
- Pull Requests a `main`, `develop`

**Jobs:**
1. **e2e-tests**: Pruebas con mocks (siempre)
2. **integration-tests**: Pruebas con backend real (solo `main`/`develop`)

**Artifacts Generados:**
- Screenshots en fallo (7 días retención)
- Logs de pruebas (7 días retención)
- Reporte de cobertura (opcional)

### Comandos Locales para CI

```powershell
# Simular ejecución CI localmente
npm run e2e:ci

# Verificar logs
Get-Content e2e\screenshots\*.png | Measure-Object

# Limpiar artifacts
Remove-Item -Recurse -Force e2e\screenshots\*
```

---

## 📈 Mejores Prácticas

### Durante Desarrollo
1. **Usar mocks** para iteración rápida
2. **Ejecutar suite específica** del módulo en desarrollo
3. **Revisar logs** inmediatamente después de fallos
4. **Validar cambios** con `npm run e2e:mock` antes de commit

### Antes de PR/Merge
1. **Ejecutar suite completa**: `npm run e2e:validador`
2. **Verificar cobertura**: `npm run test:coverage`
3. **Ejecutar en modo CI**: `npm run e2e:ci`
4. **Validar con backend real** (si disponible)

### En CI/CD
1. **Mocks primero**: Validación rápida (job obligatorio)
2. **Integración después**: Validación exhaustiva (job opcional)
3. **Retener artifacts**: Screenshots y logs para debugging
4. **Notificaciones**: Alertas en Slack/Teams en fallo

---

## 🎓 Recursos Adicionales

### Documentación
- [PLAN_PRUEBAS_E2E_VALIDADOR_MULTICANAL.md](./PLAN_PRUEBAS_E2E_VALIDADOR_MULTICANAL.md) - Plan maestro de pruebas
- [e2e/src/validador-multicanal/README.md](./e2e/src/validador-multicanal/README.md) - Guía técnica detallada
- [Protractor Docs](https://www.protractortest.org/) - Documentación oficial

### Archivos Clave
- `e2e/src/mocks/referencia-mock.data.ts` - Datos mock
- `src/app/shared/service/validador-referencia.service.mock.ts` - Servicio mock
- `e2e/src/validador-multicanal/page-objects/` - Page Objects (POM)
- `e2e/src/validador-multicanal/*.e2e-spec.ts` - Specs de prueba (58 tests)

---

## ✅ Checklist de Ejecución

### Primera Ejecución
- [ ] Instalar dependencias: `npm install`
- [ ] Actualizar WebDriver: `npx webdriver-manager update`
- [ ] Verificar archivos de configuración existen
- [ ] Crear directorio screenshots: `mkdir e2e\screenshots`
- [ ] Ejecutar prueba básica: `npm run e2e:mock`

### Ejecución Regular (Desarrollo)
- [ ] Código actualizado desde repositorio
- [ ] Backend corriendo (si modo integración)
- [ ] Ejecutar suite específica: `npm run e2e:buscar`
- [ ] Revisar resultados en consola
- [ ] Verificar screenshots si hay fallos

### Ejecución Pre-Deploy
- [ ] Branch actualizado con `main`
- [ ] Sin cambios sin commitear
- [ ] Ejecutar suite completa: `npm run e2e:validador`
- [ ] Ejecutar cobertura: `npm run test:coverage`
- [ ] Ejecutar modo CI: `npm run e2e:ci`
- [ ] Validar métricas de calidad
- [ ] Revisar artifacts generados

---

## 📞 Soporte

**Equipo de Desarrollo:**
- Frontend: [Angular 7 Team]
- Backend: [Java/Spring Boot Team]
- QA: [Testing Team]

**Recursos:**
- Issues: [GitHub Issues](https://github.com/...)
- Wiki: [Confluence/Wiki Interna]
- Chat: [Slack #elink-validador-multicanal]

---

**Última Actualización:** Implementación E2E Infrastructure - Fase Autónoma  
**Versión:** 1.0.0  
**Estado:** ✅ Infraestructura Completa y Operativa
