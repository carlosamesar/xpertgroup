// Protractor configuration for mock testing
const { SpecReporter } = require('jasmine-spec-reporter');

exports.config = {
  allScriptsTimeout: 20000,
  specs: [
    './src/validador-multicanal/**/*.e2e-spec.ts'
  ],
  capabilities: {
    browserName: 'chrome',
    chromeOptions: {
      args: [
        '--disable-web-security',
        '--disable-gpu',
        '--window-size=1920,1080'
      ]
    }
  },
  directConnect: true,
  baseUrl: 'http://localhost:4200/',
  framework: 'jasmine',
  jasmineNodeOpts: {
    showColors: true,
    defaultTimeoutInterval: 45000,
    print: function() {}
  },
  onPrepare() {
    require('ts-node').register({
      project: require('path').join(__dirname, './tsconfig.e2e.json')
    });
    
    jasmine.getEnv().addReporter(new SpecReporter({ 
      spec: { 
        displayStacktrace: 'pretty',
        displayErrorMessages: true,
        displaySuccessful: true,
        displayFailed: true,
        displayPending: true,
        displayDuration: true
      },
      summary: {
        displayErrorMessages: true,
        displayStacktrace: true,
        displaySuccessful: true,
        displayFailed: true,
        displayPending: true,
        displayDuration: true
      }
    }));
    
    // Agregar reporter personalizado para estadísticas
    jasmine.getEnv().addReporter({
      jasmineStarted: function() {
        console.log('\n========================================');
        console.log('🧪 Iniciando Pruebas E2E con Mocks');
        console.log('========================================\n');
      },
      jasmineDone: function(result) {
        console.log('\n========================================');
        console.log('📊 Resumen de Ejecución:');
        console.log(`   Total specs: ${result.totalSpecsDefined}`);
        console.log(`   ✅ Exitosas: ${result.totalSpecsDefined - result.failedExpectations.length}`);
        console.log(`   ❌ Fallidas: ${result.failedExpectations.length}`);
        console.log('========================================\n');
      }
    });
    
    console.log('🔧 Configuración: Modo MOCK activado');
    console.log('📁 Specs objetivo: ./src/validador-multicanal/**/*.e2e-spec.ts\n');
  }
};
