/**
 * Page Object para Buscar Referencia Component
 * 
 * Encapsula los selectores y acciones de la página de búsqueda de referencias.
 * Sigue el patrón Page Object Model para mantener las pruebas mantenibles.
 */

import { browser, by, element, ElementFinder, ExpectedConditions as EC } from 'protractor';

export class BuscarReferenciaPage {
  
  // URL de la página
  private readonly url = '/validador-multicanal';
  
  // Timeouts
  private readonly defaultTimeout = 10000;
  private readonly spinnerTimeout = 15000;
  
  /**
   * Selectores de elementos del formulario de búsqueda
   */
  private get empresaSelect(): ElementFinder {
    return element(by.css('select[name="empresa"]'));
  }
  
  private get anoSelect(): ElementFinder {
    return element(by.css('select[name="ano"]'));
  }
  
  private get coleccionSelect(): ElementFinder {
    return element(by.css('select[name="coleccion"]'));
  }
  
  private get referenciaInput(): ElementFinder {
    return element(by.css('input[name="referencia"]'));
  }
  
  private get buscarButton(): ElementFinder {
    return element(by.css('button[type="submit"]'));
  }
  
  private get limpiarButton(): ElementFinder {
    return element(by.buttonText('Limpiar'));
  }
  
  /**
   * Selectores de elementos de resultados
   */
  private get resultadosContainer(): ElementFinder {
    return element(by.css('.resultados-referencias'));
  }
  
  private get referenciaCards() {
    return element.all(by.css('.card-referencia'));
  }
  
  private get sinResultadosMessage(): ElementFinder {
    return element(by.css('.sin-resultados'));
  }
  
  private get spinner(): ElementFinder {
    return element(by.css('ngx-spinner'));
  }
  
  /**
   * Selectores de botones de acción
   */
  private get verAtributosButtons() {
    return element.all(by.buttonText('Ver Atributos'));
  }
  
  private get asignarFechaButton(): ElementFinder {
    return element(by.buttonText('Asignar Fecha Lanzamiento'));
  }
  
  /**
   * Navegación
   */
  async navigateTo(): Promise<void> {
    await browser.get(this.url);
    await browser.wait(EC.presenceOf(this.empresaSelect), this.defaultTimeout);
  }
  
  /**
   * Llenar formulario de búsqueda
   */
  async llenarFormularioBusqueda(datos: {
    empresa: string;
    ano?: number;
    coleccion?: string;
    referencia?: string;
  }): Promise<void> {
    await this.seleccionarEmpresa(datos.empresa);
    
    if (datos.ano) {
      await this.seleccionarAno(datos.ano);
    }
    
    if (datos.coleccion) {
      await this.seleccionarColeccion(datos.coleccion);
    }
    
    if (datos.referencia) {
      await this.ingresarReferencia(datos.referencia);
    }
  }
  
  /**
   * Seleccionar empresa
   */
  async seleccionarEmpresa(empresa: string): Promise<void> {
    await this.empresaSelect.click();
    await element(by.css(`select[name="empresa"] option[value="${empresa}"]`)).click();
  }
  
  /**
   * Seleccionar año
   */
  async seleccionarAno(ano: number): Promise<void> {
    await this.anoSelect.click();
    await element(by.css(`select[name="ano"] option[value="${ano}"]`)).click();
  }
  
  /**
   * Seleccionar colección
   */
  async seleccionarColeccion(coleccion: string): Promise<void> {
    await this.coleccionSelect.click();
    await element(by.css(`select[name="coleccion"] option[value="${coleccion}"]`)).click();
  }
  
  /**
   * Ingresar código de referencia
   */
  async ingresarReferencia(referencia: string): Promise<void> {
    await this.referenciaInput.clear();
    await this.referenciaInput.sendKeys(referencia);
  }
  
  /**
   * Click en botón buscar
   */
  async clickBuscar(): Promise<void> {
    await this.buscarButton.click();
    await this.esperarCargaCompleta();
  }
  
  /**
   * Click en botón limpiar
   */
  async clickLimpiar(): Promise<void> {
    await this.limpiarButton.click();
  }
  
  /**
   * Esperar a que termine la carga (spinner desaparezca)
   */
  async esperarCargaCompleta(): Promise<void> {
    // Esperar a que aparezca el spinner (opcional, puede ser rápido)
    try {
      await browser.wait(EC.presenceOf(this.spinner), 2000);
    } catch (e) {
      // Si no aparece en 2s, probablemente ya terminó
    }
    
    // Esperar a que desaparezca
    await browser.wait(EC.invisibilityOf(this.spinner), this.spinnerTimeout);
    
    // Esperar un poco más para que se rendericen los resultados
    await browser.sleep(500);
  }
  
  /**
   * Obtener cantidad de resultados
   */
  async obtenerCantidadResultados(): Promise<number> {
    return await this.referenciaCards.count();
  }
  
  /**
   * Verificar si hay resultados
   */
  async hayResultados(): Promise<boolean> {
    const count = await this.obtenerCantidadResultados();
    return count > 0;
  }
  
  /**
   * Verificar si se muestra mensaje "sin resultados"
   */
  async seMuestraSinResultados(): Promise<boolean> {
    return await this.sinResultadosMessage.isPresent();
  }
  
  /**
   * Obtener referencia por índice
   */
  obtenerReferenciaPorIndice(index: number): ElementFinder {
    return this.referenciaCards.get(index);
  }
  
  /**
   * Obtener checkbox de referencia por índice
   */
  obtenerCheckboxPorIndice(index: number): ElementFinder {
    return this.referenciaCards.get(index).element(by.css('input[type="checkbox"]'));
  }
  
  /**
   * Seleccionar referencia por índice (check)
   */
  async seleccionarReferencia(index: number): Promise<void> {
    const checkbox = this.obtenerCheckboxPorIndice(index);
    const isSelected = await checkbox.isSelected();
    
    if (!isSelected) {
      await checkbox.click();
    }
  }
  
  /**
   * Deseleccionar referencia por índice (uncheck)
   */
  async deseleccionarReferencia(index: number): Promise<void> {
    const checkbox = this.obtenerCheckboxPorIndice(index);
    const isSelected = await checkbox.isSelected();
    
    if (isSelected) {
      await checkbox.click();
    }
  }
  
  /**
   * Verificar si referencia está seleccionada
   */
  async estaSeleccionada(index: number): Promise<boolean> {
    const checkbox = this.obtenerCheckboxPorIndice(index);
    return await checkbox.isSelected();
  }
  
  /**
   * Obtener código de referencia por índice
   */
  async obtenerCodigoReferencia(index: number): Promise<string> {
    const card = this.obtenerReferenciaPorIndice(index);
    const codigoElement = card.element(by.css('.referencia-codigo'));
    return await codigoElement.getText();
  }
  
  /**
   * Obtener nombre de referencia por índice
   */
  async obtenerNombreReferencia(index: number): Promise<string> {
    const card = this.obtenerReferenciaPorIndice(index);
    const nombreElement = card.element(by.css('.referencia-nombre'));
    return await nombreElement.getText();
  }
  
  /**
   * Verificar si referencia es válida (icono check verde)
   */
  async esReferenciaValida(index: number): Promise<boolean> {
    const card = this.obtenerReferenciaPorIndice(index);
    const iconoValido = card.element(by.css('.validador-icono.valido'));
    return await iconoValido.isPresent();
  }
  
  /**
   * Verificar si referencia es inválida (icono X rojo)
   */
  async esReferenciaInvalida(index: number): Promise<boolean> {
    const card = this.obtenerReferenciaPorIndice(index);
    const iconoInvalido = card.element(by.css('.validador-icono.invalido'));
    return await iconoInvalido.isPresent();
  }
  
  /**
   * Click en botón "Ver Atributos" de una referencia
   */
  async clickVerAtributos(index: number): Promise<void> {
    const button = this.verAtributosButtons.get(index);
    await button.click();
    await browser.sleep(500); // Esperar a que se abra el modal
  }
  
  /**
   * Click en botón "Asignar Fecha Lanzamiento" (requiere al menos 1 seleccionada)
   */
  async clickAsignarFechaLanzamiento(): Promise<void> {
    await browser.wait(EC.elementToBeClickable(this.asignarFechaButton), this.defaultTimeout);
    await this.asignarFechaButton.click();
    await browser.sleep(500); // Esperar a que se abra el modal
  }
  
  /**
   * Verificar si botón "Asignar Fecha" está habilitado
   */
  async botonAsignarFechaHabilitado(): Promise<boolean> {
    return await this.asignarFechaButton.isEnabled();
  }
  
  /**
   * Obtener cantidad de referencias seleccionadas
   */
  async obtenerCantidadSeleccionadas(): Promise<number> {
    let count = 0;
    const total = await this.obtenerCantidadResultados();
    
    for (let i = 0; i < total; i++) {
      if (await this.estaSeleccionada(i)) {
        count++;
      }
    }
    
    return count;
  }
  
  /**
   * Seleccionar todas las referencias
   */
  async seleccionarTodas(): Promise<void> {
    const total = await this.obtenerCantidadResultados();
    
    for (let i = 0; i < total; i++) {
      await this.seleccionarReferencia(i);
    }
  }
  
  /**
   * Deseleccionar todas las referencias
   */
  async deseleccionarTodas(): Promise<void> {
    const total = await this.obtenerCantidadResultados();
    
    for (let i = 0; i < total; i++) {
      await this.deseleccionarReferencia(i);
    }
  }
  
  /**
   * Verificar si formulario está vacío
   */
  async formularioEstaVacio(): Promise<boolean> {
    const empresaValue = await this.empresaSelect.getAttribute('value');
    const referenciaValue = await this.referenciaInput.getAttribute('value');
    
    return !empresaValue || empresaValue === '' && (!referenciaValue || referenciaValue === '');
  }
  
  /**
   * Obtener valor del campo empresa
   */
  async obtenerEmpresaSeleccionada(): Promise<string> {
    return await this.empresaSelect.getAttribute('value');
  }
  
  /**
   * Obtener valor del campo año
   */
  async obtenerAnoSeleccionado(): Promise<string> {
    return await this.anoSelect.getAttribute('value');
  }
  
  /**
   * Obtener valor del campo colección
   */
  async obtenerColeccionSeleccionada(): Promise<string> {
    return await this.coleccionSelect.getAttribute('value');
  }
  
  /**
   * Obtener valor del campo referencia
   */
  async obtenerReferenciaIngresada(): Promise<string> {
    return await this.referenciaInput.getAttribute('value');
  }
}
