/**
 * Page Object para Modal de Fecha de Lanzamiento
 * 
 * Encapsula los selectores y acciones del modal de asignación de fecha.
 */

import { browser, by, element, ElementFinder, ExpectedConditions as EC } from 'protractor';

export class ModalFechaLanzamientoPage {
  
  // Timeout por defecto
  private readonly defaultTimeout = 10000;
  
  /**
   * Selectores del modal
   */
  private get modal(): ElementFinder {
    return element(by.css('elk-modal-fecha-lanzamiento-referencia .modal-content'));
  }
  
  private get modalHeader(): ElementFinder {
    return this.modal.element(by.css('.modal-header'));
  }
  
  private get modalBody(): ElementFinder {
    return this.modal.element(by.css('.modal-body'));
  }
  
  private get modalFooter(): ElementFinder {
    return this.modal.element(by.css('.modal-footer'));
  }
  
  private get tituloModal(): ElementFinder {
    return this.modalHeader.element(by.css('.modal-title'));
  }
  
  private get closeIcon(): ElementFinder {
    return this.modalHeader.element(by.css('button.close'));
  }
  
  /**
   * Selectores del formulario
   */
  private get fechaInput(): ElementFinder {
    return this.modalBody.element(by.css('input[type="date"]'));
  }
  
  private get listaCanales() {
    return this.modalBody.all(by.css('.canal-checkbox'));
  }
  
  private get contadorReferencias(): ElementFinder {
    return this.modalBody.element(by.css('.contador-referencias'));
  }
  
  /**
   * Selectores de botones
   */
  private get asignarButton(): ElementFinder {
    return this.modalFooter.element(by.buttonText('Asignar'));
  }
  
  private get cancelarButton(): ElementFinder {
    return this.modalFooter.element(by.buttonText('Cancelar'));
  }
  
  private get spinner(): ElementFinder {
    return this.modal.element(by.css('ngx-spinner'));
  }
  
  /**
   * Selectores de mensajes
   */
  private get mensajeError(): ElementFinder {
    return this.modalBody.element(by.css('.alert-danger'));
  }
  
  private get mensajeExito(): ElementFinder {
    return this.modalBody.element(by.css('.alert-success'));
  }
  
  /**
   * Esperar a que el modal esté visible
   */
  async esperarModalVisible(): Promise<void> {
    await browser.wait(EC.visibilityOf(this.modal), this.defaultTimeout);
    await browser.sleep(500);
  }
  
  /**
   * Verificar si el modal está visible
   */
  async estaVisible(): Promise<boolean> {
    return await this.modal.isPresent() && await this.modal.isDisplayed();
  }
  
  /**
   * Obtener título del modal
   */
  async obtenerTitulo(): Promise<string> {
    return await this.tituloModal.getText();
  }
  
  /**
   * Obtener cantidad de referencias a procesar
   */
  async obtenerCantidadReferencias(): Promise<number> {
    const texto = await this.contadorReferencias.getText();
    // Extraer número del texto, ej: "2 referencias seleccionadas" -> 2
    const match = texto.match(/(\d+)/);
    return match ? parseInt(match[1], 10) : 0;
  }
  
  /**
   * Ingresar fecha
   */
  async ingresarFecha(fecha: string): Promise<void> {
    await this.fechaInput.clear();
    await this.fechaInput.sendKeys(fecha);
  }
  
  /**
   * Obtener fecha ingresada
   */
  async obtenerFechaIngresada(): Promise<string> {
    return await this.fechaInput.getAttribute('value');
  }
  
  /**
   * Verificar si campo fecha está vacío
   */
  async fechaEstaVacia(): Promise<boolean> {
    const valor = await this.obtenerFechaIngresada();
    return !valor || valor === '';
  }
  
  /**
   * Obtener cantidad de canales disponibles
   */
  async obtenerCantidadCanales(): Promise<number> {
    return await this.listaCanales.count();
  }
  
  /**
   * Obtener checkbox de canal por índice
   */
  obtenerCheckboxCanalPorIndice(index: number): ElementFinder {
    return this.listaCanales.get(index).element(by.css('input[type="checkbox"]'));
  }
  
  /**
   * Obtener label de canal por índice
   */
  async obtenerNombreCanal(index: number): Promise<string> {
    const label = this.listaCanales.get(index).element(by.css('label'));
    return await label.getText();
  }
  
  /**
   * Seleccionar canal por índice
   */
  async seleccionarCanal(index: number): Promise<void> {
    const checkbox = this.obtenerCheckboxCanalPorIndice(index);
    const isSelected = await checkbox.isSelected();
    
    if (!isSelected) {
      await checkbox.click();
    }
  }
  
  /**
   * Deseleccionar canal por índice
   */
  async deseleccionarCanal(index: number): Promise<void> {
    const checkbox = this.obtenerCheckboxCanalPorIndice(index);
    const isSelected = await checkbox.isSelected();
    
    if (isSelected) {
      await checkbox.click();
    }
  }
  
  /**
   * Verificar si canal está seleccionado
   */
  async canalEstaSeleccionado(index: number): Promise<boolean> {
    const checkbox = this.obtenerCheckboxCanalPorIndice(index);
    return await checkbox.isSelected();
  }
  
  /**
   * Seleccionar todos los canales
   */
  async seleccionarTodosCanales(): Promise<void> {
    const total = await this.obtenerCantidadCanales();
    
    for (let i = 0; i < total; i++) {
      await this.seleccionarCanal(i);
    }
  }
  
  /**
   * Deseleccionar todos los canales
   */
  async deseleccionarTodosCanales(): Promise<void> {
    const total = await this.obtenerCantidadCanales();
    
    for (let i = 0; i < total; i++) {
      await this.deseleccionarCanal(i);
    }
  }
  
  /**
   * Obtener cantidad de canales seleccionados
   */
  async obtenerCantidadCanalesSeleccionados(): Promise<number> {
    let count = 0;
    const total = await this.obtenerCantidadCanales();
    
    for (let i = 0; i < total; i++) {
      if (await this.canalEstaSeleccionado(i)) {
        count++;
      }
    }
    
    return count;
  }
  
  /**
   * Verificar si botón Asignar está habilitado
   */
  async botonAsignarEstaHabilitado(): Promise<boolean> {
    return await this.asignarButton.isEnabled();
  }
  
  /**
   * Click en botón Asignar
   */
  async clickAsignar(): Promise<void> {
    await browser.wait(EC.elementToBeClickable(this.asignarButton), this.defaultTimeout);
    await this.asignarButton.click();
    await this.esperarProcesamiento();
  }
  
  /**
   * Click en botón Cancelar
   */
  async clickCancelar(): Promise<void> {
    await this.cancelarButton.click();
    await this.esperarModalCerrado();
  }
  
  /**
   * Cerrar modal con icono X
   */
  async cerrarConIcono(): Promise<void> {
    await this.closeIcon.click();
    await this.esperarModalCerrado();
  }
  
  /**
   * Esperar a que termine el procesamiento (spinner desaparezca)
   */
  async esperarProcesamiento(): Promise<void> {
    try {
      await browser.wait(EC.presenceOf(this.spinner), 2000);
      await browser.wait(EC.invisibilityOf(this.spinner), this.defaultTimeout);
    } catch (e) {
      // Si no hay spinner o ya desapareció, continuar
    }
    await browser.sleep(500);
  }
  
  /**
   * Esperar a que el modal se cierre
   */
  async esperarModalCerrado(): Promise<void> {
    await browser.wait(EC.invisibilityOf(this.modal), this.defaultTimeout);
    await browser.sleep(500);
  }
  
  /**
   * Verificar si se muestra mensaje de error
   */
  async seMuestraMensajeError(): Promise<boolean> {
    return await this.mensajeError.isPresent() && await this.mensajeError.isDisplayed();
  }
  
  /**
   * Obtener texto del mensaje de error
   */
  async obtenerTextoMensajeError(): Promise<string> {
    if (await this.seMuestraMensajeError()) {
      return await this.mensajeError.getText();
    }
    return '';
  }
  
  /**
   * Verificar si se muestra mensaje de éxito
   */
  async seMuestraMensajeExito(): Promise<boolean> {
    return await this.mensajeExito.isPresent() && await this.mensajeExito.isDisplayed();
  }
  
  /**
   * Obtener texto del mensaje de éxito
   */
  async obtenerTextoMensajeExito(): Promise<string> {
    if (await this.seMuestraMensajeExito()) {
      return await this.mensajeExito.getText();
    }
    return '';
  }
  
  /**
   * Validar formulario completo (fecha y al menos 1 canal)
   */
  async formularioEsValido(): Promise<boolean> {
    const fechaLlena = !(await this.fechaEstaVacia());
    const canalesSeleccionados = await this.obtenerCantidadCanalesSeleccionados();
    
    return fechaLlena && canalesSeleccionados > 0;
  }
  
  /**
   * Llenar formulario completo
   */
  async llenarFormulario(fecha: string, canalesIndices: number[]): Promise<void> {
    await this.ingresarFecha(fecha);
    
    for (const index of canalesIndices) {
      await this.seleccionarCanal(index);
    }
  }
  
  /**
   * Obtener fecha mínima permitida (atributo min del input)
   */
  async obtenerFechaMinima(): Promise<string> {
    return await this.fechaInput.getAttribute('min');
  }
  
  /**
   * Verificar si fecha es válida (posterior a hoy)
   */
  async fechaEsValida(fecha: string): Promise<boolean> {
    const hoy = new Date();
    hoy.setHours(0, 0, 0, 0);
    
    const fechaIngresada = new Date(fecha);
    fechaIngresada.setHours(0, 0, 0, 0);
    
    return fechaIngresada >= hoy;
  }
}
