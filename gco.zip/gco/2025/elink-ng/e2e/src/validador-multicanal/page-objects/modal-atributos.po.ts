/**
 * Page Object para Modal de Atributos de Referencia
 * 
 * Encapsula los selectores y acciones del modal de atributos.
 */

import { browser, by, element, ElementFinder, ExpectedConditions as EC } from 'protractor';

export class ModalAtributosReferenciaPage {
  
  // Timeout por defecto
  private readonly defaultTimeout = 10000;
  
  /**
   * Selectores del modal
   */
  private get modal(): ElementFinder {
    return element(by.css('elk-modal-atributos-referencia .modal-content'));
  }
  
  private get modalHeader(): ElementFinder {
    return this.modal.element(by.css('.modal-header'));
  }
  
  private get modalBody(): ElementFinder {
    return this.modal.element(by.css('.modal-body'));
  }
  
  private get modalFooter(): ElementFinder {
    return this.modal.element(by.css('.modal-footer'));
  }
  
  private get tituloModal(): ElementFinder {
    return this.modalHeader.element(by.css('.modal-title'));
  }
  
  private get codigoReferencia(): ElementFinder {
    return this.modalBody.element(by.css('.codigo-referencia'));
  }
  
  private get nombreReferencia(): ElementFinder {
    return this.modalBody.element(by.css('.nombre-referencia'));
  }
  
  private get cerrarButton(): ElementFinder {
    return this.modalFooter.element(by.buttonText('Cerrar'));
  }
  
  private get closeIcon(): ElementFinder {
    return this.modalHeader.element(by.css('button.close'));
  }
  
  /**
   * Selectores de sección de atributos
   */
  private get seccionAtributos(): ElementFinder {
    return this.modalBody.element(by.css('.seccion-atributos'));
  }
  
  private get listaAtributos() {
    return this.seccionAtributos.all(by.css('.atributo-item'));
  }
  
  /**
   * Selectores de sección de canales
   */
  private get seccionCanales(): ElementFinder {
    return this.modalBody.element(by.css('.seccion-canales'));
  }
  
  private get listaCanales() {
    return this.seccionCanales.all(by.css('.canal-badge'));
  }
  
  private get spinner(): ElementFinder {
    return this.modal.element(by.css('ngx-spinner'));
  }
  
  /**
   * Esperar a que el modal esté visible
   */
  async esperarModalVisible(): Promise<void> {
    await browser.wait(EC.visibilityOf(this.modal), this.defaultTimeout);
    await this.esperarCargaCompleta();
  }
  
  /**
   * Esperar a que termine la carga del modal
   */
  async esperarCargaCompleta(): Promise<void> {
    try {
      await browser.wait(EC.invisibilityOf(this.spinner), this.defaultTimeout);
    } catch (e) {
      // Si no hay spinner o ya desapareció, continuar
    }
    await browser.sleep(500);
  }
  
  /**
   * Verificar si el modal está visible
   */
  async estaVisible(): Promise<boolean> {
    return await this.modal.isPresent() && await this.modal.isDisplayed();
  }
  
  /**
   * Obtener título del modal
   */
  async obtenerTitulo(): Promise<string> {
    return await this.tituloModal.getText();
  }
  
  /**
   * Obtener código de referencia mostrado
   */
  async obtenerCodigoReferencia(): Promise<string> {
    return await this.codigoReferencia.getText();
  }
  
  /**
   * Obtener nombre de referencia mostrado
   */
  async obtenerNombreReferencia(): Promise<string> {
    return await this.nombreReferencia.getText();
  }
  
  /**
   * Obtener cantidad de atributos mostrados
   */
  async obtenerCantidadAtributos(): Promise<number> {
    return await this.listaAtributos.count();
  }
  
  /**
   * Obtener atributo por índice
   */
  obtenerAtributoPorIndice(index: number): ElementFinder {
    return this.listaAtributos.get(index);
  }
  
  /**
   * Obtener nombre de atributo por índice
   */
  async obtenerNombreAtributo(index: number): Promise<string> {
    const atributo = this.obtenerAtributoPorIndice(index);
    const nombreElement = atributo.element(by.css('.atributo-nombre'));
    return await nombreElement.getText();
  }
  
  /**
   * Verificar si atributo está OK (check verde)
   */
  async atributoEstaOk(index: number): Promise<boolean> {
    const atributo = this.obtenerAtributoPorIndice(index);
    const iconoOk = atributo.element(by.css('.fa-check-circle'));
    return await iconoOk.isPresent();
  }
  
  /**
   * Verificar si atributo tiene error (X rojo)
   */
  async atributoTieneError(index: number): Promise<boolean> {
    const atributo = this.obtenerAtributoPorIndice(index);
    const iconoError = atributo.element(by.css('.fa-times-circle'));
    return await iconoError.isPresent();
  }
  
  /**
   * Obtener valor de atributo por índice
   */
  async obtenerValorAtributo(index: number): Promise<string> {
    const atributo = this.obtenerAtributoPorIndice(index);
    const valorElement = atributo.element(by.css('.atributo-valor'));
    return await valorElement.getText();
  }
  
  /**
   * Obtener cantidad de canales mostrados
   */
  async obtenerCantidadCanales(): Promise<number> {
    return await this.listaCanales.count();
  }
  
  /**
   * Obtener canal por índice
   */
  obtenerCanalPorIndice(index: number): ElementFinder {
    return this.listaCanales.get(index);
  }
  
  /**
   * Obtener nombre de canal por índice
   */
  async obtenerNombreCanal(index: number): Promise<string> {
    const canal = this.obtenerCanalPorIndice(index);
    return await canal.getText();
  }
  
  /**
   * Verificar si canal está completo (badge verde)
   */
  async canalEstaCompleto(index: number): Promise<boolean> {
    const canal = this.obtenerCanalPorIndice(index);
    const classes = await canal.getAttribute('class');
    return classes.includes('badge-success');
  }
  
  /**
   * Verificar si canal tiene faltantes (badge rojo con count)
   */
  async canalTieneFaltantes(index: number): Promise<boolean> {
    const canal = this.obtenerCanalPorIndice(index);
    const classes = await canal.getAttribute('class');
    return classes.includes('badge-danger');
  }
  
  /**
   * Obtener cantidad de atributos faltantes en un canal (del badge)
   */
  async obtenerCantidadFaltantesCanal(index: number): Promise<number> {
    const canal = this.obtenerCanalPorIndice(index);
    const badge = canal.element(by.css('.badge'));
    
    try {
      const text = await badge.getText();
      return parseInt(text, 10) || 0;
    } catch (e) {
      return 0;
    }
  }
  
  /**
   * Hacer hover sobre un canal (para ver tooltip)
   */
  async hoverSobreCanal(index: number): Promise<void> {
    const canal = this.obtenerCanalPorIndice(index);
    await browser.actions().mouseMove(canal).perform();
    await browser.sleep(500); // Esperar a que aparezca el tooltip
  }
  
  /**
   * Obtener texto del tooltip (requiere hover previo)
   */
  async obtenerTextoTooltip(): Promise<string> {
    const tooltip = element(by.css('.tooltip-inner'));
    await browser.wait(EC.visibilityOf(tooltip), 3000);
    return await tooltip.getText();
  }
  
  /**
   * Cerrar modal con botón
   */
  async cerrarConBoton(): Promise<void> {
    await this.cerrarButton.click();
    await this.esperarModalCerrado();
  }
  
  /**
   * Cerrar modal con icono X
   */
  async cerrarConIcono(): Promise<void> {
    await this.closeIcon.click();
    await this.esperarModalCerrado();
  }
  
  /**
   * Esperar a que el modal se cierre
   */
  async esperarModalCerrado(): Promise<void> {
    await browser.wait(EC.invisibilityOf(this.modal), this.defaultTimeout);
    await browser.sleep(500);
  }
  
  /**
   * Contar atributos OK
   */
  async contarAtributosOk(): Promise<number> {
    let count = 0;
    const total = await this.obtenerCantidadAtributos();
    
    for (let i = 0; i < total; i++) {
      if (await this.atributoEstaOk(i)) {
        count++;
      }
    }
    
    return count;
  }
  
  /**
   * Contar atributos con error
   */
  async contarAtributosConError(): Promise<number> {
    let count = 0;
    const total = await this.obtenerCantidadAtributos();
    
    for (let i = 0; i < total; i++) {
      if (await this.atributoTieneError(i)) {
        count++;
      }
    }
    
    return count;
  }
  
  /**
   * Contar canales completos
   */
  async contarCanalesCompletos(): Promise<number> {
    let count = 0;
    const total = await this.obtenerCantidadCanales();
    
    for (let i = 0; i < total; i++) {
      if (await this.canalEstaCompleto(i)) {
        count++;
      }
    }
    
    return count;
  }
  
  /**
   * Contar canales con faltantes
   */
  async contarCanalesConFaltantes(): Promise<number> {
    let count = 0;
    const total = await this.obtenerCantidadCanales();
    
    for (let i = 0; i < total; i++) {
      if (await this.canalTieneFaltantes(i)) {
        count++;
      }
    }
    
    return count;
  }
}
