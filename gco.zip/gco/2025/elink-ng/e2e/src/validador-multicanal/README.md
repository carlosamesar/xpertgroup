# Pruebas E2E - Validador Multicanal

## 📋 Descripción

Suite de pruebas end-to-end (E2E) para el módulo **Validador Multicanal** del sistema Elink. Estas pruebas utilizan **Protractor** y el patrón **Page Object Model** para validar la funcionalidad completa del módulo con datos mock antes de la integración con el backend real.

---

## 🎯 Objetivo

Certificar que la implementación del módulo Validador Multicanal funciona correctamente sin depender de datos reales, permitiendo:

- ✅ Validación de flujos de usuario completos
- ✅ Detección temprana de bugs de UI
- ✅ Desarrollo paralelo frontend/backend
- ✅ Ejecución rápida y confiable de pruebas
- ✅ Documentación viva de casos de uso

---

## 📁 Estructura de Archivos

```
e2e/
├── src/
│   ├── validador-multicanal/
│   │   ├── buscar-referencia.e2e-spec.ts       # Pruebas de búsqueda
│   │   ├── modal-atributos.e2e-spec.ts         # Pruebas de modal atributos
│   │   ├── modal-fecha-lanzamiento.e2e-spec.ts # Pruebas de modal fecha
│   │   ├── flujo-completo.e2e-spec.ts          # Flujos completos E2E
│   │   └── page-objects/
│   │       ├── buscar-referencia.po.ts         # Page Object: Búsqueda
│   │       ├── modal-atributos.po.ts           # Page Object: Modal Atributos
│   │       └── modal-fecha-lanzamiento.po.ts   # Page Object: Modal Fecha
│   └── mocks/
│       └── referencia-mock.data.ts             # Datos mock
└── protractor.conf.js                          # Configuración Protractor
```

---

## 🚀 Configuración Inicial

### 1. Instalar Dependencias

```powershell
cd c:\resources\xpert\gco\2025\elink-ng
npm install
```

### 2. Configurar Mock Service

Editar `src/app/app.module.ts` para usar el mock service en pruebas:

```typescript
import { ValidadorReferenciaService } from './shared/service/validador-referencia.service';
import { ValidadorReferenciaMockService } from './shared/service/validador-referencia.service.mock';

// En providers:
providers: [
  // En modo de pruebas, usar mock
  {
    provide: ValidadorReferenciaService,
    useClass: environment.useMocks ? ValidadorReferenciaMockService : ValidadorReferenciaService
  }
]
```

### 3. Configurar Environment para Testing

Editar `src/environments/environment.ts`:

```typescript
export const environment = {
  // ... configuración existente
  useMocks: true  // ← Agregar este flag
};
```

### 4. Actualizar WebDriver

```powershell
node_modules\.bin\webdriver-manager update
```

---

## ▶️ Ejecución de Pruebas

### Ejecutar Todas las Pruebas E2E

```powershell
npm run e2e
```

### Ejecutar Suite Específica

```powershell
# Solo pruebas de búsqueda
ng e2e --specs='e2e/src/validador-multicanal/buscar-referencia.e2e-spec.ts'

# Solo pruebas de modal de atributos
ng e2e --specs='e2e/src/validador-multicanal/modal-atributos.e2e-spec.ts'

# Solo pruebas de modal de fecha
ng e2e --specs='e2e/src/validador-multicanal/modal-fecha-lanzamiento.e2e-spec.ts'

# Solo flujos completos
ng e2e --specs='e2e/src/validador-multicanal/flujo-completo.e2e-spec.ts'

# Todas las pruebas del validador
ng e2e --specs='e2e/src/validador-multicanal/**/*.e2e-spec.ts'
```

### Modo Headless (CI/CD)

Para ejecutar sin abrir el navegador:

```powershell
ng e2e --protractor-config=e2e/protractor-ci.conf.js
```

Crear `e2e/protractor-ci.conf.js`:

```javascript
const config = require('./protractor.conf').config;

config.capabilities = {
  browserName: 'chrome',
  chromeOptions: {
    args: ['--headless', '--disable-gpu', '--window-size=1920,1080']
  }
};

exports.config = config;
```

---

## 📊 Casos de Prueba Incluidos

### Búsqueda de Referencias (buscar-referencia.e2e-spec.ts)

| ID | Descripción | Estado |
|----|-------------|--------|
| E2E-BR-001 | Búsqueda exitosa con referencia completa | ✅ |
| E2E-BR-002 | Búsqueda con referencia incompleta | ✅ |
| E2E-BR-003 | Búsqueda sin resultados | ✅ |
| E2E-BR-004 | Validación de campos obligatorios | ✅ |
| E2E-BR-005 | Filtro por año y colección | ✅ |
| E2E-BR-006 | Selección múltiple de referencias | ✅ |
| E2E-BR-007 | Deselección de referencias | ✅ |
| E2E-BR-008 | Validación visual de iconos | ✅ |

**Total: 15 specs**

### Modal de Atributos (modal-atributos.e2e-spec.ts)

| ID | Descripción | Estado |
|----|-------------|--------|
| E2E-MA-001 | Abrir modal desde referencia completa | ✅ |
| E2E-MA-002 | Abrir modal desde referencia incompleta | ✅ |
| E2E-MA-003 | Visualizar atributos con estado OK | ✅ |
| E2E-MA-004 | Visualizar atributos con estado Error | ✅ |
| E2E-MA-005 | Visualizar canales completos (verde) | ✅ |
| E2E-MA-006 | Visualizar canales con faltantes (rojo) | ✅ |
| E2E-MA-007 | Tooltip de atributos faltantes | ✅ |
| E2E-MA-008 | Cerrar modal correctamente | ✅ |

**Total: 13 specs**

### Modal de Fecha de Lanzamiento (modal-fecha-lanzamiento.e2e-spec.ts)

| ID | Descripción | Estado |
|----|-------------|--------|
| E2E-MF-001 | Abrir modal con 1 referencia | ✅ |
| E2E-MF-002 | Abrir modal con múltiples referencias | ✅ |
| E2E-MF-003 | Seleccionar fecha válida | ✅ |
| E2E-MF-004 | Seleccionar múltiples canales | ✅ |
| E2E-MF-005 | Validación sin fecha | ✅ |
| E2E-MF-006 | Validación sin canales | ✅ |
| E2E-MF-007 | Asignación exitosa | ✅ |
| E2E-MF-008 | Cancelar asignación | ✅ |
| E2E-MF-009 | Manejo de error del servidor | ✅ |

**Total: 21 specs**

### Flujos Completos (flujo-completo.e2e-spec.ts)

| ID | Descripción | Estado |
|----|-------------|--------|
| E2E-FC-001 | Flujo completo usuario feliz | ✅ |
| E2E-FC-002 | Búsqueda → Ver atributos → Cerrar | ✅ |
| E2E-FC-003 | Búsqueda → Asignar fecha → Éxito | ✅ |
| E2E-FC-004 | Validar persistencia de selección | ✅ |
| E2E-FC-005 | Navegación entre modales | ✅ |

**Total: 9 specs**

---

## 📈 Resultados Esperados

### Métricas de Éxito

- ✅ **Cobertura E2E**: 100% de los flujos principales
- ✅ **Tasa de éxito**: 100% de las pruebas pasan
- ✅ **Tiempo de ejecución**: ≤ 5 minutos para suite completa
- ✅ **Falsos positivos**: 0%

### Resumen de Cobertura

```
Total de specs: 58
Suites: 4
  - Búsqueda: 15 specs
  - Modal Atributos: 13 specs
  - Modal Fecha: 21 specs
  - Flujos Completos: 9 specs
```

---

## 🔧 Troubleshooting

### Problema: Protractor no encuentra elementos

**Causa**: Selectores incorrectos o tiempos de espera insuficientes.

**Solución**:

```typescript
// Usar waits explícitos
await browser.wait(EC.presenceOf(element), 10000);

// Aumentar timeout en protractor.conf.js
jasmineodenTimeout: 60000
```

### Problema: Pruebas intermitentes (flaky tests)

**Causa**: Dependencia de timings con `sleep()`.

**Solución**:

```typescript
// ❌ Evitar
await browser.sleep(2000);

// ✅ Usar
await browser.wait(EC.visibilityOf(element), 10000);
```

### Problema: Mock service no se activa

**Causa**: Environment flag no configurado.

**Solución**:

```typescript
// src/environments/environment.ts
export const environment = {
  useMocks: true  // ← Verificar este flag
};
```

### Problema: Errores de TypeScript en specs

**Causa**: Page Objects no compilados correctamente.

**Solución**:

```powershell
# Limpiar y recompilar
rm -rf dist/
ng build
npm run e2e
```

---

## 📝 Convenciones de Escritura

### Nomenclatura de Specs

```typescript
describe('Módulo - Funcionalidad', () => {
  it('E2E-XX-001: Debe realizar acción esperada', async () => {
    // Arrange
    // Act
    // Assert
  });
});
```

### Patrón AAA (Arrange-Act-Assert)

```typescript
it('Debe buscar referencias correctamente', async () => {
  // Arrange: Preparar datos y estado
  await buscarPage.llenarFormularioBusqueda({ empresa: 'IC' });
  
  // Act: Ejecutar acción
  await buscarPage.clickBuscar();
  
  // Assert: Verificar resultado
  expect(await buscarPage.hayResultados()).toBe(true);
});
```

### Selectores CSS Recomendados

```typescript
// ✅ Bueno: IDs y clases específicas
by.css('#buscar-btn')
by.css('.referencia-card')

// ✅ Bueno: Atributos data-*
by.css('[data-test="buscar-btn"]')

// ❌ Evitar: Selectores frágiles
by.css('div > div > button')
by.xpath('//div[3]/button[1]')
```

---

## 🔄 Integración Continua (CI/CD)

### GitHub Actions Example

```yaml
name: E2E Tests

on: [push, pull_request]

jobs:
  e2e:
    runs-on: windows-latest
    
    steps:
      - uses: actions/checkout@v2
      
      - name: Setup Node.js
        uses: actions/setup-node@v2
        with:
          node-version: '12'
      
      - name: Install dependencies
        run: npm ci
      
      - name: Run E2E tests
        run: npm run e2e -- --protractor-config=e2e/protractor-ci.conf.js
      
      - name: Upload screenshots on failure
        if: failure()
        uses: actions/upload-artifact@v2
        with:
          name: e2e-screenshots
          path: e2e/screenshots/
```

---

## 📚 Referencias

- [Protractor Documentation](https://www.protractortest.org/)
- [Page Object Pattern](https://www.protractortest.org/#/page-objects)
- [Angular Testing Guide](https://angular.io/guide/testing)
- [Jasmine Framework](https://jasmine.github.io/)

---

## 🤝 Contribución

Para agregar nuevas pruebas:

1. Crear el spec en `e2e/src/validador-multicanal/`
2. Seguir el patrón Page Object Model
3. Usar naming convention: `E2E-XX-###`
4. Documentar el caso en este README
5. Ejecutar la suite completa antes de commit

---

## 📞 Soporte

Para dudas o problemas:

- **Equipo de QA**: qa@gco.com
- **Tech Lead**: techlead@gco.com
- **Documentación**: Ver `PLAN_PRUEBAS_E2E_VALIDADOR_MULTICANAL.md`

---

**Última actualización**: Noviembre 2025  
**Versión**: 1.0  
**Mantenedor**: Equipo de Desarrollo Elink
