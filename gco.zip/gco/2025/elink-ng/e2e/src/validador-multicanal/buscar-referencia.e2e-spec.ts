/**
 * E2E Tests - Búsqueda de Referencias
 * 
 * Suite de pruebas end-to-end para la funcionalidad de búsqueda de referencias
 * del módulo Validador Multicanal.
 */

import { browser } from 'protractor';
import { BuscarReferenciaPage } from './page-objects/buscar-referencia.po';

describe('Validador Multicanal - Búsqueda de Referencias', () => {
  let page: BuscarReferenciaPage;
  
  beforeEach(async () => {
    page = new BuscarReferenciaPage();
    await page.navigateTo();
  });
  
  afterEach(async () => {
    // Limpiar el formulario después de cada prueba
    try {
      await page.clickLimpiar();
    } catch (e) {
      // Si falla, continuar
    }
  });
  
  describe('Carga Inicial', () => {
    
    it('E2E-BR-000: Debe cargar la página correctamente', async () => {
      // Verificar que los elementos principales estén presentes
      expect(await page.obtenerEmpresaSeleccionada()).toBeDefined();
      expect(await page.formularioEstaVacio()).toBe(true);
    });
    
    it('E2E-BR-000-B: Debe tener los selectores visibles', async () => {
      // Verificar que se puedan obtener valores de los campos
      const empresa = await page.obtenerEmpresaSeleccionada();
      const ano = await page.obtenerAnoSeleccionado();
      const coleccion = await page.obtenerColeccionSeleccionada();
      
      expect(empresa).toBeDefined();
      expect(ano).toBeDefined();
      expect(coleccion).toBeDefined();
    });
    
  });
  
  describe('E2E-BR-001: Búsqueda exitosa con referencia completa', () => {
    
    it('Debe encontrar referencias cuando se busca solo por empresa', async () => {
      // Arrange
      await page.llenarFormularioBusqueda({ empresa: 'IC' });
      
      // Act
      await page.clickBuscar();
      
      // Assert
      expect(await page.hayResultados()).toBe(true);
      const cantidad = await page.obtenerCantidadResultados();
      expect(cantidad).toBeGreaterThan(0);
    });
    
    it('Debe mostrar los datos correctos de cada referencia', async () => {
      // Arrange
      await page.llenarFormularioBusqueda({ empresa: 'IC' });
      await page.clickBuscar();
      
      // Act
      const codigo = await page.obtenerCodigoReferencia(0);
      const nombre = await page.obtenerNombreReferencia(0);
      
      // Assert
      expect(codigo).toBeTruthy();
      expect(nombre).toBeTruthy();
      expect(codigo.length).toBeGreaterThan(0);
      expect(nombre.length).toBeGreaterThan(0);
    });
    
    it('Debe mostrar icono de validación correcto para referencias completas', async () => {
      // Arrange
      await page.llenarFormularioBusqueda({ empresa: 'IC' });
      await page.clickBuscar();
      
      // Act - Buscar la primera referencia válida
      const cantidad = await page.obtenerCantidadResultados();
      let encontroValida = false;
      
      for (let i = 0; i < cantidad; i++) {
        if (await page.esReferenciaValida(i)) {
          encontroValida = true;
          break;
        }
      }
      
      // Assert
      expect(encontroValida).toBe(true);
    });
    
  });
  
  describe('E2E-BR-002: Búsqueda con referencia incompleta', () => {
    
    it('Debe mostrar icono de error para referencias incompletas', async () => {
      // Arrange
      await page.llenarFormularioBusqueda({ empresa: 'IC' });
      await page.clickBuscar();
      
      // Act - Buscar la primera referencia inválida
      const cantidad = await page.obtenerCantidadResultados();
      let encontroInvalida = false;
      
      for (let i = 0; i < cantidad; i++) {
        if (await page.esReferenciaInvalida(i)) {
          encontroInvalida = true;
          break;
        }
      }
      
      // Assert
      expect(encontroInvalida).toBe(true);
    });
    
  });
  
  describe('E2E-BR-003: Búsqueda sin resultados', () => {
    
    it('Debe mostrar mensaje cuando no hay resultados', async () => {
      // Arrange
      await page.llenarFormularioBusqueda({
        empresa: 'IC',
        referencia: 'NOEXISTE999'
      });
      
      // Act
      await page.clickBuscar();
      
      // Assert
      expect(await page.hayResultados()).toBe(false);
      expect(await page.seMuestraSinResultados()).toBe(true);
    });
    
  });
  
  describe('E2E-BR-004: Validación de campos obligatorios', () => {
    
    it('Debe requerir empresa para buscar', async () => {
      // Arrange - No llenar empresa
      await page.ingresarReferencia('11659150');
      
      // Act & Assert
      // El botón buscar debería estar deshabilitado o mostrar error
      // (esto depende de la implementación del componente)
      const formularioValido = !(await page.formularioEstaVacio());
      expect(formularioValido).toBe(false);
    });
    
  });
  
  describe('E2E-BR-005: Filtro por año y colección', () => {
    
    it('Debe filtrar por año correctamente', async () => {
      // Arrange
      await page.llenarFormularioBusqueda({
        empresa: 'IC',
        ano: 2024
      });
      
      // Act
      await page.clickBuscar();
      
      // Assert
      expect(await page.hayResultados()).toBe(true);
    });
    
    it('Debe filtrar por colección correctamente', async () => {
      // Arrange
      await page.llenarFormularioBusqueda({
        empresa: 'IC',
        ano: 2024,
        coleccion: '01'
      });
      
      // Act
      await page.clickBuscar();
      
      // Assert
      expect(await page.hayResultados()).toBe(true);
    });
    
    it('Debe filtrar por referencia específica', async () => {
      // Arrange
      await page.llenarFormularioBusqueda({
        empresa: 'IC',
        referencia: '11659150'
      });
      
      // Act
      await page.clickBuscar();
      
      // Assert
      if (await page.hayResultados()) {
        const codigo = await page.obtenerCodigoReferencia(0);
        expect(codigo).toContain('11659150');
      }
    });
    
  });
  
  describe('E2E-BR-006: Selección múltiple de referencias', () => {
    
    it('Debe permitir seleccionar una referencia', async () => {
      // Arrange
      await page.llenarFormularioBusqueda({ empresa: 'IC' });
      await page.clickBuscar();
      
      // Act
      await page.seleccionarReferencia(0);
      
      // Assert
      expect(await page.estaSeleccionada(0)).toBe(true);
    });
    
    it('Debe permitir seleccionar múltiples referencias', async () => {
      // Arrange
      await page.llenarFormularioBusqueda({ empresa: 'IC' });
      await page.clickBuscar();
      const cantidad = await page.obtenerCantidadResultados();
      
      if (cantidad >= 2) {
        // Act
        await page.seleccionarReferencia(0);
        await page.seleccionarReferencia(1);
        
        // Assert
        expect(await page.estaSeleccionada(0)).toBe(true);
        expect(await page.estaSeleccionada(1)).toBe(true);
        expect(await page.obtenerCantidadSeleccionadas()).toBe(2);
      }
    });
    
    it('Debe actualizar el conteo de referencias seleccionadas', async () => {
      // Arrange
      await page.llenarFormularioBusqueda({ empresa: 'IC' });
      await page.clickBuscar();
      
      // Act
      await page.seleccionarReferencia(0);
      const seleccionadas = await page.obtenerCantidadSeleccionadas();
      
      // Assert
      expect(seleccionadas).toBe(1);
    });
    
    it('Debe habilitar botón "Asignar Fecha" cuando hay seleccionadas', async () => {
      // Arrange
      await page.llenarFormularioBusqueda({ empresa: 'IC' });
      await page.clickBuscar();
      
      // Act
      await page.seleccionarReferencia(0);
      
      // Assert
      expect(await page.botonAsignarFechaHabilitado()).toBe(true);
    });
    
  });
  
  describe('E2E-BR-007: Deselección de referencias', () => {
    
    it('Debe permitir deseleccionar una referencia', async () => {
      // Arrange
      await page.llenarFormularioBusqueda({ empresa: 'IC' });
      await page.clickBuscar();
      await page.seleccionarReferencia(0);
      expect(await page.estaSeleccionada(0)).toBe(true);
      
      // Act
      await page.deseleccionarReferencia(0);
      
      // Assert
      expect(await page.estaSeleccionada(0)).toBe(false);
    });
    
    it('Debe actualizar el conteo al deseleccionar', async () => {
      // Arrange
      await page.llenarFormularioBusqueda({ empresa: 'IC' });
      await page.clickBuscar();
      await page.seleccionarReferencia(0);
      
      // Act
      await page.deseleccionarReferencia(0);
      const seleccionadas = await page.obtenerCantidadSeleccionadas();
      
      // Assert
      expect(seleccionadas).toBe(0);
    });
    
  });
  
  describe('E2E-BR-008: Validación visual de iconos', () => {
    
    it('Debe mostrar check verde para referencias válidas', async () => {
      // Arrange
      await page.llenarFormularioBusqueda({ empresa: 'IC' });
      await page.clickBuscar();
      
      // Act & Assert
      const cantidad = await page.obtenerCantidadResultados();
      
      for (let i = 0; i < cantidad; i++) {
        const esValida = await page.esReferenciaValida(i);
        const esInvalida = await page.esReferenciaInvalida(i);
        
        // Debe tener uno u otro, no ambos
        expect(esValida || esInvalida).toBe(true);
        expect(esValida && esInvalida).toBe(false);
      }
    });
    
  });
  
  describe('Funcionalidad Limpiar', () => {
    
    it('Debe limpiar el formulario correctamente', async () => {
      // Arrange
      await page.llenarFormularioBusqueda({
        empresa: 'IC',
        ano: 2024,
        coleccion: '01',
        referencia: '11659150'
      });
      
      // Act
      await page.clickLimpiar();
      
      // Assert
      expect(await page.formularioEstaVacio()).toBe(true);
      expect(await page.hayResultados()).toBe(false);
    });
    
    it('Debe limpiar las selecciones', async () => {
      // Arrange
      await page.llenarFormularioBusqueda({ empresa: 'IC' });
      await page.clickBuscar();
      await page.seleccionarReferencia(0);
      
      // Act
      await page.clickLimpiar();
      await page.llenarFormularioBusqueda({ empresa: 'IC' });
      await page.clickBuscar();
      
      // Assert
      expect(await page.obtenerCantidadSeleccionadas()).toBe(0);
    });
    
  });
  
  describe('Spinner de Carga', () => {
    
    it('Debe mostrar y ocultar spinner durante la búsqueda', async () => {
      // Arrange
      await page.llenarFormularioBusqueda({ empresa: 'IC' });
      
      // Act
      await page.clickBuscar();
      // El método clickBuscar ya espera a que termine la carga
      
      // Assert
      // Si llegamos aquí sin timeout, el spinner funcionó correctamente
      expect(await page.hayResultados()).toBe(true);
    });
    
  });
  
});
