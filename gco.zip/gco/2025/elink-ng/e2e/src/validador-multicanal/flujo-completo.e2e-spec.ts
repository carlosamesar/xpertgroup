/**
 * E2E Tests - Flujo Completo Usuario
 * 
 * Suite de pruebas que validan los flujos completos de usuario del inicio al fin,
 * simulando los casos de uso reales del módulo Validador Multicanal.
 */

import { browser } from 'protractor';
import { BuscarReferenciaPage } from './page-objects/buscar-referencia.po';
import { ModalAtributosReferenciaPage } from './page-objects/modal-atributos.po';
import { ModalFechaLanzamientoPage } from './page-objects/modal-fecha-lanzamiento.po';

describe('Validador Multicanal - Flujos Completos', () => {
  let buscarPage: BuscarReferenciaPage;
  let modalAtributosPage: ModalAtributosReferenciaPage;
  let modalFechaPage: ModalFechaLanzamientoPage;
  
  beforeEach(async () => {
    buscarPage = new BuscarReferenciaPage();
    modalAtributosPage = new ModalAtributosReferenciaPage();
    modalFechaPage = new ModalFechaLanzamientoPage();
    
    await buscarPage.navigateTo();
  });
  
  describe('E2E-FC-001: Flujo completo usuario feliz', () => {
    
    it('Debe completar el flujo: Buscar → Ver Atributos → Seleccionar → Asignar Fecha', async () => {
      // 1. Buscar referencias
      await buscarPage.llenarFormularioBusqueda({ empresa: 'IC' });
      await buscarPage.clickBuscar();
      
      expect(await buscarPage.hayResultados()).toBe(true);
      
      // 2. Ver atributos de la primera referencia
      await buscarPage.clickVerAtributos(0);
      await modalAtributosPage.esperarModalVisible();
      
      expect(await modalAtributosPage.estaVisible()).toBe(true);
      expect(await modalAtributosPage.obtenerCantidadAtributos()).toBeGreaterThan(0);
      
      await modalAtributosPage.cerrarConBoton();
      
      // 3. Seleccionar referencias
      await buscarPage.seleccionarReferencia(0);
      
      if (await buscarPage.obtenerCantidadResultados() >= 2) {
        await buscarPage.seleccionarReferencia(1);
      }
      
      expect(await buscarPage.obtenerCantidadSeleccionadas()).toBeGreaterThanOrEqual(1);
      
      // 4. Asignar fecha de lanzamiento
      await buscarPage.clickAsignarFechaLanzamiento();
      await modalFechaPage.esperarModalVisible();
      
      expect(await modalFechaPage.estaVisible()).toBe(true);
      
      // 5. Llenar formulario de fecha
      const fechaFutura = new Date();
      fechaFutura.setDate(fechaFutura.getDate() + 15);
      const fechaStr = fechaFutura.toISOString().split('T')[0];
      
      await modalFechaPage.llenarFormulario(fechaStr, [0]);
      
      expect(await modalFechaPage.formularioEsValido()).toBe(true);
      
      // 6. Confirmar asignación
      await modalFechaPage.clickAsignar();
      
      // Verificar que el modal se cierra tras éxito
      expect(await modalFechaPage.estaVisible()).toBe(false);
    });
    
  });
  
  describe('E2E-FC-002: Flujo Búsqueda → Ver Atributos → Cerrar', () => {
    
    it('Debe permitir ver atributos de múltiples referencias secuencialmente', async () => {
      // 1. Buscar
      await buscarPage.llenarFormularioBusqueda({ empresa: 'IC' });
      await buscarPage.clickBuscar();
      
      const cantidadResultados = await buscarPage.obtenerCantidadResultados();
      expect(cantidadResultados).toBeGreaterThan(0);
      
      const iteraciones = Math.min(3, cantidadResultados);
      
      // 2. Ver atributos de varias referencias
      for (let i = 0; i < iteraciones; i++) {
        await buscarPage.clickVerAtributos(i);
        await modalAtributosPage.esperarModalVisible();
        
        expect(await modalAtributosPage.estaVisible()).toBe(true);
        
        const codigo = await modalAtributosPage.obtenerCodigoReferencia();
        expect(codigo).toBeTruthy();
        
        await modalAtributosPage.cerrarConBoton();
        expect(await modalAtributosPage.estaVisible()).toBe(false);
      }
      
      // 3. Verificar que los resultados siguen ahí
      expect(await buscarPage.obtenerCantidadResultados()).toBe(cantidadResultados);
    });
    
  });
  
  describe('E2E-FC-003: Flujo Búsqueda → Asignar Fecha → Éxito', () => {
    
    it('Debe permitir asignar fecha sin ver atributos previos', async () => {
      // 1. Buscar
      await buscarPage.llenarFormularioBusqueda({ empresa: 'IC' });
      await buscarPage.clickBuscar();
      
      expect(await buscarPage.hayResultados()).toBe(true);
      
      // 2. Seleccionar referencias directamente
      await buscarPage.seleccionarReferencia(0);
      
      // 3. Ir directo a asignar fecha
      await buscarPage.clickAsignarFechaLanzamiento();
      await modalFechaPage.esperarModalVisible();
      
      // 4. Completar formulario
      const fechaFutura = new Date();
      fechaFutura.setDate(fechaFutura.getDate() + 20);
      const fechaStr = fechaFutura.toISOString().split('T')[0];
      
      await modalFechaPage.llenarFormulario(fechaStr, [0]);
      
      // 5. Asignar
      await modalFechaPage.clickAsignar();
      
      expect(await modalFechaPage.estaVisible()).toBe(false);
    });
    
  });
  
  describe('E2E-FC-004: Validar persistencia de selección', () => {
    
    it('Debe mantener las selecciones después de ver atributos', async () => {
      // 1. Buscar
      await buscarPage.llenarFormularioBusqueda({ empresa: 'IC' });
      await buscarPage.clickBuscar();
      
      // 2. Seleccionar referencia
      await buscarPage.seleccionarReferencia(0);
      expect(await buscarPage.estaSeleccionada(0)).toBe(true);
      
      // 3. Abrir modal de atributos
      await buscarPage.clickVerAtributos(0);
      await modalAtributosPage.esperarModalVisible();
      await modalAtributosPage.cerrarConBoton();
      
      // 4. Verificar que sigue seleccionada
      expect(await buscarPage.estaSeleccionada(0)).toBe(true);
    });
    
    it('Debe mantener las selecciones después de cancelar asignación de fecha', async () => {
      // 1. Buscar y seleccionar
      await buscarPage.llenarFormularioBusqueda({ empresa: 'IC' });
      await buscarPage.clickBuscar();
      await buscarPage.seleccionarReferencia(0);
      
      const seleccionadasAntes = await buscarPage.obtenerCantidadSeleccionadas();
      
      // 2. Abrir modal de fecha y cancelar
      await buscarPage.clickAsignarFechaLanzamiento();
      await modalFechaPage.esperarModalVisible();
      await modalFechaPage.clickCancelar();
      
      // 3. Verificar que las selecciones persisten
      const seleccionadasDespues = await buscarPage.obtenerCantidadSeleccionadas();
      expect(seleccionadasDespues).toBe(seleccionadasAntes);
    });
    
  });
  
  describe('E2E-FC-005: Navegación entre modales', () => {
    
    it('Debe permitir cerrar modal de atributos y abrir modal de fecha', async () => {
      // 1. Buscar
      await buscarPage.llenarFormularioBusqueda({ empresa: 'IC' });
      await buscarPage.clickBuscar();
      
      // 2. Ver atributos
      await buscarPage.clickVerAtributos(0);
      await modalAtributosPage.esperarModalVisible();
      expect(await modalAtributosPage.estaVisible()).toBe(true);
      
      // 3. Cerrar modal de atributos
      await modalAtributosPage.cerrarConBoton();
      expect(await modalAtributosPage.estaVisible()).toBe(false);
      
      // 4. Seleccionar y abrir modal de fecha
      await buscarPage.seleccionarReferencia(0);
      await buscarPage.clickAsignarFechaLanzamiento();
      await modalFechaPage.esperarModalVisible();
      
      expect(await modalFechaPage.estaVisible()).toBe(true);
    });
    
  });
  
  describe('Flujo con Filtros Avanzados', () => {
    
    it('Debe funcionar con filtros de año y colección', async () => {
      // 1. Buscar con filtros específicos
      await buscarPage.llenarFormularioBusqueda({
        empresa: 'IC',
        ano: 2024,
        coleccion: '01'
      });
      
      await buscarPage.clickBuscar();
      
      if (await buscarPage.hayResultados()) {
        // 2. Ver atributos del primer resultado
        await buscarPage.clickVerAtributos(0);
        await modalAtributosPage.esperarModalVisible();
        
        expect(await modalAtributosPage.obtenerCantidadAtributos()).toBeGreaterThan(0);
        
        await modalAtributosPage.cerrarConBoton();
        
        // 3. Seleccionar y asignar fecha
        await buscarPage.seleccionarReferencia(0);
        await buscarPage.clickAsignarFechaLanzamiento();
        await modalFechaPage.esperarModalVisible();
        
        const fechaFutura = new Date();
        fechaFutura.setDate(fechaFutura.getDate() + 10);
        const fechaStr = fechaFutura.toISOString().split('T')[0];
        
        await modalFechaPage.llenarFormulario(fechaStr, [0]);
        await modalFechaPage.clickAsignar();
        
        expect(await modalFechaPage.estaVisible()).toBe(false);
      }
    });
    
  });
  
  describe('Flujo con Limpiar y Recargar', () => {
    
    it('Debe permitir limpiar y realizar nueva búsqueda', async () => {
      // 1. Primera búsqueda
      await buscarPage.llenarFormularioBusqueda({ empresa: 'IC', ano: 2024 });
      await buscarPage.clickBuscar();
      
      const resultados1 = await buscarPage.obtenerCantidadResultados();
      
      // 2. Seleccionar referencias
      if (resultados1 > 0) {
        await buscarPage.seleccionarReferencia(0);
      }
      
      // 3. Limpiar
      await buscarPage.clickLimpiar();
      expect(await buscarPage.formularioEstaVacio()).toBe(true);
      expect(await buscarPage.hayResultados()).toBe(false);
      
      // 4. Nueva búsqueda
      await buscarPage.llenarFormularioBusqueda({ empresa: 'IC' });
      await buscarPage.clickBuscar();
      
      // 5. Verificar que funciona la nueva búsqueda
      if (await buscarPage.hayResultados()) {
        await buscarPage.clickVerAtributos(0);
        await modalAtributosPage.esperarModalVisible();
        
        expect(await modalAtributosPage.estaVisible()).toBe(true);
        
        await modalAtributosPage.cerrarConBoton();
      }
    });
    
  });
  
  describe('Flujo de Validación Completa', () => {
    
    it('Debe completar el ciclo completo de validación y asignación', async () => {
      // 1. Buscar referencias
      await buscarPage.llenarFormularioBusqueda({ empresa: 'IC' });
      await buscarPage.clickBuscar();
      
      expect(await buscarPage.hayResultados()).toBe(true);
      const cantidadResultados = await buscarPage.obtenerCantidadResultados();
      
      // 2. Identificar referencias válidas e inválidas
      let indiceValida = -1;
      let indiceInvalida = -1;
      
      for (let i = 0; i < cantidadResultados; i++) {
        if (await buscarPage.esReferenciaValida(i) && indiceValida === -1) {
          indiceValida = i;
        }
        if (await buscarPage.esReferenciaInvalida(i) && indiceInvalida === -1) {
          indiceInvalida = i;
        }
        if (indiceValida !== -1 && indiceInvalida !== -1) {
          break;
        }
      }
      
      // 3. Ver atributos de referencia válida
      if (indiceValida !== -1) {
        await buscarPage.clickVerAtributos(indiceValida);
        await modalAtributosPage.esperarModalVisible();
        
        const atributosOk = await modalAtributosPage.contarAtributosOk();
        expect(atributosOk).toBeGreaterThan(0);
        
        await modalAtributosPage.cerrarConBoton();
      }
      
      // 4. Ver atributos de referencia inválida
      if (indiceInvalida !== -1) {
        await buscarPage.clickVerAtributos(indiceInvalida);
        await modalAtributosPage.esperarModalVisible();
        
        const atributosError = await modalAtributosPage.contarAtributosConError();
        expect(atributosError).toBeGreaterThan(0);
        
        await modalAtributosPage.cerrarConBoton();
      }
      
      // 5. Seleccionar solo referencias válidas para asignar fecha
      if (indiceValida !== -1) {
        await buscarPage.seleccionarReferencia(indiceValida);
        
        await buscarPage.clickAsignarFechaLanzamiento();
        await modalFechaPage.esperarModalVisible();
        
        const fechaFutura = new Date();
        fechaFutura.setDate(fechaFutura.getDate() + 30);
        const fechaStr = fechaFutura.toISOString().split('T')[0];
        
        await modalFechaPage.llenarFormulario(fechaStr, [0]);
        await modalFechaPage.clickAsignar();
        
        expect(await modalFechaPage.estaVisible()).toBe(false);
      }
    });
    
  });
  
});
