/**
 * E2E Tests - Modal de Atributos de Referencia
 * 
 * Suite de pruebas end-to-end para el modal de visualización de atributos.
 */

import { browser } from 'protractor';
import { BuscarReferenciaPage } from './page-objects/buscar-referencia.po';
import { ModalAtributosReferenciaPage } from './page-objects/modal-atributos.po';

describe('Validador Multicanal - Modal de Atributos', () => {
  let buscarPage: BuscarReferenciaPage;
  let modalPage: ModalAtributosReferenciaPage;
  
  beforeEach(async () => {
    buscarPage = new BuscarReferenciaPage();
    modalPage = new ModalAtributosReferenciaPage();
    
    // Navegar y realizar búsqueda inicial
    await buscarPage.navigateTo();
    await buscarPage.llenarFormularioBusqueda({ empresa: 'IC' });
    await buscarPage.clickBuscar();
  });
  
  afterEach(async () => {
    // Cerrar modal si está abierto
    try {
      if (await modalPage.estaVisible()) {
        await modalPage.cerrarConBoton();
      }
    } catch (e) {
      // Si el modal no está abierto, continuar
    }
  });
  
  describe('E2E-MA-001: Abrir modal desde referencia completa', () => {
    
    it('Debe abrir el modal correctamente', async () => {
      // Arrange - Buscar una referencia válida
      const cantidad = await buscarPage.obtenerCantidadResultados();
      let indiceValida = -1;
      
      for (let i = 0; i < cantidad; i++) {
        if (await buscarPage.esReferenciaValida(i)) {
          indiceValida = i;
          break;
        }
      }
      
      if (indiceValida === -1) {
        pending('No hay referencias válidas para probar');
        return;
      }
      
      // Act
      await buscarPage.clickVerAtributos(indiceValida);
      await modalPage.esperarModalVisible();
      
      // Assert
      expect(await modalPage.estaVisible()).toBe(true);
    });
    
    it('Debe mostrar el título correcto', async () => {
      // Arrange
      await buscarPage.clickVerAtributos(0);
      await modalPage.esperarModalVisible();
      
      // Act
      const titulo = await modalPage.obtenerTitulo();
      
      // Assert
      expect(titulo).toContain('Detalles de Atributos');
    });
    
    it('Debe mostrar el código y nombre de la referencia', async () => {
      // Arrange
      const codigoEsperado = await buscarPage.obtenerCodigoReferencia(0);
      await buscarPage.clickVerAtributos(0);
      await modalPage.esperarModalVisible();
      
      // Act
      const codigoModal = await modalPage.obtenerCodigoReferencia();
      const nombreModal = await modalPage.obtenerNombreReferencia();
      
      // Assert
      expect(codigoModal).toBe(codigoEsperado);
      expect(nombreModal).toBeTruthy();
    });
    
  });
  
  describe('E2E-MA-002: Abrir modal desde referencia incompleta', () => {
    
    it('Debe abrir el modal desde referencia inválida', async () => {
      // Arrange - Buscar una referencia inválida
      const cantidad = await buscarPage.obtenerCantidadResultados();
      let indiceInvalida = -1;
      
      for (let i = 0; i < cantidad; i++) {
        if (await buscarPage.esReferenciaInvalida(i)) {
          indiceInvalida = i;
          break;
        }
      }
      
      if (indiceInvalida === -1) {
        pending('No hay referencias inválidas para probar');
        return;
      }
      
      // Act
      await buscarPage.clickVerAtributos(indiceInvalida);
      await modalPage.esperarModalVisible();
      
      // Assert
      expect(await modalPage.estaVisible()).toBe(true);
    });
    
  });
  
  describe('E2E-MA-003: Visualizar atributos con estado OK', () => {
    
    it('Debe mostrar al menos un atributo', async () => {
      // Arrange
      await buscarPage.clickVerAtributos(0);
      await modalPage.esperarModalVisible();
      
      // Act
      const cantidadAtributos = await modalPage.obtenerCantidadAtributos();
      
      // Assert
      expect(cantidadAtributos).toBeGreaterThan(0);
    });
    
    it('Debe mostrar check verde para atributos completos', async () => {
      // Arrange
      await buscarPage.clickVerAtributos(0);
      await modalPage.esperarModalVisible();
      
      // Act
      const atributosOk = await modalPage.contarAtributosOk();
      
      // Assert
      expect(atributosOk).toBeGreaterThanOrEqual(0);
    });
    
    it('Debe mostrar el nombre y valor de cada atributo', async () => {
      // Arrange
      await buscarPage.clickVerAtributos(0);
      await modalPage.esperarModalVisible();
      
      // Act
      const nombre = await modalPage.obtenerNombreAtributo(0);
      
      // Assert
      expect(nombre).toBeTruthy();
      expect(nombre.length).toBeGreaterThan(0);
    });
    
  });
  
  describe('E2E-MA-004: Visualizar atributos con estado Error', () => {
    
    it('Debe mostrar X rojo para atributos incompletos', async () => {
      // Arrange - Buscar referencia inválida
      const cantidad = await buscarPage.obtenerCantidadResultados();
      let indiceInvalida = -1;
      
      for (let i = 0; i < cantidad; i++) {
        if (await buscarPage.esReferenciaInvalida(i)) {
          indiceInvalida = i;
          break;
        }
      }
      
      if (indiceInvalida === -1) {
        pending('No hay referencias inválidas para probar');
        return;
      }
      
      await buscarPage.clickVerAtributos(indiceInvalida);
      await modalPage.esperarModalVisible();
      
      // Act
      const atributosError = await modalPage.contarAtributosConError();
      
      // Assert
      expect(atributosError).toBeGreaterThan(0);
    });
    
  });
  
  describe('E2E-MA-005: Visualizar canales completos (verde)', () => {
    
    it('Debe mostrar al menos un canal', async () => {
      // Arrange
      await buscarPage.clickVerAtributos(0);
      await modalPage.esperarModalVisible();
      
      // Act
      const cantidadCanales = await modalPage.obtenerCantidadCanales();
      
      // Assert
      expect(cantidadCanales).toBeGreaterThan(0);
    });
    
    it('Debe mostrar badge verde para canales completos', async () => {
      // Arrange - Buscar referencia válida
      const cantidad = await buscarPage.obtenerCantidadResultados();
      let indiceValida = -1;
      
      for (let i = 0; i < cantidad; i++) {
        if (await buscarPage.esReferenciaValida(i)) {
          indiceValida = i;
          break;
        }
      }
      
      if (indiceValida === -1) {
        pending('No hay referencias válidas para probar');
        return;
      }
      
      await buscarPage.clickVerAtributos(indiceValida);
      await modalPage.esperarModalVisible();
      
      // Act
      const canalesCompletos = await modalPage.contarCanalesCompletos();
      
      // Assert
      expect(canalesCompletos).toBeGreaterThan(0);
    });
    
  });
  
  describe('E2E-MA-006: Visualizar canales con faltantes (rojo)', () => {
    
    it('Debe mostrar badge rojo con count para canales incompletos', async () => {
      // Arrange - Buscar referencia inválida
      const cantidad = await buscarPage.obtenerCantidadResultados();
      let indiceInvalida = -1;
      
      for (let i = 0; i < cantidad; i++) {
        if (await buscarPage.esReferenciaInvalida(i)) {
          indiceInvalida = i;
          break;
        }
      }
      
      if (indiceInvalida === -1) {
        pending('No hay referencias inválidas para probar');
        return;
      }
      
      await buscarPage.clickVerAtributos(indiceInvalida);
      await modalPage.esperarModalVisible();
      
      // Act
      const canalesFaltantes = await modalPage.contarCanalesConFaltantes();
      
      // Assert
      expect(canalesFaltantes).toBeGreaterThan(0);
    });
    
    it('Debe mostrar el número de atributos faltantes en el badge', async () => {
      // Arrange - Buscar referencia inválida
      const cantidad = await buscarPage.obtenerCantidadResultados();
      let indiceInvalida = -1;
      
      for (let i = 0; i < cantidad; i++) {
        if (await buscarPage.esReferenciaInvalida(i)) {
          indiceInvalida = i;
          break;
        }
      }
      
      if (indiceInvalida === -1) {
        pending('No hay referencias inválidas para probar');
        return;
      }
      
      await buscarPage.clickVerAtributos(indiceInvalida);
      await modalPage.esperarModalVisible();
      
      // Act
      const cantidadCanales = await modalPage.obtenerCantidadCanales();
      
      for (let i = 0; i < cantidadCanales; i++) {
        if (await modalPage.canalTieneFaltantes(i)) {
          const faltantes = await modalPage.obtenerCantidadFaltantesCanal(i);
          
          // Assert
          expect(faltantes).toBeGreaterThan(0);
          break;
        }
      }
    });
    
  });
  
  describe('E2E-MA-007: Tooltip de atributos faltantes', () => {
    
    it('Debe mostrar tooltip al hacer hover sobre canal con faltantes', async () => {
      // Arrange - Buscar referencia inválida
      const cantidad = await buscarPage.obtenerCantidadResultados();
      let indiceInvalida = -1;
      
      for (let i = 0; i < cantidad; i++) {
        if (await buscarPage.esReferenciaInvalida(i)) {
          indiceInvalida = i;
          break;
        }
      }
      
      if (indiceInvalida === -1) {
        pending('No hay referencias inválidas para probar');
        return;
      }
      
      await buscarPage.clickVerAtributos(indiceInvalida);
      await modalPage.esperarModalVisible();
      
      // Buscar primer canal con faltantes
      const cantidadCanales = await modalPage.obtenerCantidadCanales();
      
      for (let i = 0; i < cantidadCanales; i++) {
        if (await modalPage.canalTieneFaltantes(i)) {
          // Act
          await modalPage.hoverSobreCanal(i);
          const tooltip = await modalPage.obtenerTextoTooltip();
          
          // Assert
          expect(tooltip).toBeTruthy();
          expect(tooltip.length).toBeGreaterThan(0);
          break;
        }
      }
    });
    
  });
  
  describe('E2E-MA-008: Cerrar modal correctamente', () => {
    
    it('Debe cerrar el modal con el botón Cerrar', async () => {
      // Arrange
      await buscarPage.clickVerAtributos(0);
      await modalPage.esperarModalVisible();
      expect(await modalPage.estaVisible()).toBe(true);
      
      // Act
      await modalPage.cerrarConBoton();
      
      // Assert
      expect(await modalPage.estaVisible()).toBe(false);
    });
    
    it('Debe cerrar el modal con el icono X', async () => {
      // Arrange
      await buscarPage.clickVerAtributos(0);
      await modalPage.esperarModalVisible();
      expect(await modalPage.estaVisible()).toBe(true);
      
      // Act
      await modalPage.cerrarConIcono();
      
      // Assert
      expect(await modalPage.estaVisible()).toBe(false);
    });
    
    it('Debe mantener los resultados después de cerrar el modal', async () => {
      // Arrange
      const cantidadAntes = await buscarPage.obtenerCantidadResultados();
      await buscarPage.clickVerAtributos(0);
      await modalPage.esperarModalVisible();
      
      // Act
      await modalPage.cerrarConBoton();
      const cantidadDespues = await buscarPage.obtenerCantidadResultados();
      
      // Assert
      expect(cantidadDespues).toBe(cantidadAntes);
    });
    
  });
  
  describe('Validación de Datos', () => {
    
    it('Debe coincidir el código entre la lista y el modal', async () => {
      // Arrange
      const codigoLista = await buscarPage.obtenerCodigoReferencia(0);
      
      // Act
      await buscarPage.clickVerAtributos(0);
      await modalPage.esperarModalVisible();
      const codigoModal = await modalPage.obtenerCodigoReferencia();
      
      // Assert
      expect(codigoModal).toBe(codigoLista);
    });
    
  });
  
});
