/**
 * Datos Mock para Pruebas E2E - Validador Multicanal
 * 
 * Este archivo contiene datos de prueba que simulan respuestas del backend
 * para permitir pruebas E2E sin conexión a base de datos real.
 */

import { ReferenciaValidacionDto } from '../../../src/app/shared/Interfaces/referencia-validacion-dto';
import { DetalleAtributosReferenciaDto } from '../../../src/app/shared/Interfaces/detalle-atributos-referencia-dto';

/**
 * Referencias Mock - Diferentes escenarios de validación
 */
export const MOCK_REFERENCIAS: ReferenciaValidacionDto[] = [
  {
    id: 'REF-001',
    codigo: '11659150',
    nombre: 'Camiseta Básica Algodón',
    descripcion: 'Camiseta 100% algodón, manga corta, cuello redondo',
    urlImagen: 'https://via.placeholder.com/150/4CAF50/FFFFFF?text=REF-001',
    isValid: true,
    empresa: 'IC',
    ano: 2024,
    coleccion: '01',
    periodo: 1,
    referencia: '11659150',
    fechaLanzamiento: new Date('2024-12-01')
  },
  {
    id: 'REF-002',
    codigo: '11659151',
    nombre: 'Pantalón Denim Slim Fit',
    descripcion: 'Pantalón jean denim azul, corte slim fit',
    urlImagen: 'https://via.placeholder.com/150/FF9800/FFFFFF?text=REF-002',
    isValid: false,
    empresa: 'IC',
    ano: 2024,
    coleccion: '01',
    periodo: 1,
    referencia: '11659151',
    fechaLanzamiento: null
  },
  {
    id: 'REF-003',
    codigo: '11659152',
    nombre: 'Chaqueta Sport Casual',
    descripcion: null,
    urlImagen: null,
    isValid: false,
    empresa: 'IC',
    ano: 2024,
    coleccion: '01',
    periodo: 1,
    referencia: '11659152',
    fechaLanzamiento: null
  },
  {
    id: 'REF-004',
    codigo: '11659153',
    nombre: 'Zapatos Deportivos Running',
    descripcion: 'Zapatos deportivos con tecnología de amortiguación',
    urlImagen: 'https://via.placeholder.com/150/2196F3/FFFFFF?text=REF-004',
    isValid: true,
    empresa: 'IC',
    ano: 2024,
    coleccion: '01',
    periodo: 1,
    referencia: '11659153',
    fechaLanzamiento: new Date('2024-11-15')
  },
  {
    id: 'REF-005',
    codigo: '11659154',
    nombre: 'Vestido Floral Verano',
    descripcion: 'Vestido estampado floral, manga corta',
    urlImagen: 'https://via.placeholder.com/150/E91E63/FFFFFF?text=REF-005',
    isValid: true,
    empresa: 'IC',
    ano: 2024,
    coleccion: '02',
    periodo: 2,
    referencia: '11659154',
    fechaLanzamiento: new Date('2025-01-10')
  }
];

/**
 * Detalles de Atributos Mock - Referencia Completa
 */
export const MOCK_DETALLE_ATRIBUTOS_COMPLETO: DetalleAtributosReferenciaDto = {
  idReferencia: 'REF-001',
  codigoReferencia: '11659150',
  nombreReferencia: 'Camiseta Básica Algodón',
  atributos: [
    { nombre: 'Descripción', ok: true, valor: 'Camiseta 100% algodón, manga corta, cuello redondo' },
    { nombre: 'Imagen', ok: true, valor: 'https://via.placeholder.com/150/4CAF50/FFFFFF?text=REF-001' },
    { nombre: 'Color', ok: true, valor: 'Azul' },
    { nombre: 'Talla', ok: true, valor: 'M' },
    { nombre: 'Composición', ok: true, valor: '100% Algodón' },
    { nombre: 'Marca', ok: true, valor: 'GCO Basics' },
    { nombre: 'Categoría', ok: true, valor: 'Ropa > Camisetas > Manga Corta' }
  ],
  canales: [
    {
      codigo: 'IC',
      nombre: 'Internet Colombia',
      ok: true,
      atributosFaltantes: []
    },
    {
      codigo: 'VN',
      nombre: 'Ventas Nacionales',
      ok: true,
      atributosFaltantes: []
    },
    {
      codigo: 'MKT',
      nombre: 'Marketplace Principal',
      ok: true,
      atributosFaltantes: []
    }
  ]
};

/**
 * Detalles de Atributos Mock - Referencia Incompleta
 */
export const MOCK_DETALLE_ATRIBUTOS_INCOMPLETO: DetalleAtributosReferenciaDto = {
  idReferencia: 'REF-002',
  codigoReferencia: '11659151',
  nombreReferencia: 'Pantalón Denim Slim Fit',
  atributos: [
    { nombre: 'Descripción', ok: true, valor: 'Pantalón jean denim azul, corte slim fit' },
    { nombre: 'Imagen', ok: true, valor: 'https://via.placeholder.com/150/FF9800/FFFFFF?text=REF-002' },
    { nombre: 'Color', ok: false, valor: null },
    { nombre: 'Talla', ok: false, valor: null },
    { nombre: 'Composición', ok: true, valor: '98% Algodón, 2% Elastano' },
    { nombre: 'Marca', ok: false, valor: null },
    { nombre: 'Categoría', ok: true, valor: 'Ropa > Pantalones' }
  ],
  canales: [
    {
      codigo: 'IC',
      nombre: 'Internet Colombia',
      ok: false,
      atributosFaltantes: ['Color', 'Talla', 'Marca']
    },
    {
      codigo: 'VN',
      nombre: 'Ventas Nacionales',
      ok: false,
      atributosFaltantes: ['Color', 'Talla', 'Marca']
    },
    {
      codigo: 'MKT',
      nombre: 'Marketplace Principal',
      ok: false,
      atributosFaltantes: ['Color', 'Talla', 'Marca']
    }
  ]
};

/**
 * Detalles de Atributos Mock - Referencia Sin Imagen
 */
export const MOCK_DETALLE_ATRIBUTOS_SIN_IMAGEN: DetalleAtributosReferenciaDto = {
  idReferencia: 'REF-003',
  codigoReferencia: '11659152',
  nombreReferencia: 'Chaqueta Sport Casual',
  atributos: [
    { nombre: 'Descripción', ok: false, valor: null },
    { nombre: 'Imagen', ok: false, valor: null },
    { nombre: 'Color', ok: true, valor: 'Negro' },
    { nombre: 'Talla', ok: true, valor: 'L' },
    { nombre: 'Composición', ok: false, valor: null },
    { nombre: 'Marca', ok: true, valor: 'Sport Line' },
    { nombre: 'Categoría', ok: false, valor: null }
  ],
  canales: [
    {
      codigo: 'IC',
      nombre: 'Internet Colombia',
      ok: false,
      atributosFaltantes: ['Descripción', 'Imagen', 'Composición', 'Categoría']
    },
    {
      codigo: 'VN',
      nombre: 'Ventas Nacionales',
      ok: false,
      atributosFaltantes: ['Descripción', 'Imagen', 'Composición', 'Categoría']
    },
    {
      codigo: 'MKT',
      nombre: 'Marketplace Principal',
      ok: false,
      atributosFaltantes: ['Descripción', 'Imagen', 'Composición', 'Categoría']
    }
  ]
};

/**
 * Canales Mock - Para modal de fecha de lanzamiento
 */
export const MOCK_CANALES = [
  { codigo: 'IC', nombre: 'Internet Colombia', activo: true },
  { codigo: 'VN', nombre: 'Ventas Nacionales', activo: true },
  { codigo: 'MKT', nombre: 'Marketplace Principal', activo: true },
  { codigo: 'WHL', nombre: 'White Label 1', activo: true },
  { codigo: 'WH2', nombre: 'White Label 2', activo: false }
];

/**
 * Respuestas de Asignación Mock
 */
export const MOCK_ASIGNACION_EXITOSA = {
  mensaje: 'Fecha de lanzamiento asignada correctamente a 2 referencias en 3 canales',
  referenciasActualizadas: 2,
  canalesActualizados: 3,
  errores: []
};

export const MOCK_ASIGNACION_CON_ERRORES = {
  mensaje: 'Asignación completada con algunos errores',
  referenciasActualizadas: 1,
  canalesActualizados: 2,
  errores: [
    'Error al actualizar canal VN para referencia REF-002',
    'Canal MKT no disponible para referencia REF-002'
  ]
};

/**
 * Escenarios de Error Mock
 */
export const MOCK_ERROR_SERVIDOR = {
  status: 500,
  error: 'Internal Server Error',
  message: 'Error al procesar la solicitud',
  timestamp: new Date().toISOString()
};

export const MOCK_ERROR_NO_AUTORIZADO = {
  status: 401,
  error: 'Unauthorized',
  message: 'Token expirado o inválido',
  timestamp: new Date().toISOString()
};

export const MOCK_ERROR_NO_ENCONTRADO = {
  status: 404,
  error: 'Not Found',
  message: 'Referencia no encontrada',
  timestamp: new Date().toISOString()
};

/**
 * Helper: Obtener referencia mock por ID
 */
export function obtenerReferenciaMockPorId(id: string): ReferenciaValidacionDto | undefined {
  return MOCK_REFERENCIAS.find(ref => ref.id === id);
}

/**
 * Helper: Obtener detalles de atributos mock por ID
 */
export function obtenerDetalleAtributosMockPorId(id: string): DetalleAtributosReferenciaDto | null {
  switch (id) {
    case 'REF-001':
      return MOCK_DETALLE_ATRIBUTOS_COMPLETO;
    case 'REF-002':
      return MOCK_DETALLE_ATRIBUTOS_INCOMPLETO;
    case 'REF-003':
      return MOCK_DETALLE_ATRIBUTOS_SIN_IMAGEN;
    default:
      return null;
  }
}

/**
 * Helper: Filtrar referencias mock por criterios
 */
export function filtrarReferenciasMock(
  empresa: string,
  ano?: number,
  coleccion?: string,
  referencia?: string
): ReferenciaValidacionDto[] {
  let resultado = MOCK_REFERENCIAS.filter(ref => ref.empresa === empresa);
  
  if (ano) {
    resultado = resultado.filter(ref => ref.ano === ano);
  }
  
  if (coleccion && coleccion !== '-1') {
    resultado = resultado.filter(ref => ref.coleccion === coleccion);
  }
  
  if (referencia && referencia !== '-1') {
    resultado = resultado.filter(ref => ref.codigo.includes(referencia));
  }
  
  return resultado;
}

/**
 * Helper: Simular delay de red (para pruebas realistas)
 */
export function simularDelayRed(ms: number = 500): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}
