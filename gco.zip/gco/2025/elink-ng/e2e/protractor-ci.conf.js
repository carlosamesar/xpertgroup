// Protractor configuration for CI/CD (headless mode)
const { SpecReporter } = require('jasmine-spec-reporter');

exports.config = {
  allScriptsTimeout: 30000,
  specs: [
    './src/**/*.e2e-spec.ts'
  ],
  capabilities: {
    browserName: 'chrome',
    chromeOptions: {
      args: [
        '--headless',
        '--disable-gpu',
        '--window-size=1920,1080',
        '--no-sandbox',
        '--disable-dev-shm-usage'
      ]
    }
  },
  directConnect: true,
  baseUrl: 'http://localhost:4200/',
  framework: 'jasmine',
  jasmineNodeOpts: {
    showColors: true,
    defaultTimeoutInterval: 60000,
    print: function() {}
  },
  onPrepare() {
    require('ts-node').register({
      project: require('path').join(__dirname, './tsconfig.e2e.json')
    });
    jasmine.getEnv().addReporter(new SpecReporter({ 
      spec: { 
        displayStacktrace: 'pretty',
        displayErrorMessages: true,
        displaySuccessful: true,
        displayFailed: true,
        displayPending: true,
        displayDuration: true
      } 
    }));
    
    // Configurar screenshots en caso de fallo
    const path = require('path');
    const fs = require('fs-extra');
    
    jasmine.getEnv().addReporter({
      specDone: async function(result) {
        if (result.status === 'failed') {
          const screenshot = await browser.takeScreenshot();
          const screenshotPath = path.join(__dirname, 'screenshots');
          
          fs.ensureDirSync(screenshotPath);
          
          const fileName = `${result.fullName.replace(/\s+/g, '-')}-${Date.now()}.png`;
          const filePath = path.join(screenshotPath, fileName);
          
          fs.writeFileSync(filePath, screenshot, 'base64');
          console.log(`Screenshot saved: ${filePath}`);
        }
      }
    });
  }
};
