export const environment = {
  production: false,
  nombre: "qa",
  release: "Elink Canales",
  version: "2.0.2",
  URL_ATRIBUTOS: "http://localhost:8080/siconline/commerce/atributos",
  URL_MARKETPLACE: "http://localhost:8080/siconline/commerce/marketplace",
  URL_CATEGORIAS: "http://localhost:8080/siconline/commerce/categorias",
  URL_PRODUCTOS: "http://localhost:8080/siconline/commerce/referencia",
  URL_VALES: 'http://localhost:8080/commerce/vales',
  URL_EQUIVALENCIAS:
    "http://localhost:8080/siconline/commerce/equivalencias",
  // URL_AUTENTICACION: 'http://seraplipru.gco.com.co:8088/SecurityServicesWeb/rest/security/authenticate?dsapp=Siconline',
  // URL_RESOURCES: 'http://seraplipru.gco.com.co:8088/SecurityServicesWeb/rest/security/resources',
  // URL_RESET_CONTRASENA: 'http://seraplipru.gco.com.co:8088/SecurityServicesWeb/rest/security/changePasswordToUser',
  URL_AUTENTICACION:
    "http://10.66.166.14:8443/SecurityServicesWeb/rest/security/authenticate?dsapp=elink",
  URL_RESOURCES:
    "http://10.66.166.14:8443/SecurityServicesWeb/rest/security/resources",
  URL_RESET_CONTRASENA:
    "http://10.66.166.14:8443/SecurityServicesWeb/rest/security/changePasswordToUser",
  equivalencias: {
    TIPO_COMPOSICION: 5,
    TIPO_COLOR: 4,
    TIPO_TALLA: 1,
  },
};
