// Environment configuration for E2E testing with mocks
export const environment = {
    production: false,
    nombre: 'e2e-test',
    release: 'Elink Canales',
    version: '2.0.2',
    useMocks: true,  // Activar mocks para pruebas E2E
    URL_ATRIBUTOS: 'http://localhost:8080/commerce/atributos',
    URL_MARKETPLACE: 'http://localhost:8080/commerce/marketplace',
    URL_CATEGORIAS: 'http://localhost:8080/commerce/categorias',
    URL_PRODUCTOS: 'http://localhost:8080/commerce/referencia',
    URL_VALES: 'http://localhost:8080/commerce/vales',
    URL_EQUIVALENCIAS: 'http://localhost:8080/commerce/equivalencias',
    URL_DESCRIPCION: 'https://gco-gu.app.n8n.cloud/webhook/cd8f4390-0d86-42b8-a3f7-2e1a01d1bade',
    URL_AUTENTICACION: 'http://localhost:8080/commerce/api/auth/login',
    URL_RESOURCES: 'http://localhost:8080/commerce/api/auth/resources',
    URL_RESET_CONTRASENA: 'http://localhost:8080/commerce/api/auth/changePasswordToUser',
    equivalencias: {
        TIPO_COMPOSICION: 5,
        TIPO_COLOR: 4,
        TIPO_TALLA: 1
    }
};
