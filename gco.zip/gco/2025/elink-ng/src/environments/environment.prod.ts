export const environment = {
    production: true,
    nombre: 'prod',
    release: 'Elink Canales',
    version: '2.0.2',
    URL_ATRIBUTOS: 'http://elink.gco.com.co/commerce/atributos',
    URL_MARKETPLACE: 'http://elink.gco.com.co/commerce/marketplace',
    URL_CATEGORIAS: 'http://elink.gco.com.co/commerce/categorias',
    URL_PRODUCTOS: 'http://elink.gco.com.co/commerce/referencia',
    URL_VALES: 'http://elink.gco.com.co/commerce/vales',
    URL_EQUIVALENCIAS: 'http://elink.gco.com.co/commerce/equivalencias',
    URL_DESCRIPCION: 'https://gco-gu.app.n8n.cloud/webhook/cd8f4390-0d86-42b8-a3f7-2e1a01d1bade',

    //URL_AUTENTICACION: 'http://serjbosslave1.gco.com.co:8088/SecurityServicesWeb/rest/security/authenticate?dsapp=Siconline',
    //URL_RESOURCES: 'http://serjbosslave1.gco.com.co:8088/SecurityServicesWeb/rest/security/resources?dsapp=SiconlinePortal',
    //URL_RESET_CONTRASENA: 'http://serjbosslave1.gco.com.co:8088/SecurityServicesWeb/rest/security/changePasswordToUser',
    URL_AUTENTICACION: 'http://elink.gco.com.co/commerce/api/auth/login',
    URL_RESOURCES: 'http://elink.gco.com.co/commerce/api/auth/resources',
    URL_RESET_CONTRASENA: 'http://elink.gco.com.co/commerce/api/auth/changePasswordToUser',
     equivalencias: {
        TIPO_COMPOSICION: 5,
        TIPO_COLOR: 4,
        TIPO_TALLA: 1
    }
};
