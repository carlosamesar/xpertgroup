import { Component, OnInit } from '@angular/core';
import { SeguridadService } from './shared/service/seguridad.service';
import { Router, NavigationEnd, NavigationStart, ActivatedRoute } from '@angular/router';
import { environment } from 'src/environments/environment';

@Component({
    selector: 'elk-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
    
    title = 'Elink';
    logueado = false;
    entorno = environment.nombre;
    release = environment.release;
    version = environment.version;
    param = 0;
    opened = false;
    classSideBar = 'demo-sidebar navbar-dark bg-dark sombra';
    usuario = '';

    opciones: any = {
        categorias: 'categorias',
        categoriasProducto: 'categorias',
        productos: 'productos',
        equivalencias: 'equivalencias',
        atributos: 'atributos',
        market: 'marketplaces',
        wl: 'white-labels',
        vale: 'vales'
    };

    constructor(private seguridadService: SeguridadService,
                private router: Router,
                private actRoute: ActivatedRoute) {
                    
    }

    ngOnInit(): void {

        // This would print out the json object which contained
        // all of our query parameters for this particular route.
        this.actRoute.queryParams.subscribe(params => {

            if (params.t) {
                this.seguridadService.accesoContoken(params);
            }

        });

        this.seguridadService.logueado.subscribe(data => {

            console.log('Emit logeado', data);
            this.logueado = data;

            if (this.logueado) {

                if (this.seguridadService.usuarioApp) {
                    this.usuario = this.seguridadService.usuarioApp.data.username;
                }

            } else {

                this.router.navigate(['/login']);

            }
            
        });

        this.seguridadService.onResources.subscribe(data => {

            // Actualizo el parámetro del pipe para disparalo manualmente
            this.param = Math.random() * 10;

        });

        this.listenRouterEvents(this.router);

        window.onload = () => {
            
            // Abro un canal de comunicación
            console.log('Creando canal');
            const channel = new BroadcastChannel('elink');

            // Listen for messages on "my_bus".
            channel.onmessage = (e) => {

                // alert(e);

            };

            // A function to process messages received by the window.
            const receiveMessage = (e) => {

                //console.log(e);
                //console.log(e.data);

                if (e.data.type && e.data.type.indexOf('webpack') >= 0 ) {
                    return;
                }

                if (typeof e.data === 'string') {
                    try {
                        const data = JSON.parse(e.data);
            
                        console.log("Informacion data... ", data);
            
                        localStorage.setItem('u', data.data.u);
                        localStorage.setItem('t', data.data.t);
            
                        // Send a message on "my_bus".
                        channel.postMessage(data.data.t);
                    } catch (error) {
                        console.error("Error al analizar el JSON:", error);
                    }
                }

            };
            // Setup an event listener that calls receiveMessage() when the window
            // receives a new MessageEvent.
            window.addEventListener('message', receiveMessage);

        };

    }
    

    // Me suscribo a los eventos de navegación del router
    listenRouterEvents(router: Router) {

        router.events.subscribe(evt => {

            if (evt instanceof NavigationEnd) {

                console.log('router.events.subscribe', evt);
                
                if (!this.seguridadService.estaLogueado()) {

                    this.router.navigate(['/login']);

                } else {

                    if (!this.logueado) {
                        this.logueado = true;
                    }

                    if (this.seguridadService.usuarioApp) {
                        this.usuario = this.seguridadService.usuarioApp.data.username;
                    }

                }
            }

        });

    }

    logout() {

        this.seguridadService.logout();

    }

    mostrarOpcion(opcion: string): boolean {

        console.log('En el mostrar opción');
        return this.seguridadService.mostrarOpcion(opcion);

    }

    toggleSidebar() {
        this.opened = !this.opened;
    }

}
