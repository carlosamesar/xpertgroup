import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './features/home/home.component';
import { CategoriasComponent } from './features/categorias/categorias.component';
import { ProductosComponent } from './features/productos/productos.component';
import { LoginComponent } from './features/login/login.component';
import { EquivalenciasComponent } from './features/equivalencias/equivalencias.component';
import { CaterogoriasProductoComponent } from './features/caterogorias-producto/caterogorias-producto.component';
import { AtributosComponent } from './features/atributos/atributos.component';
import { MarketPlacesComponent } from './features/market-places/market-places.component';
import { CambioContrasenaComponent } from './features/seguridad/cambio-contrasena/cambio-contrasena.component';
import { WhiteLabelsComponent } from './features/white-labels/white-labels.component';
import { GenerarValesComponent } from './features/generar-vales/generar-vales.component';
import { BuscarReferenciaComponent } from './features/buscar-referencia/buscar-referencia.component';


const routes: Routes = [
    {path: 'app', component: HomeComponent},
    {path: 'productos', component: ProductosComponent},
    {path: 'categorias', component: CategoriasComponent},
    {path: 'categorias-producto', component: CaterogoriasProductoComponent},
    {path: 'equivalencias', component: EquivalenciasComponent},
    {path: 'atributos', component: AtributosComponent},
    {path: 'marketplaces', component: MarketPlacesComponent},
    {path: 'vales', component: GenerarValesComponent},
    {path: 'validador-multicanal', component: BuscarReferenciaComponent},
    {path: 'login', component: LoginComponent},
    {path: 'contrasena', component: CambioContrasenaComponent},
    {path: 'white-labels', component: WhiteLabelsComponent},
    { path: '**', component: HomeComponent }
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule { }
