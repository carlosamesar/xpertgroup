import { Component, OnInit } from '@angular/core';
import { QuoteServiceService } from 'src/app/shared/service/quote-service.service';
import { ThrowStmt } from '@angular/compiler';

@Component({
    selector: 'elk-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

    frase = 'No hay frase';
    autor = '';

    constructor(private quoteService: QuoteServiceService) { }

    ngOnInit() {

        this.quoteService.obtenerQuote().subscribe(data => {

            console.log('frase del dia', data);

            if (data) {

                this.frase = data.contents.quotes[0].quote;
                this.autor = data.contents.quotes[0].author;

            }

        });

    }

}
