import { Canales } from "./../../shared/clases/canales";
import { Empresa } from "./../../shared/clases/empresa";
import {
  Component,
  OnInit,
  ViewChild,
  ElementRef,
  ViewChildren,
  QueryList,
} from "@angular/core";
import { MarketplaceService } from "src/app/shared/service/marketplace.service";
import { AlertaService } from "src/app/shared/service/alerta.service";
import { NgxSpinnerService } from "ngx-spinner";
import { Marketplace } from "src/app/shared/clases/marketplace";
import { AtributosService } from "src/app/shared/service/atributos.service";
import { AtributoMarket } from "src/app/shared/clases/atributo-market";
import { FormGroup, FormArray, FormBuilder, Validators } from "@angular/forms";
import { BsModalService, ModalOptions } from "ngx-bootstrap/modal";
import { PoliticasComercialesComponent } from "../politicas-comerciales/politicas-comerciales.component";
import { fillChanels, fillCompany } from "src/app/shared/utils/listar-canales";
import { Resource } from "src/app/shared/clases/resource";

@Component({
  selector: "elk-atributos",
  templateUrl: "./atributos.component.html",
  styleUrls: ["./atributos.component.css"],
})
export class AtributosComponent implements OnInit {
  formulario: FormGroup = new FormGroup({});
  items: FormArray;

  listaMarket: Marketplace[];
  idCanalSel: string;
  marketSeleccionado: Marketplace;
  empresaSeleccionada: Empresa;
  canalSeleccionado: any = null;
  listaEmpresa: Empresa[];
  listaCanal: Canales[] = [];
  filtroListaCanal: Canales[] = [];
  listaTiposAtributos = [
    { id: "PRO", valor: "Producto" },
    { id: "PLU", valor: "Plu" },
    { id: "COM", valor: "Política comercial" },
  ];
  atribSeleccionado: string;
  listaAtributos: AtributoMarket[] = [];
  esSeleccionado = false;
  resources: Resource;

  @ViewChild("miTabla") miTabla: ElementRef;
  @ViewChildren("miFormulario") miFormulario: QueryList<ElementRef>;

  constructor(
    private marketService: MarketplaceService,
    private alertaService: AlertaService,
    private spinner: NgxSpinnerService,
    private atributoService: AtributosService,
    private formBuilder: FormBuilder,
    private modalService: BsModalService
  ) {}

  ngOnInit() {
    this.esSeleccionado
    this.resources = JSON.parse(localStorage.getItem('recursosElink'));

    this.marketService.obtenerEmpresas(this.resources.marca).subscribe((data) => {
      this.listaEmpresa = data;
    });

    // Configuro el forulario
    this.formulario = this.formBuilder.group({
      detalle: this.formBuilder.array([]),
    });
  }

  // convenience getter for easy access to form fields
  get f() {
    return this.formulario.controls;
  }

  get detalleArray() {
    return this.formulario.get("detalle") as FormArray;
  }

  set detalleArray(forma: FormArray) {
    this.formulario.controls.detalle = forma;
  }

  esSic(checked: boolean){
    this.esSeleccionado = checked
  }

  listarEmpresas(): void {
    fillCompany.bind(this)();
  }

  listarCanales(): void {
    fillChanels.bind(this)();
  }

  
  seleccionarCanal(event: any): void {
    if (this.canalSeleccionado) {
      this.idCanalSel = this.canalSeleccionado.id;

      this.consultarAtributos();
    }
    console.log(this.canalSeleccionado)
  }

  /* seleccionarMarketPlace(event: any) {

        this.marketSeleccionado = event as Marketplace;

        this.consultarAtributos();

    } */

  seleccionarTipoAtributo(event: any) {
    this.consultarAtributos();
  }

  consultarAtributos() {
    if (!this.idCanalSel) {
      return; 
    }

    if (!this.atribSeleccionado) {
      return;
    }

    this.spinner.show();

    this.atributoService
      .consultar(this.idCanalSel, this.atribSeleccionado)
      .subscribe(
        (data) => {
          this.spinner.hide();
          this.listaAtributos = data;

          this.crearItemTodos(this.listaAtributos);
          this.suscribirCambiosDetalleForm();
        },
        (error) => {
          this.spinner.hide();
          this.alertaService.mostrar(
            "Ocurrió un error consultando los atributos"
          );
          console.error(error);
        }
      );
  }

  crearItemTodos(lstAtributos: AtributoMarket[]) {
    this.items = this.formBuilder.array([]);

    lstAtributos.forEach((atributo) => {
      this.items.push(
        this.formBuilder.group({
          nombre: [atributo.armpValor, Validators.required],
          codigo: [atributo.armpCodigo, Validators.required],
          sic: [atributo.armpSic]
        })
      );
    });

    this.detalleArray = this.items;
  }

  private suscribirCambiosDetalleForm() {
    // -------------------------------------------------------
    // Me suscribo a los cambios de valor del form array
    // -------------------------------------------------------
    this.detalleArray.valueChanges.subscribe((valores) => {
      valores.forEach((elem, i) => {
        this.listaAtributos[i].armpValor = elem.nombre;
        this.listaAtributos[i].armpCodigo = elem.codigo;
        this.listaAtributos[i].armpSic = elem.sic;
      });
    });
  }

  crearItem(atributo: AtributoMarket): FormGroup {
    return this.formBuilder.group({
      nombre: [atributo.armpValor, Validators.required],
      codigo: [atributo.armpCodigo, Validators.required],
      sic: [atributo.armpSic]

    });
  }

  guardar(itemForm: FormGroup, index?: number) {
    if (!itemForm) {
      return;
    }

    if (itemForm.invalid) {
      return;
    }

    const atributo = this.listaAtributos[index];

    if (this.esAtributoDuplicado(atributo, index)) {
      return;
    }

    this.spinner.show();

    this.atributoService.guardar(atributo).subscribe(
      (data) => {
        atributo.armpUid = data.armpUid;
        atributo.armpEstado = data.armpEstado;
        atributo.armpUsuario = data.armpUsuario;
        atributo.armpSic = data.armpSic

        this.spinner.hide();
      },
      (error) => {
        this.spinner.hide();
        this.alertaService.mostrar("Ocurrió un error guardando el atributo");
        console.log(error);
      }
    );
  }

  inactivar(itemForm: FormGroup, index?: number) {
    const eliminarDetalle = (inidice) => {
      this.listaAtributos.splice(inidice, 1);
      this.detalleArray.removeAt(inidice);
    };

    this.alertaService
      .confirmar("Está seguro de eliminar el registro?")
      .subscribe((data) => {
        if (data === true) {
          const atributo = this.listaAtributos[index];

          if (!atributo.armpUid || atributo.armpUid === 0) {
            eliminarDetalle(index);
            return;
          }

          this.spinner.show();

          this.atributoService
            .inactivar(this.idCanalSel, atributo.armpUid)
            .subscribe(
              () => {
                this.spinner.hide();
                eliminarDetalle(index);
              },
              (error) => {
                this.spinner.hide();
                this.alertaService.mostrar(
                  "Ocurrió un error eliminando el atributo."
                );
                console.log(error);
              }
            );
        }
      });
  }

  limpiar() {
    this.idCanalSel = null;
    this.atribSeleccionado = null;
    this.empresaSeleccionada = null;
    this.filtroListaCanal = null;
    this.canalSeleccionado = null;

    this.items = this.formBuilder.array([]);
    this.detalleArray = this.items;

    this.listaAtributos = [];
    // this.listaMarket = [];
    // this.listaTiposAtributos = [];
  }

  adicionarDetalle() {
    const atributo = new AtributoMarket();

    atributo.elkCanalMae = this.canalSeleccionado;
    atributo.armpTipo = this.atribSeleccionado;

    const longitud = this.listaAtributos.push(atributo);

    this.detalleArray.push(this.crearItem(this.listaAtributos[longitud - 1]));

    // Pongo el foco en el nuevo campo
    setTimeout(() => {
      this.miFormulario.last.nativeElement.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
      this.miFormulario.last.nativeElement.cells[1].children[0].focus();
    }, 50);
  }

  esAtributoDuplicado(atributo: AtributoMarket, index: number): boolean {
    // Valido si el nombre existe
    let idx = this.listaAtributos.findIndex((attr) => {
      return attr.armpValor === atributo.armpValor;
    });

    if (idx >= 0 && idx !== index) {
      this.alertaService.mostrar(
        "El atributo " + atributo.armpValor + " ya existe."
      );
      return true;
    }

    // Valido si el código existe
    idx = this.listaAtributos.findIndex((attr) => {
      return attr.armpCodigo === atributo.armpCodigo;
    });

    if (idx >= 0 && idx !== index) {
      this.alertaService.mostrar(
        "El código de atributo " + atributo.armpCodigo + " ya existe."
      );
      return true;
    }

    return false;
  }

  abrirModalImportacionPoliticas() {
    const estadoInicial = new ModalOptions();
    estadoInicial.class = "modal-xl";
    estadoInicial.initialState = {
      titulo: "Importar políticas comerciales",
    };

    this.modalService.show(PoliticasComercialesComponent, estadoInicial);
  }
}
