import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AtributosComponent } from './atributos.component';
import { NgSelectModule } from '@ng-select/ng-select';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { ContainerComponent } from '../container/container.component';
import { NgxSpinnerModule } from 'ngx-spinner';
import { ModalModule } from 'ngx-bootstrap/modal';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('AtributosComponent', () => {
    let component: AtributosComponent;
    let fixture: ComponentFixture<AtributosComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [
                NgSelectModule,
                FormsModule,
                ReactiveFormsModule,
                NgxSpinnerModule,
                HttpClientTestingModule,
                ModalModule.forRoot()
            ],
            declarations: [AtributosComponent, ContainerComponent]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(AtributosComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
