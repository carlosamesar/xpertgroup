import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { SeguridadService } from 'src/app/shared/service/seguridad.service';
import { Login } from 'src/app/shared/clases/login';
import { Router } from '@angular/router';
import { AlertaService } from 'src/app/shared/service/alerta.service';
import { CambioContrasena } from 'src/app/shared/clases/cambio-contrasena';

@Component({
    selector: 'elk-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

    login: Login;

    constructor(private segService: SeguridadService,
                private router: Router,
                private alertaService: AlertaService) { }

    ngOnInit() {
        this.login = new Login();
    }

    autenticar() {

        this.segService.login(this.login, true).subscribe(respuesta => {

            console.log('Subscribe LoginComponent');
            console.log(respuesta);

            if (respuesta.data.jwt) {

                // Pongo este timeout para dar tiempo al servicio de seguridad
                // de que emita el evento de logeo y lo escueh el app.component
                setTimeout(() => {
                    this.router.navigate(['/app']);
                }, 30);

            } else {

                this.alertaService.mostrar('Usuario o contraseña incorrectos.');

            }
            
            

        }, error => {
            
            console.log('Error autenticando', error);
            this.alertaService.mostrar(error.error.message);

            
        });

    }

    /*
    cambiarContra() {

        const cambioContra = new CambioContrasena();
        cambioContra.user = 'sicotest';
        cambioContra.password = 'admin2018';

        this.segService.cambiarPassword(cambioContra).subscribe(respuesta => {

            console.log('cambio', respuesta);

        }, error => {
            
            console.log('Error autenticando', error);
            
        });

    }
    */
}
