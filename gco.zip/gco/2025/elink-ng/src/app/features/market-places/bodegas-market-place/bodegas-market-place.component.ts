import { Component, OnInit } from '@angular/core';
import { Subject } from 'rxjs';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { AlertaService } from 'src/app/shared/service/alerta.service';
import { Marketplace } from 'src/app/shared/clases/marketplace';
import { MarketplaceService } from 'src/app/shared/service/marketplace.service';
import { BodegaMarkerPlace } from 'src/app/shared/clases/bodega-marker-place';
import { NgForm } from '@angular/forms';
import { Canales } from 'src/app/shared/clases/canales';

@Component({
    selector: 'elk-bodegas-market-place',
    templateUrl: './bodegas-market-place.component.html',
    styleUrls: ['./bodegas-market-place.component.css']
})
export class BodegasMarketPlaceComponent implements OnInit {

    public onClose: Subject<boolean>;

    titulo: string;
    closeBtnName: string;
    aceptarBtnName: string;
    canal: Canales;
    listaBodegas: BodegaMarkerPlace[] = [];
    
    constructor(public bsModalRef: BsModalRef,
                private alertaService: AlertaService,
                private marketService: MarketplaceService) { }

    ngOnInit() {

        this.onClose = new Subject();

        this.marketService.obtenerBodegas(parseInt(this.canal.id)).subscribe(data => {

            console.log(data);
            this.listaBodegas = data;

        });

    }

    cerrar() {
        this.bsModalRef.hide();
    }

    insertar() {

        const bodega = new BodegaMarkerPlace();
        this.listaBodegas.push(bodega);

    }

    eliminar(index?: number) {

        if (index) {

            const bodega = this.listaBodegas[index];

            if (bodega.uid) {

                this.alertaService.confirmar('Está seguro de eliminar la bodega seleccionada?').subscribe(rtn => {

                    if (rtn === true) {

                        this.marketService.inactivarBodega(parseInt(this.canal.id), bodega.uid).subscribe(data => {

                            this.listaBodegas.splice(index, 1);
                            this.alertaService.mostrar('Bodega eliminada exitosamente.');
            
                        }, error => {
                            this.alertaService.mostrar('Ocurrió un error eliminando la bodega');
                        });

                    }

                });

            } else {

                this.listaBodegas.splice(index, 1);

            }
            
        }

    }


    guardar(form: NgForm, index: number) {

        console.log('form', form);

        if (form.invalid) {

            return;

        }

        const bodega = this.listaBodegas[index];

        if (this.tieneDuplicados(bodega, index)) {
            return;
        }

        this.marketService.guardarBodega(parseInt(this.canal.id), bodega).subscribe(data => {

            bodega.uid = data.uid;
            this.alertaService.mostrar('Bodega guardada exitosamente.');

        }, error => {

            this.alertaService.mostrar('Ocurrió un error guardando la bodega.');
            console.log(error);

        });

    }

    private tieneDuplicados(bodega: BodegaMarkerPlace, indice: number): boolean {

        const idx = this.listaBodegas.findIndex(bod => {

            return bod.codigo === bodega.codigo;

        });

        if (idx >= 0 && idx !== indice) {
            this.alertaService.mostrar('El código de bodega ya existe.');
            return true;
        }
        
    }

}
