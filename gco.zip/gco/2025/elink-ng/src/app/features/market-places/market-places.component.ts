import { Component, OnInit } from '@angular/core';
import { MarketplaceService } from 'src/app/shared/service/marketplace.service';
import { AlertaService } from 'src/app/shared/service/alerta.service';
import { BsModalService, ModalOptions } from 'ngx-bootstrap/modal';
import { BodegasMarketPlaceComponent } from './bodegas-market-place/bodegas-market-place.component';
import { Canales } from 'src/app/shared/clases/canales';
import { NgForm } from '@angular/forms';
import { Parametros } from 'src/app/shared/clases/parametros';
import { ListaprecioCanal } from 'src/app/shared/clases/listaprecio-canal';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
    selector: 'elk-market-places',
    templateUrl: './market-places.component.html',
    styleUrls: ['./market-places.component.css']
})
export class MarketPlacesComponent implements OnInit {

    listaMarket: Canales[] = [];
    marketActual: Canales;
    listaprecioCanal: ListaprecioCanal[] = [];
    listaprecioActual: ListaprecioCanal;
    esSeleccionado = false;
    html: string;
    numeroPos: string = '';

    page: number = 0;
    size: number = 25;
    totalPages: number;
    lastPage: boolean = false; 

    constructor(private marketService: MarketplaceService,
                private alertaService: AlertaService,
                private spinner: NgxSpinnerService,
                private modalService: BsModalService) { }

    ngOnInit() {

        this.esSeleccionado

        this.listaprecioActual = new ListaprecioCanal();

        this.marketActual = new Canales();

        this.obtenerCanales()

        this.marketService.obtenerListaprecioCanal().subscribe(data =>{
            this.listaprecioCanal = data;
            console.log(this.listaprecioCanal)
        });
    }

    obtenerCanales(){
        this.spinner.show();

        if (!this.numeroPos) {
            this.numeroPos = '';
        }

        this.marketService.obtenerMarketPlacesPaginados(this.numeroPos, this.page, this.size).subscribe(data => {
            console.log(data);
            this.listaMarket = data.content;
            this.totalPages = data.totalPages;
            this.lastPage = data.last;
            this.spinner.hide();
            
        });
    }

    editar(canal: Canales) {
        this.marketActual = canal;
        
        const canalLista = this.listaprecioCanal.find(item => item.idCanal === canal.id);

        if (canalLista) {
            this.listaprecioActual = { ...canalLista };
        } else {
            this.listaprecioActual = new ListaprecioCanal();
        }
    }

    limpiar(form: NgForm) {
        this.marketActual = new Canales();
        form.resetForm();
    }

    esMarketplace(checked: boolean){
        this.esSeleccionado = checked
        console.log(this.esSeleccionado)
    }

    infoMarketplace(){
        this.html = `<div><strong>Dejar sin marcar si la tienda es white label</strong></div>`
    }

    guardar(form: NgForm) {

        this.alertaService.confirmar('Está seguro de guardar el marketplace?').subscribe(data => {

            if (data === true) {
                this.spinner.show();
                this.marketService.guardar(this.marketActual, this.listaprecioActual.codPais,
                    this.listaprecioActual.divisa).subscribe(rtn => {

                    if (!this.marketActual.id) {

                        this.marketActual.id = rtn.id;
                        this.listaMarket.push(this.marketActual);
                        
                    }
                    
                    this.alertaService.mostrar('Marketplace guardado exitosamente.');
                    this.limpiar(form);
                    this.ngOnInit();

                }, error => {

                    if (error.error) {

                        this.alertaService.mostrar(error.error.message);

                    } else {

                        this.alertaService.mostrar('Ocurrió un error guardando el marketplace.');

                    }
                    
                    console.log(error);
                    this.ngOnInit();

                });

            } else {
                
            }
        });
    }


    inactivar(indice: number) {

        const canal = this.listaMarket[indice];
        this.alertaService.confirmar('Está seguro de inactivar el marketplace ' + canal.id
        + ' ' + canal.nombre + '?').subscribe(data => {
            
            if (data === true) {
                
                var stringToConvert = canal.id;
                var numberValue = Number(canal.id);
                this.marketService.inactivar(numberValue).subscribe(() => {
                    this.ngOnInit();
                    }, error => {

                        console.log(error);
                        this.alertaService.mostrar('Ocurrió un error inactivando el marketplace');

                    });
            }
        });
    }
    
    activar(indice: number) {

        const canal = this.listaMarket[indice];
        this.alertaService.confirmar('Está seguro de activar el marketplace ' + canal.id
        + ' ' + canal.nombre + '?').subscribe(data => {

            if (data === true) {

                var numberValue = Number(canal.id);
                this.marketService.activar(numberValue).subscribe(() => {
                    this.ngOnInit();
                    }, error => {

                        console.log(error);
                        this.alertaService.mostrar('Ocurrió un error activando el marketplace');
                    });
            }
        });
    }
        
    administrarBodegas() {

        const estadoInicial = new ModalOptions();
        estadoInicial.class = 'modal-lg';
        estadoInicial.initialState = {
            titulo: 'Bodegas de marketplace',
            closeBtnName: 'Cancelar',
            aceptarBtnName: 'Aceptar',
            market: this.marketActual
        };

        this.modalService.show(BodegasMarketPlaceComponent, estadoInicial);

    }

    previousPage() {
        if(this.page - 1 >= 0){
            this.page -= 1
            this.obtenerCanales();   
        }
    }

    nextPage() {
        if (this.page + 1 < this.totalPages) {
            this.page += 1;
            this.obtenerCanales();   
        }
    }

    goToPage(newPage: number) {
        this.page = newPage
        this.obtenerCanales();
    }

    onChangeSelectElements(valueElements){
        this.size = valueElements;
        this.obtenerCanales();
    }

    isRowDisabled(estado: string): boolean {
        return estado !== 'A';
    }
    
}
