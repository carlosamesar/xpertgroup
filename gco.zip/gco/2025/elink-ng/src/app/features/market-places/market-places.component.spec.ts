import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MarketPlacesComponent } from './market-places.component';
import { FormsModule } from '@angular/forms';
import { SharedModule } from 'src/app/shared/shared.module';
import { ModalModule } from 'ngx-bootstrap/modal';
import { ContainerComponent } from '../container/container.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('MarketPlacesComponent', () => {
    let component: MarketPlacesComponent;
    let fixture: ComponentFixture<MarketPlacesComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [
                FormsModule,
                SharedModule,
                ModalModule.forRoot(),
                HttpClientTestingModule,
            ],
            declarations: [
                MarketPlacesComponent,
                ContainerComponent
            ]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(MarketPlacesComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
