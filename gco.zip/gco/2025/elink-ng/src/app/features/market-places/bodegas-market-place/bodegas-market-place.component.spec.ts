import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BodegasMarketPlaceComponent } from './bodegas-market-place.component';
import { FormsModule } from '@angular/forms';
import { SharedModule } from 'src/app/shared/shared.module';
import { HttpClientModule } from '@angular/common/http';
import { ModalModule, BsModalRef } from 'ngx-bootstrap/modal';
import { Marketplace } from 'src/app/shared/clases/marketplace';

describe('BodegasMarketPlaceComponent', () => {
    let component: BodegasMarketPlaceComponent;
    let fixture: ComponentFixture<BodegasMarketPlaceComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [
                FormsModule,
                SharedModule,
                ModalModule.forRoot(),
                HttpClientModule,
            ],
            declarations: [BodegasMarketPlaceComponent],
            providers: [BsModalRef]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(BodegasMarketPlaceComponent);
        component = fixture.componentInstance;

        component.market = new Marketplace();
        component.market.uid = 1;

        component.titulo = 'Bodegas de marketplace';

        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('Debe tener el título de marketplaces', () => {
        expect(component.titulo).toBe('Bodegas de marketplace');
    });
});
