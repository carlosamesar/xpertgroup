import { Component, OnInit } from '@angular/core';
import { Login } from 'src/app/shared/clases/login';
import { AlertaService } from 'src/app/shared/service/alerta.service';
import { SeguridadService } from 'src/app/shared/service/seguridad.service';
import { CambioContrasena } from 'src/app/shared/clases/cambio-contrasena';
import { Router } from '@angular/router';

@Component({
    selector: 'elk-cambio-contrasena',
    templateUrl: './cambio-contrasena.component.html',
    styleUrls: ['./cambio-contrasena.component.css']
})
export class CambioContrasenaComponent implements OnInit {

    cambio: CambioContrasena;
    login: Login;
    passwordActual: string;
    confirmacionPassword: string;

    constructor(private alertaService: AlertaService,
                private segService: SeguridadService,
                private router: Router) { }

    ngOnInit() {
        this.cambio = new CambioContrasena();
    }

    cambiar() {

        if (this.cambio.password !== this.confirmacionPassword) {
            this.alertaService.mostrar('La nueva contraseña y la confirmación no son iguales');
            return;
        }

        this.cambio.username = this.segService.usuarioApp.data.username;
        this.login = new Login();

        this.login.username = this.cambio.username;
        this.login.password = this.passwordActual;

        console.log(this.login);

        this.segService.login(this.login, false).subscribe(data => {  

            if (data.data.jwt) {
              
                // Si el login fue exitoso, cambio el password
                this.segService.cambiarPassword(this.cambio).subscribe(resp => {

                    console.log('Cambio de contraseña', resp);
                    this.segService.logout();
                    this.alertaService.mostrar('Contraseña modificada exitosamente. Por favor inicie sesion nuevamente');

                    setTimeout(() => {
                        this.router.navigate(['/login']);
                    }, 2000);

                },
                (error) => {
                    console.log('Error cambio de contraseña', error);
                    this.alertaService.mostrar('Ocurrió un error modificando la contraseña.');
                });

            } else {

                this.alertaService.mostrar('La contraseña actual no es correcta.');

            }

            

        },
        (error) => {
            this.router.navigate(['/contrasena']);
            console.log('Error cambio de contraseña', error);
            this.router.navigate(['/contrasena']);
            this.alertaService.mostrar('Ocurrió un error modificando la contraseña.'+ error.error.message);
        });


    }

}
