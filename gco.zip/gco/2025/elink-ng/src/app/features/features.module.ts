import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';
import { CategoriasComponent } from './categorias/categorias.component';
import { HomeComponent } from './home/home.component';
import { TreeModule } from 'angular-tree-component';
import { SharedModule } from '../shared/shared.module';
import { ProductosComponent } from './productos/productos.component';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { UiSwitchModule } from 'ngx-ui-switch';
import { NgxSpinnerModule } from 'ngx-spinner';
import { AgGridModule } from 'ag-grid-angular';
import { ModalAsignacionEquivalenciaComponent } from './equivalencias/modal-asignacion-equivalencia/modal-asignacion-equivalencia.component';
import { ModalFechaLanzamientoComponent } from './productos/modal-fecha-lanzamiento/modal-fecha-lanzamiento.component';
import { LoginComponent } from './login/login.component';
import { EquivalenciasComponent } from './equivalencias/equivalencias.component';
import { ContainerComponent } from './container/container.component';
import { ArbolCategoriasComponent } from './arbol-categorias/arbol-categorias.component';
import { CaterogoriasProductoComponent } from './caterogorias-producto/caterogorias-producto.component';
import { AtributosComponent } from './atributos/atributos.component';
import { ImportArchivoCatProdComponent } from './caterogorias-producto/import-archivo-cat-prod/import-archivo-cat-prod.component';
import { DetalleProductosComponent } from './productos/detalle-productos/detalle-productos.component';
import { MarketPlacesComponent } from './market-places/market-places.component';
import { BodegasMarketPlaceComponent } from './market-places/bodegas-market-place/bodegas-market-place.component';
import { CambioContrasenaComponent } from './seguridad/cambio-contrasena/cambio-contrasena.component';
import { ImagenRendererComponent } from '../shared/componentes/imagen-renderer/imagen-renderer.component';
import { PoliticasComercialesComponent } from './politicas-comerciales/politicas-comerciales.component';
import { ModalAtributosSICComponent } from './productos/modal-atributos-sic/modal-atributos-sic.component';
import { ModalGenerarDescripcionesComponent } from './productos/modal-descripciones-gpt/modal-descripciones-gpt.component';
import { WhiteLabelsComponent } from './white-labels/white-labels.component';
import { GenerarValesComponent } from './generar-vales/generar-vales.component';
import { BuscarReferenciaComponent } from './buscar-referencia/buscar-referencia.component';
import { ModalAtributosReferenciaComponent } from './buscar-referencia/modal-atributos-referencia/modal-atributos-referencia.component';
import { ModalFechaLanzamientoReferenciaComponent } from './buscar-referencia/modal-fecha-lanzamiento-referencia/modal-fecha-lanzamiento-referencia.component';
import { DetalleValidacionComponent } from './buscar-referencia/detalle-validacion/detalle-validacion.component';
import { ModalDetalleValidacionComponent } from './buscar-referencia/modal-detalle-validacion/modal-detalle-validacion.component';


@NgModule({
    declarations: [
        HomeComponent,
        CategoriasComponent,
        ProductosComponent,
        ModalAsignacionEquivalenciaComponent,
        ModalFechaLanzamientoComponent,
        LoginComponent,
        EquivalenciasComponent,
        ContainerComponent,
        ArbolCategoriasComponent,
        CaterogoriasProductoComponent,
        AtributosComponent,
        ImportArchivoCatProdComponent,
        DetalleProductosComponent,
        MarketPlacesComponent,
        BodegasMarketPlaceComponent,
        CambioContrasenaComponent,
        PoliticasComercialesComponent,
        ModalAtributosSICComponent,
        ModalGenerarDescripcionesComponent,
        WhiteLabelsComponent,
        GenerarValesComponent,
        BuscarReferenciaComponent,
        ModalAtributosReferenciaComponent,
        ModalFechaLanzamientoReferenciaComponent,
        DetalleValidacionComponent,
        ModalDetalleValidacionComponent
    ],
    imports: [
        CommonModule,
        BrowserModule,
        ReactiveFormsModule,
        BrowserAnimationsModule,
        NgSelectModule,
        FormsModule,
        TreeModule.forRoot(),
        SharedModule,
        BsDatepickerModule.forRoot(),
        AccordionModule.forRoot(),
        PopoverModule.forRoot(),
        TooltipModule.forRoot(),
        PaginationModule.forRoot(),
        TabsModule.forRoot(),
        UiSwitchModule,
        NgxSpinnerModule,
        AgGridModule.withComponents([ImagenRendererComponent])
    ],
    exports: [
        HomeComponent,
        CategoriasComponent,
        ProductosComponent,
        ModalFechaLanzamientoComponent,
        LoginComponent,
        EquivalenciasComponent,
        ContainerComponent,
        ArbolCategoriasComponent,
        CaterogoriasProductoComponent,
        AtributosComponent,
        ImportArchivoCatProdComponent,
        MarketPlacesComponent,
        BodegasMarketPlaceComponent,
        CambioContrasenaComponent,
        PoliticasComercialesComponent,
        ModalAtributosSICComponent,
        ModalGenerarDescripcionesComponent,
        BuscarReferenciaComponent
    ],
    entryComponents: [
        ModalAsignacionEquivalenciaComponent,
        ModalFechaLanzamientoComponent,
        BodegasMarketPlaceComponent,
        PoliticasComercialesComponent,
        ModalAtributosSICComponent,
        ModalGenerarDescripcionesComponent,
        ModalAtributosReferenciaComponent,
        ModalFechaLanzamientoReferenciaComponent,
        ModalDetalleValidacionComponent
    ]
})
export class FeaturesModule { }
