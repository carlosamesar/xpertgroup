import { Component, OnInit, Input, Output, EventEmitter, SimpleChanges } from '@angular/core';
import { CategoriaProductoDto } from 'src/app/shared/clases/categoria-producto-dto';
import { NgxSpinnerService } from 'ngx-spinner';
import { CategoriasService } from 'src/app/shared/service/categorias.service';
import { AlertaService } from 'src/app/shared/service/alerta.service';
import * as XLSX from 'xlsx';
import { IPoliticaComercial } from 'src/app/shared/Interfaces/ipolitica-comercial';
import { AtributosService } from 'src/app/shared/service/atributos.service';
import { IRespuestaPolitica } from 'src/app/shared/Interfaces/irespuesta-politica';
import { BsModalRef } from 'ngx-bootstrap/modal';


@Component({
  selector: 'elk-politicas-comerciales',
  templateUrl: './politicas-comerciales.component.html',
  styleUrls: ['./politicas-comerciales.component.css']
})
export class PoliticasComercialesComponent implements OnInit {

  titulo = '';

  @Output() archivoImportado: EventEmitter<any>;
  archivoCargado: string;
  archivoSrc: string;
  arrayBuffer: any;
  columnas: string[];
  excelRows: IPoliticaComercial[] = [];
  arrayPoliticas: IPoliticaComercial[] = [];
  objectKeys = Object.keys;
  politicaActiva = true;

  constructor(private spinner: NgxSpinnerService,
              private atributoService: AtributosService,
              private alertaService: AlertaService,
              public bsModalRef: BsModalRef) {

    console.log('constructor ImportArchivoCatProdComponent');

  }

  ngOnInit() {

    console.log('ImportArchivoCatProdComponent');

  }

  handleInputChange(e) {

    this.excelRows = [];

    this.archivoCargado = e.target.files[0].name;
    const file = e.dataTransfer ? e.dataTransfer.files[0] : e.target.files[0];

    const pattern = /application\/vnd-*/;

    const reader = new FileReader();

    if (!file.type.match(pattern)) {
      alert('Formato no permitido');
      return;
    }

    if (reader.readAsBinaryString) {

      reader.onload = this.handleReaderLoaded.bind(this);
      reader.readAsBinaryString(file);

    }

  }

  cambioCheck(evt) {

    console.log('Cambio check', evt);

  }

  private handleReaderLoaded(e) {

    const reader = e.target;
    this.procesarExcel(reader.result);

  }

  private procesarExcel(data) {

    const workbook = XLSX.read(data, {
      type: 'binary'
    });

    // Fetch the name of First Sheet.
    const firstSheet = workbook.SheetNames[0];

    // Read all rows from First Sheet into an JSON array.
    this.excelRows = XLSX.utils.sheet_to_json(workbook.Sheets[firstSheet], {raw: true, defval: null});
    this.columnas = Object.keys(this.excelRows[0]);

  }

  cargarArchivo() {

    console.log(this.excelRows);

    // Creo el array de políticas
    this.arrayPoliticas = this.excelRows.map(row => {

      const politica = {} as IPoliticaComercial;

      politica.proveedor = row.proveedor;
      politica.canal = row.canal
      politica.referencia = row.referencia;
      politica.politica = row.politica;

      return politica;
    });
    console.log(this.arrayPoliticas)


    this.spinner.show();

    
    this.atributoService.upload(this.arrayPoliticas, this.politicaActiva).subscribe(data => {

      if (data.length > 0 ) {
        
        this.alertaService.mostrar('Algunos registros no se pudieron procesar.');
        this.procesarErrores(data);

      } else {

        this.alertaService.mostrar('Archivo procesado exitosamente.');
        
      }
      
      this.spinner.hide();

    }, error => {

      this.spinner.hide();

      if (error.error) {

        this.alertaService.mostrar(error.error.message);

      } else {

        this.alertaService.mostrar('Ocurrió un error importando las políticas comerciales de producto');

      }

      console.error(error);

    });
    

  }

  procesarErrores(errores: IRespuestaPolitica[]) {

    errores.forEach((error) => {

      const registro = error.reg;

      const filaTabla = this.excelRows.filter((row) => {

        let proveedor = null;
        let referencia = null;
        let nomPpolitica = null;

        if (row.proveedor) {
          proveedor = row.proveedor.toString();
        }

        if (row.referencia) {
          referencia = row.referencia.toString();
        }

        if (row.politica) {
          nomPpolitica = row.politica.toString();
        }

        return registro.proveedor === proveedor &&
          registro.referencia === referencia &&
          registro.politica === nomPpolitica;

      });

      if (filaTabla) {
        filaTabla.forEach((fila) => fila.error = error.error);
      }

    });
    
  }

  cancelar() {
    this.bsModalRef.hide();
  }

}
