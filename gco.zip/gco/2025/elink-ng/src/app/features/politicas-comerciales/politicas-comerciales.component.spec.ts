import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PoliticasComercialesComponent } from './politicas-comerciales.component';

describe('PoliticasComercialesComponent', () => {
  let component: PoliticasComercialesComponent;
  let fixture: ComponentFixture<PoliticasComercialesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PoliticasComercialesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PoliticasComercialesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
