import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalAtributosSICComponent } from './modal-atributos-sic.component';

describe('ModalAtributosSICComponent', () => {
  let component: ModalAtributosSICComponent;
  let fixture: ComponentFixture<ModalAtributosSICComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModalAtributosSICComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModalAtributosSICComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
