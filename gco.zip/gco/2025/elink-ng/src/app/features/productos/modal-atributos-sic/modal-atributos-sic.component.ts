import { Component, OnInit } from "@angular/core";
import { BsModalRef } from "ngx-bootstrap/modal";
import { Subject } from "rxjs";
import { ReferenciaVtexDto } from "src/app/shared/clases/referencia-vtex-dto";
import { IAtributoReferencia } from "src/app/shared/Interfaces/iatributo-referencia";
import { AtributosService } from "src/app/shared/service/atributos.service";
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: "elk-modal-atributos-sic",
  templateUrl: "./modal-atributos-sic.component.html",
  styleUrls: ["./modal-atributos-sic.component.css"],
})
export class ModalAtributosSICComponent implements OnInit {
  titulo: string;
  closeBtnName: string;
  aceptarBtnName: string;
  referencia: ReferenciaVtexDto;
  idCanal: number;
  lstAtributos: IAtributoReferencia[];

  public onClose: Subject<Date>;

  constructor(
    public bsModalRef: BsModalRef,
    public atribService: AtributosService,
    private spinner: NgxSpinnerService
  ) {}

  ngOnInit() {
    this.onClose = new Subject();
    
    this.spinner.show();

    this.atribService
      .listarAtributosReferencia(
        this.referencia.ano,
        this.referencia.codReferencia,
        this.referencia.codProveedor,
        this.idCanal
      )
      .subscribe({
        next: (data) => {
        console.log(data);
        this.lstAtributos = data;
        this.spinner.hide();},
        
        error: (err) => {
          console.error(err);
          this.spinner.hide();
        },
      });
  }

  asignarFechaLanzamiento() {}

  public confirmar(): void {
    this.bsModalRef.hide();
  }

  public cancelar(): void {
    this.onClose.next();
    this.bsModalRef.hide();
  }
}
