import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductosComponent } from './productos.component';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { SharedModule } from 'src/app/shared/shared.module';
import { FormsModule } from '@angular/forms';
import { ModalModule } from 'ngx-bootstrap/modal';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NgxSpinnerModule } from 'ngx-spinner';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { NgSelectModule } from '@ng-select/ng-select';
import { UiSwitchModule } from 'ngx-ui-switch';
import { DetalleProductosComponent } from './detalle-productos/detalle-productos.component';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

describe('ProductosComponent', () => {
    let component: ProductosComponent;
    let fixture: ComponentFixture<ProductosComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [
                SharedModule,
                FormsModule,
                ModalModule.forRoot(),
                HttpClientTestingModule,
                NgxSpinnerModule,
                NgSelectModule,
                UiSwitchModule,
                PaginationModule.forRoot(),
                PopoverModule.forRoot(),
                TooltipModule.forRoot(),
                BsDatepickerModule.forRoot(),
                AccordionModule.forRoot(),
                BrowserAnimationsModule
            ],
            declarations: [
                ProductosComponent,
                DetalleProductosComponent
            ]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ProductosComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('Debe consultar productos.', () => {

        spyOn(component , 'consultar').and.callThrough();
        component.consultar();
        expect(component.consultar).toHaveBeenCalled();

    });

    it('No debe validar obligatorios.', () => {

        const validado = component.validarObligatorios();

        expect(validado).toBe(false);

    });

    it('Debe validar obligatorios año y colección.', () => {

        component.canalSeleccionado = null;

        // const parametros = component.parametros;
        component.parametros.ano = 2018;
        component.parametros.coleccion = '1';

        fixture.detectChanges();

        const validado = component.validarObligatorios();

        expect(validado).toBe(true);

    });

    it('Debe validar obligatorios año y referencias', () => {

        component.canalSeleccionado = null;
        component.parametros.ano = 2018;
        component.parametros.referencias = `1123
        1234
        3455`;

        fixture.detectChanges();

        const validado = component.validarObligatorios();

        expect(validado).toBe(true);

    });

});
