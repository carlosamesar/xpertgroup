import { Component, OnInit } from "@angular/core";
import { BsModalRef } from "ngx-bootstrap/modal";
import { Subject } from "rxjs";
import { DescripcionGpt } from "src/app/shared/clases/descripcion-gpt";
import { Empresa } from "src/app/shared/clases/empresa";
import { ReferenciaVtexDto } from "src/app/shared/clases/referencia-vtex-dto";
import { DescripcionGptService } from "src/app/shared/service/descripciones-gpt.service";
import { AlertaService } from "src/app/shared/service/alerta.service";
import { NgxSpinnerService } from "ngx-spinner";
import { AtributoIADto } from "src/app/shared/clases/atributo-ia-dto";
import { AtributoIAResponseDTO } from "src/app/shared/clases/atributo-ia-response-dto";

@Component({
  selector: "elk-modal-descripciones-gpt",
  templateUrl: "./modal-descripciones-gpt.component.html",
  styleUrls: ["./modal-descripciones-gpt.component.css"],
})
export class ModalGenerarDescripcionesComponent implements OnInit {
  titulo: string;
  closeBtnName: string;
  aceptarBtnName: string;
  referencia: ReferenciaVtexDto;
  empresa: Empresa;
  lstDescription: DescripcionGpt;
  DescriptionIaResponse: AtributoIAResponseDTO;
  description: string;
  nomComercial :string;
  AtributoIA :AtributoIADto[];
  btnActivo: boolean;
  canal: number;
  public onClose: Subject<Date>;
  classAcordion = "customClass";

  constructor(
    public bsModalRef: BsModalRef,
    public descService: DescripcionGptService,
    private alertaService: AlertaService,
    private spinner: NgxSpinnerService,
    private alerta: AlertaService
    ) { }
  

  ngOnInit() {
    this.description=this.referencia.descripcion;
   this.nomComercial=this.referencia.nombreComercial;

 this.DescriptionIaResponse = {
      name: '',
      description: '',
      sensation: '',
      use: '',
      recommendation: '',
      features: '',
      care_instructions: '',
      meta_tags: '',
      meta_data: { tile: '', description: '' },
      img_description: '',
      model_size: '',
      notes: ''

    };

   this.generar();
  }


  public confirmar(): void {
    this.bsModalRef.hide();
  }

  public cancelar(): void {
    this.onClose.next();
    this.bsModalRef.hide();
  }
  public generar(): void {
    let descGpt= new DescripcionGpt();
    this.onClose = new Subject();

    descGpt =({
      id: this.referencia.codReferencia,
      name: this.referencia.nombreComercial,
      product: this.referencia.nomCategoria,
      brand: this.empresa.nomMarca,
      composition: [this.referencia.composicion],
      fit: this.referencia.fit,
      atributo:this.referencia.atributo,
      gender:this.referencia.gender,
      url_image:this.referencia.imgArray


    });
  console.log(descGpt);
  this.spinner.show();
    this.descService
      .Generar(
        descGpt)
      .subscribe((data) => {
        this.spinner.hide();
        this.DescriptionIaResponse = data;
        this.btnActivo=true;
      },
      
        (error) => {
          this.spinner.hide();
          this.alertaService.mostrar(
            "Ocurrió un error consultando los atributos"
          );
          console.error(error);
        });
  }

  public guardarAtributos(): void {
    const mensaje = 'Confirmar el reemplazo de los atributos?.';

    this.alerta.confirmar(mensaje).subscribe(rtn => {

      // Respuesta exitosa
      if (rtn) {
    this.AtributoIA=[];

    this.AtributoIA.push({
      referencia: this.referencia.codReferencia,
      empresa : this.empresa.codEmpresa,
      descripcion : this.DescriptionIaResponse.description,
      nombre : this.DescriptionIaResponse.name,
      canal: this.canal,
      sensation : this.DescriptionIaResponse.sensation,
      use : this.DescriptionIaResponse.use,
      recommendation : this.DescriptionIaResponse.recommendation, 
      features :   this.DescriptionIaResponse.features,
      careInstructions :    this.DescriptionIaResponse.care_instructions,
      metaTags :  this.DescriptionIaResponse.meta_tags,
      medaDataTile: this.DescriptionIaResponse.meta_data.tile ,
      medaDataDescription: this.DescriptionIaResponse.meta_data.description ,
      imgDescription:this.DescriptionIaResponse.img_description,
      modelSize:this.DescriptionIaResponse.model_size,
      notes:this.DescriptionIaResponse.notes
    })
    

    this.spinner.show();
    this.descService
      .GuardarAtributo(
        this.AtributoIA)
      .subscribe((data) => {
        this.spinner.hide();
        this.description = this.DescriptionIaResponse.description ;
        this.nomComercial = this.DescriptionIaResponse.name ;
        this.lstDescription = data;
        this.alertaService.mostrar(
          "Se han actualizado correctamente los atributos"
        );
        this.btnActivo=false;
        this.referencia.descripcion=this.description;       
         this.referencia.nombreComercial=this.nomComercial;

      },
      
        (error) => {
          this.spinner.hide();
          this.alertaService.mostrar(
            "Ocurrió un error guardando los atributos"
          );
          console.error(error);
        });
   };
  });
}

}
