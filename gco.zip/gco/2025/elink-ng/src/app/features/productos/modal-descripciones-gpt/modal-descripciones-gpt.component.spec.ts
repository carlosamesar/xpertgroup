import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalGenerarDescripcionesComponent } from './modal-descripciones-gpt.component';

describe('ModalGenerarDescripcionesComponent', () => {
  let component: ModalGenerarDescripcionesComponent;
  let fixture: ComponentFixture<ModalGenerarDescripcionesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModalGenerarDescripcionesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModalGenerarDescripcionesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
