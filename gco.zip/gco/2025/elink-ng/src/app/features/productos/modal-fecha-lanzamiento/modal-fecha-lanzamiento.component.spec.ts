import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalFechaLanzamientoComponent } from './modal-fecha-lanzamiento.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { FormsModule } from '@angular/forms';
import { ModalModule, BsModalRef } from 'ngx-bootstrap/modal';

describe('ModalFechaLanzamientoComponent', () => {
    let component: ModalFechaLanzamientoComponent;
    let fixture: ComponentFixture<ModalFechaLanzamientoComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [
                SharedModule,
                FormsModule,
                ModalModule.forRoot(),
                /*ReactiveFormsModule,
                HttpClientModule,
                
                PaginationModule.forRoot(),
                PopoverModule.forRoot(),
                TooltipModule.forRoot(),
                */
                BsDatepickerModule.forRoot(),
            ],
            declarations: [ModalFechaLanzamientoComponent],
            providers: [BsModalRef]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ModalFechaLanzamientoComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
