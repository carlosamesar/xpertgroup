import { Component, OnInit } from '@angular/core';
import { EquivalenciaDto } from 'src/app/shared/clases/equivalencia-dto';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { AlertaService } from 'src/app/shared/service/alerta.service';
import { Subject } from 'rxjs';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';

@Component({
    selector: 'elk-modal-fecha-lanzamiento',
    templateUrl: './modal-fecha-lanzamiento.component.html',
    styleUrls: ['./modal-fecha-lanzamiento.component.css']
})
export class ModalFechaLanzamientoComponent implements OnInit {

    titulo: string;
    closeBtnName: string;
    aceptarBtnName: string;
    fechaLanzamiento = new Date();
    bsConfig: Partial<BsDatepickerConfig>;
    minDate: Date = null;
    maxDate: Date = null;

    public onClose: Subject<Date>;

    constructor(public bsModalRef: BsModalRef,
                private alertaService: AlertaService) { }

    ngOnInit() {
        this.onClose = new Subject();
        
        // Configuración explícita para permitir cualquier fecha
        this.bsConfig = {
            dateInputFormat: 'YYYY-MM-DD',
            containerClass: 'theme-red',
            showWeekNumbers: false,
            adaptivePosition: true,
            minDate: undefined,
            maxDate: undefined
        };
        
        // Asegurar que minDate y maxDate sean null para eliminar restricciones
        this.minDate = null;
        this.maxDate = null;
    }

    asignarFechaLanzamiento() {

    }

    public confirmar(): void {
        this.onClose.next(this.fechaLanzamiento);
        this.bsModalRef.hide();
    }

    public cancelar(): void {
        this.onClose.next(null);
        this.bsModalRef.hide();
    }

}
