import { Component, OnInit, ChangeDetectionStrategy, Input, OnChanges, SimpleChanges, Output, EventEmitter } from '@angular/core';
import { ReferenciaVtexDto } from 'src/app/shared/clases/referencia-vtex-dto';
import { NoEsCargablePipe } from 'src/app/shared/pipes/no-es-cargable.pipe';
import { FechaPipe } from 'src/app/shared/pipes/fecha.pipe';
import { BsModalService, ModalOptions } from 'ngx-bootstrap/modal';
import { environment } from 'src/environments/environment';
import { ModalAsignacionEquivalenciaComponent } from '../../equivalencias/modal-asignacion-equivalencia/modal-asignacion-equivalencia.component';
import { DatePipe } from '@angular/common';
import { ImagenRendererComponent } from 'src/app/shared/componentes/imagen-renderer/imagen-renderer.component';
import { GridOptions, ValueGetterParams } from 'ag-grid-community';
import { CaritasRendererComponent } from 'src/app/shared/componentes/caritas-renderer/caritas-renderer.component';
import { ReferenciaRendererComponent } from 'src/app/shared/componentes/referencia-renderer/referencia-renderer.component';
import { DescripcionRendererComponent } from 'src/app/shared/componentes/descripcion-renderer/descripcion-renderer.component';
import { ComposicionRendererComponent } from 'src/app/shared/componentes/composicion-renderer/composicion-renderer.component';
import { FechaRendererComponent } from 'src/app/shared/componentes/fecha-renderer/fecha-renderer.component';
import * as moment from 'moment';
import { ModalAtributosSICComponent } from '../modal-atributos-sic/modal-atributos-sic.component';
import { ModalGenerarDescripcionesComponent } from '../modal-descripciones-gpt/modal-descripciones-gpt.component';
import { StaticInjector } from '@angular/core/src/di/injector';
import { Empresa } from 'src/app/shared/clases/empresa';


@Component({
  selector: 'elk-detalle-productos',
  templateUrl: './detalle-productos.component.html',
  styleUrls: ['./detalle-productos.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [
      NoEsCargablePipe,
      FechaPipe,
      DatePipe
  ]
})
export class DetalleProductosComponent implements OnInit, OnChanges {

  // tslint:disable-next-line:no-input-rename
  @Input('data') listaReferenciasSrc: ReferenciaVtexDto[];

  @Input() idCanal: number;
  @Input() empresa: Empresa;


  @Output() registrosSeleccionados = new EventEmitter<ReferenciaVtexDto[]>();

  // listaReferencias: ReferenciaVtexDto[];
  refsSeleccionadas: ReferenciaVtexDto[] = [];
  seleccionadosTodos = false;
  html: string;
  columnasGrid = [];

  context;
  frameworkComponents;
  gridApi;
  gridColumnApi;
  gridOptions: GridOptions;


  constructor(private modalService: BsModalService,
              private noEsCargablePipe: NoEsCargablePipe,
              private datePipe: DatePipe) {

    if (!this.listaReferenciasSrc) {
        this.listaReferenciasSrc = [];
    }

    const esFilaSeleccionable = (rowNode) => {

      const noEsCargable = this.noEsCargablePipe.transform(rowNode.data as ReferenciaVtexDto);
      return !noEsCargable;
      
    };

    const onCambioSeleccion = (event) => {

      this.gridApi.forEachNodeAfterFilter( (node, index) => {

      });
        
      this.refsSeleccionadas = event.api.getSelectedRows() as ReferenciaVtexDto[];

      // Emito el evento de selección de registros
      this.registrosSeleccionados.emit(this.refsSeleccionadas);

    };

    this.gridOptions = {
      columnDefs: this.crearColumnasGrid(),
      context: { componentParent: this },
      rowHeight: 120,
      headerHeight: 45,
      enableCellTextSelection: true,
      enableColResize: true,
      defaultColDef: {
        sortable: true,
        filter: true
      },
      rowSelection: 'multiple',
      suppressRowClickSelection: true,
      isRowSelectable: (params) => {

        const noEsCargable = this.noEsCargablePipe.transform(params.data as ReferenciaVtexDto);
        return !noEsCargable;
        
      },
      onSelectionChanged: onCambioSeleccion,
      
      frameworkComponents: {
        imagenRenderer: ImagenRendererComponent,
        caritasRenderer: CaritasRendererComponent,
        referenciaRenderer: ReferenciaRendererComponent,
        descripcionRenderer: DescripcionRendererComponent,
        composicionRenderer: ComposicionRendererComponent,
        fechaRenderer: FechaRendererComponent
      }
    } as GridOptions as GridOptions;

  }


  ngOnInit() {
  }

  private crearColumnasGrid() {

    const fvalueGetter = (params: ValueGetterParams) => {
      return params.data;
    };

    return [
      {
        colId: '1',
        headerName: 'Imagen',
        field: 'urlImagen',
        headerCheckboxSelection: true,
        headerCheckboxSelectionFilteredOnly: true,
        cellRenderer: 'imagenRenderer',
        width: 110,
        valueGetter: fvalueGetter,
        comparator: (valueA, valueB) => {

          if (valueA.urlImagen > valueB.urlImagen) {
            return 1;
          }

          if (valueA.urlImagen < valueB.urlImagen) {
            return -1;
          }

          return 0;
        },
        checkboxSelection: (params) => {

          const noEsCargable = this.noEsCargablePipe.transform(params.data as ReferenciaVtexDto);
          return !noEsCargable;
          
        }
      },
      {
        colId: '2',
        headerName: 'Referencia / Talla / Color',
        valueGetter: fvalueGetter,
        comparator: (valueA, valueB) => {

          if (valueA.codReferencia > valueB.codReferencia) {
            return 1;
          }

          if (valueA.codReferencia < valueB.codReferencia) {
            return -1;
          }

          return 0;
        },
        filterParams: {
          valueGetter: params => {

            const origen = params.data.indOrigen === 'N' ? 'NACIONAL': 'IMPORTADO';

            const strFiltro = (params.data.codReferencia || ' ') +
              (params.data.equivTalla || ' ') +
              (params.data.nomColor || ' ') +
              (params.data.equivColor || ' ') + origen;

            return  strFiltro;
          }
        },
        cellRenderer: 'referenciaRenderer',
        width: 110,
      },
      {
        colId: '3',
        headerName: 'Descripción',
        field: 'descripcion',
        valueGetter: fvalueGetter,
        comparator: (valueA, valueB) => {

          if ((valueA.descripcion || '') > (valueB.descripcion || '')) {
            return 1;
          }

          if ((valueA.descripcion || '') < (valueB.descripcion || '')) {
            return -1;
          }

          return 0;
        },
        filterParams: {
          valueGetter: params => {

            const strFiltro = (params.data.codReferencia || ' ') +
              (params.data.nomReferencia || ' ') +
              (params.data.descripcion || ' ');

            return  strFiltro;
          }
        },
        cellRenderer: 'descripcionRenderer',
        width: 120
      },
      {
        colId: '4',
        headerName: 'Composición',
        width: 110,
        valueGetter: fvalueGetter,
        comparator: (valueA, valueB) => {

          if ((valueA.composicion || '') > (valueB.composicion || '')) {
            return 1;
          }

          if ((valueA.composicion || '') < (valueB.composicion || '')) {
            return -1;
          }

          return 0;
        },
        filterParams: {
          valueGetter: params => {

            const strFiltro = (params.data.codReferencia || ' ') +
              (params.data.equivComposicion || ' ') +
              (params.data.composicion || ' ') + 
              ((params.data.colorFamily && params.data.colorFamily.length() > 0 ? 'CON COLOR FAMILY' : 'SIN COLOR FAMILY'));

            return  strFiltro;
          }
        },
        cellRenderer: 'composicionRenderer'
      },
      {
        colId: '5',
        headerName: 'ID. vtex',
        field: 'idMarketplace',
        width: 60,
        filterParams: {
          valueGetter: params => {

            if (!params.data.idMarketplace || params.data.idMarketplace.trim() === '') {
              return '-1';
            }
            
            return  params.data.idMarketplace;

          }
        }
      },
      {
        colId: '6',
        headerName: 'Fec. lanz.',
        width: 90,
        valueGetter: fvalueGetter,
        comparator: (valueA, valueB) => {

          if ((valueA.fechaLanzamiento || 0) > (valueB.fechaLanzamiento || 0)) {
            return 1;
          }

          if ((valueA.fechaLanzamiento || 0) < (valueB.fechaLanzamiento || 0)) {
            return -1;
          }

          return 0;
        },
        filterParams: {
          valueGetter: params => {

            const fecha = new Date(params.data.fechaLanzamiento);

            return moment(fecha).format('YYYY-MM-DD HH:mm:ss');
          }
        },
        cellRenderer: 'fechaRenderer'
      },

      {
        colId: '7',
        headerName: 'Desc?',
        field: 'tieneDescripcion',
        width: 50,
        cellRenderer: 'caritasRenderer',
      },
      {
        colId: '8',
        headerName: 'Img?', field: 'tieneImagen',
        width: 50,
        cellRenderer: 'caritasRenderer',
      },
      {
        colId: '10',
        headerName: 'Talla?', field: 'tieneTalla',
        width: 45,
        cellRenderer: 'caritasRenderer'
      },
      {
        colId: '11',
        headerName: 'Color?', field: 'tieneColor',
        width: 45,
        cellRenderer: 'caritasRenderer'
      },
      {
        colId: '12',
        headerName: 'Cat?', field: 'tieneCategoria',
        width: 45,
        cellRenderer: 'caritasRenderer'
      },
      {
        colId: '13',
        headerName: 'Act?', field: 'actualizado',
        width: 45,
        cellRenderer: 'caritasRenderer'
      },
      {
        colId: '14',
        headerName: 'Referencia',
        valueGetter: (params: ValueGetterParams) => {
          return `${params.data.codProveedor}_${params.data.codReferencia.trim()}_${params.data.color.trim()}`;
        },
        hide: true
      },
      {
        colId: '15',
        headerName: 'Talla',
        valueGetter: (params: ValueGetterParams) => {
          return params.data.talla + ' | ' + params.data.equivTalla;
        },
        hide: true
      },
      {
        colId: '16',
        headerName: 'Color',
        valueGetter: (params: ValueGetterParams) => {
          return params.data.color + ' | ' + params.data.nomColor;
        },
        hide: true
      },
      {
        colId: '17',
        headerName: 'Plu',
        valueGetter: (params: ValueGetterParams) => {
          return params.data.codPlu;
        },
        hide: true
      },
      {
        colId: '18',
        headerName: 'Descrip',
        valueGetter: (params: ValueGetterParams) => {
          return params.data.descripcion;
        },
        hide: true
      },
      {
        colId: '19',
        headerName: 'Compsicion',
        valueGetter: (params: ValueGetterParams) => {
          return params.data.equivComposicion;
        },
        hide: true
      },
      {
        colId: '20',
        headerName: 'Categoria',
        valueGetter: (params: ValueGetterParams) => {
          return params.data.nomCategoria;
        },
        hide: true
      },
      {
        colId: '21',
        headerName: 'Fec lanzamiento',
        valueGetter: (params: ValueGetterParams) => {

          const fecha = new Date(params.data.fechaLanzamiento);

          return moment(fecha).format('YYYY-MM-DD HH:mm:ss');
        },
        hide: true
      },
      {
        colId: '22',
        headerName: 'Fec carga',
        valueGetter: (params: ValueGetterParams) => {

          if (params.data.fechaCarga && params.data.fechaCarga > 0) {

            const fecha = new Date(params.data.fechaCarga);
            return moment(fecha).format('YYYY-MM-DD HH:mm:ss');

          }

          return '';
          
        },
        hide: true
      },
      {
        colId: '23',
        headerName: 'SIC?', field: 'atributoSic',
        width: 45,
        cellRenderer: 'caritasRenderer'
      },
      {
        colId: '24',
        headerName: 'ID. Referencia',
        field: 'idReferencia',
        width: 60,
        filterParams: {
          valueGetter: params => {

            if (!params.data.idReferencia || params.data.idReferencia.trim() === '') {
              return '-1';
            }
            
            return  params.data.idReferencia;

          }
        },
        hide: true
      },
      
    ];

  }

  
  ngOnChanges(changes: SimpleChanges): void {

      console.log('changes detalle');
      if (!this.listaReferenciasSrc) {
          this.listaReferenciasSrc = [];
      }

      this.refsSeleccionadas = [];

      setTimeout(() => {
        // this.actualizarImagenes(this.listaReferenciasSrc);
      }, 100);

  }

  actualizarImagenes(listaRefs: ReferenciaVtexDto[]) {

    console.log('actualizarImagenes :::::: ');
    
    const arrUrls = Array.from(new Set(listaRefs.map(refs => refs.urlImagen)));

    const validarImagen = (url) => {

      const promesa = new Promise((resolve, reject) => {
        
        const imagenNotFound = (evt) => {

          console.log('imagenNotFound :::::: ');
          
          listaRefs.forEach(ref => {
  
            if (ref.urlImagen === evt.srcElement.currentSrc) {
              ref.tieneImagen = false;
            }
  
          });

          resolve('');
          
        };

        const imagenExiste = (evt) => {

          resolve('');
          
        };

        const testImg = new Image();
        testImg.src = url;
        testImg.onerror = imagenNotFound;
        testImg.onload = imagenExiste;

      });
      

      return promesa;

    };

    const arrayPromesas = [];

    arrUrls.forEach(url => {

      arrayPromesas.push(validarImagen(url));

    });

    Promise.all(arrayPromesas).then(() => {

      this.listaReferenciasSrc = listaRefs;

      this.gridOptions.api.setRowData(listaRefs);

    });

  }


  public crearColor(item: ReferenciaVtexDto) {

      console.log('item', item);

      if (!item.nomColor) {
          return;
      }

      const estadoInicial = new ModalOptions();
      estadoInicial.class = 'modal-lg';
      estadoInicial.initialState = {
          titulo: 'Asignar color',
          closeBtnName: 'Cancelar',
          aceptarBtnName: 'Aceptar',
          valor: item.nomColor,
          tipoEquivalencia: environment.equivalencias.TIPO_COLOR
      };

      this.modalService.show(ModalAsignacionEquivalenciaComponent, estadoInicial);

  }


  crearComposicion(item: ReferenciaVtexDto) {

      console.log('item', item);

      const estadoInicial = new ModalOptions();
      estadoInicial.class = 'modal-lg';
      estadoInicial.initialState = {
          titulo: 'Asignar composición',
          closeBtnName: 'Cancelar',
          aceptarBtnName: 'Aceptar',
          valor: item.composicion,
          tipoEquivalencia: environment.equivalencias.TIPO_COMPOSICION
      };

      this.modalService.show(ModalAsignacionEquivalenciaComponent, estadoInicial);

  }


  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;

    params.api.sizeColumnsToFit();

  }

  public exportarDatos() {

    const fecha = new Date();

    const fecStr = moment(fecha).format('YYYYMMDD_HHmmss');

    const params = {
      allColumns: false,
      suppressQuotes: false,
      fileName: `productos_${fecStr}.csv`,
      columnSeparator: ',',
      columnKeys: ['5', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '1']
    };

    this.gridApi.exportDataAsCsv(params);

  }

  public verAtributos(item: ReferenciaVtexDto) {

    console.log('item', item);

    if (!item.nomColor) {
        return;
    }

    const estadoInicial = new ModalOptions();
    estadoInicial.class = 'modal-lg';
    estadoInicial.initialState = {
        titulo: 'Atributos de la referencia',
        closeBtnName: 'Cancelar',
        aceptarBtnName: 'Aceptar',
        referencia: item,
        idCanal: this.idCanal
    };

    this.modalService.show(ModalAtributosSICComponent, estadoInicial);

  }
  public generarDescripcion(item: ReferenciaVtexDto) {

    console.log('item', item);

    if (!item.nomColor) {
        return;
    }

    const estadoInicialDesc = new ModalOptions();
    estadoInicialDesc.class = 'modal-xl';
    estadoInicialDesc.initialState = {
        titulo: 'Generador de Atributos',
        closeBtnName: 'Cancelar',
        aceptarBtnName: 'Aceptar',
        referencia: item,
        empresa: this.empresa,
        canal:this.idCanal
    };

    
    this.modalService.show(ModalGenerarDescripcionesComponent, estadoInicialDesc);

  }
}
