import { fillChanels, fillCompany } from "src/app/shared/utils/listar-canales";
import { Canales } from "./../../shared/clases/canales";
import { Empresa } from "./../../shared/clases/empresa";
import {
  Component,
  OnInit,
  ChangeDetectionStrategy,
  ViewChild,
} from "@angular/core";
import { ProductosService } from "src/app/shared/service/productos.service";
import { ReferenciaVtexDto } from "src/app/shared/clases/referencia-vtex-dto";
import { Parametros } from "src/app/shared/clases/parametros";
import { Marketplace } from "src/app/shared/clases/marketplace";
import { MarketplaceService } from "src/app/shared/service/marketplace.service";
import { BsModalService, ModalOptions, BsModalRef } from "ngx-bootstrap/modal";
import { ModalAsignacionEquivalenciaComponent } from "../equivalencias/modal-asignacion-equivalencia/modal-asignacion-equivalencia.component";
import { environment } from "src/environments/environment";
import { NoEsCargablePipe } from "src/app/shared/pipes/no-es-cargable.pipe";
import { ModalFechaLanzamientoComponent } from "./modal-fecha-lanzamiento/modal-fecha-lanzamiento.component";
import { AlertaService } from "src/app/shared/service/alerta.service";
import { FechaPipe } from "src/app/shared/pipes/fecha.pipe";
import { NgxSpinnerService } from "ngx-spinner";
import { CategoriasService } from "src/app/shared/service/categorias.service";
import { DetalleProductosComponent } from "./detalle-productos/detalle-productos.component";
import { AtributosService } from "src/app/shared/service/atributos.service";
import * as XLSX from "xlsx";
import * as FileSaver from "file-saver";
import { Resource } from "src/app/shared/clases/resource";

@Component({
  selector: "elk-productos",
  templateUrl: "./productos.component.html",
  styleUrls: ["./productos.component.css"],
  providers: [NoEsCargablePipe, FechaPipe],
})
export class ProductosComponent implements OnInit {
  @ViewChild(DetalleProductosComponent) elkDetProd: DetalleProductosComponent;
  listaReferencias: ReferenciaVtexDto[];
  exportacionAtributosSic: any[];
  //listaRefOriginal: ReferenciaVtexDto[];
  refSeleccionadas: ReferenciaVtexDto[];
  classAcordion = "customClass";
  parametros: Parametros;
  listaEmpresa: Empresa[];
  listaCanal: Canales[];
  filtroListaCanal: Canales[];
  empresaSeleccionada: Empresa;
  canalSeleccionado: null;
  filtroAdicional: string;
  verSinDescripcion = false;
  enviado = false;
  esSeleccionado = false;
  resources: Resource;

  modalRef: BsModalRef;

  constructor(
    private productosService: ProductosService,
    private marketService: MarketplaceService,
    private modalService: BsModalService,
    private fechaPipe: FechaPipe,
    private alertaService: AlertaService,
    private spinner: NgxSpinnerService,
    private categoriaService: CategoriasService,
    private atributosService: AtributosService,
  ) {}

  ngOnInit() {
    this.parametros = new Parametros();
    this.resources = JSON.parse(localStorage.getItem('recursosElink'));

    this.marketService.obtenerEmpresas( this.resources.marca).subscribe((data) => {
      this.listaEmpresa = data;
    });
  }

  esEcommerce(checked: boolean) {
    this.esSeleccionado = checked
    console.log(this.esSeleccionado)
    if(this.esSeleccionado){
      this.parametros.ecommerce = 'NO'
    }
  }
  
  consultar(): boolean {
    this.enviado = true;

    /*if (!this.validarObligatorios()) {
            return false;
        }*/

    if (this.parametros.referencias) {
      const arrayReferencias = this.parametros.referencias.split("\n");
      console.log(arrayReferencias);
      this.parametros.referencias64 = btoa(JSON.stringify(arrayReferencias));
    } else {
      this.parametros.referencias64 = "-1";
    }
 
    this.spinner.show();

    this.productosService.consultar(this.parametros).subscribe(
      (respuesta) => {     
        console.log(respuesta);

        // Reemplazo la fecha del servidor por un new date
        if (respuesta) {
          this.spinner.hide();

          respuesta.forEach((obj) => {
            obj.fechaLanzamiento = this.fechaPipe.transform(
              obj.fechaLanzamiento
            );
          });

          // this.listaRefOriginal = [];
          this.listaReferencias = [];

          // this.listaRefOriginal = respuesta;
          this.exportacionAtributosSic = [];
          var sizeRespuesta = respuesta.length;
          console.log("respuesta");
          console.log(respuesta);
          this.exportacionAtributosSic =
            respuesta[sizeRespuesta - 1].exportacionAtributosSic;
          respuesta[sizeRespuesta - 1].exportacionAtributosSic = [];
          this.listaReferencias = respuesta;
          console.log("this.exportacionAtributosSic");
          console.log(this.exportacionAtributosSic);

          // Filtro la lista
          this.changeFiltro();

        }
      },
      (error) => {
        this.spinner.hide();
        if(error.error.message == "-1" || error.error.status == 500){
          this.limpiarReferencias();
        }
        console.log(error.error.message)
      }
    );
    return true;
  }

  exportarAtributos(): boolean {
    this.enviado = true;

    if (!this.validarObligatorios()) {
      return false;
    }

    if (this.parametros.referencias) {
      const arrayReferencias = this.parametros.referencias.split("\n");
      this.parametros.referencias64 = btoa(JSON.stringify(arrayReferencias));
    } else {
      this.parametros.referencias64 = "-1";
    }

    this.spinner.show();

    this.atributosService
      .listarAtributosReferenciaCol(this.parametros, this.canalSeleccionado)
      .subscribe(
        (respuesta) => {
          console.log(respuesta);
          this.spinner.hide();
          const ws = XLSX.utils.json_to_sheet(respuesta);

          /* add to workbook */
          const wb = XLSX.utils.book_new();
          XLSX.utils.book_append_sheet(wb, ws, "atributos");

          /* generate an XLSX file */
          XLSX.writeFile(wb, "atributos.xlsx");
        },
        (error) => {
          this.spinner.hide();
        }
      );

    return true;
  }

  exportarAtributosS(): boolean {
    // chevignon, Amcno y Esprit
    let marketPlaceHabilitado = [2, 4, 1];

    if (!marketPlaceHabilitado.includes(this.canalSeleccionado)) {
      this.alertaService.mostrar(
        "La empresa no corresponde a una de la empresas habilitadas para este proceso"
      );
      return;
    }

    if (!this.parametros.referencias) {
      this.alertaService.mostrar(
        "Para este proceso las lista de referencias es obligatoria"
      );
      return;
    }

    this.enviado = true;

    const arrayReferencias = this.parametros.referencias.split("\n");
    this.parametros.referencias64 = btoa(JSON.stringify(arrayReferencias));

    this.spinner.show();

    this.atributosService
      .listarAtributosReferenciaSicKliiker(
        this.parametros,
        this.canalSeleccionado
      )
      .subscribe(
        (respuesta) => {
          if (respuesta.length === 0) {
            this.spinner.hide();
            this.alertaService.mostrar(
              "No se encontraron datos para esa referencia"
            );
          } else {
            console.log(respuesta);
            this.spinner.hide();
            const ws = XLSX.utils.json_to_sheet(respuesta);

            const wb = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(wb, ws, "Sic - kliiker");

            XLSX.writeFile(wb, "sic-kliiker.xlsx");
          }
        },
        (error) => {
          this.spinner.hide();
        }
      );

    return true;
    
  }

  exportarAtributosSic(): boolean {
    this.enviado = true;

    if (!this.validarObligatorios()) {
      return false;
    }

    if (this.parametros.referencias) {
      var arrayReferencias = this.parametros.referencias.split("\n");
      this.parametros.referencias64 = btoa(JSON.stringify(arrayReferencias));
      if (arrayReferencias.length >= 500) {
        this.alertaService.mostrar(
          "Ha ingresado mas de 500 referencias, el limite para procesar son 500. Puede presentar lentitud o problemas al ingresar más"
        );
      } else {
        this.alertaService.mostrar(
          "Recuerde que se consultará información de cada plu asociada a cada referencia que ingrese, por lo cual el proceso puede tardar varios minutos."
        );
      }
    } else {
      this.parametros.referencias64 = "-1";
      this.alertaService.mostrar(
        "Recuerde que se consultará información de cada plu asociada a cada referencia relacionada al año y colección que ingrese, por lo cual el proceso puede tardar varios minutos"
      );
    }

    this.spinner.show();
    this.atributosService.exportarAtributosSic(this.parametros).subscribe(
      (respuesta) => {
        console.log(respuesta);
        this.spinner.hide();
        const ws = XLSX.utils.json_to_sheet(respuesta);
        /* add to workbook */
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "atributos");
        /* generate an XLSX file */
        XLSX.writeFile(wb, "atributosSic.xlsx");
        // this.alertaService.mostrar('El archivo se ha descargado en su equipo');
      },
      (error) => {
        this.spinner.hide();
      }
    );

    return true;
  }

  downloadAttributes(data?: any) {
    if (this.exportacionAtributosSic) {
      const ws = XLSX.utils.json_to_sheet(this.exportacionAtributosSic);
      /* add to workbook */
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "atributos");
      /* generate an XLSX file */
      XLSX.writeFile(wb, "atributos.xlsx");
    } else {
      this.alertaService.mostrar(
        "No hay datos para descargar, debe realizar la consulta primero"
      );
    }
  }

  limpiar() {
    this.refSeleccionadas = [];
    this.listaReferencias = [];
    this.parametros = new Parametros();
    this.enviado = false;
    this.empresaSeleccionada = null;
    this.filtroListaCanal = null;
    this.canalSeleccionado = null;
  }

  limpiarReferencias() {
    this.refSeleccionadas = [];
    this.listaReferencias = [];
  }

  changeFiltro() {
    /*
        setTimeout(() => {
    
            console.log('filtro adicional', this.filtroAdicional);
            console.log('verSinDescripcion ', this.verSinDescripcion);
    
            if (!this.listaRefOriginal || this.listaRefOriginal.length === 0) {
                return;
            }
    
            // Ejecuto el filtro adicional
            if (!this.filtroAdicional || this.filtroAdicional.length === 0) {
                this.listaReferencias = this.listaRefOriginal;
            } else {
    
                this.listaReferencias = this.listaRefOriginal.filter(referencia => {
    
                    return  (referencia.codPlu.includes(this.filtroAdicional)) ||
                            (referencia.descripcion && referencia.descripcion.includes(this.filtroAdicional)) ||
                            (referencia.codReferencia && referencia.codReferencia.includes(this.filtroAdicional)) ||
                            (referencia.equivComposicion && referencia.equivComposicion.includes(this.filtroAdicional)) ||
                            (referencia.equivColor && referencia.equivColor.includes(this.filtroAdicional));
     
                });
    
            }
            
            // Ejecuto el filtro de ver sin descripción
            if (this.verSinDescripcion) {
    
                console.log('Filtrando ver sin descripción');
    
                this.listaReferencias = this.listaReferencias.filter(referencia => {
    
                    if (referencia.descripcion) {
                        return false;
                    } else {
                        return true;
                    }
    
                    
     
                });
    
            } else {
    
            }
    
        }, 50);
        */
  }

  crearComposicion(item: ReferenciaVtexDto) {
    console.log("item", item);

    const estadoInicial = new ModalOptions();
    estadoInicial.class = "modal-lg";
    estadoInicial.initialState = {
      titulo: "Asignar composición",
      closeBtnName: "Cancelar",
      aceptarBtnName: "Aceptar",
      valor: item.composicion,
      tipoEquivalencia: environment.equivalencias.TIPO_COMPOSICION,
    };

    this.modalService.show(ModalAsignacionEquivalenciaComponent, estadoInicial);
  }

  /* seleccionarMarketPlace(event?: any) {

        if (!event) {
            this.parametros.nombre = null;
            this.parametros.id = null;
            this.parametros.marca = null;
        } else {
            this.parametros.nombre = event.nombre;
            this.parametros.id = event.id;
            this.parametros.marca = event.marca;
            
        }
        console.log(this.parametros)
    } */

  listarEmpresas(): void {
    fillCompany.bind(this)();
  }

  listarCanales(): void {
    fillChanels.bind(this)();
  }

  seleccionarCanal(): void {
    const canal = this.filtroListaCanal.find(
      (canal) => canal.id === this.canalSeleccionado
    );
    if (canal) {
      this.parametros.nombre = canal.nombre;
      this.parametros.id = canal.id;
      this.parametros.marca = canal.marca;
      console.log(this.parametros);
    } else {
      this.parametros.nombre = null;
      this.parametros.id = null;
      this.parametros.marca = null;
    }
    console.log(canal);
  }

  asignarFechaLanzamiento() {
    if (!this.refSeleccionadas || this.refSeleccionadas.length === 0) {
      this.alertaService.mostrar(
        "No existen registros para asignar fecha de lanzamiento."
      );
      return;
    }

    const estadoInicial = new ModalOptions();
    estadoInicial.class = "modal-md";
    estadoInicial.initialState = {
      titulo: "Asignar fecha de lanzamiento",
      closeBtnName: "Cancelar",
      aceptarBtnName: "Aceptar",
    };

    this.modalRef = this.modalService.show(
      ModalFechaLanzamientoComponent,
      estadoInicial
    );

    this.modalRef.content.onClose.subscribe((respuesta) => {
      console.log("Nueva fecha de lanzamiento!!!", respuesta);
      let idReferencia;
      if (respuesta) {
        // Filtro el array y luego a cada elemento le asigno la fecha
        // Programación funcional bebé!!!!
        this.refSeleccionadas.forEach((refe) => {
          refe.fechaLanzamiento = respuesta;
          idReferencia = refe.idReferencia;
        });
        console.log(idReferencia);
        this.spinner.show();

        this.productosService
          .asignarFechaLanzamiento(
            this.refSeleccionadas,
            parseInt(this.parametros.id),
            idReferencia
          )
          .subscribe(
            (rtn) => {
              this.spinner.hide();
              console.log(rtn);
              this.alertaService.mostrar("Fecha actualizada exitosamente.");
            },
            (error) => {
              this.spinner.hide();
              console.log(error);
              this.alertaService.mostrar(
                "Ocurrió un error asignando la fecha de lanzamiento."
              );
            }
          );
      }
    });
  }

  enviarAlOutlet() {
    const enviarOutlet = () => {
      console.log("this.marketSeleccionado", this.canalSeleccionado);

      // Valido que por lo menos exista un registro seleccionado
      const idx = this.listaReferencias.findIndex((refer) => {
        return refer.seleccionado === true;
      });

      if (idx === -1) {
        this.alertaService.mostrar(
          "Debe seleccionar por lo menos una referencia para enviar al outlet."
        );
        return;
      }

      const arrayRefs = this.listaReferencias
        .map((refe) => refe.codReferencia)
        .filter((x, i, a) => a.indexOf(x) === i);

      console.log(arrayRefs);

      this.spinner.show();

      this.categoriaService
        .trasladarCategoriasProdutoOutlet(this.canalSeleccionado, arrayRefs)
        .subscribe(
          (data) => {
            console.log(data);
            this.alertaService.mostrar(
              "Seleccionadas: " +
                arrayRefs.length +
                ". Enviadas al outlet: " +
                data.length
            );

            this.spinner.hide();
          },
          (error) => {
            this.alertaService.mostrar(
              "Ocurrió un error enviando referencias al outlet"
            );

            this.spinner.hide();
          }
        );
    };

    this.alertaService
      .confirmar(
        "Está seguro se enviar las referencias seleccionadas al outlet?"
      )
      .subscribe((data) => {
        if (data) {
          enviarOutlet();
        }
      });
  }

  onChangeSwtich(evento: any) {
    setTimeout(() => {
      console.log("evento", evento);
      console.log("verSindesc", this.verSinDescripcion);
    }, 50);
  }

  validarObligatorios(campo?: string): boolean {
    const arrayCampos = ["empresa", "ano", "coleccion", "referencias", "canal"];

    if (!campo) {
      let esValido = true;

      arrayCampos.forEach((camp) => {
        // Solo si no se cumple alguna validación, retorno false
        if (!this.validarObligatorios(camp)) {
          esValido = false;
        }
      });

      return esValido;
    }

    // Validación de la empresa
    if (campo === arrayCampos[0]) {
      if (this.empresaSeleccionada == null) {
        return false;
      }
    }

    // Validación del año
    // Solo valido el año si no se han seleccionado referencias
    if (campo === arrayCampos[1]) {
      if (!this.parametros.referencias && !this.parametros.ano) {
        return false;
      }
    }

    // Solo valido la colección si no existen referencias seleccionadas
    if (campo === arrayCampos[2]) {
      if (!this.parametros.referencias && !this.parametros.coleccion) {
        return false;
      }
    }

    // Solo valido las referencias si no se han seleccionado
    // el año y la colección
    if (campo === arrayCampos[3]) {
      if (
        !this.parametros.ano &&
        !this.parametros.coleccion &&
        !this.parametros.referencias
      ) {
        return false;
      }
    }
    // Validación del canal
    if (campo === arrayCampos[4]) {
      if (!this.canalSeleccionado) {
        return false;
      }
    }

    return true;
  }

  downloadFile(data?: any) {
    this.elkDetProd.exportarDatos();
    /*
        try {
            const replacer = (key, value) => value === null ? '' : value; // specify how you want to handle null values here
    
            const header = Object.keys(data[0]);
            const csv = data.map(row => header.map(fieldName => JSON.stringify(row[fieldName], replacer)).join(','));
            csv.unshift(header.join(','));
            const csvArray = csv.join('\r\n');
    
            console.log('exportando', csvArray);
        
            const a = document.createElement('a');
            const blob = new Blob([csvArray], {type: 'text/csv;charset=utf-8' });
    
            const url = window.URL.createObjectURL(blob);
    
            window.open(url);
    
        } catch (error) {
            console.log(error);
        }
        */
  }

  integrarProductos() {
    this.spinner.show();

    this.productosService
      .integrarProductos(this.parametros.marca.toString())
      .subscribe(
        (data) => {
          console.log(data);
          this.alertaService.mostrar(
            "La carga de productos se agendó satisfactoriamente"
          );
        },
        (error) => {
          console.error(error);
          this.alertaService.mostrar(
            "Ocurrió un error agendando la carga de productos"
          );
          this.spinner.hide();
        },
        () => this.spinner.hide()
      );
  }

  onRegistrosSeleccionados(event: ReferenciaVtexDto[]) {
    console.log("onRegistrosSeleccionados ::: ", event);
    this.refSeleccionadas = event;
  }
}
