import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DetalleProductosComponent } from './detalle-productos.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ModalModule } from 'ngx-bootstrap/modal';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('DetalleProductosComponent', () => {
    let component: DetalleProductosComponent;
    let fixture: ComponentFixture<DetalleProductosComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [
                SharedModule,
                FormsModule,
                ReactiveFormsModule,
                HttpClientTestingModule,
                ModalModule.forRoot(),
                PaginationModule.forRoot(),
                PopoverModule.forRoot(),
                TooltipModule.forRoot(),
                BsDatepickerModule.forRoot(),
            ],
            declarations: [DetalleProductosComponent]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(DetalleProductosComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
