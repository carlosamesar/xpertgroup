import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImportArchivoCatProdComponent } from './import-archivo-cat-prod.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ModalModule } from 'ngx-bootstrap/modal';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from 'src/app/shared/shared.module';

describe('ImportArchivoCatProdComponent', () => {
    let component: ImportArchivoCatProdComponent;
    let fixture: ComponentFixture<ImportArchivoCatProdComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [
                SharedModule,
                FormsModule,
                ReactiveFormsModule,
                HttpClientTestingModule,
                ModalModule.forRoot()
            ],
            declarations: [ImportArchivoCatProdComponent],
            
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ImportArchivoCatProdComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
