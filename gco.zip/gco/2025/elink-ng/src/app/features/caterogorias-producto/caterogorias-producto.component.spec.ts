import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaterogoriasProductoComponent } from './caterogorias-producto.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';
import { TreeModule } from 'angular-tree-component';
import { HttpClientModule } from '@angular/common/http';
import { ModalModule } from 'ngx-bootstrap/modal';
import { ArbolCategoriasComponent } from '../arbol-categorias/arbol-categorias.component';
import { ContainerComponent } from '../container/container.component';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { ImportArchivoCatProdComponent } from './import-archivo-cat-prod/import-archivo-cat-prod.component';
import { NgxSpinnerModule } from 'ngx-spinner';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('CaterogoriasProductoComponent', () => {
    let component: CaterogoriasProductoComponent;
    let fixture: ComponentFixture<CaterogoriasProductoComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [
                FormsModule,
                ReactiveFormsModule,
                NgSelectModule,
                TreeModule.forRoot(),
                HttpClientTestingModule,
                ModalModule.forRoot(),
                TabsModule.forRoot(),
                NgxSpinnerModule
            ],
            declarations: [
                CaterogoriasProductoComponent,
                ArbolCategoriasComponent,
                ContainerComponent,
                ImportArchivoCatProdComponent
            ]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(CaterogoriasProductoComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
