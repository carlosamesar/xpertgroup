import { Empresa } from "./../../shared/clases/empresa";
import { Canales } from "./../../shared/clases/canales";
import { Component, OnInit, ViewChildren, QueryList, ElementRef, ViewChild, } from "@angular/core";
import { FormGroup, FormBuilder, Validators, FormArray, FormControl } from "@angular/forms";
import { AlertaService } from "src/app/shared/service/alerta.service";
import { CategoriasService } from "src/app/shared/service/categorias.service";
import { MarketplaceService } from "src/app/shared/service/marketplace.service";
import { Categoria } from "src/app/shared/clases/categoria";
import { CategoriaProducto } from "src/app/shared/clases/categoria-producto";
import { NgxSpinnerService } from "ngx-spinner";
import { Observable } from "rxjs";
import { CategoriaProductoDto } from "src/app/shared/clases/categoria-producto-dto";
import { ArbolCategoriasComponent } from "../arbol-categorias/arbol-categorias.component";

@Component({
  selector: "elk-caterogorias-producto",
  templateUrl: "./caterogorias-producto.component.html",
  styleUrls: ["./caterogorias-producto.component.css"],
})
export class CaterogoriasProductoComponent implements OnInit {
  @ViewChild(ArbolCategoriasComponent)
  arbolCat: ArbolCategoriasComponent;
  
  formulario: FormGroup = new FormGroup({});
  items: FormArray;
  submitted = false;
  esCanalSeleccionado = false;
  idCanalSel: string;
  listaCanal: Canales[];
  canalSeleccionado: Canales;
  empresaSeleccionada: Empresa;
  filtroListaCanal: Canales[];
  lstCatProd: CategoriaProducto[] = [];
  categoriaSeleccionada: Categoria;
  observable = Observable;
  @ViewChildren("miFormulario") miFormulario: QueryList<ElementRef>;

  constructor(
    private marketService: MarketplaceService,
    private categoriaService: CategoriasService,
    private alertaService: AlertaService,
    private formBuilder: FormBuilder,
    private spinner: NgxSpinnerService
  ) {}

  ngOnInit() {
    this.canalSeleccionado = new Canales();

    // Configuro el forulario
    this.formulario = this.formBuilder.group({
      detalle: this.formBuilder.array([]),
    });

    this.spinner.show();
    this.marketService.obtenerMarketPlaces().subscribe(
      (data) => {
        this.listaCanal = data;
        this.spinner.hide();
      },
      (error) => {
        this.spinner.hide();
        this.alertaService.mostrar("Error consultando los market places.");
      }
    );
  }

  // convenience getter for easy access to form fields
  get f() {
    return this.formulario.controls;
  }

  get detalleArray() {
    return this.formulario.get("detalle") as FormArray;
  }

  set detalleArray(forma: FormArray) {
    this.formulario.controls.detalle = forma;
  }

  crearItemTodos(catProducto: CategoriaProducto[]) {
    this.items = this.formBuilder.array([]);

    catProducto.forEach((catPro) => {
      const form = this.formBuilder.group({
        campCodigo: [
          catPro.elkCategoriasMarketPlace.campCodigo,
          Validators.required,
        ],
        cmprProductoErp: [catPro.cmprProductoErp, Validators.required],
        cmprBrandMarket: [catPro.cmprBrandMarket, Validators.required],
        codColor: catPro.codColor,
      });

      form.controls["cmprProductoErp"].disable({
        onlySelf: true,
        emitEvent: true,
      });

      // Me suscribo a los cambios de valor del formulario
      
      /* form.valueChanges.subscribe(data => {

        console.log('this.formulario.valueChanges', data);

      }); */
            

      this.items.push(form);
    });

    this.detalleArray = this.items;
  }

  crearItem(catProducto: CategoriaProducto): FormGroup {
    return this.formBuilder.group({
      campCodigo: [
        catProducto.elkCategoriasMarketPlace.campCodigo,
        Validators.required,
      ],
      cmprProductoErp: [catProducto.cmprProductoErp, Validators.required],
      cmprBrandMarket: [catProducto.cmprBrandMarket, Validators.required],
      codColor: catProducto.codColor,
    });
  }

  adicionarDetalle() {
    const categoriaProd = new CategoriaProducto();

    categoriaProd.elkCategoriasMarketPlace = this.categoriaSeleccionada;
    categoriaProd.cmprBrandMarket = "";
    categoriaProd.cmprProductoErp = "";
    categoriaProd.codColor = "";

    const longitud = this.lstCatProd.push(categoriaProd);

    this.detalleArray.push(this.crearItem(this.lstCatProd[longitud - 1]));

    // Pongo el foco en el nuevo campo
    setTimeout(() => {
      this.miFormulario.last.nativeElement.cells[2].children[0].focus();
      this.miFormulario.last.nativeElement.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
    }, 80);
  }

  guardar(itemForm: FormGroup, index?: number) {
    if (!itemForm) {
      return;
    }

    if (itemForm.invalid) {
      return;
    }

    const catProducto = this.crearCategoriaProductoDto(index);

    console.log("catProducto", catProducto);

    this.spinner.show();

    this.categoriaService.guardarPorProducto(catProducto).subscribe(
      (data) => {
        this.spinner.hide();
        this.alertaService.mostrar("Categoría guardada exitosamente.");
        this.lstCatProd[index].cmprUid = data.cmprUid;
        // catProducto.idCategoriaProducto = data.cmprUid;
      },
      (error) => {
        this.spinner.hide();
        console.log(error);
        this.alertaService.mostrar(
          "Ocurrió un error asignando el producto a la categoría."
        );
      }
    );
  }

  inactivar(itemForm: FormGroup, index?: number) {
    const eliminar = (indice) => {
      this.detalleArray.removeAt(indice);
      this.lstCatProd.splice(indice, 1);
    };

    this.alertaService
      .confirmar("Está seguro de eliminar el producto?")
      .subscribe((data) => {
        if (data === true) {
          const catProducto = this.crearCategoriaProductoDto(index);

          if (!catProducto.idCategoriaProducto) {
            eliminar(index);
          }

          this.spinner.show();

          this.categoriaService.inactivarPorProducto(catProducto).subscribe(
            (resp) => {
              this.spinner.hide();
              eliminar(index);
              this.alertaService.mostrar("Registro eliminado exitosamente.");
            },
            (error) => {
              this.spinner.hide();
              console.log(error);
            }
          );
        }
      });
  }

  limpiar() {
    this.lstCatProd = [];
    this.detalleArray = this.formBuilder.array([]);
    this.esCanalSeleccionado = false;
    this.arbolCat.canalSeleccionado = null;
    this.arbolCat.empresaSeleccionada = null;
    this.arbolCat.filtroListaCanal = null;
    this.arbolCat.existenNodos = false;

    this.formulario.reset();
  }

  onSeleccionCanal(evento: any) {
    console.log("onSeleccionCanal", evento);

    this.canalSeleccionado = evento;
    this.esCanalSeleccionado = true;
  }

  onBorradoCanal() {
    this.esCanalSeleccionado = false;
  }

  onNodoActivo(evento: any) {
    if (evento.node.data.categoria) {
      this.categoriaSeleccionada = evento.node.data.categoria;
      const categoria: Categoria = evento.node.data.categoria;

      this.spinner.show();
      this.categoriaService
        .obtenerCategoriasPorProducto(
          this.canalSeleccionado.id,
          categoria.campUid
        )
        .subscribe(
          (data) => {
            console.log(this.categoriaSeleccionada);

            this.lstCatProd = data;

            this.crearItemTodos(this.lstCatProd);

            this.suscribirCambiosDetalleForm();

            this.spinner.hide();
          },
          (error) => {
            this.spinner.hide();
            this.alertaService.mostrar(
              "Error consultando las categorías por producto."
            );
          }
        );
    } else {
    }
  }

  private crearCategoriaProductoDto(index: number): CategoriaProductoDto {
    const catProdActual = this.lstCatProd[index];

    console.log("catProdActual", catProdActual);

    if (!catProdActual.cmprProductoErp) {
      catProdActual.cmprProductoErp =
        this.detalleArray.controls[index].get("cmprProductoErp").value;
    }

    if (!catProdActual.codColor) {
      catProdActual.codColor =
        this.detalleArray.controls[index].get("codColor").value;
    }

    console.log("crearCategoriaProductoDto", catProdActual);

    const catProducto = new CategoriaProductoDto();

    catProducto.brand = catProdActual.cmprBrandMarket;
    catProducto.idCategoria = catProdActual.elkCategoriasMarketPlace.campUid;
    catProducto.idCategoriaProducto = catProdActual.cmprUid;
    catProducto.idMarketPlace = this.canalSeleccionado.id;
    catProducto.productoCategoria = catProdActual.cmprProductoErp;
    catProducto.codigoCategoria =
    catProdActual.elkCategoriasMarketPlace.campCodigo;
    catProducto.codColor = catProdActual.codColor;

    return catProducto;
  }

  private suscribirCambiosDetalleForm() {
    // Me suscribo a los cambios de valor del form array
    this.detalleArray.valueChanges.subscribe((valores) => {
      valores.forEach((elem, i) => {
        this.lstCatProd[i].cmprBrandMarket = elem.cmprBrandMarket;
        this.lstCatProd[i].cmprProductoErp = elem.cmprProductoErp;
      });
    });
  }

  guardarDetalle(index) {
    console.log(index);
  }
}
