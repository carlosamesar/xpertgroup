import { Component, OnInit, Input, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import * as XLSX from 'xlsx';
import { Marketplace } from 'src/app/shared/clases/marketplace';
import { NgxSpinnerService } from 'ngx-spinner';
import { CategoriaProductoDto } from 'src/app/shared/clases/categoria-producto-dto';
import { CategoriasService } from 'src/app/shared/service/categorias.service';
import { AlertaService } from 'src/app/shared/service/alerta.service';


@Component({
    selector: 'elk-import-archivo-cat-prod',
    templateUrl: './import-archivo-cat-prod.component.html',
    styleUrls: ['./import-archivo-cat-prod.component.css']
})
export class ImportArchivoCatProdComponent implements OnInit, OnChanges {

    @Input() data: Marketplace;
    @Input() deshabilitado: false;
    @Output() archivoImportado: EventEmitter<any>;
    archivoCargado: string;
    archivoSrc: string;
    arrayBuffer: any;
    columnas: string[];
    excelRows = [];
    arrayCategoriasProd: CategoriaProductoDto[] = [];
    objectKeys = Object.keys;

    constructor(private spinner: NgxSpinnerService,
                private categoriasService: CategoriasService,
                private alertaService: AlertaService) {

        console.log('constructor ImportArchivoCatProdComponent');

    }

    ngOnInit() {

        console.log('ImportArchivoCatProdComponent');

    }

    ngOnChanges(changes: SimpleChanges): void {

        console.log('changes', changes);
        console.log('data', this.data);

    }

    handleInputChange(e) {

        this.excelRows = [];

        this.archivoCargado = e.target.files[0].name;
        const file = e.dataTransfer ? e.dataTransfer.files[0] : e.target.files[0];

        const pattern = /application\/vnd-*/;

        const reader = new FileReader();
        
        if (!file.type.match(pattern)) {
            alert('Formato no permitido');
            return;
        }

        if (reader.readAsBinaryString) {

            reader.onload = this.handleReaderLoaded.bind(this);
            reader.readAsBinaryString(file);

        }

    }

    private handleReaderLoaded(e) {

        const reader = e.target;
        this.procesarExcel(reader.result);

    }

    private procesarExcel(data) {

        const workbook = XLSX.read(data, {
            type: 'binary'
        });

        // Fetch the name of First Sheet.
        const firstSheet = workbook.SheetNames[0];

        // Read all rows from First Sheet into an JSON array.
        this.excelRows = XLSX.utils.sheet_to_json(workbook.Sheets[firstSheet]);
        this.columnas = Object.keys(this.excelRows[0]);

        console.log('this.columnas', this.columnas);

    }

    cargarArchivo() {

        console.log(this.excelRows);

        this.arrayCategoriasProd = this.excelRows.map(row => {

            const catProducto = new CategoriaProductoDto();

            catProducto.idCategoriaProducto = null;
            catProducto.idMarketPlace = this.data.id;
            catProducto.codigoCategoria = row.categoria;
            catProducto.productoCategoria = row.referencia;
            catProducto.brand = row.brand;
            catProducto.codColor = row.color;

            return catProducto;

        });

        this.spinner.show();

        this.categoriasService.guardarPorProductoMasivo(this.arrayCategoriasProd).subscribe(data => {

            console.log('Resultado del import', data);
            this.alertaService.mostrar('Archivo procesado exitosamente.');
            this.spinner.hide();

        }, error => {

            this.spinner.hide();

            if (error.error) {

                this.alertaService.mostrar(error.error.message);

            } else {

                this.alertaService.mostrar('Ocurrió un error importando las categorías por producto');
                
            }
            
            console.error(error);

        });

    }

}
