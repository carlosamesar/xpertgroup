import { Component, OnInit, Input } from '@angular/core';

@Component({
    selector: 'elk-container',
    templateUrl: './container.component.html',
    styleUrls: ['./container.component.css']
})
export class ContainerComponent implements OnInit {

    @Input() nombre: string;

    constructor() { }

    ngOnInit() {
    }

}
