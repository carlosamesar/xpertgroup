import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CategoriasComponent } from './categorias.component';
import { ReactiveFormsModule } from '@angular/forms';
import { ArbolCategoriasComponent } from '../arbol-categorias/arbol-categorias.component';
import { NgSelectModule } from '@ng-select/ng-select';
import { TreeModule } from 'angular-tree-component';
import { ModalModule } from 'ngx-bootstrap/modal';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('CategoriasComponent', () => {
    let component: CategoriasComponent;
    let fixture: ComponentFixture<CategoriasComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [
                ReactiveFormsModule,
                NgSelectModule,
                TreeModule.forRoot(),
                HttpClientTestingModule,
                ModalModule.forRoot(),
            ],
            declarations: [
                CategoriasComponent,
                ArbolCategoriasComponent
            ]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(CategoriasComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
