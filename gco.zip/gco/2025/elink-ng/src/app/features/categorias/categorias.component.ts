import { fillChanels, fillCompany } from "src/app/shared/utils/listar-canales";
import { Canales } from "./../../shared/clases/canales";
import { Empresa } from "./../../shared/clases/empresa";
import { Component, OnInit, ViewChild } from "@angular/core";
import { MarketplaceService } from "../../shared/service/marketplace.service";
import { Marketplace } from "../../shared/clases/marketplace";
import { CategoriasService } from "../../shared/service/categorias.service";
import { ArbolCategorias } from "../../shared/clases/arbol-categorias";
import { Categoria } from "../../shared/clases/categoria";
import { AlertaService } from "../../shared/service/alerta.service";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { ArbolCategoriasComponent } from "../arbol-categorias/arbol-categorias.component";
import { Resource } from "src/app/shared/clases/resource";

@Component({
  selector: "elk-categorias",
  templateUrl: "./categorias.component.html",
  styleUrls: ["./categorias.component.css"],
})
export class CategoriasComponent implements OnInit {
  @ViewChild(ArbolCategoriasComponent)
  arbolCat: ArbolCategoriasComponent;

  formulario: FormGroup;

  idCanalSel: number;
  empresaSeleccionada: Empresa;
  canalSeleccionado: Canales;
  listaEmpresa: Empresa[];
  listaCanal: Canales[];
  filtroListaCanal: Canales[];
  arbolCategorias = new ArbolCategorias();
  opcionesArbol = {};
  existenNodos = false;
  listaNodos: ArbolCategorias[] = [];
  categoriaSeleccionada: Categoria = new Categoria();
  nodoSeleccionado = new ArbolCategorias();
  submitted = false;
  esNodoSeleccionado = false;
  resources: Resource;

  constructor(
    private marketService: MarketplaceService,
    private categoriaService: CategoriasService,
    private alertaService: AlertaService,
    private formBuilder: FormBuilder
  ) {}

  ngOnInit() {
    // Configuro el forulario
    this.formulario = this.formBuilder.group({
      codigo: ["", Validators.required],
      padre: ["", Validators.required],
      nombre: ["", Validators.required],
      codigoOutlet: "",
      codigoEquivalente: "",
    });
    this.resources = JSON.parse(localStorage.getItem('recursosElink'));

    this.marketService.obtenerEmpresas( this.resources.marca).subscribe((data) => {
      this.listaEmpresa = data;
    });
  }

  // convenience getter for easy access to form fields
  get f() {
    return this.formulario.controls;
  }

  public onNodoActivo(evento: any) {
    if (!evento.node.data.categoria) {
      this.categoriaSeleccionada = new Categoria();
      this.esNodoSeleccionado = false;
    } else {
      this.esNodoSeleccionado = true;
      this.nodoSeleccionado = evento.node;
      this.categoriaSeleccionada = evento.node.data.categoria;

      const nombreCat = this.categoriaSeleccionada.campNombre
        .substring(0, this.categoriaSeleccionada.campNombre.indexOf("("))
        .trim();

      this.formulario.patchValue({
        codigo: this.categoriaSeleccionada.campCodigo,
        padre: this.categoriaSeleccionada.campCategoPadre,
        nombre: nombreCat,
        codigoOutlet: this.categoriaSeleccionada.campCategoOutlet,
        codigoEquivalente: this.categoriaSeleccionada.campCodEquivalente,
        //id:this.marketSeleccionado.id,
      });

      this.formulario.controls["codigo"].disable({
        onlySelf: true,
        emitEvent: true,
      });
      this.formulario.controls["padre"].disable({
        onlySelf: true,
        emitEvent: true,
      });
      //this.formulario.controls['id'].disable({onlySelf: true, emitEvent: true});
    }
  }

  guardar(formulario: FormGroup) {
    this.submitted = true;

    // stop here if form is invalid
    if (formulario.invalid) {
      return;
    }

    this.alertaService
      .confirmar("Está seguro guardar la categoría?")
      .subscribe((respuesta) => {
        if (respuesta) {
          this.crearGuardar(formulario);
        }
      });
  }

  limpiar() {
    this.arbolCat.empresaSeleccionada = null;
    this.arbolCat.filtroListaCanal = null;
    this.arbolCat.canalSeleccionado = null;
    this.esNodoSeleccionado = false;
    this.existenNodos = false;
    this.submitted = false;
    this.categoriaSeleccionada = new Categoria();
    this.formulario.reset();
  }

  inactivar(formulario) {
    this.submitted = true;

    // stop here if form is invalid
    if (formulario.invalid) {
      return;
    }

    // Si tiene hijos, no dejo eliminar
    if (this.nodoTieneHijos(this.categoriaSeleccionada.campCodigo)) {
      this.alertaService.mostrar(
        "La categoría " +
          this.categoriaSeleccionada.campCodigo +
          " tiene categorías hijas."
      );
      return;
    }

    this.alertaService
      .confirmar("Está seguro elimiar la categoría?")
      .subscribe((respuesta) => {
        if (respuesta) {
          console.log(this.categoriaSeleccionada);
          (this.categoriaSeleccionada.elkCanalMae = this.canalSeleccionado),
            this.categoriaService
              .inactivar(this.categoriaSeleccionada)
              .subscribe(
                () => {
                  this.alertaService.mostrar(
                    "Categoría eliminada existosamente."
                  );
                  this.listaNodos = [];
                  this.limpiar();
                },
                (error) => {
                  this.alertaService.mostrar(
                    "Ocurrió un error inactivando la categoría."
                  );
                }
              );
        }
      });
  }

  private crearGuardar(formulario: FormGroup) {
    const formRaw = formulario.getRawValue();

    // Asigno los valores del formulario a la clase
    this.categoriaSeleccionada.campCodigo = formRaw.codigo;
    this.categoriaSeleccionada.campCategoPadre = formRaw.padre;
    this.categoriaSeleccionada.campNombre = formulario.value.nombre;
    this.categoriaSeleccionada.campCategoOutlet = formulario.value.codigoOutlet;
    this.categoriaSeleccionada.campCodEquivalente = formulario.value.codigoEquivalente;

    if (!this.validarCodigo(this.categoriaSeleccionada)) {
      return;
    }

    if (this.formulario.value.codigo === "0" && this.formulario.value.padre === "0") {
      this.categoriaSeleccionada.campCategoPadre = null;
    }

    if (!this.categoriaSeleccionada.elkCanalMae) {
      this.categoriaSeleccionada.elkCanalMae = this.canalSeleccionado;
    }

    this.categoriaService.guardar(this.categoriaSeleccionada).subscribe(
      (data) => {
        // Actualizo la pk de la categoría
        this.categoriaSeleccionada.campUid = data.campUid;

        // actualizo el arbol de categorias
        this.arbolCat.seleccionarCanal(this.canalSeleccionado);

        this.alertaService.mostrar("Categoría guarda existosamente.");
      },
      (error) => {
        this.alertaService.mostrar("Ocurrió un error guardando la categoría.");
      }
    );
  }

  
  seleccionarCanal(event: any): void {
    if (this.canalSeleccionado) {
      this.idCanalSel = parseInt(this.canalSeleccionado.id);

    }
    console.log(event);
  }

  onSeleccionCanal(event): void {
    
    this.canalSeleccionado = event as Canales;
  }

  validarCodigo(categoriaSeleccionada?: Categoria) {
    let cod: string;
    let codigo: string;

    if (categoriaSeleccionada) {
      cod = categoriaSeleccionada.campCodigo;
    }

    if (cod) {
      codigo = cod;
    } else {
      codigo = this.formulario.value.codigo;
    }

    console.log("change", codigo);
    console.log("Lista nodos", this.arbolCat.listaCategorias);

    const idx = this.arbolCat.listaCategorias.findIndex((catego) => {
      return catego.campCodigo === codigo;
    });

    if (idx >= 0) {
      let duplicado = true;

      // Valido si la categoría seleccionada tiene la pk asociada.
      if (
        categoriaSeleccionada &&
        categoriaSeleccionada.campUid &&
        categoriaSeleccionada.campUid > 0
      ) {
        const categoEncontrada = this.arbolCat.listaCategorias[idx];

        if (categoEncontrada.campUid === categoriaSeleccionada.campUid) {
          duplicado = false;
        }
      }

      if (duplicado) {
        this.alertaService.mostrar("El código " + codigo + " ya existe.");
        this.formulario.patchValue({
          codigo: null,
        });

        return false;
      }
    }

    return true;
  }

  nodoTieneHijos(codigoNodo: string) {
    const idx = this.arbolCat.listaCategorias.findIndex((catego) => {
      return catego.campCategoPadre === codigoNodo;
    });

    // El nodo tiene hijos asociadoas
    if (idx >= 0) {
      return true;
    }

    return false;
  }
}
