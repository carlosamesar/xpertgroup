import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EquivalenciasComponent } from './equivalencias.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';
import { TreeModule } from 'angular-tree-component';
import { ModalModule } from 'ngx-bootstrap/modal';
import { ContainerComponent } from '../container/container.component';
import { NgxSpinnerModule } from 'ngx-spinner';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('EquivalenciasComponent', () => {
    let component: EquivalenciasComponent;
    let fixture: ComponentFixture<EquivalenciasComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [
                FormsModule,
                ReactiveFormsModule,
                NgSelectModule,
                TreeModule.forRoot(),
                HttpClientTestingModule,
                ModalModule.forRoot(),
                NgxSpinnerModule
            ],
            declarations: [
                EquivalenciasComponent,
                ContainerComponent
            ]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(EquivalenciasComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
