import { Component, OnInit, EventEmitter } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { TitleCasePipe } from '@angular/common';
import { EquivalenciasService } from 'src/app/shared/service/equivalencias.service';
import { EquivalenciaDto } from 'src/app/shared/clases/equivalencia-dto';
import { AlertaService } from 'src/app/shared/service/alerta.service';
import { environment } from 'src/environments/environment';
import { CambiaPalabraPipe } from 'src/app/shared/pipes/cambia-palabra.pipe';

@Component({
    selector: 'elk-modal-asignacion-equivalencia',
    templateUrl: './modal-asignacion-equivalencia.component.html',
    styleUrls: ['./modal-asignacion-equivalencia.component.css'],
    providers: [TitleCasePipe, CambiaPalabraPipe]
})
export class ModalAsignacionEquivalenciaComponent implements OnInit {

    titulo: string;
    closeBtnName: string;
    aceptarBtnName: string;
    tipoEquivalencia: number;
    valor: string;
    valorEquivalencia: string;
    lstEquivalencias: EquivalenciaDto[] = [];
    
    constructor(public bsModalRef: BsModalRef,
                private titleCasePipe: TitleCasePipe,
                private cambiaPalabraPipe: CambiaPalabraPipe,
                private equivService: EquivalenciasService,
                private alertaService: AlertaService) { }

    ngOnInit() {
        this.valorEquivalencia = this.titleCasePipe.transform(this.valor).trim();
        
        if (this.tipoEquivalencia === environment.equivalencias.TIPO_COMPOSICION) {
            this.valorEquivalencia = this.cambiaPalabraPipe.transform('Composición ' + this.valorEquivalencia);
        }
    }

    crearEquivalencia() {

        const equivalenciaDto = new EquivalenciaDto();

        equivalenciaDto.tipo = this.tipoEquivalencia;
        equivalenciaDto.valor = this.valor;
        equivalenciaDto.equivalencia = this.valorEquivalencia;

        this.lstEquivalencias.push(equivalenciaDto);

        this.equivService.guardar(this.lstEquivalencias).subscribe(respuesta => {

          this.bsModalRef.hide();
          this.alertaService.mostrar('Equivalencia creada exitosamente');

        }, error => {

            if (error.error.message) {
                this.alertaService.mostrar(error.error.message);
            } else {
                this.alertaService.mostrar('Error creando la equivalencia');
            }
            
            console.log(error);

        });

    }

}
