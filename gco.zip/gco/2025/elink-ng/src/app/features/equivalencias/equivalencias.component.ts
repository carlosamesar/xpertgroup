import { Component, OnInit } from '@angular/core';
import { EquivalenciasService } from 'src/app/shared/service/equivalencias.service';
import { TipoEquivalencia } from 'src/app/shared/clases/tipo-equivalencia';
import { NgxSpinnerService } from 'ngx-spinner';
import { Equivalencia } from 'src/app/shared/clases/equivalencia';
import { EquivalenciaDto } from 'src/app/shared/clases/equivalencia-dto';
import { AlertaService } from 'src/app/shared/service/alerta.service';

@Component({
    selector: 'elk-equivalencias',
    templateUrl: './equivalencias.component.html',
    styleUrls: ['./equivalencias.component.css']
})
export class EquivalenciasComponent implements OnInit {

    listaTipos: TipoEquivalencia[];
    tipoEqSeleccionado: number;
    tipoEquivalencia: TipoEquivalencia;
    listaEquivalencias: Equivalencia[];
    listaEquivalenciasOriginal: Equivalencia[];
    nombre = '';


    nuevasEquivalencias: EquivalenciaDto[] = [];
    deshabilitarNuevo = true;
    filtro: string;

    page: number = 0;
    size: number = 50;
    totalPages: number;
    lastPage: boolean = false; 

    constructor(private equivalenciaService: EquivalenciasService,
                private spinner: NgxSpinnerService,
                private alerta: AlertaService) { }

    
    ngOnInit() {

        // this.nuevaEquivalencia = new EquivalenciaDto();

        this.equivalenciaService.obtenerTipoEquivalencias().subscribe(data => {

            this.listaTipos = data;

        });

    }
    

    seleccionarTipoEquivalencia(event) {

        this.tipoEquivalencia = event;

        this.obtenerEquivalencias();

    }


    obtenerEquivalencias() {

        if (!this.tipoEqSeleccionado) {
            this.deshabilitarNuevo = true;
            return;
        }

        this.deshabilitarNuevo = false;

        if (!this.nombre) {
            this.nombre = '';
        }

        this.nombre = this.nombre.toLowerCase();

        this.spinner.show();

        this.equivalenciaService.obtenerPorTipo(this.tipoEqSeleccionado, this.nombre, this.page, this.size).subscribe(data => {

            console.log('data', data);
            this.listaEquivalencias = data.content;
            this.listaEquivalenciasOriginal = data.content;
            this.totalPages = data.totalPages;
            this.lastPage = data.last;
            this.spinner.hide();

        }, error => {

            this.spinner.hide();

        });

    }

    public trackByFn(indice: number, item: Equivalencia) {

        return item.equiUid;

    }


    insertar() {

        const equivalencia = new EquivalenciaDto();
        this.nuevasEquivalencias.push(equivalencia);

    }
    

    guardar(item: Equivalencia) {

        console.log('item', item);

        const listaEquiv: EquivalenciaDto[] = [];
        const equivalenciaDto = new EquivalenciaDto();

        equivalenciaDto.idEquivalencia = item.equiUid;
        equivalenciaDto.tipo = this.tipoEqSeleccionado;
        equivalenciaDto.valor = item.equiValorOrigen;
        equivalenciaDto.equivalencia = item.equiValorEquivalencia || '';

        listaEquiv.push(equivalenciaDto);

        this.spinner.show();

        this.equivalenciaService.guardar(listaEquiv).subscribe(data => {

            this.spinner.hide();

        }, error => {

            console.log(error);

            if (error.message) {
                this.alerta.mostrar('Error almacenando la equivalencia.\n' + error.message);
            } else {
                this.alerta.mostrar('Error almacenando la equivalencia.\n' + error);
            }
            
            this.spinner.hide();

        });


    }

    inactivar(item: Equivalencia) {

        const mensaje = 'Está seguro de eliminar la equivalencia ' + item.equiValorOrigen + '?';

        this.alerta.confirmar(mensaje).subscribe(rtn => {

            // Respuesta exitosa
            if (rtn) {

                this.spinner.show();

                this.equivalenciaService.eliminar(item.equiUid).subscribe(data => {

                    let idx = this.listaEquivalencias.findIndex(equiv => {
                        return equiv.equiUid === item.equiUid;
                    });

                    if (idx >= 0) {
                        this.listaEquivalencias.splice(idx,1);
                    }

                    idx = this.listaEquivalenciasOriginal.findIndex(equiv => {
                        return equiv.equiUid === item.equiUid;
                    });

                    if (idx >= 0) {
                        this.listaEquivalenciasOriginal.splice(idx,1);
                    }
                    
                    this.spinner.hide();

                }, error => {

                    console.log('error', error);

                    this.alerta.mostrar('Error eliminando la equivalencia.\n' + error.message);
                    this.spinner.hide();

                });
            }

        });

    }

    
    limpiar() {

        this.nuevasEquivalencias = [];
        this.tipoEqSeleccionado = null;
        this.nombre = "";
        this.deshabilitarNuevo = true;
        this.listaEquivalencias = [];
        this.listaEquivalenciasOriginal = [];

    }


    eliminarNuevo(idx: number) {

        console.log('idx', idx);
        this.nuevasEquivalencias.splice(idx, 1);

    }


    guardarTodos() {

        if (!this.nuevasEquivalencias) {
            return;
        }

        // Seteo el tipo de equivalencia a cada elemento del array
        this.nuevasEquivalencias.forEach(equiv => {
            equiv.tipo = this.tipoEqSeleccionado;
        });

        this.spinner.show();

        this.equivalenciaService.guardar(this.nuevasEquivalencias).subscribe(data => {

          console.log(data);

          this.spinner.hide();
          this.alerta.mostrar('Equivalencias creadas exitosamente.');
          this.nuevasEquivalencias = [];

        }, error => {

            console.log(error);
            
            if (error.error) {
                this.alerta.mostrar('Error almacenando la equivalencia.\r\n' + error.error.message);
            } else {
                this.alerta.mostrar('Error almacenando la equivalencia.');
            }
            
            this.spinner.hide();

        });


    }

    filtrar() {
        this.listaEquivalencias = this.listaEquivalenciasOriginal.filter(equivalencia => {
            return equivalencia.equiValorOrigen.includes(this.filtro);
        });

    }

    previousPage() {
        if(this.page - 1 >= 0){
            this.page -= 1
            this.obtenerEquivalencias();
        }
    }

    nextPage() {
        if (this.page + 1 < this.totalPages) {
            this.page += 1
            this.obtenerEquivalencias();
        }
    }

    goToPage(newPage: number) {
        this.page = newPage
        this.obtenerEquivalencias();
    }

    onChangeSelectElements(valueElements){
        
        console.log(this.size);
        this.size = valueElements;
        console.log(this.size);
        this.obtenerEquivalencias();

    }

}
