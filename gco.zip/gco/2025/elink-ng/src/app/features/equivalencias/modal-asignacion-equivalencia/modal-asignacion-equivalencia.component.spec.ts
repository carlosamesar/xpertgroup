import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalAsignacionEquivalenciaComponent } from './modal-asignacion-equivalencia.component';
import { FormsModule } from '@angular/forms';
import { SharedModule } from 'src/app/shared/shared.module';
import { ModalModule, BsModalRef } from 'ngx-bootstrap/modal';
import { HttpClientModule } from '@angular/common/http';
import { TitleCasePipe } from '@angular/common';

describe('ModalAsignacionEquivalenciaComponent', () => {
    let component: ModalAsignacionEquivalenciaComponent;
    let fixture: ComponentFixture<ModalAsignacionEquivalenciaComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [
                FormsModule,
                SharedModule,
                ModalModule.forRoot(),
                HttpClientModule,
            ],
            declarations: [ModalAsignacionEquivalenciaComponent],
            providers: [BsModalRef, TitleCasePipe]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ModalAsignacionEquivalenciaComponent);
        component = fixture.componentInstance;

        component.valor = 'EQUIVALENCIA 1';
        component.valorEquivalencia = 'VLR EQUIVALENCIA 1';
        fixture.detectChanges();

    });

    it('should create', () => {

        component.valor = 'El valor';
        expect(component).toBeTruthy();
    });
});
