import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
import { NgxSpinnerService } from 'ngx-spinner';
import { forkJoin } from 'rxjs';
import { Canales } from 'src/app/shared/clases/canales';
import { Empresa } from 'src/app/shared/clases/empresa';
import { Resource } from 'src/app/shared/clases/resource';
import { IActualizarValeRequestDTO } from 'src/app/shared/Interfaces/iactualizar-vale-request-dto';
import { IValeRequestDTO } from 'src/app/shared/Interfaces/ivale-request-dto';
import { IValeResponseDTO } from 'src/app/shared/Interfaces/ivale-response-dto';
import { MarketplaceService } from 'src/app/shared/service/marketplace.service';
import { ValesService } from 'src/app/shared/service/vales.service';
import { fillChanels, fillCompany } from 'src/app/shared/utils/listar-canales';
import * as XLSX from 'xlsx';

const TODAY = new Date().toISOString().split('T')[0];
const ERROR_VALE = "Fallo al generar el vale.";

@Component({
  selector: 'elk-generar-vales',
  templateUrl: './generar-vales.component.html',
  styleUrls: ['./generar-vales.component.css']
})
export class GenerarValesComponent implements OnInit {
  @ViewChild('modalVales') modalVales: TemplateRef<any>;
  @ViewChild('modalError') modalError: TemplateRef<any>;
  @ViewChild('modalExito') modalExito: TemplateRef<any>;
  @ViewChild('modalRecarga') modalRecarga: TemplateRef<any>;
  canalSeleccionado: any = null;
  modalRef: BsModalRef;
  listaEmpresa: Empresa[];
  listaCanal: Canales[] = [];
  filtroListaCanal: Canales[] = [];
  empresaSeleccionada: Empresa;
  resources: Resource;
  valeForm: FormGroup;
  textoSpinner: string;
  mensajeError: string = '';
  mensajeExito: string = "";
  mensajeRecarga: string = "";
  formattedValue: string = '';
  listaVales: IValeResponseDTO[] = [];
  consutar: boolean = false;
  genear: boolean = true;
  alianzaBuscada: string = '';
  errorVale: string = ERROR_VALE;

  constructor(private fB: FormBuilder,
              private marketService: MarketplaceService,
              private valesService: ValesService,
              private spinner: NgxSpinnerService,
              private modalService: BsModalService,
  ) {
    this.valeForm = this.fB.group({
      empresa: ['', Validators.required],
      canal: ['', Validators.required],
      relationName: ['', Validators.required],
      quantity: ['', [Validators.required, Validators.min(1)]],
      expiringDate: ['', Validators.required],
      restrictedToOwner: ['', Validators.required],
      multipleRedemptions: ['', Validators.required],
      multipleCredits: ['', Validators.required],
      profileId: ['', [Validators.required, Validators.pattern(/^[a-zA-Z0-9_+&*-]+(?:\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,4}$/i)]],
      value : ['', [Validators.required, Validators.min(1000)]],
      name: ['', Validators.required]
    })
   }

  ngOnInit() {
    this.resources = JSON.parse(localStorage.getItem('recursosElink'));

    this.marketService.obtenerEmpresas(this.resources.marca).subscribe((data) => {
      this.listaEmpresa = data;
    });
  }

  listarEmpresas(): void {
    fillCompany.bind(this)();
  }

  listarCanales(): void {
    fillChanels.bind(this)();
  }

  onInputChange(event: any) {
    let rawValue = event.target.value.replace(/\D/g, '');
    let formatted = `$${Number(rawValue).toLocaleString('es-CO')}`;
    this.formattedValue = formatted;
  }

  convertToNumber(value: string): number {
    if (!value) return 0; 

    let numericValue = value.replace(/[^0-9,]/g, '');
    numericValue = numericValue.replace(/\./g, '');  
    numericValue = numericValue.replace(',', '.');
  
    return parseFloat(numericValue);
  }

  consultarVales(){
    this.spinner.show();
    this.textoSpinner = "Consultando bonos...";
    this.valesService.consultarVales(this.alianzaBuscada).subscribe(
      data => {
        this.listaVales = data.sort((a, b) => a.id - b.id);
        this.spinner.hide();
        this.textoSpinner = "";
      },
      error => {
        this.spinner.hide();
        this.textoSpinner = "";
        this.mensajeError =  "No se encontraron bonos para la campaña: " + this.alianzaBuscada;
        this.modalRef = this.modalService.show(this.modalError, { class: 'modal-md', ignoreBackdropClick: true, keyboard: false  });
      }
    );
  }

  generarVale() {
    if (this.valeForm.valid) {
      const value = this.convertToNumber(this.formattedValue);
      this.spinner.show();
      this.textoSpinner = "Generando bonos...";
      const request: IValeRequestDTO = {
        ...this.valeForm.value,
        value: value,
        empresa: this.empresaSeleccionada.codEmpresa,
        canal: this.canalSeleccionado.id + ' - ' + this.canalSeleccionado.descripcion,
        restrictedToOwner: this.valeForm.value.restrictedToOwner === 'SI',
        multipleRedemptions: this.valeForm.value.multipleRedemptions === 'SI',
        multipleCredits: this.valeForm.value.multipleCredits === 'SI',
        emissionDate: TODAY,
        caption: this.valeForm.value.relationName,
        description: this.valeForm.value.relationName,
        usuario: JSON.parse(localStorage.getItem('usuarioElink')).data.username
      }
      this.valesService.generarVales(request)
      .subscribe(
        data => {
        if(data.message){
          this.spinner.hide();
          this.mensajeRecarga = "Se han creado los bonos exitosamente.";
          this.modalRef = this.modalService.show(this.modalRecarga, { class: 'modal-md', ignoreBackdropClick: true, keyboard: false  });
        }
      }, error => {
        this.spinner.hide();
        this.textoSpinner = "";
        this.mensajeError = "Ocurrió un error al crear los bonos. Intenta nuevamente.";
        this.modalRef = this.modalService.show(this.modalError, { class: 'modal-md', ignoreBackdropClick: true, keyboard: false  });
      });
    }else{      
      Object.keys(this.valeForm.controls).forEach(field => {
        const control = this.valeForm.get(field);
        if (control) {
          control.markAsTouched();
        }
      });       
    }
  }

  actualizarVales(){
    this.spinner.show();
    this.textoSpinner = "Recargando bonos...";
    const request: IActualizarValeRequestDTO = {
      nombreAlianza: this.valeForm.value.relationName,
      idVtex: null,
      campana: this.valeForm.value.relationName,
    }
    this.valesService.actualizarVales(request)
    .subscribe(
      data => {
        this.spinner.hide();
        this.textoSpinner = "";
        if (data.message) {
          if (this.modalRef) {
            this.modalRef.hide();
          }
          this.modalRef = this.modalService.show(this.modalVales, { class: 'modal-md', ignoreBackdropClick: true, keyboard: false  });
        }
      }, error => {
        this.spinner.hide();
        this.textoSpinner = "";
        this.mensajeRecarga = "Ocurrió un error al recargar los bonos. Intenta nuevamente.";
        this.modalRef = this.modalService.show(this.mensajeRecarga, { class: 'modal-md', ignoreBackdropClick: true, keyboard: false  });
      }
    );
  }

  recargarVales() {
    this.spinner.show();
    this.textoSpinner = "Actualizando bonos...";
  
    const peticiones = this.listaVales
      .filter(vale => !vale.recargado && vale.idVtex !== null)
      .map(vale => {
        const request: IActualizarValeRequestDTO = {
          id: vale.id,
          nombreAlianza: vale.nombreAlianza,
          campana: vale.campana,
          idVtex: vale.idVtex
        };
        return this.valesService.actualizarVales(request);
      });
  
    if (peticiones.length === 0) {
      this.spinner.hide();
      this.mensajeExito = "No hay bonos pendientes por actualizar.";
      this.modalRef = this.modalService.show(this.modalExito, { 
        class: 'modal-md',
        ignoreBackdropClick: true, 
        keyboard: false
      });
    }
    forkJoin(peticiones).subscribe(
      respuestas => {
        this.spinner.hide();
        console.log("Todas las respuestas", respuestas);
  
        if (respuestas.some(resp => resp.message)) {
          this.mensajeExito = "Se han actualizado los bonos exitosamente.";
          this.modalRef = this.modalService.show(this.modalExito, { 
            class: 'modal-md',
            ignoreBackdropClick: true, 
            keyboard: false
          });
        }
      },
      error => {
        this.spinner.hide();
        this.mensajeError = "Ocurrió un error al recargar los bonos. Intenta nuevamente.";
        this.modalRef = this.modalService.show(this.modalError, { 
          class: 'modal-md', 
          ignoreBackdropClick: true, 
          keyboard: false
        });
      }
    );
  }

  recargarVale(vale: IValeResponseDTO){
    this.spinner.show();
    this.textoSpinner = "Actualizando bono...";
    const request: IActualizarValeRequestDTO = {
      id: vale.id,
      nombreAlianza: vale.nombreAlianza,
      campana: vale.campana,
      idVtex: vale.idVtex
    }
    
    this.valesService.actualizarVales(request)
    .subscribe(
      data => {
        if (data.message) {
          this.spinner.hide();
          console.log("data", data);
          this.mensajeExito = "Se ha actualizado el bono exitosamente.";
          this.modalRef = this.modalService.show(this.modalExito, {class: 'modal-md', ignoreBackdropClick: true, keyboard: false })
        }
      }, error => {
        console.log("error", error);
        this.spinner.hide();
        this.mensajeError = "Ocurrió un error al recargar el bono. Intenta nuevamente.";
        this.modalRef = this.modalService.show(this.modalError, { class: 'modal-md', ignoreBackdropClick: true, keyboard: false  });
      });
    
  }

  exportarExcel() {
    if (this.alianzaBuscada === '') this.alianzaBuscada = this.valeForm.value.relationName;
    
    this.consultarVales();
    const intervalo = setInterval(() => {
      if (this.listaVales.length > 0) {
          clearInterval(intervalo);
          
          const vales = this.listaVales.map(vale => ({
              id: vale.id,
              nombreAlianza: vale.nombreAlianza,
              email: vale.email,
              valor: vale.valor,
              marca: vale.marca,
              estado: vale.estado,
              fechaExpiracion: vale.fechaExpiracion,
              fechaCreacion: vale.fechaCreacion,
              idVtex: vale.idVtex,
              cupon: vale.cupon,
              campana: vale.campana,
              recargado: vale.recargado ? 'Si' : 'No'
          }));

          const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(vales);
          const wb: XLSX.WorkBook = XLSX.utils.book_new();
          XLSX.utils.book_append_sheet(wb, ws, "Vales");
          XLSX.writeFile(wb, `Vales_${TODAY}.xlsx`);
      }
  }, 500);
    
  }

  btnConsultar(){
    this.consutar = true;
    this.genear = false;
    this.resetvalues();
  }

  btnGenerar(){
    this.genear = true;
    this.consutar = false;
    this.resetvalues();
  }

  cerrarModal() {
    if (this.modalRef) {
      this.modalRef.hide();
      this.modalRef = null;
      window.location.reload();
    }
  }

  cerrarModalRecarga() {
    if (this.modalRef) {
      this.modalRef.hide();
      this.modalRef = null;
      this.consultarVales();
    }
  }

  resetvalues(){
    this.valeForm.reset();
    this.listaVales = [];
    this.mensajeError = '';
    this.textoSpinner = '';
    this.alianzaBuscada = '';
    this.formattedValue = '';
    this.canalSeleccionado = null;
    this.empresaSeleccionada = null;
  }
}
