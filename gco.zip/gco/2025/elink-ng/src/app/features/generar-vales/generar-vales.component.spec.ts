import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GenerarValesComponent } from './generar-vales.component';

describe('GenerarValesComponent', () => {
  let component: GenerarValesComponent;
  let fixture: ComponentFixture<GenerarValesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GenerarValesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GenerarValesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
