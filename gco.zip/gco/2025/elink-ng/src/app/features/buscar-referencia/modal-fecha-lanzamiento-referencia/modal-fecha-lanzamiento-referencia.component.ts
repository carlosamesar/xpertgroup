import { Component, OnInit } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { NgxSpinnerService } from 'ngx-spinner';
import { Subject, forkJoin } from 'rxjs';
import { ValidadorReferenciaService } from 'src/app/shared/service/validador-referencia.service';
import { MarketplaceService } from 'src/app/shared/service/marketplace.service';
import { AlertaService } from 'src/app/shared/service/alerta.service';
import { ReferenciaValidacionDto } from 'src/app/shared/Interfaces/referencia-validacion-dto';
import { AsignacionFechaLanzamientoDto } from 'src/app/shared/Interfaces/asignacion-fecha-lanzamiento-dto';
import { Canales } from 'src/app/shared/clases/canales';
import { ValidacionCanalDto } from 'src/app/shared/Interfaces/validacion-dto';

@Component({
  selector: 'elk-modal-fecha-lanzamiento-referencia',
  templateUrl: './modal-fecha-lanzamiento-referencia.component.html',
  styleUrls: ['./modal-fecha-lanzamiento-referencia.component.css']
})
export class ModalFechaLanzamientoReferenciaComponent implements OnInit {

  // Datos de entrada (pasados por initialState)
  referencias: ReferenciaValidacionDto[];
  empresa: string;
  codEmpresa: number; // Código de empresa para filtrar canales

  // Datos del modal
  fechaSeleccionada: Date;
  fechaMinima: Date;
  listaCanales: Canales[] = [];
  canalesSeleccionados: string[] = [];

  // Validaciones de canales
  canalesValidados: Map<string, boolean> = new Map(); // Mapa para guardar estado de validación por canal
  cargandoValidaciones = false;

  // Control
  procesando = false;
  
  // Observable para notificar al componente padre
  public onClose: Subject<any> = new Subject();

  constructor(
    public bsModalRef: BsModalRef,
    private validadorService: ValidadorReferenciaService,
    private marketplaceService: MarketplaceService,
    private spinner: NgxSpinnerService,
    private alertaService: AlertaService
  ) { }

  ngOnInit(): void {
    this.cargarCanales();
    this.cargarValidacionesCanales();
    // Inicializar fecha con la fecha actual
    this.fechaSeleccionada = new Date();
    // Permitir seleccionar cualquier fecha (sin restricción de fecha mínima)
    this.fechaMinima = null;
  }

  /**
   * Carga los canales disponibles de la empresa filtrados por marca
   */
  cargarCanales(): void {
    this.marketplaceService.obtenerMarketPlaces().subscribe(
      (data: Canales[]) => {
        // Filtrar canales por marca (codEmpresa) y que sean marketplace
        if (this.codEmpresa) {
          this.listaCanales = data.filter(
            canal => canal.marca === this.codEmpresa.toString() && canal.marketplace === true
          );
          console.log('Canales filtrados por marca', this.codEmpresa, ':', this.listaCanales);
        } else {
          this.listaCanales = data.filter(canal => canal.marketplace === true);
          console.warn('No se proporcionó codEmpresa, mostrando todos los canales marketplace');
        }
      },
      (error) => {
        console.error('Error al cargar canales', error);
        this.alertaService.mostrar('Error al cargar canales');
      }
    );
  }

  /**
   * Maneja la selección/deselección de un canal
   */
  toggleCanal(codigoCanal: string, event: any): void {
    const checkbox = event.target as HTMLInputElement;
    
    if (checkbox.checked) {
      // Agregar canal si no existe
      if (!this.canalesSeleccionados.includes(codigoCanal)) {
        this.canalesSeleccionados.push(codigoCanal);
      }
    } else {
      // Remover canal si existe
      const index = this.canalesSeleccionados.indexOf(codigoCanal);
      if (index > -1) {
        this.canalesSeleccionados.splice(index, 1);
      }
    }
    
    console.log('Canales seleccionados:', this.canalesSeleccionados);
  }

  /**
   * Verifica si un canal está seleccionado
   */
  esCanalSeleccionado(codigoCanal: string): boolean {
    return this.canalesSeleccionados.includes(codigoCanal);
  }

  /**
   * Asigna la fecha de lanzamiento a las referencias seleccionadas
   */
  asignarFecha(): void {
    // Validaciones
    if (!this.fechaSeleccionada) {
      this.alertaService.mostrar('Debe seleccionar una fecha');
      return;
    }

    if (this.canalesSeleccionados.length === 0) {
      this.alertaService.mostrar('Debe seleccionar al menos un canal');
      return;
    }

    console.log('=== ASIGNACIÓN FECHA LANZAMIENTO ===');
    console.log('Referencias a procesar:', this.referencias.length);
    console.log('Canales SELECCIONADOS:', this.canalesSeleccionados);
    console.log('Total canales seleccionados:', this.canalesSeleccionados.length);
    console.log('Fecha seleccionada:', this.fechaSeleccionada);

    this.procesando = true;
    this.spinner.show();

    // Formatear fecha a 'yyyy-MM-dd'
    let fechaFormateada: string;
    if (typeof this.fechaSeleccionada === 'string') {
      fechaFormateada = this.fechaSeleccionada;
    } else {
      const fecha = new Date(this.fechaSeleccionada);
      const year = fecha.getFullYear();
      const month = String(fecha.getMonth() + 1).padStart(2, '0');
      const day = String(fecha.getDate()).padStart(2, '0');
      fechaFormateada = `${year}-${month}-${day}`;
    }

    // Asignar fecha a cada referencia seleccionada
    const asignaciones = this.referencias.map(ref => {
      const asignacion: AsignacionFechaLanzamientoDto = {
        fecha: fechaFormateada,
        canales: this.canalesSeleccionados  // SOLO los canales seleccionados
      };

      console.log(`Asignando fecha a referencia ${ref.codigo} con empresa ${this.empresa}:`, asignacion);
      return this.validadorService.asignarFechaLanzamiento(ref.codigo, this.empresa, asignacion).toPromise();
    });

    Promise.all(asignaciones)
      .then(() => {
        console.log('✓ Asignación completada exitosamente para todos los canales seleccionados');
        this.alertaService.mostrar('Fecha de lanzamiento asignada exitosamente');
        this.procesando = false;
        this.spinner.hide();
        
        // Notificar éxito al componente padre
        this.onClose.next({ success: true });
        this.cerrar();
      })
      .catch((error) => {
        console.error('✗ Error al asignar fecha', error);
        const errorMsg = error.error && error.error.error ? error.error.error : error.message;
        this.alertaService.mostrar('Error al asignar fecha de lanzamiento: ' + errorMsg);
        this.procesando = false;
        this.spinner.hide();
      });
  }

  /**
   * Carga las validaciones de todos los canales para las referencias seleccionadas
   */
  cargarValidacionesCanales(): void {
    if (!this.referencias || this.referencias.length === 0) {
      console.warn('No hay referencias para validar');
      return;
    }

    if (!this.codEmpresa) {
      console.warn('No se proporcionó codEmpresa para validar canales');
      return;
    }

    this.cargandoValidaciones = true;
    this.canalesValidados.clear();

    // Crear array de observables para consultar validaciones de cada referencia
    const validacionesObservables = this.referencias.map(ref => {
      const codReferencia = ref.codigo || ref.codReferencia;
      return this.validadorService.consultarValidacionesPorCanal(codReferencia, this.codEmpresa.toString());
    });

    // Ejecutar todas las consultas en paralelo
    forkJoin(validacionesObservables).subscribe(
      (resultados: ValidacionCanalDto[][]) => {
        // Procesar resultados para determinar estado de cada canal
        const validacionesPorCanal = new Map<string, boolean>();

        resultados.forEach(validacionesRef => {
          validacionesRef.forEach(validacion => {
            const nombreCanal = validacion.nombreCanal;
            const esCanalValido = this.validarCanal(validacion);

            // Acumular validaciones: el canal es válido solo si TODAS las referencias lo validan
            if (!validacionesPorCanal.has(nombreCanal)) {
              validacionesPorCanal.set(nombreCanal, esCanalValido);
            } else {
              // Si ya existe, hacer AND lógico: solo true si ambos son true
              const estadoActual = validacionesPorCanal.get(nombreCanal);
              validacionesPorCanal.set(nombreCanal, estadoActual && esCanalValido);
            }
          });
        });

        // Guardar en el mapa de canales validados
        this.canalesValidados = validacionesPorCanal;
        this.cargandoValidaciones = false;
        console.log('Validaciones de canales cargadas:', this.canalesValidados);
      },
      (error) => {
        console.error('Error al cargar validaciones de canales', error);
        this.cargandoValidaciones = false;
        // En caso de error, permitir todos los canales
      }
    );
  }

  /**
   * Valida si un canal tiene todas las validaciones completas
   */
  private validarCanal(validacion: ValidacionCanalDto): boolean {
    return validacion.descripcionOk && 
           validacion.sicOk && 
           validacion.imagenOk && 
           validacion.tallaOk && 
           validacion.colorOk && 
           validacion.categoriaOk && 
           validacion.precioOk ;
  }

  /**
   * Verifica si un canal es válido (pasa todas las validaciones)
   * @param nombreCanal Nombre del canal a verificar
   * @returns true si el canal es válido, false en caso contrario
   */
  esCanalValido(nombreCanal: string): boolean {
    // Si aún están cargando las validaciones, permitir todos los canales temporalmente
    if (this.cargandoValidaciones) {
      return true;
    }

    // Si no hay validaciones cargadas (size === 0), permitir todos los canales
    if (this.canalesValidados.size === 0) {
      return true;
    }

    // Verificar si el canal está en el mapa de validaciones
    const esValido = this.canalesValidados.get(nombreCanal);
    
    // Si el canal no está en el mapa, significa que no se encontró en las validaciones
    // En este caso, permitirlo (true) por defecto para evitar bloqueos
    return esValido !== undefined ? esValido : true;
  }

  /**
   * Cierra el modal
   */
  cerrar(): void {
    this.bsModalRef.hide();
  }
}
