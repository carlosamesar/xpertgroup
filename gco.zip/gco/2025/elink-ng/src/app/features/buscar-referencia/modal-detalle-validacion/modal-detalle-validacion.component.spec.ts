import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalDetalleValidacionComponent } from './modal-detalle-validacion.component';

describe('ModalDetalleValidacionComponent', () => {
  let component: ModalDetalleValidacionComponent;
  let fixture: ComponentFixture<ModalDetalleValidacionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModalDetalleValidacionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModalDetalleValidacionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
