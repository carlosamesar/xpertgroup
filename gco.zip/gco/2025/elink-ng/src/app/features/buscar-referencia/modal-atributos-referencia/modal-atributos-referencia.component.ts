import { Component, OnInit } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { NgxSpinnerService } from 'ngx-spinner';
import { ValidadorReferenciaService } from 'src/app/shared/service/validador-referencia.service';
import { AlertaService } from 'src/app/shared/service/alerta.service';
import { DetalleAtributosReferenciaDto } from 'src/app/shared/Interfaces/detalle-atributos-referencia-dto';

@Component({
  selector: 'elk-modal-atributos-referencia',
  templateUrl: './modal-atributos-referencia.component.html',
  styleUrls: ['./modal-atributos-referencia.component.css']
})
export class ModalAtributosReferenciaComponent implements OnInit {

  // Datos de entrada (pasados por initialState)
  idReferencia: string;
  codigoReferencia: string;
  empresa: string;

  // Datos del modal
  detalleAtributos: DetalleAtributosReferenciaDto;
  cargando = false;

  constructor(
    public bsModalRef: BsModalRef,
    private validadorService: ValidadorReferenciaService,
    private spinner: NgxSpinnerService,
    private alertaService: AlertaService
  ) { }

  ngOnInit(): void {
    this.cargarAtributos();
  }

  /**
   * Carga los atributos de la referencia
   */
  cargarAtributos(): void {
    this.cargando = true;
    this.spinner.show();

    this.validadorService.obtenerDetalleAtributos(this.idReferencia, this.empresa)
      .subscribe(
        (data: DetalleAtributosReferenciaDto) => {
          this.detalleAtributos = data;
          this.cargando = false;
          this.spinner.hide();
        },
        (error) => {
          console.error('Error al cargar atributos', error);
          this.alertaService.mostrar('Error al cargar atributos: ' + error.message);
          this.cargando = false;
          this.spinner.hide();
        }
      );
  }

  /**
   * Cierra el modal
   */
  cerrar(): void {
    this.bsModalRef.hide();
  }

  /**
   * Obtiene el tooltip para un canal con faltantes
   */
  obtenerTooltipCanal(canal: any): string {
    if (!canal.ok && canal.atributosFaltantes && canal.atributosFaltantes.length > 0) {
      return 'Faltantes: ' + canal.atributosFaltantes.join(', ');
    }
    return 'Completo';
  }
}
