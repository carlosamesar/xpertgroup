import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { BsModalService } from 'ngx-bootstrap/modal';
import { NgxSpinnerService } from 'ngx-spinner';
import { BuscarReferenciaComponent } from './buscar-referencia.component';
import { ValidadorReferenciaService } from 'src/app/shared/service/validador-referencia.service';
import { MarketplaceService } from 'src/app/shared/service/marketplace.service';
import { AlertaService } from 'src/app/shared/service/alerta.service';
import { FechaPipe } from 'src/app/shared/pipes/fecha.pipe';
import { of, throwError } from 'rxjs';
import { ReferenciaValidacionDto } from 'src/app/shared/Interfaces/referencia-validacion-dto';
import { Empresa } from 'src/app/shared/clases/empresa';

describe('BuscarReferenciaComponent - Criterio 1: Búsqueda por referencia', () => {
  let component: BuscarReferenciaComponent;
  let fixture: ComponentFixture<BuscarReferenciaComponent>;
  let validadorService: any;
  let marketplaceService: any;
  let alertaService: any;
  let spinnerService: any;

  beforeEach(() => {
    const validadorSpy = jasmine.createSpyObj('ValidadorReferenciaService', ['validadorReferencia']);
    const marketplaceSpy = jasmine.createSpyObj('MarketplaceService', ['obtenerEmpresas']);
    const alertaSpy = jasmine.createSpyObj('AlertaService', ['mostrar']);
    const spinnerSpy = jasmine.createSpyObj('NgxSpinnerService', ['show', 'hide']);
    const modalSpy = jasmine.createSpyObj('BsModalService', ['show']);

    TestBed.configureTestingModule({
      declarations: [ BuscarReferenciaComponent ],
      imports: [
        FormsModule,
        HttpClientTestingModule
      ],
      providers: [
        { provide: ValidadorReferenciaService, useValue: validadorSpy },
        { provide: MarketplaceService, useValue: marketplaceSpy },
        { provide: AlertaService, useValue: alertaSpy },
        { provide: NgxSpinnerService, useValue: spinnerSpy },
        { provide: BsModalService, useValue: modalSpy },
        FechaPipe
      ]
    });

    fixture = TestBed.createComponent(BuscarReferenciaComponent);
    component = fixture.componentInstance;
    validadorService = TestBed.get(ValidadorReferenciaService);
    marketplaceService = TestBed.get(MarketplaceService);
    alertaService = TestBed.get(AlertaService);
    spinnerService = TestBed.get(NgxSpinnerService);

    // Mock de localStorage
    const mockResources = { marca: 'GCO' };
    spyOn(localStorage, 'getItem').and.returnValue(JSON.stringify(mockResources));

    // Mock de empresas
    const mockEmpresas: Empresa[] = [
      { codEmpresa: '001', nomEmpresa: 'Empresa Test' } as Empresa
    ];
    marketplaceService.obtenerEmpresas.and.returnValue(of(mockEmpresas));
  });

  describe('Given: Referencias con espacios y mayúsculas', () => {
    it('When: El usuario busca "  REF001  ", Then: La búsqueda debe normalizar a "ref001"', (done) => {
      // Arrange
      const mockResponse: ReferenciaValidacionDto[] = [
        {
          codReferencia: 'ref001',
          nomReferencia: 'Producto Test',
          estadoGeneral: true,
          baseUrlImagen: 'http://test.com/img.jpg'
        }
      ];
      
      validadorService.validadorReferencia.and.returnValue(of(mockResponse));
      
      const mockEmpresa: Empresa = { codEmpresa: '001', nomEmpresa: 'Empresa Test' } as Empresa;
      component.empresaSeleccionada = mockEmpresa;
      component.referenciaBuscar = '  REF001  ';

      // Act
      component.buscarReferencias();

      // Assert
      setTimeout(() => {
        expect(validadorService.validadorReferencia).toHaveBeenCalled();
        const callArgs = validadorService.validadorReferencia.calls.argsFor(0);
        expect(callArgs[0]).toContain('ref001');
        expect(component.listaReferencias.length).toBe(1);
        done();
      }, 100);
    });

    it('When: El usuario busca múltiples referencias con espacios "REF001\\n  REF002  ", Then: Deben normalizarse correctamente', (done) => {
      // Arrange
      const mockResponse: ReferenciaValidacionDto[] = [
        { codReferencia: 'ref001', nomReferencia: 'Producto 1', estadoGeneral: true, baseUrlImagen: '' },
        { codReferencia: 'ref002', nomReferencia: 'Producto 2', estadoGeneral: true, baseUrlImagen: '' }
      ];
      
      validadorService.validadorReferencia.and.returnValue(of(mockResponse));
      
      const mockEmpresa: Empresa = { codEmpresa: '001', nomEmpresa: 'Empresa Test' } as Empresa;
      component.empresaSeleccionada = mockEmpresa;
      component.referenciaBuscar = 'REF001\n  REF002  ';

      // Act
      component.buscarReferencias();

      // Assert
      setTimeout(() => {
        expect(validadorService.validadorReferencia).toHaveBeenCalled();
        const callArgs = validadorService.validadorReferencia.calls.argsFor(0);
        expect(callArgs[0]).toContain('ref001');
        expect(callArgs[0]).toContain('ref002');
        expect(component.listaReferencias.length).toBe(2);
        done();
      }, 100);
    });

    it('When: El usuario busca con líneas vacías, Then: Las líneas vacías deben ser filtradas', (done) => {
      // Arrange
      const mockResponse: ReferenciaValidacionDto[] = [
        { codReferencia: 'ref001', nomReferencia: 'Producto 1', estadoGeneral: true, baseUrlImagen: '' }
      ];
      
      validadorService.validadorReferencia.and.returnValue(of(mockResponse));
      
      const mockEmpresa: Empresa = { codEmpresa: '001', nomEmpresa: 'Empresa Test' } as Empresa;
      component.empresaSeleccionada = mockEmpresa;
      component.referenciaBuscar = 'REF001\n\n\n  \n';

      // Act
      component.buscarReferencias();

      // Assert
      setTimeout(() => {
        expect(validadorService.validadorReferencia).toHaveBeenCalled();
        const callArgs = validadorService.validadorReferencia.calls.argsFor(0);
        expect(callArgs[0].length).toBe(1);
        expect(callArgs[0]).toContain('ref001');
        done();
      }, 100);
    });
  });

  describe('Given: Validaciones de campos requeridos', () => {
    it('When: No se selecciona empresa, Then: Debe mostrar alerta', () => {
      // Arrange
      component.empresaSeleccionada = null;
      component.referenciaBuscar = 'REF001';

      // Act
      component.buscarReferencias();

      // Assert
      expect(alertaService.mostrar).toHaveBeenCalledWith('Debe seleccionar una empresa');
      expect(validadorService.validadorReferencia).not.toHaveBeenCalled();
    });

    it('When: No se ingresa referencia, Then: Debe mostrar alerta', () => {
      // Arrange
      const mockEmpresa: Empresa = { codEmpresa: '001', nomEmpresa: 'Empresa Test' } as Empresa;
      component.empresaSeleccionada = mockEmpresa;
      component.referenciaBuscar = '';

      // Act
      component.buscarReferencias();

      // Assert
      expect(alertaService.mostrar).toHaveBeenCalled();
      expect(validadorService.validadorReferencia).not.toHaveBeenCalled();
    });
  });

  describe('Given: Manejo de errores', () => {
    it('When: El servicio falla, Then: Debe mostrar mensaje de error y ocultar spinner', (done) => {
      // Arrange
      const errorResponse = { message: 'Error de conexión' };
      validadorService.validadorReferencia.and.returnValue(throwError(errorResponse));
      
      const mockEmpresa: Empresa = { codEmpresa: '001', nomEmpresa: 'Empresa Test' } as Empresa;
      component.empresaSeleccionada = mockEmpresa;
      component.referenciaBuscar = 'REF001';

      // Act
      component.buscarReferencias();

      // Assert
      setTimeout(() => {
        expect(alertaService.mostrar).toHaveBeenCalled();
        expect(spinnerService.hide).toHaveBeenCalled();
        done();
      }, 100);
    });
  });

  describe('Given: Lógica de spinner', () => {
    it('When: Se inicia la búsqueda, Then: Debe mostrar el spinner', () => {
      // Arrange
      validadorService.validadorReferencia.and.returnValue(of([]));
      
      const mockEmpresa: Empresa = { codEmpresa: '001', nomEmpresa: 'Empresa Test' } as Empresa;
      component.empresaSeleccionada = mockEmpresa;
      component.referenciaBuscar = 'REF001';

      // Act
      component.buscarReferencias();

      // Assert
      expect(spinnerService.show).toHaveBeenCalled();
    });

    it('When: La búsqueda finaliza exitosamente, Then: Debe ocultar el spinner', (done) => {
      // Arrange
      validadorService.validadorReferencia.and.returnValue(of([]));
      
      const mockEmpresa: Empresa = { codEmpresa: '001', nomEmpresa: 'Empresa Test' } as Empresa;
      component.empresaSeleccionada = mockEmpresa;
      component.referenciaBuscar = 'REF001';

      // Act
      component.buscarReferencias();

      // Assert
      setTimeout(() => {
        expect(spinnerService.hide).toHaveBeenCalled();
        done();
      }, 100);
    });
  });
});

