import { Component, OnInit } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { Subject, forkJoin } from 'rxjs';
import { ValidadorReferenciaService } from 'src/app/shared/service/validador-referencia.service';
import { ReferenciaValidacionDto } from 'src/app/shared/Interfaces/referencia-validacion-dto';
import { ValidacionResumenDto, ValidacionCanalDto } from 'src/app/shared/Interfaces/validacion-dto';
import { NgxSpinnerService } from 'ngx-spinner';
import { AlertaService } from 'src/app/shared/service/alerta.service';

@Component({
  selector: 'elk-modal-detalle-validacion',
  templateUrl: './modal-detalle-validacion.component.html',
  styleUrls: ['./modal-detalle-validacion.component.css']
})
export class ModalDetalleValidacionComponent implements OnInit {

  // Datos de entrada
  referencia: ReferenciaValidacionDto;
  marca: string; // Código de marca (empresa)

  // Datos de validación
  resumenValidacion: ValidacionResumenDto;
  validacionesPorCanal: ValidacionCanalDto[] = [];

  // Estado
  cargando = false;
  vistaActual: 'resumen' | 'canales' = 'resumen';

  // Propiedades calculadas
  porcentajeCompletitud = 0;
  validacionesCompletas = 0;
  totalValidaciones = 8;

  // Observable para notificar al componente padre
  public onClose: Subject<any>;

  constructor(
    public bsModalRef: BsModalRef,
    private validadorService: ValidadorReferenciaService,
    private spinner: NgxSpinnerService,
    private alertaService: AlertaService
  ) { }

  ngOnInit(): void {
    this.onClose = new Subject();
    
    if (!this.referencia || !this.marca) {
      console.error('Datos insuficientes para cargar el detalle de validación');
      this.alertaService.mostrar('Error: No se recibieron los datos necesarios para mostrar el detalle');
      return;
    }

    this.cargarValidaciones();
  }

  /**
   * Carga las validaciones (resumen y por canal) de la referencia
   */
  cargarValidaciones(): void {
    this.cargando = true;
    this.spinner.show();

    const codReferencia = this.referencia.codigo || this.referencia.codReferencia;

    console.log('Cargando validaciones para referencia:', codReferencia);
    console.log('Marca:', this.marca);

    // Llamar a ambos endpoints en paralelo usando array syntax de RxJS 6.3.3
    forkJoin([
      this.validadorService.consultarValidacionResumen(codReferencia, this.marca),
      this.validadorService.consultarValidacionesPorCanal(codReferencia, this.marca)
    ]).subscribe(
      ([resumen, canales]) => {
        this.resumenValidacion = resumen;
        this.validacionesPorCanal = canales;

        // Calcular estadísticas del resumen
        this.calcularEstadisticasResumen();

        console.log('Resumen de validaciones:', this.resumenValidacion);
        console.log('Validaciones por canal:', this.validacionesPorCanal);
        console.log('Completitud:', this.porcentajeCompletitud + '%');
        
        // Debug: Verificar nombres de canales
        if (this.validacionesPorCanal && this.validacionesPorCanal.length > 0) {
          console.log('=== DEBUG: Nombres de canales recibidos ===');
          this.validacionesPorCanal.forEach((canal, index) => {
            console.log(`Canal ${index + 1}:`, {
              nombreCanal: canal.nombreCanal,
              codigoReferencia: canal.codigoReferencia,
              objetoCompleto: canal
            });
          });
        }

        this.cargando = false;
        this.spinner.hide();
      },
      (error) => {
        console.error('Error al cargar validaciones', error);
        this.alertaService.mostrar('Error al cargar las validaciones. Por favor, intente nuevamente.');
        this.cargando = false;
        this.spinner.hide();
      }
    );
  }

  /**
   * Calcula las estadísticas del resumen de validaciones
   */
  private calcularEstadisticasResumen(): void {
    if (!this.resumenValidacion) {
      return;
    }

    const validaciones = [
      this.resumenValidacion.descripcion,
      this.resumenValidacion.sic,
      this.resumenValidacion.imagen,
      this.resumenValidacion.talla,
      this.resumenValidacion.color,
      this.resumenValidacion.categoria,
      this.resumenValidacion.precio,
      this.resumenValidacion.cargado
    ];

    this.validacionesCompletas = validaciones.filter(v => v === true).length;
    this.porcentajeCompletitud = Math.round((this.validacionesCompletas / this.totalValidaciones) * 100);
  }

  /**
   * Cambia entre vista de resumen y vista por canales
   */
  cambiarVista(vista: 'resumen' | 'canales'): void {
    this.vistaActual = vista;
  }

  /**
   * Cierra el modal
   */
  cerrar(): void {
    this.onClose.next(null);
    this.bsModalRef.hide();
  }

  /**
   * Obtiene el ícono de Font Awesome según el estado de validación
   */
  obtenerIcono(estado: boolean): string {
    return estado ? 'fa-check-circle' : 'fa-times-circle';
  }

  /**
   * Obtiene la clase de color según el estado de validación
   */
  obtenerClase(estado: boolean): string {
    return estado ? 'text-success' : 'text-danger';
  }

  /**
   * Obtiene el texto según el estado de validación
   */
  obtenerTexto(estado: boolean): string {
    return estado ? 'Validado en todos los canales' : 'Falta validación en al menos un canal';
  }

  /**
   * Obtiene el nombre legible de una validación
   */
  obtenerNombreValidacion(campo: string): string {
    const nombres: { [key: string]: string } = {
      'descripcion': 'Descripción',
      'sic': 'Atributos SIC',
      'imagen': 'Imagen',
      'talla': 'Talla',
      'color': 'Color',
      'categoria': 'Categoría',
      'precio': 'Precio',
      'cargado': 'Cargado'
    };
    return nombres[campo] || campo;
  }

  /**
   * Verifica si un canal tiene todas las validaciones completas
   */
  esCanalCompleto(canal: ValidacionCanalDto): boolean {
    return canal.descripcionOk && canal.sicOk && canal.imagenOk && 
           canal.tallaOk && canal.colorOk && canal.categoriaOk && 
           canal.precioOk && canal.cargadoOk;
  }

  /**
   * Cuenta cuántas validaciones tiene completas un canal
   */
  contarValidacionesCanal(canal: ValidacionCanalDto): number {
    const validaciones = [
      canal.descripcionOk, canal.sicOk, canal.imagenOk,
      canal.tallaOk, canal.colorOk, canal.categoriaOk,
      canal.precioOk, canal.cargadoOk
    ];
    return validaciones.filter(v => v === true).length;
  }

  /**
   * Obtiene la clase de badge para el estado del canal
   */
  obtenerClaseCanal(canal: ValidacionCanalDto): string {
    const completas = this.contarValidacionesCanal(canal);
    if (completas === this.totalValidaciones) {
      return 'badge-success';
    } else if (completas >= this.totalValidaciones / 2) {
      return 'badge-warning';
    } else {
      return 'badge-danger';
    }
  }

  /**
   * Obtiene la clase de progreso según el porcentaje
   */
  obtenerClaseProgreso(): string {
    if (this.porcentajeCompletitud === 100) {
      return 'bg-success';
    } else if (this.porcentajeCompletitud >= 75) {
      return 'bg-info';
    } else if (this.porcentajeCompletitud >= 50) {
      return 'bg-warning';
    } else {
      return 'bg-danger';
    }
  }
}
