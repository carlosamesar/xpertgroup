import { Component, OnInit, Input, OnChanges, SimpleChanges, Output, EventEmitter } from '@angular/core';
import { ReferenciaValidacionDto } from 'src/app/shared/Interfaces/referencia-validacion-dto';
import { BsModalService, ModalOptions } from 'ngx-bootstrap/modal';
import { GridOptions, ValueGetterParams } from 'ag-grid-community';
import { ImagenRendererComponent } from 'src/app/shared/componentes/imagen-renderer/imagen-renderer.component';
import { CaritasRendererComponent } from 'src/app/shared/componentes/caritas-renderer/caritas-renderer.component';
import { FechaRendererComponent } from 'src/app/shared/componentes/fecha-renderer/fecha-renderer.component';
import { ModalAtributosReferenciaComponent } from '../modal-atributos-referencia/modal-atributos-referencia.component';
import { ModalFechaLanzamientoReferenciaComponent } from '../modal-fecha-lanzamiento-referencia/modal-fecha-lanzamiento-referencia.component';
import { ModalDetalleValidacionComponent } from '../modal-detalle-validacion/modal-detalle-validacion.component';
import * as moment from 'moment';

@Component({
  selector: 'elk-detalle-validacion',
  templateUrl: './detalle-validacion.component.html',
  styleUrls: ['./detalle-validacion.component.css']
})
export class DetalleValidacionComponent implements OnInit, OnChanges {

  @Input('data') listaReferenciasSrc: ReferenciaValidacionDto[];
  @Input() empresaSeleccionada: string;

  @Output() registrosSeleccionados = new EventEmitter<ReferenciaValidacionDto[]>();

  refsSeleccionadas: ReferenciaValidacionDto[] = [];
  seleccionadosTodos = false;
  
  gridApi;
  gridColumnApi;
  gridOptions: GridOptions;

  constructor(private modalService: BsModalService) {

    if (!this.listaReferenciasSrc) {
      this.listaReferenciasSrc = [];
    }

    const onCambioSeleccion = (event) => {
      this.refsSeleccionadas = event.api.getSelectedRows() as ReferenciaValidacionDto[];
      this.registrosSeleccionados.emit(this.refsSeleccionadas);
    };

    this.gridOptions = {
      columnDefs: this.crearColumnasGrid(),
      context: { componentParent: this },
      rowHeight: 60,
      headerHeight: 40,
      enableCellTextSelection: true,
      enableColResize: true,
      defaultColDef: {
        sortable: true,
        filter: true,
        resizable: true
      },
      rowSelection: 'multiple',
      suppressRowClickSelection: true,
      suppressClickEdit: true,
      onSelectionChanged: onCambioSeleccion,
      frameworkComponents: {
        imagenRenderer: ImagenRendererComponent,
        caritasRenderer: CaritasRendererComponent,
        fechaRenderer: FechaRendererComponent
      }
    } as GridOptions;
  }

  ngOnInit() {
  }

  private crearColumnasGrid() {
    const fvalueGetter = (params: ValueGetterParams) => {
      return params.data;
    };

    return [
      {
        colId: '1',
        headerName: '',
        field: 'urlImagen',
        headerCheckboxSelection: true,
        headerCheckboxSelectionFilteredOnly: true,
        cellRenderer: 'imagenRenderer',
        width: 90,
        valueGetter: fvalueGetter,
        checkboxSelection: true,
        suppressMenu: true,
        sortable: false,
        filter: false,
        cellStyle: {
          'display': 'flex',
          'align-items': 'center',
          'justify-content': 'center',
          'padding': '5px'
        }
      },
      {
        colId: '2',
        headerName: 'Código',
        field: 'codigo',
        width: 130,
        cellStyle: { 
          'font-weight': 'bold',
          'display': 'flex',
          'align-items': 'center',
          'justify-content': 'flex-start'
        },
        filterParams: {
          valueGetter: params => {
            return (params.data.codigo || '');
          }
        }
      },
      {
        colId: '3',
        headerName: 'Nombre',
        field: 'nombre',
        width: 400,
        cellStyle: {
          'display': 'flex',
          'align-items': 'center',
          'justify-content': 'flex-start'
        },
        filterParams: {
          valueGetter: params => {
            return (params.data.nombre || '');
          }
        }
      },
      {
        colId: '4',
        headerName: 'Estado',
        field: 'isValid',
        width: 100,
        cellRenderer: 'caritasRenderer',
        cellStyle: { 
          'text-align': 'center',
          'display': 'flex',
          'align-items': 'center',
          'justify-content': 'center'
        },
        cellRendererParams: (params) => {
          return {
            value: params.data.isValid,
            data: params.data
          };
        },
        filterParams: {
          valueGetter: params => {
            return params.data.isValid ? 'Válido' : 'Advertencia';
          }
        }
      }
    ];
  }

  ngOnChanges(changes: SimpleChanges): void {
    console.log('changes detalle validacion');
    if (!this.listaReferenciasSrc) {
      this.listaReferenciasSrc = [];
    }

    this.refsSeleccionadas = [];
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;

    params.api.sizeColumnsToFit();
  }

  public exportarDatos() {
    const fecha = new Date();
    const fecStr = moment(fecha).format('YYYYMMDD_HHmmss');

    const params = {
      allColumns: true,
      suppressQuotes: false,
      fileName: `validacion_referencias_${fecStr}.csv`,
      columnSeparator: ','
    };

    this.gridApi.exportDataAsCsv(params);
  }

  public verAtributos(item: ReferenciaValidacionDto) {
    console.log('Ver atributos', item);

    const estadoInicial = new ModalOptions();
    estadoInicial.class = 'modal-lg';
    estadoInicial.initialState = {
      idReferencia: item.id,
      codigoReferencia: item.codigo,
      empresa: this.empresaSeleccionada
    };

    this.modalService.show(ModalAtributosReferenciaComponent, estadoInicial);
  }

  /**
   * Abre el modal de detalle de validacion para una referencia
   * Este metodo es llamado desde el cell renderer (caritas-renderer)
   */
  public abrirModalDetalleValidacion(referencia: ReferenciaValidacionDto) {
    console.log('=== DetalleValidacionComponent - abrirModalDetalleValidacion ===');
    console.log('Referencia recibida:', referencia);
    console.log('Empresa seleccionada (input):', this.empresaSeleccionada);
    console.log('Tipo de empresaSeleccionada:', typeof this.empresaSeleccionada);

    if (!referencia) {
      console.error('No se recibio una referencia valida');
      return;
    }

    if (!this.empresaSeleccionada) {
      console.error('ERROR: empresaSeleccionada es null o undefined');
      console.error('Valor recibido:', this.empresaSeleccionada);
      alert('No se ha seleccionado una empresa. Por favor, seleccione una empresa antes de ver los detalles.');
      return;
    }

    const estadoInicial = new ModalOptions();
    estadoInicial.class = 'modal-xl'; // Cambiado a xl para mejor visualización
    estadoInicial.backdrop = true;
    estadoInicial.ignoreBackdropClick = false;
    estadoInicial.initialState = {
      referencia: referencia,
      marca: this.empresaSeleccionada // Cambio: empresa → marca (código de empresa)
    };

    console.log('Estado inicial del modal:', estadoInicial);
    console.log('Abriendo modal ModalDetalleValidacionComponent...');
    console.log('Referencia:', referencia);
    console.log('Marca (empresa):', this.empresaSeleccionada);

    const modalRef = this.modalService.show(ModalDetalleValidacionComponent, estadoInicial);
    console.log('Modal abierto, referencia:', modalRef);
  }
}
