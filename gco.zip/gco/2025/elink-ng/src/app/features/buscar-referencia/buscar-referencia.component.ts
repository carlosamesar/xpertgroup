import { Component, OnInit, ViewChild } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { ValidadorReferenciaService } from 'src/app/shared/service/validador-referencia.service';
import { MarketplaceService } from 'src/app/shared/service/marketplace.service';
import { AlertaService } from 'src/app/shared/service/alerta.service';
import { ReferenciaValidacionDto } from 'src/app/shared/Interfaces/referencia-validacion-dto';
import { Empresa } from 'src/app/shared/clases/empresa';
import { Resource } from 'src/app/shared/clases/resource';
import { ModalAtributosReferenciaComponent } from './modal-atributos-referencia/modal-atributos-referencia.component';
import { ModalFechaLanzamientoReferenciaComponent } from './modal-fecha-lanzamiento-referencia/modal-fecha-lanzamiento-referencia.component';
import { FechaPipe } from 'src/app/shared/pipes/fecha.pipe';
import { DetalleValidacionComponent } from './detalle-validacion/detalle-validacion.component';

@Component({
  selector: 'elk-buscar-referencia',
  templateUrl: './buscar-referencia.component.html',
  styleUrls: ['./buscar-referencia.component.css'],
  providers: [FechaPipe]
})
export class BuscarReferenciaComponent implements OnInit {

  @ViewChild(DetalleValidacionComponent) elkDetValidacion: DetalleValidacionComponent;

  // Filtros de búsqueda
  listaEmpresa: Empresa[];
  empresaSeleccionada: Empresa;
  ano: number;
  coleccion: string;
  referenciaBuscar: string;

  // Resultados
  listaReferencias: ReferenciaValidacionDto[] = [];
  referenciasSeleccionadas: ReferenciaValidacionDto[] = [];

  // Estado
  buscando = false;
  enviado = false;
  classAcordion = 'customClass';
  mostrarAlertaSinResultados = false;
  mensajeAlerta = '';

  // Permisos
  resources: Resource;

  constructor(
    private validadorService: ValidadorReferenciaService,
    private marketService: MarketplaceService,
    private spinner: NgxSpinnerService,
    private modalService: BsModalService,
    private alertaService: AlertaService,
    private fechaPipe: FechaPipe
  ) { }

  ngOnInit(): void {
    // Validación de permisos del usuario
    this.resources = JSON.parse(localStorage.getItem('recursosElink'));
    
    if (!this.resources || !this.resources.marca) {
      this.alertaService.mostrar('No tiene permisos para acceder a este módulo');
      return;
    }

    // Cargar empresas según permisos del usuario
    this.marketService.obtenerEmpresas(this.resources.marca).subscribe(
      (data) => {
        this.listaEmpresa = data;
      },
      (error) => {
        console.error('Error al cargar empresas', error);
        this.alertaService.mostrar('Error al cargar las empresas disponibles');
      }
    );

    // Establecer año actual por defecto
    const currentYear = new Date().getFullYear();
    this.ano = currentYear;
  }

  /**
   * Realiza la búsqueda de referencias según los filtros
   */
  buscarReferencias(): void {
    this.enviado = true;
    this.mostrarAlertaSinResultados = false;
    this.mensajeAlerta = '';

    // Validar campos obligatorios
    if (!this.validarBusqueda()) {
      return;
    }

    this.buscando = true;
    this.spinner.show();

    // Procesar referencias: dividir por saltos de línea, limpiar y normalizar (trim + lowercase)
    const referencias = this.referenciaBuscar
      .split('\n')
      .map(ref => ref.trim().toLowerCase())
      .filter(ref => ref.length > 0);

    // Validar que haya al menos una referencia después del procesamiento
    if (referencias.length === 0) {
      this.alertaService.mostrar('Debe ingresar al menos una referencia válida');
      this.spinner.hide();
      this.buscando = false;
      return;
    }

    let referencias64 = btoa(JSON.stringify(referencias));

    // Llamar al nuevo endpoint validador-referencia con la consulta SQL nativa
    console.log('Buscando referencias:', referencias);
    console.log('Empresa seleccionada:', this.empresaSeleccionada);
    console.log('Código de empresa (marca):', this.empresaSeleccionada.codEmpresa);
    console.log('Año:', this.ano);
    console.log('Colección:', this.coleccion);

    this.validadorService.validadorReferencia(
      referencias64,
      this.empresaSeleccionada.codEmpresa,
      this.ano,
      this.coleccion
    ).subscribe(
      (data: ReferenciaValidacionDto[]) => {
        // Mapear las propiedades del backend a las esperadas por el frontend
        this.listaReferencias = data.map(ref => {
          // Construir ID compuesto: empresa-ano-coleccion-referencia
          // Solo incluir los componentes que tienen valor
          const partes = [
            this.empresaSeleccionada.empresa,
            this.ano ? this.ano.toString() : null,
            this.coleccion,
            ref.codReferencia
          ].filter(parte => parte !== null && parte !== undefined && parte !== '');
          
          const idCompuesto = partes.join('-');
          
          return {
            ...ref,
            id: idCompuesto,
            codigo: ref.codReferencia,
            nombre: ref.nomReferencia,
            urlImagen: ref.baseUrlImagen,
            isValid: ref.estadoGeneral
          };
        });
        this.referenciasSeleccionadas = [];
        
        if (data.length === 0) {
          this.mostrarAlertaSinResultados = true;
          this.mensajeAlerta = 'No se encontraron referencias con los criterios de búsqueda ingresados. Por favor, intente con otros valores.';
        }
        
        this.buscando = false;
        this.spinner.hide();
      },
      (error) => {
        console.error('Error al buscar referencias', error);
        this.mostrarAlertaSinResultados = true;
        const errorMsg = error.error && error.error.message ? error.error.message : (error.message || 'Error desconocido. Por favor, intente nuevamente.');
        this.mensajeAlerta = 'Error al buscar referencias: ' + errorMsg;
        this.buscando = false;
        this.spinner.hide();
      }
    );
  }

  /**
   * Valida los campos obligatorios para la búsqueda
   * @returns true si la validación es exitosa, false en caso contrario
   */
  private validarBusqueda(): boolean {
    if (!this.empresaSeleccionada) {
      this.alertaService.mostrar('Debe seleccionar una empresa');
      return false;
    }

    if (!this.empresaSeleccionada.codEmpresa) {
      this.alertaService.mostrar('La empresa seleccionada no tiene código de empresa válido');
      console.error('Empresa seleccionada sin codEmpresa:', this.empresaSeleccionada);
      return false;
    }

    if (!this.referenciaBuscar || this.referenciaBuscar.trim() === '') {
      this.alertaService.mostrar('Debe ingresar una referencia para buscar');
      return false;
    }

    return true;
  }

  /**
   * Abre el modal para asignar fecha de lanzamiento
   */
  abrirModalFechaLanzamiento(): void {
    if (this.referenciasSeleccionadas.length === 0) {
      this.alertaService.mostrar('Debe seleccionar al menos una referencia');
      return;
    }

    const initialState = {
      referencias: this.referenciasSeleccionadas,
      empresa: this.empresaSeleccionada.codEmpresa.toString(),
      codEmpresa: this.empresaSeleccionada.codEmpresa
    };

    const config = {
      class: 'modal-lg',
      initialState: initialState,
      backdrop: true,
      ignoreBackdropClick: false
    };

    const modalRef = this.modalService.show(ModalFechaLanzamientoReferenciaComponent, config);

    // Recargar resultados después de cerrar el modal
    if (modalRef.content && modalRef.content.onClose) {
      modalRef.content.onClose.subscribe((result: any) => {
        if (result && result.success) {
          this.buscarReferencias();
        }
      });
    }
  }

  /**
   * Maneja el cambio de selección desde el componente hijo
   */
  onRegistrosSeleccionados(referencias: ReferenciaValidacionDto[]): void {
    this.referenciasSeleccionadas = referencias;
    console.log('Referencias seleccionadas:', this.referenciasSeleccionadas.length);
  }

  /**
   * Exporta los resultados actuales
   */
  exportarResultados(): void {
    if (this.elkDetValidacion) {
      this.elkDetValidacion.exportarDatos();
    }
  }

  /**
   * Limpia los filtros y resultados
   */
  limpiarBusqueda(): void {
    this.referenciaBuscar = '';
    this.coleccion = null;
    this.ano = new Date().getFullYear();
    this.listaReferencias = [];
    this.referenciasSeleccionadas = [];
    this.enviado = false;
    this.mostrarAlertaSinResultados = false;
    this.mensajeAlerta = '';
  }
}
