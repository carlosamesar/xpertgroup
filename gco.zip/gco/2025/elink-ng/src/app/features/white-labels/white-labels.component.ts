import { Component, ElementRef, OnInit, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { MarketplaceService } from "src/app/shared/service/marketplace.service";
import { AlertaService } from "src/app/shared/service/alerta.service";
import { NgxSpinnerService } from "ngx-spinner";
import { Marketplace } from "src/app/shared/clases/marketplace";
import { AtributosService } from "src/app/shared/service/atributos.service";
import { AtributoMarket } from "src/app/shared/clases/atributo-market";
import { FormGroup, FormArray, FormBuilder, Validators } from "@angular/forms";
import { BsModalService, ModalOptions } from "ngx-bootstrap/modal";
import { PoliticasComercialesComponent } from "../politicas-comerciales/politicas-comerciales.component";
import { fillChanels, fillCompany } from "src/app/shared/utils/listar-canales";
import { Resource } from "src/app/shared/clases/resource";
import { Canales } from "./../../shared/clases/canales";
import { Empresa } from "./../../shared/clases/empresa";
import { error } from 'util';
@Component({
  selector: 'elk-white-labels',
  templateUrl: './white-labels.component.html',
  styleUrls: ['./white-labels.component.css']
})


export class WhiteLabelsComponent implements OnInit {
  formulario: FormGroup = new FormGroup({});
  items: FormArray;
  idCanalSel: string;
  marketSeleccionado: Marketplace;
  empresaSeleccionada: Empresa;
  canalSeleccionado: any = null;
  listaEmpresa: Empresa[];
  listaCanal: Canales[] = [];
  filtroListaCanal: Canales[] = [];
  listaTiposAtributos = [
    { id: "PRO", valor: "Producto" },
    { id: "PLU", valor: "Plu" },
    { id: "COM", valor: "Política comercial" },
  ];
  atribSeleccionado: string;
  listaAtributos: AtributoMarket[] = [];
  esSeleccionado = false;
  resources: Resource;
  page: number = 0;
  size: number = 25;
  listaMarket: Canales[] = [];
  marketActual: Canales;
  totalPages: number;
  lastPage: boolean = false; 
  nombreCuenta: string = '';

  @ViewChild("miTabla") miTabla: ElementRef;
  @ViewChildren("miFormulario") miFormulario: QueryList<ElementRef>;
  constructor( private marketService: MarketplaceService,
    private alertaService: AlertaService,
    private spinner: NgxSpinnerService,
    private atributoService: AtributosService,
    private formBuilder: FormBuilder,
    private modalService: BsModalService
  ) { }

  ngOnInit() {
    this.esSeleccionado
    this.resources = JSON.parse(localStorage.getItem('recursosElink'));

    this.marketService.obtenerEmpresas(this.resources.marca).subscribe((data) => {
      this.listaEmpresa = data;
    });

    // Configuro el forulario
    this.formulario = this.formBuilder.group({
      detalle: this.formBuilder.array([]),
    });
  } 
  get detalleArray() {
    return this.formulario.get("detalle") as FormArray;
  }

  set detalleArray(forma: FormArray) {
    this.formulario.controls.detalle = forma;
  }

 

  listarEmpresas(): void {
    fillCompany.bind(this)();
  }

  listarCanalesWl(): void {
    this.consultarListaWl();
    }


  consultarListaWl() {
    if (!this.empresaSeleccionada) {
      return; 
    }
    if (!this.nombreCuenta) {
      this.nombreCuenta = '';
  }
    this.spinner.show();

    this.marketService.consultarWl(this.empresaSeleccionada.codEmpresa.toString(),this.nombreCuenta, this.page, this.size).subscribe(data => {
      console.log(data);
      this.listaMarket = data.content;
      this.totalPages = data.totalPages;
      this.lastPage = data.last;
      this.spinner.hide();
      
  });
  
  }

  activar(canal: Canales) {
    this.marketActual = canal;
  
    // Mostrar spinner antes de iniciar la operación
    this.spinner.show();
  
    this.marketService
      .cambiarEstadoWl(
        this.marketActual.dominio,
        this.marketActual.apikey,
        this.marketActual.apitoken,
        this.marketActual.accountname,
        this.esSeleccionado.toString()
      )
      .subscribe({
        next: (data) => {
          console.log(data);
          this.spinner.hide();
        },
        error: (err) => {
          console.error('Error al cambiar el estado:', err);
          this.spinner.hide();
          this.alertaService.mostrar(
            'Error al cambiar el estado: ' + err
           );
        },
        complete: () => {
          console.log('Operación completada.');
           this.alertaService.mostrar(
            "Operación completada Exitosamente"
          );
        },
      });
  }
  


  isRowDisabled(estado: string): boolean {
    return estado !== 'A';
}
esActivo(checked: boolean){
  this.esSeleccionado = checked
}
previousPage() {
  if(this.page - 1 >= 0){
      this.page -= 1
      this.consultarListaWl();   
  }
}

nextPage() {
  if (this.page + 1 < this.totalPages) {
      this.page += 1;
      this.consultarListaWl();   
  }
}

goToPage(newPage: number) {
  this.page = newPage
  this.consultarListaWl();
}

onChangeSelectElements(valueElements){
  this.size = valueElements;
  this.consultarListaWl();
}

}
