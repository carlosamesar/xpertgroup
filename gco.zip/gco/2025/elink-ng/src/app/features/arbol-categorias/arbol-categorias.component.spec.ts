import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArbolCategoriasComponent } from './arbol-categorias.component';
import { ReactiveFormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';
import { TreeModule } from 'angular-tree-component';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('ArbolCategoriasComponent', () => {
    let component: ArbolCategoriasComponent;
    let fixture: ComponentFixture<ArbolCategoriasComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [
                ReactiveFormsModule,
                NgSelectModule,
                TreeModule.forRoot(),
                HttpClientTestingModule
            ],
            declarations: [ArbolCategoriasComponent]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ArbolCategoriasComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
