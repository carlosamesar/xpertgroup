import { fillChanels, fillCompany } from 'src/app/shared/utils/listar-canales';
import { MarketplaceService } from "src/app/shared/service/marketplace.service";
import { Canales } from "./../../shared/clases/canales";
import { Empresa } from "./../../shared/clases/empresa";
import {
  Component,
  OnInit,
  Output,
  EventEmitter,
  Input,
  ChangeDetectionStrategy,
} from "@angular/core";
import { Marketplace } from "src/app/shared/clases/marketplace";
import { ArbolCategorias } from "src/app/shared/clases/arbol-categorias";
import { Categoria } from "src/app/shared/clases/categoria";
import { CategoriasService } from "src/app/shared/service/categorias.service";
import { FormGroup, Validators, FormControl } from "@angular/forms";
import { Resource } from 'src/app/shared/clases/resource';

@Component({
  selector: "elk-arbol-categorias",
  templateUrl: "./arbol-categorias.component.html",
  styleUrls: ["./arbol-categorias.component.css"],
  // changeDetection: ChangeDetectionStrategy.OnPush
})
export class ArbolCategoriasComponent implements OnInit {
  @Input() data: Canales[];
  @Input() submitted = false;
  @Input() formGroup: FormGroup = new FormGroup({});
  @Output() seleccionNodo = new EventEmitter<any>();
  @Output() seleccionCanal = new EventEmitter<any>();
  @Output() borradoCanal = new EventEmitter<any>();

  idCanalSel: number;
  empresaSeleccionada: Empresa;
  canalSeleccionado: null;
  listaEmpresa: Empresa[];
  listaCanal: Canales[];
  filtroListaCanal: Canales[];
  arbolCategorias = new ArbolCategorias();
  opcionesArbol = {};
  existenNodos = false;
  listaNodos: ArbolCategorias[] = [];
  categoriaSeleccionada: Categoria = new Categoria();
  nodoSeleccionado = new ArbolCategorias();
  listaCategorias: Categoria[] = [];
  resources: Resource;

  constructor(
    private categoriaService: CategoriasService,
    private marketService: MarketplaceService
  ) {}

  ngOnInit() {
    this.resources = JSON.parse(localStorage.getItem('recursosElink'));

    this.marketService.obtenerEmpresas(this.resources.marca).subscribe((data) => {
      this.listaEmpresa = data;
    });

    if (this.formGroup) {
      this.formGroup.addControl(
        "empresa",
        new FormControl("", Validators.required)
      );
      this.formGroup.addControl(
        "canal",
        new FormControl("", Validators.required)
      );

      this.formGroup.get('empresa').valueChanges.subscribe((empresa) => {
        if (empresa) {
          this.empresaSeleccionada = empresa;
          this.existenNodos = null;
          this.formGroup.get('canal').setValue(null, {emitEvent: false});
        }
      });
      
      this.formGroup.get('canal').valueChanges.subscribe((canal) => {
        if (canal) {
          this.canalSeleccionado = canal;
          this.existenNodos = true;
        } else {
          this.canalSeleccionado = null;
          this.existenNodos = false;
        }
      });
    }
  }

  // convenience getter for easy access to form fields
  get f() {
    return this.formGroup.controls;
  }

  public onNodoActivo(evento: any) {
    this.seleccionNodo.emit(evento);
  }

  listarEmpresas(): void {
    fillCompany.bind(this)();
  }

  listarCanales(): void {
    setTimeout(() => {
    fillChanels.bind(this)();
    })
  }

  seleccionarCanal(event: any): void {
    if (!event) {
      return;
    }

    this.canalSeleccionado = event;

    this.filtroListaCanal = this.listaCanal.filter(
      (canal) => canal.marca === this.empresaSeleccionada.codEmpresa.toString()
    );
    this.listaCanal = this.filtroListaCanal;

    console.log("desde albolCat", this.canalSeleccionado);

    // Consulto el arbol de categorias asociado al market place
    this.categoriaService.obtenerCategoriasPorMarket(event.id).subscribe(
      (data) => {
        this.listaCategorias = data;
        this.crearArbolCategorias(data);
        this.existenNodos = true;

        this.listaNodos.push(this.arbolCategorias);
      },
      (error) => {
        console.error(error);
      }
    );

    console.log(event.id + "arbolCat")
    // Emito el evento de selección de market place
    this.seleccionCanal.emit(event);
  }

  clearMarket() {
    this.borradoCanal.emit();
  }

  crearArbolCategorias(arreglo: Categoria[]) {
    console.warn("Creando arbol de categorías");
    this.arbolCategorias = new ArbolCategorias();
    this.listaNodos = [];

    arreglo.forEach((catego) => {
      const nodo = new ArbolCategorias();

      nodo.id = Number(catego.campCodigo);
      nodo.padre = Number(catego.campCategoPadre);
      nodo.name = catego.campNombre;
      nodo.categoria = catego;

      this.arbolCategorias.crearNodo(nodo);
    });

    console.log(this.arbolCategorias);
  }
}
