import { Marketplace } from 'src/app/shared/clases/marketplace';
/* 
traemos todas las empresas
*/
function fillCompany() {
  this.marketService.obtenerEmpresas().subscribe((empresas) => {
    this.listaEmpresa = empresas;
    fillChanels.bind(this)();
  });
}

/* 
cuando hay una empresa seleccionada, traemos todos los canales y filtramos la lista
para que se muestren solos los que conincidan con el codigo de la empresa seleccionada
*/
function fillChanels() {
  if (this.empresaSeleccionada) {
    this.marketService.obtenerMarketPlaces().subscribe((canales) => {
      this.filtroListaCanal = canales.filter(
        (canal) =>
          canal.marca === this.empresaSeleccionada.codEmpresa.toString() && canal.marketplace === true
      );
      this.listaCanal = this.filtroListaCanal;
      this.canalSeleccionado = null;
    });
  }else {
    this.listaCanal = [];
    this.filtroListaCanal = null;
    this.canalSeleccionado = null;
  }
}

export { fillCompany, fillChanels };