import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CategoriasService } from './service/categorias.service';
import { MarketplaceService } from './service/marketplace.service';
import { RequestInterceptorService } from './service/request-interceptor.service';
import { AlertaService } from './service/alerta.service';
import { ModalModule } from 'ngx-bootstrap/modal';
import { AlertaContentComponent } from './componentes/alerta-content/alerta-content.component';
import { ProductosService } from './service/productos.service';
import { NoEsCargablePipe } from './pipes/no-es-cargable.pipe';
import { ModalElinkService } from './service/modal-elink.service';
import { EquivalenciasService } from './service/equivalencias.service';
import { FechaPipe } from './pipes/fecha.pipe';
import { SeleccionadosPipe } from './pipes/seleccionados.pipe';
import { SeguridadService } from './service/seguridad.service';
import { CookieService } from 'ngx-cookie-service';
import { MostrarOpcionPipe } from './pipes/mostrar-opcion.pipe';
import { AtributosService } from './service/atributos.service';
import { CambiaPalabraPipe } from './pipes/cambia-palabra.pipe';
import { ImagenRendererComponent } from './componentes/imagen-renderer/imagen-renderer.component';
import { CaritasRendererComponent } from './componentes/caritas-renderer/caritas-renderer.component';
import { ReferenciaRendererComponent } from './componentes/referencia-renderer/referencia-renderer.component';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { DescripcionRendererComponent } from './componentes/descripcion-renderer/descripcion-renderer.component';
import { ComposicionRendererComponent } from './componentes/composicion-renderer/composicion-renderer.component';
import { FechaRendererComponent } from './componentes/fecha-renderer/fecha-renderer.component';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { FormsModule } from '@angular/forms';
import { ValidadorReferenciaService } from './service/validador-referencia.service';
import { ValidadorReferenciaMockService } from './service/validador-referencia.service.mock';
import { environment } from '../../environments/environment';

@NgModule({
    declarations: [
        AlertaContentComponent,
        NoEsCargablePipe,
        FechaPipe,
        SeleccionadosPipe,
        MostrarOpcionPipe,
        CambiaPalabraPipe,
        ImagenRendererComponent,
        CaritasRendererComponent,
        ReferenciaRendererComponent,
        DescripcionRendererComponent,
        ComposicionRendererComponent,
        FechaRendererComponent
    ],
    providers: [
        AtributosService,
        CategoriasService,
        MarketplaceService,
        RequestInterceptorService,
        AlertaService,
        ProductosService,
        ModalElinkService,
        EquivalenciasService,
        SeguridadService,
        CookieService,
        // Usar mock service en modo de pruebas E2E
        {
            provide: ValidadorReferenciaService,
            useClass: environment.useMocks ? ValidadorReferenciaMockService : ValidadorReferenciaService
        }
    ],
    imports: [
        CommonModule,
        ModalModule.forRoot(),
        PopoverModule.forRoot(),
        BsDatepickerModule.forRoot(),
        FormsModule
    ],
    entryComponents: [
      AlertaContentComponent,
      CaritasRendererComponent,
      ReferenciaRendererComponent,
      DescripcionRendererComponent,
      ComposicionRendererComponent,
      FechaRendererComponent
    ],
    exports: [
      NoEsCargablePipe,
      FechaPipe,
      SeleccionadosPipe,
      MostrarOpcionPipe,
      CambiaPalabraPipe,
      ImagenRendererComponent,
      CaritasRendererComponent,
      ReferenciaRendererComponent,
      DescripcionRendererComponent,
      ComposicionRendererComponent,
      FechaRendererComponent
    ]
})
export class SharedModule { }
