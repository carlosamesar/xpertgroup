import { Component, OnInit } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { ICellRendererParams, IAfterGuiAttachedParams } from 'ag-grid-community';
import { ReferenciaVtexDto } from '../../clases/referencia-vtex-dto';

@Component({
  selector: 'elk-imagen-renderer',
  templateUrl: './imagen-renderer.component.html',
  styleUrls: ['./imagen-renderer.component.css']
})
export class ImagenRendererComponent implements OnInit, ICellRendererAngularComp {

  item: ReferenciaVtexDto;
  params: ICellRendererParams;
  imagenCargada = false;
  errorCargaImagen = false;

  refresh(params: any): boolean {
    throw new Error('Method not implemented.');
  }

  agInit(params: ICellRendererParams): void {

    this.params = params;
    this.item = params.value as ReferenciaVtexDto;

  }

  afterGuiAttached?(params?: IAfterGuiAttachedParams): void {
    throw new Error('Method not implemented.');
  }

  constructor() { }

  ngOnInit() {
  }

  obtenerUrl(): string {
    return this.item.urlImagen || 'assets/img/placeholder-image.png';
  }

  actualizarCaritaImagen(event) {
    // Evitar reintentos: solo ejecutar una vez
    if (this.errorCargaImagen) {
      return;
    }
    
    this.errorCargaImagen = true;
    console.log('Error al cargar imagen, usando placeholder');
    
    // Establecer imagen placeholder si falla la carga
    event.target.src = 'assets/img/placeholder-image.png';
    
    // Remover el event listener para evitar más llamados
    event.target.onerror = null;
  }

  onImagenCargada() {
    this.imagenCargada = true;
  }

}
