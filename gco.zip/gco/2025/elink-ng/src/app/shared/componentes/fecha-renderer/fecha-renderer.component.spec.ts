import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FechaRendererComponent } from './fecha-renderer.component';

describe('FechaRendererComponent', () => {
  let component: FechaRendererComponent;
  let fixture: ComponentFixture<FechaRendererComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FechaRendererComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FechaRendererComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
