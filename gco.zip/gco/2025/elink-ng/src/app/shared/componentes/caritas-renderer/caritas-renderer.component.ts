import { Component, OnInit } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { ICellRendererParams, IAfterGuiAttachedParams } from 'ag-grid-community';

@Component({
  selector: 'elk-caritas-renderer',
  templateUrl: './caritas-renderer.component.html',
  styleUrls: ['./caritas-renderer.component.css']
})
export class CaritasRendererComponent implements OnInit, ICellRendererAngularComp {

  params: ICellRendererParams;

  refresh(params: any): boolean {
    return false;
  }

  agInit(params: ICellRendererParams): void {
    this.params = params;
  }

  afterGuiAttached?(params?: IAfterGuiAttachedParams): void {
  }

  constructor() { }

  ngOnInit() {
  }

  onClick(event: Event): void {
    if (event) {
      event.stopPropagation();
      event.preventDefault();
    }

    console.log('===== CaritasRenderer onClick =====');
    console.log('Params completo:', this.params);
    console.log('Params.value:', this.params.value);
    console.log('Params.data:', this.params.data);
    console.log('Params.node:', this.params.node);
    console.log('Params.node.data:', this.params.node.data);
    console.log('Context:', this.params.context);
    console.log('ComponentParent:', this.params.context.componentParent);

    if (!this.params) {
      console.error('ERROR: params no esta definido');
      return;
    }

    if (!this.params.context) {
      console.error('ERROR: params.context no esta definido');
      return;
    }

    if (!this.params.context.componentParent) {
      console.error('ERROR: componentParent no esta definido');
      return;
    }

    // Obtener los datos de la fila (pueden estar en params.data o params.node.data)
    const rowData = this.params.data || this.params.node.data;
    
    if (!rowData) {
      console.error('ERROR: No se pudo obtener los datos de la fila');
      return;
    }

    console.log('Datos de la fila obtenidos:', rowData);

    const componentParent = this.params.context.componentParent;
    
    if (typeof componentParent.abrirModalDetalleValidacion === 'function') {
      console.log('Llamando a abrirModalDetalleValidacion con datos:', rowData);
      componentParent.abrirModalDetalleValidacion(rowData);
    } else {
      console.error('ERROR: El metodo abrirModalDetalleValidacion no existe');
      console.log('Metodos disponibles en componentParent:', Object.getOwnPropertyNames(Object.getPrototypeOf(componentParent)));
    }
  }

}
