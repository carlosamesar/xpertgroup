import { Component, OnInit } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { ReferenciaVtexDto } from '../../clases/referencia-vtex-dto';
import { ICellRendererParams, IAfterGuiAttachedParams } from 'ag-grid-community';

@Component({
  selector: 'elk-fecha-renderer',
  templateUrl: './fecha-renderer.component.html',
  styleUrls: ['./fecha-renderer.component.css']
})
export class FechaRendererComponent implements OnInit, ICellRendererAngularComp {

  item: ReferenciaVtexDto;
  html: string;
  
  constructor() { }

  ngOnInit() {
  }

  refresh(params: any): boolean {
    throw new Error('Method not implemented.');
  }

  agInit(params: ICellRendererParams): void {

    this.item = params.value as ReferenciaVtexDto;

  }

  afterGuiAttached?(params?: IAfterGuiAttachedParams): void {
    throw new Error('Method not implemented.');
  }

}
