import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AlertaContentComponent } from './alerta-content.component';
import { BsModalRef } from 'ngx-bootstrap/modal';

describe('AlertaContentComponent', () => {
    let component: AlertaContentComponent;
    let fixture: ComponentFixture<AlertaContentComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [AlertaContentComponent],
            providers: [BsModalRef]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(AlertaContentComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
