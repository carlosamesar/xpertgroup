import { Component, OnInit } from '@angular/core';
import { ICellRendererParams, IAfterGuiAttachedParams } from 'ag-grid-community';
import { ReferenciaVtexDto } from '../../clases/referencia-vtex-dto';
import { ICellRendererAngularComp } from 'ag-grid-angular';

@Component({
  selector: 'elk-descripcion-renderer',
  templateUrl: './descripcion-renderer.component.html',
  styleUrls: ['./descripcion-renderer.component.css']
})
export class DescripcionRendererComponent implements OnInit, ICellRendererAngularComp {
  params: ICellRendererParams;
  item: ReferenciaVtexDto;
  html: string;
  
  constructor() { }

  ngOnInit() {
  }

  refresh(params: any): boolean {
    throw new Error('Method not implemented.');
  }

  agInit(params: ICellRendererParams): void {
    this.params = params;
    this.item = params.value as ReferenciaVtexDto;

  }

  afterGuiAttached?(params?: IAfterGuiAttachedParams): void {
    throw new Error('Method not implemented.');
  }

  generarDescripcion(item: ReferenciaVtexDto) {
    console.log (this.params);
    this.params.context.componentParent.generarDescripcion(item);
  }
}
