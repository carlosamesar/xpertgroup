import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReferenciaRendererComponent } from './referencia-renderer.component';

describe('ReferenciaRendererComponent', () => {
  let component: ReferenciaRendererComponent;
  let fixture: ComponentFixture<ReferenciaRendererComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReferenciaRendererComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReferenciaRendererComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
