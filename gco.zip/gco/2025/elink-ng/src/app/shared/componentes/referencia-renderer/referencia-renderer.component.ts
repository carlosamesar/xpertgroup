import { Component, OnInit } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { ICellRendererParams, IAfterGuiAttachedParams } from 'ag-grid-community';
import { ReferenciaVtexDto } from '../../clases/referencia-vtex-dto';
import { FechaPipe } from '../../pipes/fecha.pipe';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'elk-referencia-renderer',
  templateUrl: './referencia-renderer.component.html',
  styleUrls: ['./referencia-renderer.component.css'],
  providers: [
    FechaPipe,
    DatePipe
]
})
export class ReferenciaRendererComponent implements ICellRendererAngularComp {

  params: ICellRendererParams;
  item: ReferenciaVtexDto;
  html: string;

  constructor(private datePipe: DatePipe) {
  }



  refresh(params: any): boolean {
    throw new Error('Method not implemented.');
  }

  agInit(params: ICellRendererParams): void {
    
    this.params = params;
    this.item = params.value as ReferenciaVtexDto;

  }

  afterGuiAttached?(params?: IAfterGuiAttachedParams): void {
    throw new Error('Method not implemented.');
  }

  

  verDetalleReferencia(item: ReferenciaVtexDto) {

    let strFecha = '';

    if (item.fechaCarga) {
        strFecha = this.datePipe.transform(item.fechaCarga, 'yyyy-MM-dd');
    }

    const colorFamily = (item.colorFamily ? item.colorFamily: '');
    const precio = (item.valorPublico && item.valorPublico > 0 ? item.valorPublico: 0);
    const nombreComercial = (item.nombreComercial ? item.nombreComercial: '');
    const categoria = (item.nomCategoria ? item.nomCategoria: '');

    this.html = `
        <div><strong>Año: </strong> ${item.ano}</div>
        <div><strong>Plu: </strong> ${item.codPlu}</div>
        <div><strong>Nombre comercial: </strong> ${nombreComercial}</div>
        <div><strong>Categoría: </strong> ${categoria}</div>
        <div><strong>Ult carga: </strong> ${strFecha} </div>
        <div><strong>Color family: </strong> ${colorFamily} </div>
    `;

  }

  crearColor(item: ReferenciaVtexDto) {
    this.params.context.componentParent.crearColor(item);
  }

  verAtributos(item: ReferenciaVtexDto) {
    this.params.context.componentParent.verAtributos(item);
  }

}
