import { Component, OnInit } from '@angular/core';
import { Subject } from 'rxjs';
import { BsModalRef } from 'ngx-bootstrap/modal';

@Component({
    selector: 'elk-alerta-content',
    templateUrl: './alerta-content.component.html',
    styleUrls: ['./alerta-content.component.css']
})
export class AlertaContentComponent implements OnInit {

    titulo = '';
    mensaje = '';
    esConfirmacion = false;

    public onClose: Subject<boolean>;

    constructor(private modalRef: BsModalRef) { }

    ngOnInit() {
        this.onClose = new Subject();
    }

    public cerrar(): void {
        this.modalRef.hide();
    }

    public confirmar(): void {
        this.onClose.next(true);
        this.modalRef.hide();
    }

    public cancelar(): void {
        this.onClose.next(false);
        this.modalRef.hide();
    }

}
