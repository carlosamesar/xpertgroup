import { Component, OnInit } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { ICellRendererParams, IAfterGuiAttachedParams } from 'ag-grid-community';
import { ReferenciaVtexDto } from '../../clases/referencia-vtex-dto';

@Component({
  selector: 'elk-composicion-renderer',
  templateUrl: './composicion-renderer.component.html',
  styleUrls: ['./composicion-renderer.component.css']
})
export class ComposicionRendererComponent implements OnInit, ICellRendererAngularComp {

  item: ReferenciaVtexDto;
  html: string;
  params: ICellRendererParams;
  
  constructor() { }

  ngOnInit() {
  }

  refresh(params: any): boolean {
    throw new Error('Method not implemented.');
  }

  agInit(params: ICellRendererParams): void {

    this.params = params;
    this.item = params.value as ReferenciaVtexDto;

  }

  afterGuiAttached?(params?: IAfterGuiAttachedParams): void {
    throw new Error('Method not implemented.');
  }

  crearComposicion(item: ReferenciaVtexDto) {
    this.params.context.componentParent.crearComposicion(item);
  }

}
