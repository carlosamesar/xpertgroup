import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaritasRendererComponent } from './caritas-renderer.component';

describe('CaritasRendererComponent', () => {
  let component: CaritasRendererComponent;
  let fixture: ComponentFixture<CaritasRendererComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaritasRendererComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaritasRendererComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
