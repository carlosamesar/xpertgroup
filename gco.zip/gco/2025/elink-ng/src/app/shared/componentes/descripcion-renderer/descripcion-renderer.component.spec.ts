import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DescripcionRendererComponent } from './descripcion-renderer.component';

describe('DescripcionRendererComponent', () => {
  let component: DescripcionRendererComponent;
  let fixture: ComponentFixture<DescripcionRendererComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DescripcionRendererComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DescripcionRendererComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
