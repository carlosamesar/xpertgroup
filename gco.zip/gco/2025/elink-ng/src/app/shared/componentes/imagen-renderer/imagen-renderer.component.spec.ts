import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImagenRendererComponent } from './imagen-renderer.component';

describe('ImagenRendererComponent', () => {
  let component: ImagenRendererComponent;
  let fixture: ComponentFixture<ImagenRendererComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImagenRendererComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImagenRendererComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
