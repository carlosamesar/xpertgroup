import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ComposicionRendererComponent } from './composicion-renderer.component';

describe('ComposicionRendererComponent', () => {
  let component: ComposicionRendererComponent;
  let fixture: ComponentFixture<ComposicionRendererComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ComposicionRendererComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ComposicionRendererComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
