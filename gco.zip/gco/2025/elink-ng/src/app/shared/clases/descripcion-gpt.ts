import { items } from "./item-descripcion";

export class DescripcionGpt {
  id: String;
  name: string;
  product: String;
  brand: String;
  composition: String[];
  description?: string;
  fit: string;
  atributo: string;
  gender: string;
  url_image: String;
}
