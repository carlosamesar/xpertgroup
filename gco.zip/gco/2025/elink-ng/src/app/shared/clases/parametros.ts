export class Parametros {
    
    nombre: string;
    ano: number;
    coleccion: string;
    referencias: string;
    referencias64: string;
    id: string;
    marca: string;
    ecommerce: string;
}
