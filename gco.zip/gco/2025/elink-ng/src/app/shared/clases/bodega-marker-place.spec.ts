import { BodegaMarkerPlace } from './bodega-marker-place';

describe('BodegaMarkerPlace', () => {
  it('should create an instance', () => {
    expect(new BodegaMarkerPlace()).toBeTruthy();
  });
});
