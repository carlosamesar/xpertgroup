export  class AtributoIAResponseDTO {
  name: string;
  description: string;
  sensation: string;
  use: string;
  recommendation: string;
  features: string;
  care_instructions: string;
  meta_tags: string;
  meta_data: MetaDataDto;
  img_description: string;
  model_size: string;
  notes: string;
}

export class MetaDataDto {
  tile: string;
  description: string;
}


