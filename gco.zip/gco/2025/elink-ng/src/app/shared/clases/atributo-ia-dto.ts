import { MetaDataDto } from "./atributo-ia-response-dto";

export class AtributoIADto {
  referencia: string;
  empresa: number;
  nombre: String;
  descripcion: String;
  canal: number;
  sensation: String;
  use: String;
  recommendation: String;
  features: String;
  careInstructions: String;
  metaTags: String;
  medaDataTile: String;
  medaDataDescription: String;
  imgDescription: String;
  modelSize: String;
  notes: String;
}
