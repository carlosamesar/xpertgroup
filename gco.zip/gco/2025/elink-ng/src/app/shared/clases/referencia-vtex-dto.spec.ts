import { ReferenciaVtexDto } from './referencia-vtex-dto';

describe('ReferenciaVtexDto', () => {
  it('should create an instance', () => {
    expect(new ReferenciaVtexDto()).toBeTruthy();
  });
});
