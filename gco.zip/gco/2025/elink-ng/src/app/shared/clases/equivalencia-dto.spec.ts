import { EquivalenciaDto } from './equivalencia-dto';

describe('EquivalenciaDto', () => {
  it('should create an instance', () => {
    expect(new EquivalenciaDto()).toBeTruthy();
  });
});
