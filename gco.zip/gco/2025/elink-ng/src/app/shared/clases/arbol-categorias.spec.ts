import { ArbolCategorias } from './arbol-categorias';

describe('ArbolCategorias', () => {
    
    it('should create an instance', () => {
        expect(new ArbolCategorias()).toBeTruthy();
    });
});
