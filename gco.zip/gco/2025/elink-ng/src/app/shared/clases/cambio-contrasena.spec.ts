import { CambioContrasena } from './cambio-contrasena';

describe('CambioContrasena', () => {
  it('should create an instance', () => {
    expect(new CambioContrasena()).toBeTruthy();
  });
});
