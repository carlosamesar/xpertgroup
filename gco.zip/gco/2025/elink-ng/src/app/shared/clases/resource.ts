export class Resource {
    rol: string;
    marca :string;
    opciones: string[];
    resources: Resource[];

    constructor() {
        this.resources = [];
    }
    
}
