export class Canales {

    id: string;
    nombre: string;
    descripcion: string;
    estado: string;
    marca: string;
    dominio: string;
    apikey: string;
    apitoken: string;
    accountname: string;
    marketplace: boolean;
    codPos: string;
    activo: boolean;
    apitokenwl: string;
    apikeynwl: string;

}
