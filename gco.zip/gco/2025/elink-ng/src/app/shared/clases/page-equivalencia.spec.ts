import { PageEquivalencia } from './page-equivalencia';

describe('PageEquivalencia', () => {
  it('should create an instance', () => {
    expect(new PageEquivalencia()).toBeTruthy();
  });
});
