export class Marketplace {
    appKey: string;
    appToken: string;
    codigo: string;
    empresaErp: number;
    estado: string;
    modificacion: string;
    multimarca: string;
    nombre: string;
    nombreTienda: string;
    passWsCoordinadora: string;
    passwordWs: string;
    proveedor: string;
    uid: number;
    urlEndpoint: string;
    usuario: string;
    usuarioWs: string;
    usuarioWsCoordinadora: string;
    warehouse: string;
    canal:string;
    id: string;
    codPos: string;

}
