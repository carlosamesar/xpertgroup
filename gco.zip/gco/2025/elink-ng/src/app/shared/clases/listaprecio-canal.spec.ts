import { ListaprecioCanal } from './listaprecio-canal';

describe('ListaprecioCanal', () => {
  it('should create an instance', () => {
    expect(new ListaprecioCanal()).toBeTruthy();
  });
});
