import { Canales } from './canales';

export class AtributoMarket {
    armpUid: number;
    armpCodigo: string;
    armpValor: string;
    armpCreacion: Date;
    armpModificacion: Date;
    armpEstado: string;
    armpUsuario: string;
    armpTipo: string;
    elkCanalMae: Canales;
    armpSic: boolean;
}
