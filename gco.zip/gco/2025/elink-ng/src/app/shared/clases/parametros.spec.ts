import { Parametros } from './parametros';

describe('Parametros', () => {
  it('should create an instance', () => {
    expect(new Parametros()).toBeTruthy();
  });
});
