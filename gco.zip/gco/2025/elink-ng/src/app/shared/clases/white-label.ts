export class whiteLabel {
    UrlLogo: string = '';
    SellerId: string = '';
    Name: string = '';
    Email: string = '';
    Description: string | null = null;
    ExchangeReturnPolicy: string = '';
    DeliveryPolicy: string | null = null;
    SecutityPrivacyPolicy: string = '';
    CNPJ: string | null = null;
    CSCIdentification: string | null = null;
    ArchiveId: string | null = null;
    ProductCommissionPercentage: number = 0.0;
    FreightCommissionPercentage: number = 0.0;
    CategoryCommissionPercentage: string = '[]';
    FulfillmentEndpoint: string = '';
    CatalogSystemEndpoint: string = '';
    IsActive: boolean = false;
    IsBetterScope: boolean = false;
    MerchantName: string | null = null;
    UserName: string | null = null;
    Password: string | null = null;
    UseHybridPaymentOptions: boolean = true;
    FulfillmentSellerId: string | null = null;
    SellerType: number = 2;
    trustPolicy: string = 'Default';
    policies: string[] = ['Default'];
    Groups: any[] = [];
  }
  