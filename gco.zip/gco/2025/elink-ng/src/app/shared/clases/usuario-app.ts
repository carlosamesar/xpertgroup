export class UsuarioApp {
  data: {
    username: string;
    jwt: string;
  };
}
