import { Marketplace } from './marketplace';

export class BodegaMarkerPlace {
    codigo: string;
    codigoErp: string;
    creacion: Date;
    estado: string;
    modificacion: Date;
    tipoBodega: string;
    uid: number;
    uidMarketplace: Marketplace;
}
