export class ListaprecioCanal {
    idCanal: string;
    divisa: string;
    codPais: string;
}
