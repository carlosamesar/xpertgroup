export class ListResource {
        id: string;
        nombre: string;
}
