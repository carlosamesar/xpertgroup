import { TipoEquivalencia } from './tipo-equivalencia';

export class Equivalencia {

    equiUid: number;
    equiValorOrigen: string;
    equiValorEquivalencia: string;
    tieqUid: TipoEquivalencia;

}
