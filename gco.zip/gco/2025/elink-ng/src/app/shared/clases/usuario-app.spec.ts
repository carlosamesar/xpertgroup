import { UsuarioApp } from './usuario-app';

describe('UsuarioApp', () => {
  it('should create an instance', () => {
    expect(new UsuarioApp()).toBeTruthy();
  });
});
