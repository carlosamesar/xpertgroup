import { Equivalencia } from './equivalencia';

export class PageEquivalencia {

    content: Equivalencia[];
    numberOfElements: number;
    totalElements: number;
    totalPages: number;
    last: boolean;

}
