import { Canales } from './canales';

export class Categoria {
    campUid: number;
    campCodigo: string;
    campNombre: string;
    campCreacion: Date;
    campModificacion: Date;
    campUsuario: string;
    campEstado: string;
    campCategoPadre: string;
    campCategoOutlet: string;
    elkCanalMae: Canales;
    campCodEquivalente: string;
    id: string;
    
    

}
