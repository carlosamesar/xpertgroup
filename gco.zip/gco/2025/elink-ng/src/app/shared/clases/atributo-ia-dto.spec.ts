import { AtributoIADto } from './atributo-ia-dto';

describe('AtributoIADto', () => {
  it('should create an instance', () => {
    expect(new AtributoIADto()).toBeTruthy();
  });
});
