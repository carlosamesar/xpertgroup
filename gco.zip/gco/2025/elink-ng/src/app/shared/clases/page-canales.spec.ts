import { PageCanales } from './page-canales';

describe('PageCanales', () => {
  it('should create an instance', () => {
    expect(new PageCanales()).toBeTruthy();
  });
});
