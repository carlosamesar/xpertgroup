export class items {

    id: String;
    name: string;
    product: String;
    brand: String;
    composition: String[];
    description?: string;
    fit: string;
    atributo: string;
    gender: string;
    image_desc: string;
    url_image: String;

}
