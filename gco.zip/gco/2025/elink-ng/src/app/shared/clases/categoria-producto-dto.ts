export class CategoriaProductoDto {

    idCategoriaProducto: number;
    idMarketPlace: string;
    idCategoria: number;
    productoCategoria: string;
    brand: string;
    codigoCategoria: string;
    codColor: string;

}
