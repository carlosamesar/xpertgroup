export class CambioContrasena {
    username: string;
    password: string;
}
