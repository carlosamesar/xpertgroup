import { Marketplace } from './marketplace';

describe('Marketplace', () => {
  it('should create an instance', () => {
    expect(new Marketplace()).toBeTruthy();
  });
});
