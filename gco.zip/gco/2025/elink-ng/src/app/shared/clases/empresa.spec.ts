import { Empresa } from './empresa';

describe('Empresa', () => {
  it('should create an instance', () => {
    expect(new Empresa()).toBeTruthy();
  });
});
