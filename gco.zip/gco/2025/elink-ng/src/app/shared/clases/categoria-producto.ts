import { Canales } from './canales';
import { Categoria } from './categoria';

export class CategoriaProducto {

    cmprUid: number;
    cmprProductoErp: string;
    cmprDescripProducto: string;
    cmprCreacion: Date;
    cmprModificacion: Date;
    cmprUsuario: string;
    cmprEstado: string;
    cmprBrandMarket: string;
    //campUid: Categoria;
    elkCategoriasMarketPlace: Categoria;
    elkCanalMae:Canales;
    codColor: string;
    id: string;

}
