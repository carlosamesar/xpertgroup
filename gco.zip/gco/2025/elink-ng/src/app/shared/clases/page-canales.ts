import { Canales } from "./canales";

export class PageCanales {
    content: Canales[];
    numberOfElements: number;
    totalElements: number;
    totalPages: number;
    last: boolean;
}
