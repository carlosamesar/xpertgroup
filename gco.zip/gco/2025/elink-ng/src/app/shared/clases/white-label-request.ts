export interface WhiteLabelDto {
    marca: string;
    name: string;
    isBetterScope: string;
    apiKey: string;
    apiToken: string;
  }