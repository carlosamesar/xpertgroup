import { Categoria } from './categoria';

export class ArbolCategorias {
    id: number;
    padre: number;
    name: string;
    children: ArbolCategorias[];
    categoria: Categoria;

    constructor() {
        this.children = [];
    }

    crearNodo(nodo: ArbolCategorias): void {

        if (nodo.id === 0) {

            this.id = nodo.id;
            this.padre = nodo.padre;
            this.name = nodo.name;

        } else if (this.id === nodo.padre) {

            this.children.push(nodo);

        } else {

            this.children.forEach(hijo => {
                hijo.crearNodo(nodo);
            });

        }

    }
}
