export class TipoEquivalencia {
    tieqUid: number;
    tieqCodigo: string;
    tieqNombre: string;
    tieqCreacion: Date;
    tieqModificacion: Date;
    tieqEstado: string;
    tieqUsuario: string;
}
