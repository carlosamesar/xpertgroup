import { CategoriaProductoDto } from './categoria-producto-dto';

describe('CategoriaProductoDto', () => {
  it('should create an instance', () => {
    expect(new CategoriaProductoDto()).toBeTruthy();
  });
});
