import { AtributoMarket } from './atributo-market';

describe('AtributoMArket', () => {
  it('should create an instance', () => {
    expect(new AtributoMarket()).toBeTruthy();
  });
});
