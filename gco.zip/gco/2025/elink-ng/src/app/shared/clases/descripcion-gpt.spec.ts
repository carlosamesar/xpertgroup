import { DescripcionGpt } from './descripcion-gpt';

describe('DescripcionGpt', () => {
  it('should create an instance', () => {
    expect(new DescripcionGpt()).toBeTruthy();
  });
});
