import { Equivalencia } from './equivalencia';

describe('Equivalencia', () => {
  it('should create an instance', () => {
    expect(new Equivalencia()).toBeTruthy();
  });
});
