import { CategoriaProducto } from './categoria-producto';

describe('CategoriaProducto', () => {
  it('should create an instance', () => {
    expect(new CategoriaProducto()).toBeTruthy();
  });
});
