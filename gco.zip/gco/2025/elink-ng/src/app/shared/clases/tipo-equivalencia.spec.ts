import { TipoEquivalencia } from './tipo-equivalencia';

describe('TipoEquivalencia', () => {
  it('should create an instance', () => {
    expect(new TipoEquivalencia()).toBeTruthy();
  });
});
