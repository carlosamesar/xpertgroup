export class EquivalenciaDto {
    idEquivalencia: number;
    tipo: number;
    valor: string;
    equivalencia: string;
}
