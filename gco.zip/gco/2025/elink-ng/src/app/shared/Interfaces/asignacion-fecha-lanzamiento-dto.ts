export interface AsignacionFechaLanzamientoDto {
  fecha: string;  // Formato 'yyyy-MM-dd' para compatibilidad con backend
  canales: string[];  // Array de códigos de canal
}
