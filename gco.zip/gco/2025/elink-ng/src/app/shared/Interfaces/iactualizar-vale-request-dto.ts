export interface IActualizarValeRequestDTO {
    id?: number;
    nombreAlianza: string;
    campana: string;
    idVtex?: string;
}