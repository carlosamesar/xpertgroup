import { IDesReferenciaPK } from './ides-referencia-pk';

export interface IDesReferencia {
    id: IDesReferenciaPK;
}