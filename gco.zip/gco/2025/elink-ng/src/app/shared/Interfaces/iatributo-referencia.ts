
export interface IAtributoReferencia {
    codReferencia: string;
    ano: number;
    talla: string;
    codColor: string;
    codPlu: string;
    codProveedoref: string;
    existe: number;
    esadoRef: string;
    estadoAtrib: string;
    estadoInv: string;
    numAtrib: number;
    nombresAtrib: string;
    tieneAtrib: string;
    idAtributo: number;
    idValor: number;
    codigo: string;
    nombre: string;
    valor: string;
}
