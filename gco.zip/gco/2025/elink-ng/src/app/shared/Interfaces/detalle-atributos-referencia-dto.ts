export interface AtributoReferenciaDto {
  nombre: string;
  ok: boolean;
  valor?: string;
}

export interface CanalReferenciaDto {
  codigo: string;
  nombre: string;
  ok: boolean;
  atributosFaltantes: string[];
}

export interface DetalleAtributosReferenciaDto {
  idReferencia: string;
  codigoReferencia: string;
  nombreReferencia?: string;
  atributos: AtributoReferenciaDto[];
  canales: CanalReferenciaDto[];
}
