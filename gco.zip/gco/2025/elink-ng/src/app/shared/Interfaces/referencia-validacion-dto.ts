export interface ReferenciaValidacionDto {
  baseUrlImagen: string;
  codReferencia: string;
  nomReferencia: string;
  estadoGeneral: boolean;
  
  // Propiedades computadas para compatibilidad con componentes existentes
  id?: string;
  codigo?: string;
  nombre?: string;
  urlImagen?: string;
  isValid?: boolean;
}
