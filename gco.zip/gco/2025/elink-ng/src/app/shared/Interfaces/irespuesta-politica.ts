import { IPoliticaComercial } from './ipolitica-comercial';

export interface IRespuestaPolitica {
    reg: IPoliticaComercial;
    error: string;
}
