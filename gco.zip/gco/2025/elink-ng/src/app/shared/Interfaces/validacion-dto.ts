/**
 * DTO para el resumen agregado de validaciones
 * Representa el estado global de todas las validaciones a través de todos los canales
 * TRUE indica que TODOS los canales cumplen con esa validación
 */
export interface ValidacionResumenDto {
  descripcion: boolean;
  sic: boolean;
  imagen: boolean;
  talla: boolean;
  color: boolean;
  categoria: boolean;
  precio: boolean;
  cargado: boolean;
}

/**
 * DTO para validaciones desagregadas por canal
 * Representa el estado individual de cada validación para un canal específico
 */
export interface ValidacionCanalDto {
  codigoReferencia: string;
  nombreCanal: string;
  descripcionOk: boolean;
  sicOk: boolean;
  imagenOk: boolean;
  tallaOk: boolean;
  colorOk: boolean;
  categoriaOk: boolean;
  precioOk: boolean;
  cargadoOk: boolean;
}
