export interface IValeRequestDTO {
    empresa: string;
    canal: string;
    relationName: string;
    quantity: number;
    expiringDate: Date;
    restrictedToOwner: boolean;
    multipleRedemptions: boolean;
    multipleCredits: boolean;
    profileId: string;
    value: number;
    name: string;
    emissionDate: Date;
    caption: string;
    description: string;
    usuario: string;
}
