import { AtributoMarket } from '../clases/atributo-market';

export interface IValoresAtribMarket {
    vampUid: number;
    vampCodigo: string;
    vampValor: string;
    vampEstado: string;
    armpUid: AtributoMarket;
}
