export interface IValeResponseDTO {
    id: number;
    nombreAlianza: string;
    email: string;
    valor: number;
    marca: string;
    estado: string;
    fechaExpiracion: Date;
    fechaCreacion: Date;
    idVtex: string;
    cupon: string;
    campana: string;
    recargado: boolean;
}