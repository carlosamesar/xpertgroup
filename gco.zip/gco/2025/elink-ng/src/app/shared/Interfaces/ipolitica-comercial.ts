export interface IPoliticaComercial {
    proveedor: string;
    referencia: string;
    canal: string;
    politica: string;
    error: string;
}

