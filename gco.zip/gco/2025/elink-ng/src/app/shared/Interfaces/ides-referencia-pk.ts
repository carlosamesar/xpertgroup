export interface IDesReferenciaPK {
    codEmpresa: number;
    tipTercerobod: string;
    numAno: number;
    codReferencia: string;
    codProveedoref: string;
}
