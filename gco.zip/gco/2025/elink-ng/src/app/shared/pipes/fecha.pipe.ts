import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'fecha'
})
export class FechaPipe implements PipeTransform {

    transform(value: any, args?: any): Date {

        if (value) {

            //if (typeof value === 'number') {
                return new Date(new Date(value).getTime());
           // }
            
        }

        return null;
    }

}
