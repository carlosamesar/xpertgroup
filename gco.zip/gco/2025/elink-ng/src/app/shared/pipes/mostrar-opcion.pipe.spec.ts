import { MostrarOpcionPipe } from './mostrar-opcion.pipe';
import { SeguridadService } from '../service/seguridad.service';

describe('MostrarOpcionPipe', () => {
    it('create an instance', () => {

        const service = new SeguridadService(null, null);

        const pipe = new MostrarOpcionPipe(service);
        expect(pipe).toBeTruthy();
    });
});
