import { Pipe, PipeTransform } from '@angular/core';
import { ReferenciaVtexDto } from '../clases/referencia-vtex-dto';

@Pipe({
    name: 'noEsCargable'
})
export class NoEsCargablePipe implements PipeTransform {

    transform(value: ReferenciaVtexDto, args?: any): boolean {

      if (!value) {
        return true;
      }

      if ((value.tieneDescripcion || value.descripcion) &&
          value.tieneImagen &&
          (value.tieneTalla || value.equivTalla) &&
          (value.tieneColor || value.equivColor) &&
          (value.nomCategoria && value.nomCategoria.length > 0)) {

          return false;

      } else {

          return true;

      }

    }

}
