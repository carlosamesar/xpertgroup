import { NoEsCargablePipe } from './no-es-cargable.pipe';

describe('NoEsCargablePipe', () => {
  it('create an instance', () => {
    const pipe = new NoEsCargablePipe();
    expect(pipe).toBeTruthy();
  });
});
