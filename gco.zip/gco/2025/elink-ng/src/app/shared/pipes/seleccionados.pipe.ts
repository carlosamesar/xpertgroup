import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'seleccionados',
    pure: false
})
export class SeleccionadosPipe implements PipeTransform {

    transform(value: any[], columna: string): number {

        if (!value || value.length === 0) {
            return 0;
        }

        const nuevoArray = value.filter(valor => {
            return valor[columna] === true;
        });

        return nuevoArray.length;

    }

}
