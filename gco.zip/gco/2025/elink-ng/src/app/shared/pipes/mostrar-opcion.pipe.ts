import { Pipe, PipeTransform } from '@angular/core';
import { SeguridadService } from '../service/seguridad.service';

@Pipe({
    name: 'mostrarOpcion'
})
export class MostrarOpcionPipe implements PipeTransform {

    constructor(private seguridadService: SeguridadService) {

    }

    transform(value: string, args?: any): boolean {

        console.log('En el pipe', value);
        
        return this.seguridadService.mostrarOpcion(value);
        
    }

}
