import { CambiaPalabraPipe } from './cambia-palabra.pipe';

describe('CambiaPalabraPipe', () => {
  it('create an instance', () => {
    const pipe = new CambiaPalabraPipe();
    expect(pipe).toBeTruthy();
  });
});
