import { Pipe, PipeTransform } from '@angular/core';

const diccionario = [
    {nombre: 'elastomero', valor: 'Elastómero'},
    {nombre: 'poliester', valor: 'Poliéster'},
    {nombre: 'algodon', valor: 'Algodón'},
    {nombre: 'acrilico', valor: 'Acrílico'},
    {nombre: 'metalico', valor: 'Metálico'},
    {nombre: 'rayon', valor: 'Rayón'},
];

@Pipe({
    name: 'cambiaPalabra'
})
export class CambiaPalabraPipe implements PipeTransform {

    transform(frase: string, args?: any): any {

        console.log(diccionario);
        const arrayPalabras = frase.split(' ');

        if (arrayPalabras.length === 0) {

            return frase;

        }

        const arrayConvertido = arrayPalabras.map(palabra => {

            // Busco la palabra en el diccionario
            const idx = diccionario.findIndex(dic => {
                return dic.nombre === palabra.toLowerCase();
            });

            if (idx >= 0) {
                palabra = diccionario[idx].valor;
            }

            return palabra;

        });

        return arrayConvertido.join(' ');
        
    }

}
