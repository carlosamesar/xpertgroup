import { SeleccionadosPipe } from './seleccionados.pipe';

describe('SeleccionadosPipe', () => {
  it('create an instance', () => {
    const pipe = new SeleccionadosPipe();
    expect(pipe).toBeTruthy();
  });
});
