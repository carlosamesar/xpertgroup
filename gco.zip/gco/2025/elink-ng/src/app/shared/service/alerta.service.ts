import { Injectable } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { AlertaContentComponent } from '../componentes/alerta-content/alerta-content.component';
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class AlertaService {

    modalRef: BsModalRef;

    constructor(private modalService: BsModalService) {

    }

    mostrar(mensaje: string) {

        this.modalRef = this.modalService.show(AlertaContentComponent);
        this.modalRef.content.esConfirmacion = false;
        this.modalRef.content.mensaje = mensaje;

    }
    
    ocultar(level: number) {

        this.modalService.hide(level);
        // this.modalRef.content.esConfirmacion = false;
        // this.modalRef.content.mensaje = mensaje;

    }

    confirmar(mensaje: string): Observable<boolean> {

        this.modalRef = this.modalService.show(AlertaContentComponent);
        this.modalRef.content.esConfirmacion = true;
        this.modalRef.content.mensaje = mensaje;

        return this.modalRef.content.onClose;

    }
    
}
