import { TestBed } from '@angular/core/testing';

import { AlertaService } from './alerta.service';
import { BsModalRef, ModalModule } from 'ngx-bootstrap/modal';
import { SharedModule } from '../shared.module';

describe('AlertaService', () => {
    beforeEach(() => TestBed.configureTestingModule({
        imports: [
            ModalModule.forRoot(),
            SharedModule
        ],
        providers: [BsModalRef],
    }));

    it('should be created', () => {
        const service: AlertaService = TestBed.get(AlertaService);
        expect(service).toBeTruthy();
    });

    it('Debe mostrar mensaje de alerta.', () => {

        const service: AlertaService = TestBed.get(AlertaService);
        
        spyOn(service , 'mostrar').and.callThrough();
        service.mostrar('Este es un mensaje');
        expect(service.mostrar).toHaveBeenCalled();
    });
});
