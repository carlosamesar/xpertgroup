import { Injectable, EventEmitter } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { EquivalenciaDto } from '../clases/equivalencia-dto';
import { Observable } from 'rxjs';
import { TipoEquivalencia } from '../clases/tipo-equivalencia';
import { Equivalencia } from '../clases/equivalencia';
import { PageEquivalencia } from '../clases/page-equivalencia';


@Injectable({
    providedIn: 'root'
})
export class EquivalenciasService {

    urlEquivalencias = environment.URL_EQUIVALENCIAS;

    constructor(private httpClient: HttpClient) { }


    guardar(lstEquivalencias: EquivalenciaDto[]): Observable<any> {

      console.log('Guardando!!!');

      const url = this.urlEquivalencias + '/upload';

      const postRtn = this.httpClient.post<EquivalenciaDto[]>(url, lstEquivalencias);

      return postRtn;

    }


    eliminar(idEquivalencia: number): Observable<any> {

        const url = this.urlEquivalencias + '/borrado/' + idEquivalencia.toString();

        return this.httpClient.delete(url);

    }

    obtenerTipoEquivalencias(): Observable<TipoEquivalencia[]> {

        const url = this.urlEquivalencias + '/tipos';

        return this.httpClient.get<TipoEquivalencia[]>(url);

    }

    obtenerPorTipo(tipoEquivalencia: number, nombre: string, page: number, size: number): Observable<PageEquivalencia> {

        const url = this.urlEquivalencias + '/portipo';

        let parametro = new HttpParams();
        parametro = parametro.set('tipo', tipoEquivalencia.toString() || '0');
        parametro = parametro.set('nombre', nombre);
        parametro = parametro.set('page', page.toString());
        parametro = parametro.set('size', size.toString());

        return this.httpClient.get<PageEquivalencia>(url, {params: parametro});

    }


}
