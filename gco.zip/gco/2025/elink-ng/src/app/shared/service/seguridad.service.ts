import { Injectable, EventEmitter } from '@angular/core';
import { Login } from '../clases/login';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UsuarioApp } from '../clases/usuario-app';
import { CookieService } from 'ngx-cookie-service';
import { Resource } from '../clases/resource';
import { CambioContrasena } from '../clases/cambio-contrasena';
import { ListResource } from '../clases/listResource';
import { jwtDecode } from 'jwt-decode';


@Injectable({
    providedIn: 'root'
})
export class SeguridadService {

    logueado = new EventEmitter<boolean>();
    onResources = new EventEmitter<any>();
    usuarioApp: UsuarioApp;
    urlSeguridad: string;
    resources: Resource;
    urlCambioPassword: string;

    constructor(private httpClient: HttpClient,
                private cookieService: CookieService) {

        this.urlSeguridad = environment.URL_AUTENTICACION;
        this.urlCambioPassword = environment.URL_RESET_CONTRASENA;
    }

    login(login: Login, obtenerRecursos: boolean): Observable<UsuarioApp> {

        const observable = this.httpClient.post<UsuarioApp>(this.urlSeguridad, login);

        // Me suscribo al post de autenticación.
        // Con la autenticación exitosa, guardo los datos del usuario en
        // el local storage.
        observable.subscribe(data => {

            console.log('subscribe del seguridad');
            console.log(data.data.jwt);

            if (data.data.jwt) {

                this.usuarioApp = data;
                this.logueado.emit(true);

                this.almacenarDatosUsuario(this.usuarioApp);
                if (obtenerRecursos) {
                    // Si el logeo fue exitoso, obtengo los recursos asociados al usuario
                    this.getResources(this.getRolesFromToken(data.data.jwt)).subscribe(recursos => {
                        
                        console.log(recursos)
                        this.procesarRecursos(recursos);

                    });

                }

            } else {

                if (obtenerRecursos) {
                    this.logueado.emit(false);
                }

            }

        }, error => {
            this.logueado.emit(false);
        });

        return observable;

    }

    getResources(listResource: ListResource[]): Observable<any> {

        const url = environment.URL_RESOURCES;

        return this.httpClient.post<any>(url,listResource);

    }

    logout() {

        this.resources = null;
        this.usuarioApp = null;

        localStorage.clear();

        this.cookieService.delete('gco_seg_token');
        this.logueado.emit(false);

    }

    cambiarPassword(cambioPass: CambioContrasena): Observable<any> {

        const headers = {
            Authorization: JSON.parse(localStorage.getItem('usuarioElink')).data.jwt
        };
    console.log(headers)
        return this.httpClient.post<any>(this.urlCambioPassword, cambioPass, { headers });

    }

    private almacenarDatosUsuario(usuario: UsuarioApp) {

        localStorage.setItem('usuarioElink', JSON.stringify(usuario));
        localStorage.setItem('u', usuario.data.username);
        localStorage.setItem('t', usuario.data.jwt);

        this.cookieService.set('gco_seg_token', usuario.data.jwt);

    }

    estaLogueado() {

        if (!this.usuarioApp) {

            const tk = localStorage.getItem('t');
            const us = localStorage.getItem('u');

            if (tk) {

                const params = {
                    t: tk,
                    u: us
                };
                this.accesoContoken(params);

                return true;

            }

            this.usuarioApp = JSON.parse(localStorage.getItem('usuarioElink'));

            if (this.usuarioApp && this.usuarioApp.data.jwt && this.usuarioApp.data.jwt.length > 0) {
                return true;
            }

            return false;

        }

        if (this.usuarioApp && this.usuarioApp.data.jwt && this.usuarioApp.data.jwt.length > 0) {
            return true;
        }

        return false;

    }

    mostrarOpcion(nombreOpcion): boolean {

        console.log('this.resources', this.resources);

        // Trato de obtener los recursos del localstorage
        if (!this.resources) {

            this.resources = JSON.parse(localStorage.getItem('recursosElink'));

            if (!this.resources) {
                return false;
            }
            
        }
        if (this.resources.opciones.length > 0) {

        }

        const idx = this.resources.opciones.findIndex((elem) => {
            if (elem === nombreOpcion) {
                return true;
            } else {
                /*if (elem.length > 0) {
                    return this.mostrarOpcion(nombreOpcion);
                } else {
                    return false;
                }*/
            }

        });

        if (idx >= 0) {
            return true;
        } else {
            return false;
        }

    }

    accesoContoken(params: any) {

        if (!this.usuarioApp ) {
            this.usuarioApp = new UsuarioApp();
            this.usuarioApp.data = {
                username: '',
                jwt: ''
              };

        }
        this.usuarioApp.data.jwt = params.t;
        this.usuarioApp.data.username = params.u;

        this.almacenarDatosUsuario(this.usuarioApp);

        this.logueado.emit(true);

        this.getResources(this.getRolesFromToken(this.usuarioApp.data.jwt)).subscribe(data => {

            console.log('Recursos ::: ', data);
            this.procesarRecursos(data);

        }, (error) => {

            console.error('Error recuros ::: ', error);
            this.logout();

        });

    }

    private procesarRecursos(recursos: any) {
        console.log(recursos)
       /* const idx = recursos.data((elem) => {
            return elem.rol === 'ADMIN';
        });*/

        console.log(recursos);

        if (recursos.data != null) {

            this.resources = recursos.data;
            localStorage.setItem('recursosElink', JSON.stringify(this.resources));

        }

        this.onResources.emit(this.resources);

    }

    private isTokenExpired(token:string): boolean{
        try{
          const decodedToken: any= jwtDecode(token);
          const expiration= new Date(decodedToken.exp*1000)
          return expiration<new Date();
        }catch(error){
          console.error('Error al verificar token', error)
          return true
        }
      }

      getRolesFromToken(token: string): ListResource[] {
        const decodedToken: any = jwtDecode(token);
        console.log (decodedToken);

        const authoritiesString = decodedToken.roles;
        const authoritiesArray = authoritiesString.split(',');
        return authoritiesArray.filter(role => role);
      }

      hasRole(role: ListResource): boolean{
        const token=localStorage.getItem('jwt')
        if(token){
          const roles=this.getRolesFromToken(token)
          return roles.includes(role);
        }
        return false;
      }

}
