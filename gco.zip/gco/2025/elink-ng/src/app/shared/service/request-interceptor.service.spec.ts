import { TestBed } from '@angular/core/testing';

import { RequestInterceptorService } from './request-interceptor.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CookieService } from 'ngx-cookie-service';

describe('RequestInterceptorService', () => {
    beforeEach(() => TestBed.configureTestingModule({
        imports: [HttpClientTestingModule],
        providers: [CookieService]
    }));

    it('should be created', () => {
        const service: RequestInterceptorService = TestBed.get(RequestInterceptorService);
        expect(service).toBeTruthy();
    });
});
