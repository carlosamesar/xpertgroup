import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { IValeRequestDTO } from '../Interfaces/ivale-request-dto';
import { IActualizarValeRequestDTO } from '../Interfaces/iactualizar-vale-request-dto';
import { IValeResponseDTO } from '../Interfaces/ivale-response-dto';

@Injectable({
  providedIn: 'root'
})
export class ValesService {
  urlVales = environment.URL_VALES;

  constructor(private httpClient: HttpClient) {}

  consultarVales(reques: string): Observable<IValeResponseDTO[]> {
    const url = this.urlVales;
    return this.httpClient.get<IValeResponseDTO[]>(url, 
      { params: new HttpParams().set('campana', reques) });
  }

  generarVales(request: IValeRequestDTO): Observable<any> {
    const url = this.urlVales;
    return this.httpClient.post<any>(url, request);
  }

  actualizarVales(request: IActualizarValeRequestDTO): Observable<any> {
    const url = this.urlVales;
    return this.httpClient.put<any>(url, request);
  }

}
