import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpParams, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { environment } from 'src/environments/environment';
import { SeguridadService } from './seguridad.service';
import { catchError } from 'rxjs/operators';
import { Router } from '@angular/router';
import { Message } from '@angular/compiler/src/i18n/i18n_ast';
import { AlertaService } from './alerta.service';

@Injectable({
    providedIn: 'root'
})
export class RequestInterceptorService implements HttpInterceptor {

    constructor(private seguridadService: SeguridadService,private router: Router,private alerta: AlertaService
    ) {

    }

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        if (req.url === environment.URL_AUTENTICACION ||
            req.url === environment.URL_RESET_CONTRASENA ||
            req.url.indexOf('http://quotes.rest') >= 0) {
    
            // No se hace nada en estos casos específicos
            return next.handle(req);
            
        } else {
            let modifiedReq = req;
    
            if (req.url === environment.URL_RESOURCES) {
                modifiedReq = req.clone({
                    setHeaders: {
                        'Authorization': this.seguridadService.usuarioApp.data.jwt
                    }
                });
            } else {
                console.log('En el request interceptor');
    
                modifiedReq = req.clone({
                    setHeaders: {
                        'siconline-user': JSON.parse(localStorage.getItem('usuarioElink')).data.username,
                        'Authorization': JSON.parse(localStorage.getItem('usuarioElink')).data.jwt
                    }
                });
            }
    
            return next.handle(modifiedReq).pipe(
                catchError((error: HttpErrorResponse) => {
                    if (error.status === 401 || error.status === 403) {
                        this.router.navigate(['/login']);
                        this.alerta.mostrar("Se ha cerrado la sesión");
                        this.seguridadService.logout();
                    }
                    return throwError(() => new Error('Error en la solicitud HTTP'));
                })
            );
        }
    }
    

}
