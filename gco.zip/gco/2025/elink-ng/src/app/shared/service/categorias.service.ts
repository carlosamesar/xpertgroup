import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpParams } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Categoria } from '../clases/categoria';
import { CategoriaProducto } from '../clases/categoria-producto';
import { CategoriaProductoDto } from '../clases/categoria-producto-dto';

@Injectable({
    providedIn: 'root'
})
export class CategoriasService {

    urlCategorias = environment.URL_CATEGORIAS;

    constructor(private httpClient: HttpClient) { }

    obtenerCategoriasPorMarket(idCanal: string): Observable<Categoria[]> {

        let parametro = new HttpParams();

        parametro = parametro.set('canal', idCanal);
        const url = this.urlCategorias + '/consulta';

        return this.httpClient.get<Categoria[]>(url, {params: parametro});

    }

    guardar(categoria: Categoria): Observable<Categoria> {
        
        const url = this.urlCategorias + '/creacion';

        return this.httpClient.post<Categoria>(url, categoria);

    }

    inactivar(categoria: Categoria): Observable<Categoria> {

        let parametro = new HttpParams();
        console.log(categoria)
        parametro = parametro.set('marketplace', categoria.elkCanalMae.id.toString());
        parametro = parametro.set('categoria', categoria.campUid.toString());

        const url = this.urlCategorias + '/inactivacion';

        return this.httpClient.delete<Categoria>(url, {params: parametro});

    }


    obtenerCategoriasPorProducto(idMarket: string, idCategoria: number): Observable<CategoriaProducto[]> {
        const url = this.urlCategorias + '/producto/consulta';
        console.log(idMarket, idCategoria)
        let parametro = new HttpParams();

        parametro = parametro.set('marketplace', idMarket.toString());
        parametro = parametro.set('categoria', idCategoria.toString());

        return this.httpClient.get<CategoriaProducto[]>(url, {params: parametro});

    }

    guardarPorProducto(catProducto: CategoriaProductoDto): Observable<CategoriaProducto> {

        const url = this.urlCategorias + '/producto/creacion';

        return this.httpClient.post<CategoriaProducto>(url, catProducto);

    }

    guardarPorProductoMasivo(catProducto: CategoriaProductoDto[]): Observable<any> {

        const url = this.urlCategorias + '/producto/creacionmasiva';

        return this.httpClient.post<CategoriaProductoDto[]>(url, catProducto);

    }

    inactivarPorProducto(catProducto: CategoriaProductoDto): Observable<any> {

        const url = this.urlCategorias + '/producto/borrado';

        return this.httpClient.request('delete', url, {body: catProducto});

    }

    trasladarCategoriasProdutoOutlet(idMarket: number, lstReferencias: string[]): Observable<string[]> {

        const url = this.urlCategorias + '/producto/trasladooutlet';

        let parametro = new HttpParams();

        parametro = parametro.set('marketplace', idMarket.toString());

        return this.httpClient.post<string[]>(url, lstReferencias, {params: parametro});

    }

}
