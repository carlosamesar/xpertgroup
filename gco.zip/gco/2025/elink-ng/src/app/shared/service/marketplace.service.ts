import { Canales } from './../clases/canales';
import { map, switchMap } from 'rxjs/operators';
import { Empresa } from './../clases/empresa';
import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { BodegaMarkerPlace } from '../clases/bodega-marker-place';
import { ListaprecioCanal } from '../clases/listaprecio-canal';
import { PageCanales } from '../clases/page-canales';
import { whiteLabel } from '../clases/white-label';
import { WhiteLabelDto } from '../clases/white-label-request';

@Injectable({
    providedIn: 'root'
})
export class MarketplaceService {
    consultarWl(marca: string,nombre: string, page: number, size: number): Observable<PageCanales>  {
        const urlServicio = this.urlMarketplace + '/listawlpaginada';
        let parametro = new HttpParams();
        parametro = parametro.set('marca', marca);
        parametro = parametro.set('accountname', nombre);
        parametro = parametro.set('page', page.toString());
        parametro = parametro.set('size', size.toString());
        return this.httpClient.get<PageCanales>(urlServicio, {params: parametro});

    }
    cambiarEstadoWl(
        marca: string, apikey: string,    apitoken: string,  name: string,   IsBetterScope: string
      ): Observable<whiteLabel> {
        const urlServicio =this.urlMarketplace +  '/modificarwl';
        const betterScope: WhiteLabelDto = {
            marca: marca,
            name: name,
            isBetterScope: IsBetterScope,
            apiKey: apikey,
            apiToken: apitoken
          };
        return this.httpClient.post<whiteLabel>(urlServicio, betterScope);
     
      }
      
    urlMarketplace: string;

    constructor(private httpClient: HttpClient) {

        this.urlMarketplace = environment.URL_MARKETPLACE;

    }

    obtenerMarketPlacesPaginados(numeroPos: string, page: number, size: number): Observable<PageCanales> {

        const urlServicio = this.urlMarketplace + '/listapaginada';
        let parametro = new HttpParams();
        parametro = parametro.set('pos', numeroPos);
        parametro = parametro.set('page', page.toString());
        parametro = parametro.set('size', size.toString());
        return this.httpClient.get<PageCanales>(urlServicio, {params: parametro});

    }

    obtenerMarketPlaces(): Observable<Canales[]> {

        const urlServicio = this.urlMarketplace + '/lista';

        return this.httpClient.get<Canales[]>(urlServicio);

    }

    obtenerListaprecioCanal(): Observable<ListaprecioCanal[]>{
        const urlServicio = this.urlMarketplace + '/listaprecio/canal';

        return this.httpClient.get<ListaprecioCanal[]>(urlServicio);
    }
    
    guardar(canal: Canales, codigoPais: string, divisa: string): Observable<Canales> {

        const urlServicio = this.urlMarketplace + '/creacion';
        let parametro = new HttpParams;

        parametro = parametro.set("codigoPais", codigoPais );
        parametro = parametro.set("divisa", divisa)

        return this.httpClient.post<Canales>(urlServicio, canal, {params: parametro});

    }

    inactivar(idCanal: number) {

        const urlServicio = this.urlMarketplace + '/borrado';

        let parametro = new HttpParams();
        parametro = parametro.set('canal', idCanal.toString() || '0');

        return this.httpClient.delete(urlServicio, {params: parametro});
        
    }

    activar(idCanal: number) {

        const urlServicio = this.urlMarketplace + '/activar';

        let parametro = new HttpParams();
        parametro = parametro.set('canal', idCanal.toString() || '0');

        return this.httpClient.get(urlServicio, {params: parametro});
        
    }


    obtenerBodegas(idCanal: number): Observable<BodegaMarkerPlace[]> {

        const urlServicio = this.urlMarketplace + '/bodegas/lista';

        let parametro = new HttpParams();
        parametro = parametro.set('canal', idCanal.toString() || '0');

        return this.httpClient.get<BodegaMarkerPlace[]>(urlServicio, {params: parametro});


    }


    guardarBodega(idCanal: number, bodega: BodegaMarkerPlace): Observable<BodegaMarkerPlace> {

        const urlServicio = this.urlMarketplace + '/bodegas/creacion';

        let parametro = new HttpParams();
        parametro = parametro.set('canal', idCanal.toString() || '0');

        return this.httpClient.post<BodegaMarkerPlace>(urlServicio, bodega, {params: parametro});

    }

    inactivarBodega(idCanal: number, idBodega: number): Observable<any> {

        const urlServicio = this.urlMarketplace + '/bodegas/borrado';

        let parametro = new HttpParams();
        parametro = parametro.set('canal', idCanal.toString() || '0');
        parametro = parametro.set('bodega', idBodega.toString() || '0');

        return this.httpClient.delete<any>(urlServicio, {params: parametro});

    }


    obtenerEmpresas(marcas:string): Observable<Empresa[]> {

        const urlServicio = this.urlMarketplace + '/listaEmpresas';
        let parametro = new HttpParams();
        parametro = parametro.set('marca', marcas.toString());
        return this.httpClient.get<Empresa[]>(urlServicio,{params: parametro});    

    }

}
