import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
    providedIn: 'root'
})
export class QuoteServiceService {

    constructor(private httpClient: HttpClient) { }

    obtenerQuote(): Observable<any> {

        return this.httpClient.get('http://quotes.rest/qod.json?category=inspire');

    }
}
