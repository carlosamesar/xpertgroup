import { Injectable } from "@angular/core";
import { environment } from "src/environments/environment";
import { HttpClient, HttpParams, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs";
import { ReferenciaVtexDto } from "../clases/referencia-vtex-dto";
import { Parametros } from "../clases/parametros";

@Injectable({
  providedIn: "root",
})
export class ProductosService {
  urlProductos = environment.URL_PRODUCTOS;

  constructor(private httpClient: HttpClient) {}

  consultar(params: Parametros): Observable<ReferenciaVtexDto[]> {
    const url = this.urlProductos + "/consulta";

    let parametro = new HttpParams();
    //parametro = parametro.set('marca', params.marca || '0');
    //parametro = parametro.set('empresa', params.nombre || '0');
    parametro = parametro.set("empresa", params.marca || "0");
    parametro = parametro.set("ano", params.ano ? params.ano.toString() : "0");
    parametro = parametro.set("coleccion", params.coleccion || "*");
    parametro = parametro.set("referencias", params.referencias64 || "-1");
    parametro = parametro.set("canal", params.id || "-1");
    parametro = parametro.set("ecommerce", params.ecommerce);

    return this.httpClient.get<ReferenciaVtexDto[]>(url, { params: parametro });
  }

  asignarFechaLanzamiento(listaProductos: ReferenciaVtexDto[], idCanal: number, idReferencia: number): Observable<any> {
    const url = this.urlProductos + "/fechalanzamiento";

    let parametro = new HttpParams();

    parametro = parametro.set('canal', idCanal.toString())
    parametro = parametro.set('referencia', idReferencia.toString())

    return this.httpClient.post<ReferenciaVtexDto[]>(url, listaProductos, { params: parametro });
  }

  integrarProductos(empresa: string): Observable<any> {
    console.log(empresa);

    let parametro = new HttpParams();
    parametro = parametro.set("empresa", empresa || "0");

    return this.httpClient.request("POST", `${this.urlProductos}/carga`, {
      params: parametro,
    });
  }
}
