import { TestBed } from '@angular/core/testing';

import { ModalElinkService } from './modal-elink.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('ModalElinkService', () => {
    beforeEach(() => TestBed.configureTestingModule({
        imports: [HttpClientTestingModule]
    }));

    it('should be created', () => {
        const service: ModalElinkService = TestBed.get(ModalElinkService);
        expect(service).toBeTruthy();
    });
});
