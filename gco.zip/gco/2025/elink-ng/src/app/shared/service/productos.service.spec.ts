import { TestBed } from '@angular/core/testing';

import { ProductosService } from './productos.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('ProductosService', () => {
    beforeEach(() => TestBed.configureTestingModule({
        imports: [HttpClientTestingModule]
    }));

    it('should be created', () => {
        const service: ProductosService = TestBed.get(ProductosService);
        expect(service).toBeTruthy();
    });
});
