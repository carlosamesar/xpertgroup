import { DescripcionGpt } from '../clases/descripcion-gpt';
import { Observable } from 'rxjs';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { AtributoIADto } from '../clases/atributo-ia-dto';

@Injectable({
    providedIn: "root",
  })


  export class DescripcionGptService {
   urlDescripcion = environment.URL_DESCRIPCION;

  constructor(private httpClient: HttpClient) { }

    Generar(descripcion: DescripcionGpt): Observable<any> {
        
    const url = this.urlDescripcion ;

    return this.httpClient.post<any>(url, descripcion);

    }
    
    GuardarAtributo(atributo: AtributoIADto[]): Observable<any> {
        
      const url = environment.URL_PRODUCTOS + '/guardarAtributoIA';
  
      return this.httpClient.post<any>(url, atributo);
  
      }
 }