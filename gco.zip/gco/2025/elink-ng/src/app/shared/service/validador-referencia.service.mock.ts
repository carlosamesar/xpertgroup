/**
 * Mock Service para ValidadorReferenciaService
 * 
 * Simula el comportamiento del servicio real sin hacer llamadas HTTP reales.
 * Usado para pruebas unitarias y E2E con datos mock.
 */

import { Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { delay } from 'rxjs/operators';
import { ReferenciaValidacionDto } from '../Interfaces/referencia-validacion-dto';
import { DetalleAtributosReferenciaDto } from '../Interfaces/detalle-atributos-referencia-dto';
import { AsignacionFechaLanzamientoDto } from '../Interfaces/asignacion-fecha-lanzamiento-dto';

// Datos mock inline (sin usar require para evitar dependencia de @types/node)
const MOCK_DATA: any = null;

@Injectable()
export class ValidadorReferenciaMockService {
  
  /**
   * Simular delay de red (configurable)
   */
  private networkDelay = 300; // ms
  
  /**
   * Flag para simular errores (útil para testing)
   */
  public simularError = false;
  public tipoError: 'servidor' | 'noAutorizado' | 'noEncontrado' = 'servidor';
  
  constructor() {}
  
  /**
   * Configurar delay de red simulado
   */
  setNetworkDelay(ms: number): void {
    this.networkDelay = ms;
  }
  
  /**
   * Buscar referencias por código (MOCK)
   */
  buscarReferencias(
    empresa: string,
    referencia?: string,
    ano?: number,
    coleccion?: string
  ): Observable<ReferenciaValidacionDto[]> {
    console.log('[MOCK] buscarReferencias llamado con:', { empresa, referencia, ano, coleccion });
    
    if (this.simularError) {
      return this.generarError();
    }
    
    // Si tenemos datos mock desde archivo, usarlos
    if (MOCK_DATA && MOCK_DATA.filtrarReferenciasMock) {
      const resultado = MOCK_DATA.filtrarReferenciasMock(empresa, ano, coleccion, referencia);
      return of(resultado).pipe(delay(this.networkDelay));
    }
    
    // Fallback: datos inline
    const mockReferencias: ReferenciaValidacionDto[] = [
      {
        baseUrlImagen: 'https://imagenesonline.gco.com.co/pub/IntimaConfidencial/111_11659150_NEGRO_0.jpg',
        codReferencia: '11659150',
        nomReferencia: 'Camiseta Básica Algodón',
        estadoGeneral: true,
        id: '11659150',
        codigo: '11659150',
        nombre: 'Camiseta Básica Algodón',
        urlImagen: 'https://imagenesonline.gco.com.co/pub/IntimaConfidencial/111_11659150_NEGRO_0.jpg',
        isValid: true
      },
      {
        baseUrlImagen: 'https://imagenesonline.gco.com.co/pub/IntimaConfidencial/111_11659151_AZUL_0.jpg',
        codReferencia: '11659151',
        nomReferencia: 'Pantalón Denim Slim Fit',
        estadoGeneral: false,
        id: '11659151',
        codigo: '11659151',
        nombre: 'Pantalón Denim Slim Fit',
        urlImagen: 'https://imagenesonline.gco.com.co/pub/IntimaConfidencial/111_11659151_AZUL_0.jpg',
        isValid: false
      }
    ];
    
    // Filtrar por referencia si se proporciona
    let resultado = mockReferencias;
    
    if (referencia && referencia !== '-1') {
      resultado = resultado.filter(ref => ref.codigo.includes(referencia));
    }
    
    return of(resultado).pipe(delay(this.networkDelay));
  }
  
  /**
   * Obtener detalle de atributos (MOCK)
   */
  obtenerDetalleAtributos(
    idReferencia: string,
    empresa: string
  ): Observable<DetalleAtributosReferenciaDto> {
    console.log('[MOCK] obtenerDetalleAtributos llamado con:', { idReferencia, empresa });
    
    if (this.simularError) {
      return this.generarError();
    }
    
    // Si tenemos datos mock desde archivo, usarlos
    if (MOCK_DATA && MOCK_DATA.obtenerDetalleAtributosMockPorId) {
      const detalle = MOCK_DATA.obtenerDetalleAtributosMockPorId(idReferencia);
      if (detalle) {
        return of(detalle).pipe(delay(this.networkDelay));
      }
    }
    
    // Fallback: datos inline según ID
    let mockDetalle: DetalleAtributosReferenciaDto;
    
    if (idReferencia === 'REF-001') {
      mockDetalle = {
        idReferencia: 'REF-001',
        codigoReferencia: '11659150',
        nombreReferencia: 'Camiseta Básica Algodón',
        atributos: [
          { nombre: 'Descripción', ok: true, valor: 'Camiseta 100% algodón' },
          { nombre: 'Imagen', ok: true, valor: 'https://...' },
          { nombre: 'Color', ok: true, valor: 'Azul' },
          { nombre: 'Talla', ok: true, valor: 'M' }
        ],
        canales: [
          { codigo: 'IC', nombre: 'Internet Colombia', ok: true, atributosFaltantes: [] },
          { codigo: 'VN', nombre: 'Ventas Nacionales', ok: true, atributosFaltantes: [] }
        ]
      };
    } else if (idReferencia === 'REF-002') {
      mockDetalle = {
        idReferencia: 'REF-002',
        codigoReferencia: '11659151',
        nombreReferencia: 'Pantalón Denim Slim Fit',
        atributos: [
          { nombre: 'Descripción', ok: true, valor: 'Pantalón jean denim' },
          { nombre: 'Imagen', ok: true, valor: 'https://...' },
          { nombre: 'Color', ok: false, valor: null },
          { nombre: 'Talla', ok: false, valor: null }
        ],
        canales: [
          { codigo: 'IC', nombre: 'Internet Colombia', ok: false, atributosFaltantes: ['Color', 'Talla'] },
          { codigo: 'VN', nombre: 'Ventas Nacionales', ok: false, atributosFaltantes: ['Color', 'Talla'] }
        ]
      };
    } else {
      return throwError(() => new Error('Referencia no encontrada'));
    }
    
    return of(mockDetalle).pipe(delay(this.networkDelay));
  }
  
  /**
   * Asignar fecha de lanzamiento (MOCK)
   */
  asignarFechaLanzamiento(
    idReferencia: string,
    asignacion: AsignacionFechaLanzamientoDto
  ): Observable<any> {
    console.log('[MOCK] asignarFechaLanzamiento llamado con:', { idReferencia, asignacion });
    
    if (this.simularError) {
      return this.generarError();
    }
    
    // Si tenemos datos mock desde archivo, usarlos
    if (MOCK_DATA && MOCK_DATA.MOCK_ASIGNACION_EXITOSA) {
      return of(MOCK_DATA.MOCK_ASIGNACION_EXITOSA).pipe(delay(this.networkDelay));
    }
    
    // Fallback: respuesta inline
    const mockRespuesta = {
      mensaje: `Fecha de lanzamiento asignada correctamente a referencia ${idReferencia} en ${asignacion.canales.length} canales`,
      referenciasActualizadas: 1,
      canalesActualizados: asignacion.canales.length,
      errores: []
    };
    
    return of(mockRespuesta).pipe(delay(this.networkDelay));
  }
  
  /**
   * Generar error simulado según el tipo configurado
   */
  private generarError(): Observable<never> {
    const errores = {
      servidor: {
        status: 500,
        statusText: 'Internal Server Error',
        message: 'Error al procesar la solicitud'
      },
      noAutorizado: {
        status: 401,
        statusText: 'Unauthorized',
        message: 'Token expirado o inválido'
      },
      noEncontrado: {
        status: 404,
        statusText: 'Not Found',
        message: 'Recurso no encontrado'
      }
    };
    
    const error = errores[this.tipoError];
    return throwError(() => error).pipe(delay(this.networkDelay));
  }
  
  /**
   * Reset del servicio mock (útil entre pruebas)
   */
  reset(): void {
    this.simularError = false;
    this.tipoError = 'servidor';
    this.networkDelay = 300;
  }
}
