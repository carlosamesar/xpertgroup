import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { AtributoMarket } from '../clases/atributo-market';
import { IPoliticaComercial } from '../Interfaces/ipolitica-comercial';
import { IRespuestaPolitica } from '../Interfaces/irespuesta-politica';
import { IAtributoReferencia } from '../Interfaces/iatributo-referencia';
import { Parametros } from '../clases/parametros';

@Injectable({
    providedIn: 'root'
})
export class AtributosService {

    urlAtributos = environment.URL_ATRIBUTOS;

    constructor(private httpClient: HttpClient) { }

    consultar(idCanal: string, tipoAtributo: string): Observable<AtributoMarket[]> {

        const url = `${this.urlAtributos}/consulta`;
        
        let parametro = new HttpParams();

        parametro = parametro.set('canal', idCanal);
        parametro = parametro.set('tipo', tipoAtributo);

        return this.httpClient.get<AtributoMarket[]>(url, {params: parametro});

    }

    guardar(atributo: AtributoMarket): Observable<any> {
        
        const url = this.urlAtributos + '/creacion';

        return this.httpClient.post<any>(url, atributo);

    }


    inactivar(idCanal: string, idAtributo: number): Observable<any> {

        const url = this.urlAtributos + '/borrado';

        let parametro = new HttpParams();

        parametro = parametro.set('canal', idCanal);
        parametro = parametro.set('atributo', idAtributo.toString());

        return this.httpClient.delete<any>(url, {params: parametro});
    }

    upload(lstEquivalencias: IPoliticaComercial[], activo: boolean): Observable<IRespuestaPolitica[]> {

        const url = this.urlAtributos + '/upload';

        let parametro = new HttpParams();

        parametro = parametro.set('activo', activo.toString());

        const postRtn = this.httpClient.post<IRespuestaPolitica[]>(url, lstEquivalencias, {params: parametro});

        return postRtn;


    }

    listarAtributosReferencia(ano: number, referencia: string, proveedor: string, idCanal: number): Observable<IAtributoReferencia[]> {

        const url = this.urlAtributos + '/referencia';

        let parametro = new HttpParams();

        parametro = parametro.set('ano', ano.toString());
        parametro = parametro.set('referencia', referencia);
        parametro = parametro.set('proveedor', proveedor);
        parametro = parametro.set('canal', idCanal.toString());

        return this.httpClient.get<IAtributoReferencia[]>(url, {params: parametro});

    }

    listarAtributosReferenciaCol(params: Parametros, idCanal: number): Observable<IAtributoReferencia[]> {

        const url = this.urlAtributos + '/sic';

        let parametro = new HttpParams();

        parametro = parametro.set('empresa', params.nombre || '0');
        parametro = parametro.set('ano', params.ano ? params.ano.toString() : '0');
        parametro = parametro.set('coleccion', params.coleccion || '*');
        parametro = parametro.set('referencias', params.referencias64 || '-1');
        parametro = parametro.set('canal', idCanal.toString());
        parametro = parametro.set('id', params.id ? params.id.toString() : '0');

        return this.httpClient.get<IAtributoReferencia[]>(url, {params: parametro});

    }

    exportarAtributosSic(params: Parametros): Observable<IAtributoReferencia[]> {

        const url = this.urlAtributos + '/exportacionAtributosSic';

        let parametro = new HttpParams();

        parametro = parametro.set('empresa', params.marca || '0');
        parametro = parametro.set('ano', params.ano ? params.ano.toString() : '0');
        parametro = parametro.set('coleccion', params.coleccion || '*');
        parametro = parametro.set('referencias', params.referencias64 || '-1');
        parametro = parametro.set('canal', params.id);
        return this.httpClient.get<IAtributoReferencia[]>(url, {params: parametro});

    }

    listarAtributosReferenciaSicKliiker(params: Parametros, idCanal: number): Observable<IAtributoReferencia[]> {

        const url = this.urlAtributos + '/sicKliiker';

        let parametro = new HttpParams();

        parametro = parametro.set('referencias', params.referencias64);
        parametro = parametro.set('canal', idCanal.toString());

        return this.httpClient.get<IAtributoReferencia[]>(url, {params: parametro});

    }



}
