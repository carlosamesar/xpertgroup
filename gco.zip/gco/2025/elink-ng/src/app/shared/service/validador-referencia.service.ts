import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { ReferenciaValidacionDto } from '../Interfaces/referencia-validacion-dto';
import { DetalleAtributosReferenciaDto } from '../Interfaces/detalle-atributos-referencia-dto';
import { AsignacionFechaLanzamientoDto } from '../Interfaces/asignacion-fecha-lanzamiento-dto';
import { ValidacionResumenDto, ValidacionCanalDto } from '../Interfaces/validacion-dto';

@Injectable({
  providedIn: 'root'
})
export class ValidadorReferenciaService {

  private urlBase = environment.URL_PRODUCTOS;
  private urlValidador = environment.URL_PRODUCTOS.replace('/referencia', '/validador');

  constructor(private httpClient: HttpClient) { }

  /**
   * Busca referencias utilizando la consulta SQL nativa del validador
   * Permite filtrar por referencias, año y/o colección
   * GET /commerce/referencia/validador-referencia?referencias=ref1,ref2&marca=123&ano=2024&coleccion=01
   */
  validadorReferencia(
    referencias: string,
    marca: number,
    ano?: number,
    coleccion?: string
  ): Observable<ReferenciaValidacionDto[]> {
    const url = `${this.urlBase}/validador-referencia`;

    let params = new HttpParams();
    
    // Parámetros obligatorios
    params = params.set('marca', marca.toString());
    
    // Parámetros opcionales
    if (referencias && referencias.length > 0) {
      params = params.set('referencias', referencias.toString());
    }
    if (ano) {
      params = params.set('ano', ano.toString());
    }
    if (coleccion) {
      params = params.set('coleccion', coleccion);
    }

    return this.httpClient.get<ReferenciaValidacionDto[]>(url, { params });
  }

  /**
   * Busca referencias por código (búsqueda ligera)
   * GET /commerce/referencia/buscar?empresa=XX&referencia=123&ano=2024&coleccion=01
   */
  buscarReferencias(
    empresa: string, 
    referencia: string, 
    ano?: number, 
    coleccion?: string
  ): Observable<ReferenciaValidacionDto[]> {
    const url = `${this.urlBase}/buscar`;

    let params = new HttpParams();
    params = params.set('empresa', empresa);
    
    if (referencia) {
      params = params.set('referencia', referencia);
    }
    if (ano) {
      params = params.set('ano', ano.toString());
    }
    if (coleccion) {
      params = params.set('coleccion', coleccion);
    }

    return this.httpClient.get<ReferenciaValidacionDto[]>(url, { params });
  }

  /**
   * Obtiene el detalle de atributos de una referencia
   * GET /commerce/referencia/{id}/atributos?empresa=XX
   */
  obtenerDetalleAtributos(
    idReferencia: string, 
    empresa: string
  ): Observable<DetalleAtributosReferenciaDto> {
    const url = `${this.urlBase}/${idReferencia}/atributos`;

    let params = new HttpParams();
    params = params.set('empresa', empresa);

    return this.httpClient.get<DetalleAtributosReferenciaDto>(url, { params });
  }

  /**
   * Asigna fecha de lanzamiento a una referencia
   * POST /commerce/referencia/{id}/{empresa}/fecha-lanzamiento
   */
  asignarFechaLanzamiento(
    idReferencia: string, 
    empresa: string,
    asignacion: AsignacionFechaLanzamientoDto
  ): Observable<any> {
    const url = `${this.urlBase}/${idReferencia}/${empresa}/fecha-lanzamiento`;

    return this.httpClient.post(url, asignacion);
  }

  /**
   * Obtiene el resumen agregado de validaciones para una referencia
   * Retorna el estado global (bool_and) de todas las validaciones a través de todos los canales
   * TRUE indica que TODOS los canales cumplen con esa validación
   * 
   * GET /commerce/validador/consulta-resumen?referencia=REF001&marca=001
   */
  consultarValidacionResumen(
    referencia: string,
    marca: string
  ): Observable<ValidacionResumenDto> {
    const url = `${this.urlValidador}/consulta-resumen`;

    let params = new HttpParams();
    params = params.set('referencia', referencia);
    params = params.set('marca', marca);

    return this.httpClient.get<ValidacionResumenDto>(url, { params });
  }

  /**
   * Obtiene las validaciones desagregadas por canal para una referencia específica
   * Retorna el estado individual de cada validación para cada canal marketplace
   * 
   * GET /commerce/validador/consulta-canal?referencia=REF001&marca=001
   */
  consultarValidacionesPorCanal(
    referencia: string,
    marca: string
  ): Observable<ValidacionCanalDto[]> {
    const url = `${this.urlValidador}/consulta-canal`;

    let params = new HttpParams();
    params = params.set('referencia', referencia);
    params = params.set('marca', marca);

    return this.httpClient.get<ValidacionCanalDto[]>(url, { params });
  }
}
