import { TestBed } from '@angular/core/testing';

import { CategoriasService } from './categorias.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('CategoriasService', () => {
    beforeEach(() => TestBed.configureTestingModule({
        imports: [HttpClientTestingModule]
    }));

    it('should be created', () => {
        const service: CategoriasService = TestBed.get(CategoriasService);
        expect(service).toBeTruthy();
    });
});
