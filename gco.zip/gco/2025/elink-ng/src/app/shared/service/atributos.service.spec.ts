import { TestBed } from '@angular/core/testing';

import { AtributosService } from './atributos.service';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { AtributoMarket } from '../clases/atributo-market';

fdescribe('AtributosService', () => {

    let service: AtributosService;
    let httpMock: HttpTestingController;

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [HttpClientTestingModule],
            providers: [AtributosService]
        });

        service = TestBed.get(AtributosService);
        httpMock = TestBed.get(HttpTestingController);
    });

    afterEach(() => {
        httpMock.verify();
    });

    it('should be created', () => {
        
        expect(service).toBeTruthy();
    });

    it('Debe obtener atributos del API', () => {

        const dummyAtributos: AtributoMarket[] = [
            {
                armpUid: 1, armpCodigo: '', armpValor: '', armpCreacion: null, armpModificacion: null, armpEstado: '',
                armpUsuario: '', armpTipo: '', elkCanalMae: null
            },
            {
                armpUid: 2, armpCodigo: '', armpValor: '', armpCreacion: null, armpModificacion: null, armpEstado: '',
                armpUsuario: '', armpTipo: '', elkCanalMae: null
            }
        ];

        // spyOn(service, 'consultar').and.returnValue(dummyAtributos);

        service.consultar('1', '2').subscribe(data => {

            expect(data.length).toBe(2);
            expect(data).toEqual(dummyAtributos);

        });

        const req = httpMock.expectOne(`${service.urlAtributos}/consulta?marketplace=1&tipo=2`);
        
        expect(req.request.method).toBe('GET');

        req.flush(dummyAtributos);

    });



});
