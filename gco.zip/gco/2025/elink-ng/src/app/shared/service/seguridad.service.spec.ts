import { TestBed } from '@angular/core/testing';

import { SeguridadService } from './seguridad.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CookieService } from 'ngx-cookie-service';

describe('SeguridadService', () => {
    beforeEach(() => TestBed.configureTestingModule({
        imports: [HttpClientTestingModule],
        providers: [CookieService]
    }));

    it('should be created', () => {
        const service: SeguridadService = TestBed.get(SeguridadService);
        expect(service).toBeTruthy();
    });
});
