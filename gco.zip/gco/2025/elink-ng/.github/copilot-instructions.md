# AI Coding Agent Instructions for `elink-ng`

## 1. Purpose & Scope
`elink-ng` is the frontend Angular 7 application for GCO's e-commerce channel management system (Elink). It provides a comprehensive interface for managing VTEX marketplace products, categories, attributes, equivalencies, and channel configurations. The application integrates with `siconline-vtex-services` backend for product operations and external services for authentication and AI-powered content generation.

Key business domains:
- **Product Management**: Configure and manage products for VTEX marketplace channels
- **Category Management**: Hierarchical category trees and product-category assignments
- **Equivalencies**: Map colors, sizes, and compositions across different systems
- **Attributes**: Channel-specific product attributes and marketplace configurations
- **Commercial Policies**: Pricing and availability rules per marketplace channel
- **White Labels & Marketplaces**: Multi-tenant channel configuration
- **Vales (Vouchers)**: Promotional code generation and management

## 2. Technology Stack & Architecture

### Core Technologies
- **Angular 7.2.0** - Framework base (DO NOT upgrade to newer versions)
- **TypeScript 3.2.2** - Language with ES2015 target
- **Bootstrap 4.5.3** - UI framework with custom styles
- **ag-grid 21.2.2** - High-performance data grids
- **ngx-bootstrap 4.3.0** - Bootstrap components for Angular
- **RxJS 6.3.3** - Reactive programming with Observables

### Key Libraries
- **angular-tree-component 8.5.6**: Hierarchical category tree rendering
- **ng-select 2.20.5**: Advanced select dropdowns with search
- **ngx-spinner 7.2.0**: Loading indicators during async operations
- **ngx-ui-switch 8.3.0**: Toggle switches for boolean fields
- **file-saver 2.0.5**: Client-side file downloads (Excel exports)
- **xlsx 0.14.5**: Excel file reading/writing
- **jwt-decode 4.0.0**: JWT token parsing
- **moment 2.29.1**: Date manipulation and formatting
- **ng-sidebar 8.1.1**: Collapsible sidebar navigation

### Build Configuration
- **Angular CLI 7.3.9**: Build tool and dev server
- **Component Prefix**: `elk-` (all components must use this prefix)
- **Build Output**: `dist/` directory
- **Environments**: `dev` (default), `qa`, `production`

## 3. Project Structure & Conventions

### Directory Organization
```
src/app/
├── features/              # Feature modules (pages/business domains)
│   ├── home/             # Dashboard with quote of the day
│   ├── login/            # Authentication page
│   ├── productos/        # Product management (largest module)
│   ├── categorias/       # Category management with tree view
│   ├── caterogorias-producto/  # Product-category associations (typo preserved)
│   ├── equivalencias/    # Color/size/composition mapping
│   ├── atributos/        # Channel-specific product attributes
│   ├── market-places/    # Marketplace configuration
│   ├── politicas-comerciales/  # Pricing policies
│   ├── white-labels/     # White label channel management
│   ├── generar-vales/    # Voucher generation
│   ├── seguridad/        # Password change
│   ├── arbol-categorias/ # Category tree component
│   └── container/        # Main layout wrapper
│
├── shared/               # Shared resources across features
│   ├── service/          # Business logic services
│   ├── componentes/      # Reusable UI components
│   ├── clases/           # TypeScript domain classes
│   ├── Interfaces/       # TypeScript interfaces (DTOs)
│   ├── pipes/            # Custom Angular pipes for transformations
│   └── utils/            # Utility functions
│
└── environments/         # Environment-specific configurations
```

### Naming Conventions
- **Components**: PascalCase with `Component` suffix (e.g., `ProductosComponent`)
- **Services**: PascalCase with `Service` suffix (e.g., `ProductosService`)
- **Classes**: PascalCase (e.g., `ReferenciaVtexDto`, `UsuarioApp`)
- **Interfaces**: PascalCase with `I` prefix for DTOs (e.g., `IDesReferencia`, `IAtributoReferencia`)
- **Pipes**: PascalCase with `Pipe` suffix (e.g., `NoEsCargablePipe`, `FechaPipe`)
- **Files**: kebab-case (e.g., `productos.component.ts`, `alerta.service.ts`)
- **Selectors**: `elk-` prefix (e.g., `elk-home`, `elk-productos`)

### Spanish Codebase
- **Language**: All variable names, comments, method names, and UI text are in Spanish
- **Domain Terms**: Preserve business terminology (referencia, equivalencia, marketplace, canal, bodega)
- **Example**: `obtenerProductos()`, `guardarCategoria()`, `empresaSeleccionada`

## 4. Module Architecture

### AppModule (Root)
- **Purpose**: Bootstrap module with core dependencies
- **Key Imports**: `HttpClientModule`, `BrowserModule`, `SidebarModule.forRoot()`
- **HTTP Interceptor**: `RequestInterceptorService` for JWT injection and error handling
- **Routing**: Delegated to `AppRoutingModule`

### FeaturesModule
- **Purpose**: Contains all feature components (pages)
- **Imports**: `TreeModule`, `NgSelectModule`, `AgGridModule`, all ngx-bootstrap modules
- **Exports**: All feature components for routing
- **Components**: 20+ feature components including modals

### SharedModule
- **Purpose**: Reusable services, components, pipes
- **Providers**: All business services (`ProductosService`, `CategoriasService`, etc.)
- **Declarations**: Custom pipes, renderer components for ag-grid
- **Exports**: Pipes and components for use in feature modules

## 5. Routing & Navigation

### Route Configuration
```typescript
// All routes defined in app-routing.module.ts
{path: 'app', component: HomeComponent}         // Dashboard
{path: 'productos', component: ProductosComponent}
{path: 'categorias', component: CategoriasComponent}
{path: 'categorias-producto', component: CaterogoriasProductoComponent}
{path: 'equivalencias', component: EquivalenciasComponent}
{path: 'atributos', component: AtributosComponent}
{path: 'marketplaces', component: MarketPlacesComponent}
{path: 'vales', component: GenerarValesComponent}
{path: 'login', component: LoginComponent}
{path: 'contrasena', component: CambioContrasenaComponent}
{path: 'white-labels', component: WhiteLabelsComponent}
{path: '**', component: HomeComponent}          // Catch-all redirect
```

### Navigation Pattern
- **Container Component**: Main layout wrapper with sidebar navigation
- **Sidebar**: `ng-sidebar` component with menu items
- **Guards**: Authentication checked via `SeguridadService.logueado` EventEmitter
- **Login Redirect**: Interceptor redirects to `/login` on 401/403 errors

## 6. State Management & Data Flow

### Authentication State
- **Service**: `SeguridadService` manages authentication state
- **Storage**: `localStorage.setItem('usuarioElink', JSON.stringify(usuarioApp))`
- **Token**: JWT stored in `usuarioApp.data.jwt`
- **Events**: `logueado: EventEmitter<boolean>` for login state changes
- **Resources**: User permissions fetched after login via `getResources()` with JWT roles

### HTTP Communication
- **Interceptor**: `RequestInterceptorService` adds headers to all requests:
  - `siconline-user`: Username from localStorage
  - `Authorization`: JWT token from localStorage
- **Error Handling**: Global 401/403 handler redirects to login and shows alert
- **Services**: All HTTP logic encapsulated in `shared/service/*` classes

### Service Layer Pattern
```typescript
// Example: ProductosService
@Injectable({ providedIn: 'root' })
export class ProductosService {
  private urlBase = environment.URL_PRODUCTOS;
  
  constructor(private httpClient: HttpClient) {}
  
  obtenerProductos(params): Observable<ReferenciaVtexDto[]> {
    return this.httpClient.get<ReferenciaVtexDto[]>(`${this.urlBase}/consulta`, { params });
  }
  
  guardarProducto(producto: ReferenciaVtexDto): Observable<any> {
    return this.httpClient.post(`${this.urlBase}/guardar`, producto);
  }
}
```

### Component Data Flow
1. **Initialization**: `ngOnInit()` loads initial data via services
2. **User Actions**: Template events call component methods
3. **Service Calls**: Component methods invoke service HTTP requests
4. **Observable Subscription**: `.subscribe()` handles responses
5. **UI Update**: Component properties updated, triggering change detection

## 7. Environment Configuration

### Environment Variables
```typescript
// environment.ts (dev), environment.qa.ts, environment.prod.ts
export const environment = {
  production: false,
  nombre: 'dev',
  release: 'Elink Canales',
  version: '2.0.2',
  
  // Backend API endpoints (siconline-vtex-services)
  URL_ATRIBUTOS: 'http://localhost:8080/commerce/atributos',
  URL_MARKETPLACE: 'http://localhost:8080/commerce/marketplace',
  URL_CATEGORIAS: 'http://localhost:8080/commerce/categorias',
  URL_PRODUCTOS: 'http://localhost:8080/commerce/referencia',
  URL_VALES: 'http://localhost:8080/commerce/vales',
  URL_EQUIVALENCIAS: 'http://localhost:8080/commerce/equivalencias',
  
  // External services
  URL_DESCRIPCION: 'https://gco-gu.app.n8n.cloud/webhook/...',  // N8N AI descriptions
  URL_AUTENTICACION: 'http://localhost:8080/commerce/api/auth/login',
  URL_RESOURCES: 'http://localhost:8080/commerce/api/auth/resources',
  URL_RESET_CONTRASENA: 'http://localhost:8080/commerce/api/auth/changePasswordToUser',
  
  // Business constants
  equivalencias: {
    TIPO_COMPOSICION: 5,
    TIPO_COLOR: 4,
    TIPO_TALLA: 1
  }
};
```

### Build Configurations
- **Development**: `ng serve` uses `environment.ts`, proxy config commented out
- **QA**: `ng build --configuration=qa` uses `environment.qa.ts`
- **Production**: `ng build --prod` uses `environment.prod.ts` with AOT, optimization

## 8. UI Component Patterns

### Modal Pattern (ngx-bootstrap)
```typescript
// Service: modal-elink.service.ts
@Injectable({ providedIn: 'root' })
export class ModalElinkService {
  constructor(private bsModalService: BsModalService) {}
  
  mostrarModal(componente: any, opciones?: any): BsModalRef {
    return this.bsModalService.show(componente, opciones);
  }
}

// Component using modal
this.modalElinkService.mostrarModal(ModalAsignacionEquivalenciaComponent, {
  class: 'modal-lg',
  initialState: { datos: this.datosSeleccionados }
});
```

### Alert Pattern
```typescript
// Service: alerta.service.ts
mostrar(mensaje: string, titulo?: string): void {
  const modalRef = this.bsModalService.show(AlertaContentComponent);
  modalRef.content.mensaje = mensaje;
  modalRef.content.titulo = titulo || 'Información';
}

confirmar(mensaje: string, titulo?: string): Observable<boolean> {
  const modalRef = this.bsModalService.show(AlertaContentComponent);
  modalRef.content.mensaje = mensaje;
  modalRef.content.titulo = titulo || 'Confirmación';
  modalRef.content.esConfirmacion = true;
  return modalRef.content.onClose;
}
```

### ag-Grid Pattern
```typescript
// Component with ag-grid
columnDefs: ColDef[] = [
  { headerName: 'Referencia', field: 'referencia', sortable: true, filter: true },
  { headerName: 'Imagen', cellRenderer: 'imagenRenderer', width: 100 },
  { headerName: 'Estado', cellRenderer: 'caritasRenderer' }
];

frameworkComponents = {
  imagenRenderer: ImagenRendererComponent,
  caritasRenderer: CaritasRendererComponent
};

// Custom cell renderer component
@Component({
  selector: 'elk-imagen-renderer',
  template: `<img [src]="params.value" width="50" height="50">`
})
export class ImagenRendererComponent implements ICellRendererAngularComp {
  params: any;
  agInit(params: any): void { this.params = params; }
  refresh(params: any): boolean { return false; }
}
```

### Tree Component Pattern
```typescript
// angular-tree-component for categories
options: ITreeOptions = {
  displayField: 'nombre',
  childrenField: 'hijos',
  actionMapping: {
    mouse: {
      click: (tree, node) => this.onNodeClick(node)
    }
  }
};

nodes = []; // Loaded from service

<tree-root [nodes]="nodes" [options]="options"></tree-root>
```

### Spinner Pattern
```typescript
// Component with loading spinner
import { NgxSpinnerService } from 'ngx-spinner';

constructor(private spinner: NgxSpinnerService) {}

cargarDatos() {
  this.spinner.show();
  this.productosService.obtenerProductos(params).subscribe(
    data => {
      this.productos = data;
      this.spinner.hide();
    },
    error => {
      this.spinner.hide();
      this.alerta.mostrar('Error al cargar productos');
    }
  );
}
```

## 9. Custom Pipes

### Available Pipes
- **NoEsCargablePipe**: Filters products by upload status
- **FechaPipe**: Formats dates using Moment.js
- **SeleccionadosPipe**: Filters selected items from arrays
- **MostrarOpcionPipe**: Conditional display logic
- **CambiaPalabraPipe**: Text transformations

### Usage Pattern
```typescript
// Pipe definition
@Pipe({ name: 'noEsCargable' })
export class NoEsCargablePipe implements PipeTransform {
  transform(referencias: any[], esCargable: boolean): any[] {
    return referencias.filter(ref => ref.esCargable === esCargable);
  }
}

// Template usage
<div *ngFor="let producto of productos | noEsCargable:true">
```

## 10. Backend Integration

### API Communication
- **Base URLs**: Defined in `environment.*.ts` files
- **Authentication**: JWT token in `Authorization` header
- **User Context**: `siconline-user` header with username
- **Error Handling**: Interceptor catches 401/403, redirects to login

### DTO Classes & Interfaces
- **Classes** (`shared/clases/`): Domain objects with methods (e.g., `ReferenciaVtexDto`, `Categoria`, `Marketplace`)
- **Interfaces** (`shared/Interfaces/`): Data transfer objects for API contracts (e.g., `IDesReferencia`, `IAtributoReferencia`)
- **Naming**: DTOs often have `-dto` suffix or `I` prefix for interfaces

### Common API Patterns
```typescript
// GET with query params
obtenerReferencias(empresa: string, ano: string, periodo: string): Observable<ReferenciaVtexDto[]> {
  const params = new HttpParams()
    .set('empresa', empresa)
    .set('ano', ano)
    .set('periodo', periodo);
  return this.httpClient.get<ReferenciaVtexDto[]>(`${this.urlBase}/consulta`, { params });
}

// POST with body
guardarReferencia(referencia: ReferenciaVtexDto): Observable<any> {
  return this.httpClient.post(`${this.urlBase}/guardar`, referencia);
}

// PUT with params and body
actualizarEstado(id: number, estado: string): Observable<any> {
  return this.httpClient.put(`${this.urlBase}/estado/${id}`, { estado });
}
```

## 11. Development Workflow

### Running the Application
```bash
# Development server (port 4200)
ng serve

# Build for development
ng build

# Build for QA
ng build --configuration=qa

# Build for production
ng build --prod

# Run tests (Jasmine + Karma)
ng test

# Run e2e tests (Protractor)
ng e2e

# Lint code (TSLint)
ng lint
```

### Code Generation
```bash
# Generate component
ng generate component features/nueva-funcionalidad --prefix=elk

# Generate service
ng generate service shared/service/nuevo-servicio

# Generate pipe
ng generate pipe shared/pipes/nueva-transformacion

# Generate class
ng generate class shared/clases/NuevoDto
```

### Backend Connectivity
- **Local Development**: Backend expected at `localhost:8080/commerce`
- **CORS**: Backend must allow frontend origin (typically `localhost:4200`)
- **Proxy Config**: `src/proxy.conf.json` exists but is commented out in `angular.json`

## 12. Key Features & Business Logic

### Product Management (`productos.component.ts`)
- **Bulk Operations**: Select multiple products for batch updates
- **Image Management**: Upload/display product images
- **Attribute Mapping**: Assign channel-specific attributes
- **Launch Dates**: Set product availability dates per marketplace
- **AI Descriptions**: Integration with N8N webhook for GPT-generated descriptions
- **Export**: Excel export functionality via `file-saver` and `xlsx`

### Category Management (`categorias.component.ts`)
- **Tree View**: Hierarchical category navigation with `angular-tree-component`
- **CRUD Operations**: Create, update, delete categories
- **Drag & Drop**: Reorder categories in tree structure
- **Product Assignment**: Link products to categories

### Equivalencies (`equivalencias.component.ts`)
- **Type Management**: Color, size, composition equivalencies
- **Mapping**: Map internal codes to marketplace codes
- **Bulk Assignment**: Assign equivalencies to multiple products
- **Types**: `TIPO_COLOR: 4`, `TIPO_TALLA: 1`, `TIPO_COMPOSICION: 5`

### Attributes (`atributos.component.ts`)
- **Channel Attributes**: Define attributes per marketplace channel
- **Value Management**: Assign attribute values to products
- **Marketplace Sync**: Push attributes to VTEX channels

### Vales/Vouchers (`generar-vales.component.ts`)
- **Code Generation**: Create promotional voucher codes
- **Batch Creation**: Generate multiple vouchers at once
- **Excel Export**: Export voucher lists

## 13. Security & Authentication

### JWT Authentication Flow
1. User submits credentials on `/login`
2. `SeguridadService.login()` posts to `URL_AUTENTICACION`
3. Backend returns `UsuarioApp` with JWT in `data.jwt` field
4. JWT stored in `localStorage` as `usuarioElink`
5. JWT decoded to extract roles: `jwtDecode(jwt)` retrieves user roles
6. `getResources()` posts roles to `URL_RESOURCES` to fetch permissions
7. Resources stored and emitted via `onResources` EventEmitter

### Token Management
```typescript
// SeguridadService extracts roles from JWT
getRolesFromToken(token: string): ListResource[] {
  const decoded: any = jwtDecode(token);
  return decoded.roles.map(role => ({ roleName: role }));
}

// RequestInterceptorService injects token
intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
  if (isPublicRoute(req.url)) {
    return next.handle(req);
  }
  
  const modifiedReq = req.clone({
    setHeaders: {
      'siconline-user': JSON.parse(localStorage.getItem('usuarioElink')).data.username,
      'Authorization': JSON.parse(localStorage.getItem('usuarioElink')).data.jwt
    }
  });
  
  return next.handle(modifiedReq).pipe(
    catchError((error: HttpErrorResponse) => {
      if (error.status === 401 || error.status === 403) {
        this.router.navigate(['/login']);
        this.alerta.mostrar('Se ha cerrado la sesión');
        this.seguridadService.logout();
      }
      return throwError(() => error);
    })
  );
}
```

### Public Routes
- `/login`: Login page (no auth required)
- `URL_AUTENTICACION`: Authentication endpoint
- `URL_RESET_CONTRASENA`: Password reset endpoint
- `http://quotes.rest`: External quote API (no auth)

### Logout
- Clears `localStorage`
- Deletes `gco_seg_token` cookie
- Emits `logueado: false`
- Redirects to `/login`

## 14. External Service Integrations

### N8N AI Description Generation
- **URL**: `environment.URL_DESCRIPCION` (N8N webhook)
- **Purpose**: Generate product descriptions using AI
- **Component**: `modal-descripciones-gpt.component.ts`
- **Flow**: Send product attributes → Receive AI-generated text → Apply to products

### Quote of the Day
- **Service**: `quote-service.service.ts`
- **API**: `http://quotes.rest/qod.json`
- **Component**: `home.component.ts`
- **Display**: Shows inspirational quote on dashboard

## 15. Code Quality & Best Practices

### TypeScript Guidelines
- **Strict Mode**: Not enabled (Angular 7 defaults)
- **Target**: ES2015, downlevel iteration enabled
- **Decorators**: `experimentalDecorators: true`, `emitDecoratorMetadata: true`
- **Type Safety**: Use explicit types for method signatures and class properties

### Component Best Practices
```typescript
// ✅ Good: Typed properties, OnInit implementation
export class ProductosComponent implements OnInit {
  productos: ReferenciaVtexDto[] = [];
  empresaSeleccionada: string;
  
  constructor(
    private productosService: ProductosService,
    private alerta: AlertaService,
    private spinner: NgxSpinnerService
  ) {}
  
  ngOnInit(): void {
    this.cargarProductos();
  }
  
  cargarProductos(): void {
    this.spinner.show();
    this.productosService.obtenerProductos().subscribe(
      (data: ReferenciaVtexDto[]) => {
        this.productos = data;
        this.spinner.hide();
      },
      (error: any) => {
        this.alerta.mostrar('Error al cargar productos');
        this.spinner.hide();
      }
    );
  }
}

// ❌ Bad: Untyped, no error handling
export class ProductosComponent {
  productos;
  
  ngOnInit() {
    this.productosService.obtenerProductos().subscribe(data => {
      this.productos = data;
    });
  }
}
```

### Service Best Practices
- **Singleton Pattern**: Use `providedIn: 'root'` for services
- **Observable Return**: Always return Observables from HTTP methods (don't subscribe in service)
- **Error Handling**: Let components handle errors (don't catch in service unless transforming)
- **Immutability**: Don't mutate service state; emit new values

### Template Best Practices
- **Safe Navigation**: Use `?.` operator for nullable properties
- **Async Pipe**: Prefer `| async` for Observables in templates (auto-unsubscribe)
- **TrackBy**: Use `trackBy` functions in `*ngFor` for performance
- **Event Binding**: Use `()` for events, `[]` for properties, `[()]` for two-way binding

## 16. Testing Strategy

### Unit Tests (Jasmine + Karma)
- **Location**: `.spec.ts` files alongside components/services
- **Pattern**: AAA (Arrange, Act, Assert)
- **Mocking**: Use Jasmine spies for service dependencies
- **Coverage**: Focus on business logic in services and component methods

### E2E Tests (Protractor)
- **Location**: `e2e/src/*.e2e-spec.ts`
- **Purpose**: Critical user flows (login, product creation, category assignment)
- **Configuration**: `e2e/protractor.conf.js`

## 17. Performance Considerations

### Change Detection
- **Strategy**: Default change detection (OnPush not used)
- **Manual Triggers**: Use `ChangeDetectorRef.detectChanges()` if needed after async operations
- **Immutability**: Update object references to trigger detection

### ag-Grid Performance
- **Row Buffer**: Configure `rowBuffer` for large datasets
- **Virtual Scrolling**: Enabled by default for grids with many rows
- **Cell Renderers**: Keep custom renderers lightweight (avoid heavy computations)

### Image Handling
- **Lazy Loading**: Consider lazy loading images in product grids
- **Thumbnails**: Use thumbnail URLs when available instead of full-size images
- **Caching**: Browser caching via HTTP headers from backend

## 18. Common Pitfalls & Solutions

### Avoid Angular Version Upgrades
- **Issue**: Project uses Angular 7.2.0 with specific library versions
- **Solution**: Do NOT upgrade Angular, TypeScript, or RxJS without full regression testing
- **Reason**: Breaking changes in Angular 8+ (Ivy, new dependency injection, etc.)

### Preserve Typos in Paths
- **Issue**: `caterogorias-producto` (typo: should be "categorías")
- **Solution**: Keep existing path/component names to avoid breaking routes and imports
- **Reason**: Renaming requires updates in routing, module imports, backend endpoints

### localStorage Parsing
- **Issue**: `JSON.parse(localStorage.getItem('usuarioElink'))` can throw if null
- **Solution**: Check for null before parsing or use try-catch
```typescript
// ✅ Good
const usuarioStr = localStorage.getItem('usuarioElink');
if (usuarioStr) {
  const usuario = JSON.parse(usuarioStr);
}

// ❌ Bad (throws if null)
const usuario = JSON.parse(localStorage.getItem('usuarioElink'));
```

### Subscription Leaks
- **Issue**: Not unsubscribing from Observables causes memory leaks
- **Solution**: Use `async` pipe in templates OR store subscriptions and unsubscribe in `ngOnDestroy()`
```typescript
// ✅ Good: Manual unsubscribe
private subscription: Subscription;

ngOnInit() {
  this.subscription = this.service.getData().subscribe(...);
}

ngOnDestroy() {
  if (this.subscription) {
    this.subscription.unsubscribe();
  }
}

// ✅ Better: Use async pipe in template
// Component:
productos$: Observable<ReferenciaVtexDto[]>;
ngOnInit() {
  this.productos$ = this.productosService.obtenerProductos();
}
// Template:
<div *ngFor="let producto of productos$ | async">
```

## 19. Extension Guidelines

### Adding New Features
1. **Feature Module**: Create component in `features/` directory
2. **Route**: Add route to `app-routing.module.ts`
3. **Service**: Create service in `shared/service/` if new API integration
4. **DTOs**: Add interfaces in `shared/Interfaces/` or classes in `shared/clases/`
5. **Navigation**: Update sidebar in `container.component` with menu item

### Adding New Services
```typescript
// 1. Create service file: shared/service/nuevo.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({ providedIn: 'root' })
export class NuevoService {
  private urlBase = environment.URL_NUEVO; // Add to environment.ts
  
  constructor(private httpClient: HttpClient) {}
  
  obtenerDatos(): Observable<any> {
    return this.httpClient.get(`${this.urlBase}/consulta`);
  }
}

// 2. Add URL to environment.ts
export const environment = {
  // ... existing config
  URL_NUEVO: 'http://localhost:8080/commerce/nuevo'
};

// 3. Inject in component
constructor(private nuevoService: NuevoService) {}
```

### Adding Custom Pipes
```typescript
// 1. Create pipe: shared/pipes/nuevo-filtro.pipe.ts
@Pipe({ name: 'nuevoFiltro' })
export class NuevoFiltroPipe implements PipeTransform {
  transform(items: any[], criterio: string): any[] {
    return items.filter(item => item.campo === criterio);
  }
}

// 2. Declare in SharedModule
@NgModule({
  declarations: [
    // ... existing pipes
    NuevoFiltroPipe
  ],
  exports: [
    // ... existing exports
    NuevoFiltroPipe
  ]
})
export class SharedModule { }

// 3. Use in template
<div *ngFor="let item of items | nuevoFiltro:'valor'">
```

## 20. Debugging & Troubleshooting

### Browser DevTools
- **Angular DevTools**: Install extension for component inspection
- **Console Logs**: Extensive `console.log()` statements in existing code (preserve these)
- **Network Tab**: Inspect HTTP requests, verify headers and payloads

### Common Errors
```typescript
// Error: Cannot read property 'data' of null
// Cause: localStorage.getItem('usuarioElink') returns null
// Fix: Check authentication state before accessing
if (localStorage.getItem('usuarioElink')) {
  const usuario = JSON.parse(localStorage.getItem('usuarioElink'));
}

// Error: NullInjectorError: No provider for SomeService
// Cause: Service not provided in module
// Fix: Add @Injectable({ providedIn: 'root' }) or add to providers array

// Error: CORS policy blocked
// Cause: Backend not allowing frontend origin
// Fix: Configure CORS in siconline-vtex-services (see application.properties)
```

### Logging Pattern
```typescript
// Existing codebase uses extensive console logging
console.log('En el request interceptor');
console.log('subscribe del seguridad', data);
console.log('frase del dia', data);

// Preserve these logs during refactoring (aids production debugging)
```

## 21. Deployment

### Build Process
```bash
# Production build
ng build --prod

# Output: dist/ directory with optimized bundles
# - main.js (app code)
# - polyfills.js (browser compatibility)
# - runtime.js (webpack runtime)
# - styles.css (compiled styles)
# - vendor.js (third-party libraries)
```

### Nginx Configuration
```nginx
# default.conf (included in project root)
server {
  listen 80;
  location / {
    root /usr/share/nginx/html;
    index index.html;
    try_files $uri $uri/ /index.html;  # SPA routing
  }
}
```

### Docker Deployment
```dockerfile
# Typical Dockerfile (not in repo, reference only)
FROM node:12 AS builder
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build -- --prod

FROM nginx:alpine
COPY --from=builder /app/dist /usr/share/nginx/html
COPY default.conf /etc/nginx/conf.d/default.conf
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```

## 22. Integration with Backend Services

### siconline-vtex-services API
- **Base Path**: `/commerce`
- **Authentication**: JWT in `Authorization` header
- **User Context**: `siconline-user` header required
- **Expected Responses**: JSON with structure matching frontend DTOs

### API Contract Consistency
- **Frontend DTOs** (`shared/clases/`, `shared/Interfaces/`)
- **Backend DTOs** (`siconline-vtex-services/com.gco.elink.ms.entity`)
- **Alignment**: Frontend expects backend response structure (referencia, categoria, marketplace)

## 23. Review Checklist for AI Changes

- ✅ **Angular 7 compatibility**: No features from Angular 8+
- ✅ **TypeScript 3.2.2**: No syntax requiring TypeScript 3.3+
- ✅ **Spanish naming**: All variables, methods, comments in Spanish
- ✅ **Component prefix**: `elk-` for all new components
- ✅ **Service patterns**: Observable return types, no subscriptions in services
- ✅ **Error handling**: Spinner hide, alert display on errors
- ✅ **Authentication**: Interceptor adds JWT and user headers
- ✅ **Routing**: New routes added to `app-routing.module.ts`
- ✅ **Module declarations**: Components declared in FeaturesModule or SharedModule
- ✅ **Environment config**: New API URLs added to all environment files
- ✅ **Unsubscribe**: Manual subscriptions cleaned up in `ngOnDestroy()`
- ✅ **Immutability**: Object references updated for change detection
- ✅ **Type safety**: Explicit types on method signatures and properties

---

## 24. Quick Reference

### Component Lifecycle
```typescript
ngOnInit()       // Initialize component, load data
ngOnDestroy()    // Cleanup, unsubscribe
ngOnChanges()    // React to input property changes
ngAfterViewInit() // DOM available, safe to access ViewChild
```

### Common Imports
```typescript
import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { NgxSpinnerService } from 'ngx-spinner';
import { AlertaService } from 'src/app/shared/service/alerta.service';
```

### Directory Shortcuts
- Services: `src/app/shared/service/`
- Components: `src/app/features/`
- DTOs: `src/app/shared/clases/` or `src/app/shared/Interfaces/`
- Pipes: `src/app/shared/pipes/`
- Environments: `src/environments/`

---

**Remember**: This is a production Angular 7 application with established patterns. Prioritize consistency with existing code over introducing new paradigms. When in doubt, follow the patterns in `productos.component.ts` (largest, most comprehensive example) and `shared/service/*.service.ts` for service implementations.
