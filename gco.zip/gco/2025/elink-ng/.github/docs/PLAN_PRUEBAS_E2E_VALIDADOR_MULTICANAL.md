# Plan de Implementación de Pruebas E2E - Validador Multicanal

## 1. Estrategia de Pruebas

### 1.1 Objetivo
Certificar la funcionalidad completa del módulo "Validador Multicanal" utilizando datos mock antes de la integración con el backend real.

### 1.2 Alcance
- ✅ Búsqueda de referencias con diferentes filtros
- ✅ Validación visual de estados (✔️/❌)
- ✅ Apertura y contenido de modal de atributos
- ✅ Apertura y contenido de modal de fecha de lanzamiento
- ✅ Asignación de fechas a múltiples referencias
- ✅ Manejo de errores y validaciones
- ✅ Flujos de usuario completos

### 1.3 Herramientas
- **Protractor** (configurado en el proyecto)
- **Jasmine** (framework de testing)
- **Angular HTTP Testing** (mocks de servicios)
- **Page Object Pattern** (organización de pruebas)

---

## 2. Arquitectura de Pruebas

```mermaid
graph TB
    subgraph "Capa de Pruebas E2E"
        A[Specs E2E]
        B[Page Objects]
        C[Test Data]
    end
    
    subgraph "Capa de Mocks"
        D[Mock Service]
        E[Mock Data]
        F[HTTP Interceptor Mock]
    end
    
    subgraph "Aplicación"
        G[Components]
        H[Services]
        I[HTTP Client]
    end
    
    A --> B
    B --> C
    A --> D
    D --> E
    D --> F
    F --> I
    B --> G
    H --> I
    
    style A fill:#4CAF50,color:#fff
    style D fill:#FF9800,color:#fff
    style G fill:#2196F3,color:#fff
```

---

## 3. Estructura de Archivos

```
elink-ng/
├── e2e/
│   ├── src/
│   │   ├── validador-multicanal/
│   │   │   ├── buscar-referencia.e2e-spec.ts
│   │   │   ├── modal-atributos.e2e-spec.ts
│   │   │   ├── modal-fecha-lanzamiento.e2e-spec.ts
│   │   │   ├── flujo-completo.e2e-spec.ts
│   │   │   └── page-objects/
│   │   │       ├── buscar-referencia.po.ts
│   │   │       ├── modal-atributos.po.ts
│   │   │       └── modal-fecha-lanzamiento.po.ts
│   │   └── mocks/
│   │       ├── referencia-mock.data.ts
│   │       └── http-mock-interceptor.ts
│   └── protractor.conf.js
│
├── src/
│   └── app/
│       └── shared/
│           └── service/
│               ├── validador-referencia.service.spec.ts
│               └── validador-referencia.service.mock.ts
```

---

## 4. Datos Mock

### 4.1 Referencias de Prueba

```typescript
// Mock data con diferentes escenarios
export const MOCK_REFERENCIAS = {
  completa: {
    id: 'REF-001',
    codigo: '11659150',
    nombre: 'Camiseta Básica Algodón',
    urlImagen: 'https://via.placeholder.com/150',
    isValid: true,
    empresa: 'IC',
    ano: 2024,
    coleccion: '01'
  },
  incompleta: {
    id: 'REF-002',
    codigo: '11659151',
    nombre: 'Pantalón Denim',
    urlImagen: 'https://via.placeholder.com/150',
    isValid: false,
    empresa: 'IC',
    ano: 2024,
    coleccion: '01'
  },
  sinImagen: {
    id: 'REF-003',
    codigo: '11659152',
    nombre: 'Chaqueta Sport',
    urlImagen: null,
    isValid: false,
    empresa: 'IC',
    ano: 2024,
    coleccion: '01'
  }
};
```

### 4.2 Detalles de Atributos Mock

```typescript
export const MOCK_DETALLE_ATRIBUTOS = {
  completo: {
    idReferencia: 'REF-001',
    codigoReferencia: '11659150',
    atributos: [
      { nombre: 'Descripción', ok: true, valor: 'Camiseta 100% algodón' },
      { nombre: 'Imagen', ok: true, valor: 'https://...' },
      { nombre: 'Color', ok: true, valor: 'Azul' },
      { nombre: 'Talla', ok: true, valor: 'M' }
    ],
    canales: [
      { codigo: 'IC', nombre: 'Internet Colombia', ok: true, atributosFaltantes: [] },
      { codigo: 'VN', nombre: 'Ventas Nacionales', ok: true, atributosFaltantes: [] }
    ]
  },
  incompleto: {
    idReferencia: 'REF-002',
    codigoReferencia: '11659151',
    atributos: [
      { nombre: 'Descripción', ok: true, valor: 'Pantalón denim' },
      { nombre: 'Imagen', ok: true, valor: 'https://...' },
      { nombre: 'Color', ok: false, valor: null },
      { nombre: 'Talla', ok: false, valor: null }
    ],
    canales: [
      { codigo: 'IC', nombre: 'Internet Colombia', ok: false, atributosFaltantes: ['Color', 'Talla'] },
      { codigo: 'VN', nombre: 'Ventas Nacionales', ok: false, atributosFaltantes: ['Color', 'Talla'] }
    ]
  }
};
```

---

## 5. Cronograma de Implementación

```mermaid
gantt
    title Plan de Implementación de Pruebas E2E
    dateFormat YYYY-MM-DD
    section Fase 1: Setup
    Configurar ambiente pruebas    :2025-01-15, 2d
    Crear estructura archivos      :2025-01-16, 1d
    Implementar datos mock         :2025-01-17, 2d
    
    section Fase 2: Mocks
    Mock de ValidadorService       :2025-01-19, 2d
    HTTP Interceptor Mock          :2025-01-20, 2d
    Validar mocks funcionan        :2025-01-22, 1d
    
    section Fase 3: Page Objects
    PO Buscar Referencia          :2025-01-23, 2d
    PO Modal Atributos            :2025-01-24, 2d
    PO Modal Fecha Lanzamiento    :2025-01-26, 2d
    
    section Fase 4: Specs
    Specs Búsqueda                :2025-01-28, 3d
    Specs Modales                 :2025-01-30, 3d
    Specs Flujo Completo          :2025-02-02, 2d
    
    section Fase 5: Certificación
    Ejecución pruebas             :2025-02-04, 2d
    Corrección defectos           :2025-02-06, 3d
    Reporte final                 :2025-02-09, 1d
```

---

## 6. Casos de Prueba E2E

### 6.1 Suite: Búsqueda de Referencias

| ID | Caso de Prueba | Prioridad | Complejidad |
|----|----------------|-----------|-------------|
| E2E-BR-001 | Búsqueda exitosa con referencia completa | Alta | Baja |
| E2E-BR-002 | Búsqueda con referencia incompleta | Alta | Baja |
| E2E-BR-003 | Búsqueda sin resultados | Media | Baja |
| E2E-BR-004 | Validación de campos obligatorios | Alta | Baja |
| E2E-BR-005 | Filtro por año y colección | Media | Media |
| E2E-BR-006 | Selección múltiple de referencias | Alta | Media |
| E2E-BR-007 | Deselección de referencias | Media | Baja |
| E2E-BR-008 | Validación visual de iconos ✔️/❌ | Alta | Media |

### 6.2 Suite: Modal de Atributos

| ID | Caso de Prueba | Prioridad | Complejidad |
|----|----------------|-----------|-------------|
| E2E-MA-001 | Abrir modal desde referencia completa | Alta | Baja |
| E2E-MA-002 | Abrir modal desde referencia incompleta | Alta | Baja |
| E2E-MA-003 | Visualizar atributos con estado OK | Alta | Media |
| E2E-MA-004 | Visualizar atributos con estado Error | Alta | Media |
| E2E-MA-005 | Visualizar canales completos (verde) | Media | Media |
| E2E-MA-006 | Visualizar canales con faltantes (rojo) | Alta | Media |
| E2E-MA-007 | Tooltip de atributos faltantes | Media | Alta |
| E2E-MA-008 | Cerrar modal correctamente | Baja | Baja |

### 6.3 Suite: Modal de Fecha de Lanzamiento

| ID | Caso de Prueba | Prioridad | Complejidad |
|----|----------------|-----------|-------------|
| E2E-MF-001 | Abrir modal con 1 referencia | Alta | Baja |
| E2E-MF-002 | Abrir modal con múltiples referencias | Alta | Media |
| E2E-MF-003 | Seleccionar fecha válida | Alta | Media |
| E2E-MF-004 | Seleccionar múltiples canales | Alta | Media |
| E2E-MF-005 | Validación sin fecha | Alta | Baja |
| E2E-MF-006 | Validación sin canales | Alta | Baja |
| E2E-MF-007 | Asignación exitosa | Alta | Alta |
| E2E-MF-008 | Cancelar asignación | Media | Baja |
| E2E-MF-009 | Manejo de error del servidor | Media | Alta |

### 6.4 Suite: Flujo Completo

| ID | Caso de Prueba | Prioridad | Complejidad |
|----|----------------|-----------|-------------|
| E2E-FC-001 | Flujo completo usuario feliz | Alta | Alta |
| E2E-FC-002 | Búsqueda → Ver atributos → Cerrar | Alta | Media |
| E2E-FC-003 | Búsqueda → Asignar fecha → Éxito | Alta | Alta |
| E2E-FC-004 | Validar persistencia de selección | Media | Media |
| E2E-FC-005 | Navegación entre modales | Baja | Alta |

---

## 7. Métricas de Éxito

### 7.1 Criterios de Aceptación

```mermaid
pie title Cobertura de Pruebas Requerida
    "Componentes" : 95
    "Servicios" : 100
    "Integraciones" : 85
    "Flujos E2E" : 80
```

### 7.2 Indicadores Clave

| Métrica | Objetivo | Crítico |
|---------|----------|---------|
| Cobertura de código | ≥ 85% | ≥ 70% |
| Pruebas exitosas | 100% | ≥ 95% |
| Tiempo ejecución suite | ≤ 5 min | ≤ 10 min |
| Falsos positivos | 0% | ≤ 5% |
| Bugs críticos encontrados | 0 | ≤ 2 |

---

## 8. Proceso de Certificación

### 8.1 Flujo de Certificación

```mermaid
graph TB
    A[Desarrollo Completo] --> B{Pruebas Unitarias}
    B -->|Pass| C{Pruebas Integración}
    B -->|Fail| Z[Corregir y Reintentar]
    C -->|Pass| D{Pruebas E2E con Mocks}
    C -->|Fail| Z
    D -->|Pass| E{Revisión QA}
    D -->|Fail| Z
    E -->|Aprobado| F[Certificación Mock Completa]
    E -->|Rechazado| Z
    F --> G{Integración Backend Real}
    G -->|Pass| H[Pruebas E2E Reales]
    G -->|Fail| Y[Ajustar Integración]
    H -->|Pass| I[Certificación Final]
    H -->|Fail| Y
    I --> J[Despliegue a Producción]
    
    style F fill:#4CAF50,color:#fff
    style I fill:#2196F3,color:#fff
    style J fill:#9C27B0,color:#fff
    style Z fill:#F44336,color:#fff
    style Y fill:#FF9800,color:#fff
```

### 8.2 Checklist de Certificación

#### Fase 1: Certificación con Mocks ✓
- [ ] Todos los mocks implementados y funcionando
- [ ] Pruebas unitarias al 100% exitosas
- [ ] Pruebas de integración con mocks al 100%
- [ ] Pruebas E2E con mocks al 100%
- [ ] Sin bugs críticos o bloqueantes
- [ ] Documentación de pruebas completa
- [ ] Reporte de cobertura generado

#### Fase 2: Certificación con Backend Real ✓
- [ ] Endpoints backend implementados y documentados
- [ ] Base de datos con datos de prueba
- [ ] Configuración de environment para testing
- [ ] Pruebas E2E con backend real al 100%
- [ ] Validación de performance (tiempos de respuesta)
- [ ] Pruebas de carga básicas
- [ ] Sin regresiones en funcionalidad existente

#### Fase 3: Aprobación Final ✓
- [ ] Sign-off de QA Lead
- [ ] Sign-off de Product Owner
- [ ] Documentación técnica actualizada
- [ ] Release notes preparadas
- [ ] Plan de rollback definido

---

## 9. Entregables

### 9.1 Documentos

1. **Plan de Pruebas E2E** (este documento)
2. **Casos de Prueba Detallados** (Excel/Spreadsheet)
3. **Reporte de Ejecución de Pruebas**
4. **Reporte de Cobertura de Código**
5. **Matriz de Trazabilidad** (Requisitos → Tests)
6. **Guía de Uso de Mocks**

### 9.2 Código

1. **Specs E2E** (`.e2e-spec.ts`)
2. **Page Objects** (`.po.ts`)
3. **Mock Services** (`.mock.ts`)
4. **Mock Data** (`.data.ts`)
5. **HTTP Interceptor Mock**
6. **Configuración Protractor Actualizada**

### 9.3 Reportes

```mermaid
graph LR
    A[Ejecución Pruebas] --> B[JUnit XML Report]
    A --> C[HTML Coverage Report]
    A --> D[Console Log Output]
    A --> E[Screenshots on Failure]
    
    B --> F[CI/CD Integration]
    C --> G[Code Review]
    D --> H[Debug Log]
    E --> I[Bug Reports]
    
    style A fill:#4CAF50,color:#fff
    style F fill:#2196F3,color:#fff
```

---

## 10. Responsabilidades

### 10.1 Equipo de Desarrollo

- Implementar mocks de servicios
- Crear datos de prueba
- Ejecutar pruebas unitarias
- Corregir bugs encontrados
- Mantener cobertura de código

### 10.2 Equipo de QA

- Diseñar casos de prueba E2E
- Implementar specs de Protractor
- Ejecutar suite completa de pruebas
- Reportar bugs encontrados
- Validar correcciones

### 10.3 Tech Lead

- Revisar arquitectura de pruebas
- Aprobar estrategia de mocks
- Validar cobertura de pruebas
- Sign-off de certificación
- Coordinación con backend

---

## 11. Riesgos y Mitigación

| Riesgo | Probabilidad | Impacto | Mitigación |
|--------|--------------|---------|------------|
| Mocks no representan realidad | Media | Alto | Validar estructura de datos con backend |
| Tiempo de ejecución excesivo | Baja | Medio | Optimizar selectores y waits |
| Pruebas frágiles (flaky tests) | Media | Alto | Usar waits explícitos, no sleeps |
| Cambios en UI rompen tests | Alta | Medio | Usar Page Objects, IDs estables |
| Backend no listo para integración | Media | Alto | Coordinar con backend, plan B con mocks |
| Cobertura insuficiente | Baja | Alto | Code reviews obligatorios |

---

## 12. Comandos de Ejecución

### 12.1 Pruebas Unitarias

```bash
# Ejecutar todas las pruebas unitarias
npm test

# Ejecutar pruebas con cobertura
npm run test:coverage

# Ejecutar en modo watch
npm run test:watch

# Pruebas específicas del validador
ng test --include='**/validador-referencia*.spec.ts'
```

### 12.2 Pruebas E2E

```bash
# Ejecutar todas las pruebas E2E
npm run e2e

# Ejecutar suite específica
ng e2e --specs='e2e/src/validador-multicanal/**/*.e2e-spec.ts'

# Ejecutar con mocks
ng e2e --config=e2e/protractor-mock.conf.js

# Ejecutar con backend real
ng e2e --config=e2e/protractor-integration.conf.js

# Modo headless (CI/CD)
ng e2e --protractor-config=e2e/protractor-ci.conf.js
```

### 12.3 Reportes

```bash
# Generar reporte de cobertura
npm run test:coverage

# Abrir reporte HTML
start coverage/index.html  # Windows
open coverage/index.html   # Mac/Linux

# Generar reporte E2E con screenshots
ng e2e --save-screenshots
```

---

## 13. Ambiente de Pruebas

### 13.1 Configuración Local

```typescript
// environment.test.ts
export const environment = {
  production: false,
  nombre: 'test',
  useMocks: true,  // ← Flag para activar mocks
  
  URL_PRODUCTOS: 'http://localhost:4200/api/mock/referencia',
  URL_MARKETPLACE: 'http://localhost:4200/api/mock/marketplace',
  // ... otros endpoints
};
```

### 13.2 Mock Server

```typescript
// Opción 1: JSON Server (simple)
{
  "referencias": [...],
  "atributos": [...],
  "canales": [...]
}

// Opción 2: Angular In-Memory Web API
import { InMemoryDbService } from 'angular-in-memory-web-api';

export class MockDataService implements InMemoryDbService {
  createDb() {
    return {
      'referencia/buscar': MOCK_REFERENCIAS,
      'referencia/atributos': MOCK_ATRIBUTOS,
      // ...
    };
  }
}
```

---

## 14. Próximos Pasos

### 14.1 Semana 1-2
1. ✅ Configurar ambiente de pruebas
2. ✅ Implementar datos mock
3. ✅ Crear mock services
4. ⏳ Implementar HTTP interceptor mock

### 14.2 Semana 3-4
1. ⏳ Crear Page Objects
2. ⏳ Implementar specs de búsqueda
3. ⏳ Implementar specs de modales
4. ⏳ Validar cobertura

### 14.3 Semana 5
1. ⏳ Ejecutar suite completa
2. ⏳ Corregir bugs encontrados
3. ⏳ Generar reportes
4. ⏳ Certificación con mocks

### 14.4 Semana 6
1. ⏳ Integración con backend real
2. ⏳ Pruebas E2E reales
3. ⏳ Certificación final
4. ⏳ Preparación para producción

---

## 15. Conclusiones

Este plan de pruebas E2E proporciona:

✅ **Estrategia completa** para certificar antes de producción  
✅ **Mocks realistas** que simulan comportamiento del backend  
✅ **Cobertura exhaustiva** de todos los flujos de usuario  
✅ **Automatización** para ejecución en CI/CD  
✅ **Reportes claros** para toma de decisiones  
✅ **Proceso de certificación** en dos fases (mocks → real)  

El uso de mocks permite:
- 🚀 Desarrollo paralelo frontend/backend
- 🔍 Detección temprana de bugs de UI
- ⚡ Ejecución rápida de pruebas
- 🛡️ Validación sin afectar datos reales
- 📊 Certificación antes de integración

---

**Documento preparado por:** Equipo de Desarrollo Elink  
**Fecha:** Noviembre 2025  
**Versión:** 1.0  
**Estado:** Pendiente de Aprobación
