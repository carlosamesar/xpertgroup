# Documentación Técnica: Módulo "Validador Multicanal"

## 1. Descripción General

El módulo **Validador Multicanal** (Buscar por Referencia) es una funcionalidad diseñada para la validación rápida y asignación de fechas de lanzamiento de referencias de productos en el sistema Elink. Permite a los usuarios buscar referencias, visualizar su estado de completitud y asignar fechas de lanzamiento por canal de forma eficiente.

### 1.1 Características Principales

- **Búsqueda ligera**: Consulta rápida sin creación ni recarga de productos
- **Validación visual**: Indicadores inmediatos del estado de completitud
- **Detalle de atributos**: Vista completa de atributos con estado por canal
- **Asignación masiva**: Fecha de lanzamiento para múltiples referencias y canales
- **Interfaz responsiva**: Diseño adaptable a diferentes dispositivos

---

## 2. Arquitectura del Sistema

### 2.1 Diagrama de Componentes

```mermaid
graph TB
    subgraph "Frontend - Angular 7"
        A[BuscarReferenciaComponent]
        B[ModalAtributosReferenciaComponent]
        C[ModalFechaLanzamientoReferenciaComponent]
        D[ValidadorReferenciaService]
        
        A --> B
        A --> C
        A --> D
        B --> D
        C --> D
    end
    
    subgraph "Backend - Spring Boot"
        E[ReferenciasController]
        F[ReferenciaService]
        G[IElkReferenciaMaeRepository]
        H[IElkEquivalenciasRepository]
        I[IElkReferenciaxcanalRepo]
        
        E --> F
        F --> G
        F --> H
        F --> I
    end
    
    subgraph "Base de Datos"
        J[(PostgreSQL)]
        K[elk_referencia_mae]
        L[elk_equivalencia]
        M[elk_referenciaxcanal]
        N[elk_canal_mae]
        
        G --> K
        H --> L
        I --> M
    end
    
    D -->|HTTP REST| E
    J --> K
    J --> L
    J --> M
    J --> N
    
    style A fill:#e1f5ff
    style E fill:#fff3e0
    style J fill:#f3e5f5
```

### 2.2 Capas de la Aplicación

```mermaid
graph LR
    A[Presentación<br/>Angular Components] --> B[Servicios<br/>Angular Services]
    B --> C[API REST<br/>Spring Controllers]
    C --> D[Lógica de Negocio<br/>Spring Services]
    D --> E[Acceso a Datos<br/>JPA Repositories]
    E --> F[Base de Datos<br/>PostgreSQL]
    
    style A fill:#4CAF50,color:#fff
    style B fill:#2196F3,color:#fff
    style C fill:#FF9800,color:#fff
    style D fill:#9C27B0,color:#fff
    style E fill:#F44336,color:#fff
    style F fill:#607D8B,color:#fff
```

---

## 3. Flujos de Proceso

### 3.1 Flujo de Búsqueda de Referencias

```mermaid
sequenceDiagram
    actor Usuario
    participant UI as BuscarReferenciaComponent
    participant Service as ValidadorReferenciaService
    participant API as ReferenciasController
    participant BL as ReferenciaService
    participant DB as PostgreSQL
    
    Usuario->>UI: Ingresa filtros y pulsa "Consultar"
    UI->>UI: Valida empresa y referencia
    UI->>Service: buscarReferencias(empresa, ref, año, col)
    Service->>API: GET /commerce/referencia/buscar?params
    API->>BL: buscarReferenciasPorCodigo(params)
    
    BL->>DB: Query referencias con filtros
    DB-->>BL: List<ElkReferenciaMae>
    
    loop Para cada referencia
        BL->>BL: validarReferenciaCompleta(ref)
        BL->>DB: Consultar equivalencias (color, talla)
        DB-->>BL: Equivalencias
        BL->>BL: Calcular isValid
    end
    
    BL-->>API: List<ReferenciaValidacionDto>
    API-->>Service: JSON Response
    Service-->>UI: Observable<Referencias[]>
    UI->>UI: Renderizar lista de resultados
    UI-->>Usuario: Muestra tarjetas con validador
```

### 3.2 Flujo de Detalle de Atributos

```mermaid
sequenceDiagram
    actor Usuario
    participant UI as BuscarReferenciaComponent
    participant Modal as ModalAtributosReferenciaComponent
    participant Service as ValidadorReferenciaService
    participant API as ReferenciasController
    participant BL as ReferenciaService
    participant DB as PostgreSQL
    
    Usuario->>UI: Click en icono validador (✔️/❌)
    UI->>Modal: abrirModalAtributos(referencia)
    activate Modal
    
    Modal->>Service: obtenerDetalleAtributos(idRef, empresa)
    Service->>API: GET /commerce/referencia/{id}/atributos
    API->>BL: obtenerDetalleAtributos(idRef, empresa)
    
    BL->>DB: Consultar referencia por ID
    DB-->>BL: ElkReferenciaMae
    
    BL->>BL: Construir lista de atributos
    Note right of BL: Descripción, Imagen, Nombre,<br/>Precio, Categoría, Color, Talla
    
    BL->>DB: Consultar equivalencias
    DB-->>BL: Equivalencias (color, talla, composición)
    
    BL->>DB: Consultar canales de la empresa
    DB-->>BL: List<ElkCanalMae>
    
    loop Para cada canal
        BL->>BL: Identificar atributos faltantes
        BL->>BL: Crear CanalReferenciaDto
    end
    
    BL-->>API: DetalleAtributosReferenciaDto
    API-->>Service: JSON Response
    Service-->>Modal: Observable<DetalleDto>
    Modal->>Modal: Renderizar atributos y canales
    Modal-->>Usuario: Muestra modal con detalles
    deactivate Modal
```

### 3.3 Flujo de Asignación de Fecha de Lanzamiento

```mermaid
sequenceDiagram
    actor Usuario
    participant UI as BuscarReferenciaComponent
    participant Modal as ModalFechaLanzamientoComponent
    participant Service as ValidadorReferenciaService
    participant API as ReferenciasController
    participant BL as ReferenciaService
    participant DB as PostgreSQL
    
    Usuario->>UI: Selecciona referencias
    Usuario->>UI: Click "Asignar fecha de lanzamiento"
    UI->>Modal: abrirModalFechaLanzamiento(referencias[])
    activate Modal
    
    Modal->>Service: Cargar canales de la empresa
    Service-->>Modal: List<Marketplace>
    Modal-->>Usuario: Muestra calendario y canales
    
    Usuario->>Modal: Selecciona fecha
    Usuario->>Modal: Selecciona canales
    Usuario->>Modal: Click "Asignar"
    
    Modal->>Modal: Validar fecha y canales
    
    loop Para cada referencia seleccionada
        Modal->>Service: asignarFechaLanzamiento(idRef, dto)
        Service->>API: POST /commerce/referencia/{id}/fecha-lanzamiento
        API->>BL: asignarFechaLanzamiento(idRef, asignacion, user)
        
        BL->>BL: Validar datos
        BL->>DB: Consultar referencia
        DB-->>BL: ElkReferenciaMae
        
        BL->>DB: UPDATE elk_referencia_mae<br/>SET fecha_lanzamiento
        
        loop Para cada canal seleccionado
            BL->>DB: INSERT/UPDATE elk_referenciaxcanal
        end
        
        DB-->>BL: Success
        BL-->>API: OK
        API-->>Service: 200 OK
    end
    
    Service-->>Modal: Success
    Modal->>Modal: Mostrar toast de éxito
    Modal->>UI: onClose.next({success: true})
    UI->>UI: Recargar resultados
    Modal-->>Usuario: Cierra modal
    deactivate Modal
```

---

## 4. Modelo de Datos

### 4.1 Diagrama de Entidades

```mermaid
erDiagram
    ELK_REFERENCIA_MAE ||--o{ ELK_REFERENCIAXCANAL : "tiene"
    ELK_REFERENCIA_MAE ||--o{ ELK_EQUIVALENCIA : "tiene"
    ELK_CANAL_MAE ||--o{ ELK_REFERENCIAXCANAL : "asignado"
    ELK_EMPRESA_MAE ||--o{ ELK_REFERENCIA_MAE : "pertenece"
    ELK_EMPRESA_MAE ||--o{ ELK_CANAL_MAE : "tiene"
    
    ELK_REFERENCIA_MAE {
        string id_referencia PK
        string empresa PK
        string referencia
        string nom_referencia
        string descripcion
        string url_imagen
        float valor_publico
        string nom_categoria
        date fecha_lanzamiento
        boolean actualizado
        boolean atributo_sic
    }
    
    ELK_EQUIVALENCIA {
        string id_referencia FK
        int tipo_equivalencia
        string equivalencia
        string codigo_equivalencia
    }
    
    ELK_REFERENCIAXCANAL {
        string id_referencia PK,FK
        string canal PK,FK
        date fecha_lanzamiento
        date fecha_creacion
        string usuario_creacion
    }
    
    ELK_CANAL_MAE {
        string empresa PK
        string canal PK
        string nombre
        boolean activo
    }
    
    ELK_EMPRESA_MAE {
        string empresa PK
        string descripcion
        boolean activo
    }
```

### 4.2 Tipos de Equivalencia

| Tipo | Descripción | Uso |
|------|-------------|-----|
| 1 | Talla | Mapeo de tallas entre sistemas |
| 4 | Color | Mapeo de colores entre sistemas |
| 5 | Composición | Material del producto |

---

## 5. APIs REST Implementadas

### 5.1 Buscar Referencias

**Endpoint:** `GET /commerce/referencia/buscar`

**Descripción:** Búsqueda ligera de referencias con validación de completitud.

**Parámetros:**
```
empresa (required): string - Código de empresa
referencia (optional): string - Código de referencia a buscar
ano (optional): integer - Año de colección
coleccion (optional): string - Código de colección
```

**Respuesta:**
```json
[
  {
    "id": "REF-001",
    "codigo": "11659150",
    "nombre": "Camiseta Básica",
    "urlImagen": "https://cdn.example.com/image.jpg",
    "isValid": true,
    "empresa": "IC",
    "ano": 2024,
    "coleccion": "01",
    "fechaLanzamiento": "2024-12-15T00:00:00"
  }
]
```

### 5.2 Obtener Detalle de Atributos

**Endpoint:** `GET /commerce/referencia/{id}/atributos`

**Descripción:** Obtiene el estado detallado de atributos y canales para una referencia.

**Parámetros:**
```
id (path): string - ID de la referencia
empresa (query): string - Código de empresa
```

**Respuesta:**
```json
{
  "idReferencia": "REF-001",
  "codigoReferencia": "11659150",
  "atributos": [
    {
      "nombre": "Descripción",
      "ok": true,
      "valor": "Camiseta de algodón 100%"
    },
    {
      "nombre": "Imagen",
      "ok": true,
      "valor": "https://cdn.example.com/image.jpg"
    },
    {
      "nombre": "Color",
      "ok": false,
      "valor": null
    }
  ],
  "canales": [
    {
      "codigo": "IC",
      "nombre": "Internet Colombia",
      "ok": false,
      "atributosFaltantes": ["Color", "Talla"]
    },
    {
      "codigo": "VN",
      "nombre": "Ventas Nacionales",
      "ok": true,
      "atributosFaltantes": []
    }
  ]
}
```

### 5.3 Asignar Fecha de Lanzamiento

**Endpoint:** `POST /commerce/referencia/{id}/fecha-lanzamiento`

**Descripción:** Asigna fecha de lanzamiento a una referencia en canales específicos.

**Parámetros:**
```
id (path): string - ID de la referencia
```

**Body:**
```json
{
  "fecha": "2024-12-15T00:00:00",
  "canales": ["IC", "VN", "IG"]
}
```

**Respuesta:**
```json
{
  "mensaje": "Fecha de lanzamiento asignada exitosamente",
  "idReferencia": "REF-001"
}
```

**Códigos de Error:**
- `400 Bad Request`: Fecha o canales faltantes
- `404 Not Found`: Referencia no encontrada
- `500 Internal Server Error`: Error de servidor

---

## 6. Componentes Frontend

### 6.1 BuscarReferenciaComponent

**Responsabilidades:**
- Renderizar formulario de búsqueda
- Gestionar lista de resultados
- Coordinar apertura de modales
- Manejar selección múltiple de referencias

**Propiedades Principales:**
```typescript
listaEmpresa: Empresa[]          // Empresas disponibles
empresaSeleccionada: Empresa     // Empresa seleccionada
ano: number                      // Año de búsqueda
coleccion: string                // Colección (opcional)
referenciaBuscar: string         // Código de referencia
listaReferencias: ReferenciaValidacionDto[]        // Resultados
referenciasSeleccionadas: ReferenciaValidacionDto[]  // Seleccionadas
```

**Métodos Principales:**
- `buscarReferencias()`: Ejecuta búsqueda
- `onSeleccionarReferencia()`: Gestiona selección
- `abrirModalAtributos()`: Muestra detalle de atributos
- `abrirModalFechaLanzamiento()`: Muestra modal de asignación

### 6.2 ModalAtributosReferenciaComponent

**Responsabilidades:**
- Mostrar atributos con estado de validación
- Listar canales con atributos faltantes
- Proporcionar tooltips informativos

**Propiedades de Entrada:**
```typescript
idReferencia: string      // ID de referencia (initialState)
codigoReferencia: string  // Código de referencia (initialState)
empresa: string           // Código de empresa (initialState)
```

**Datos Internos:**
```typescript
detalleAtributos: DetalleAtributosReferenciaDto
cargando: boolean
```

### 6.3 ModalFechaLanzamientoReferenciaComponent

**Responsabilidades:**
- Selección de fecha con date picker
- Selección múltiple de canales
- Asignación masiva a referencias
- Notificación de resultados

**Propiedades de Entrada:**
```typescript
referencias: ReferenciaValidacionDto[]  // Referencias a actualizar
empresa: string                         // Código de empresa
```

**Datos Internos:**
```typescript
fechaSeleccionada: Date
listaCanales: Marketplace[]
canalesSeleccionados: string[]
procesando: boolean
onClose: Subject<any>  // Observable para notificar éxito
```

---

## 7. Validaciones Implementadas

### 7.1 Validación de Referencia Completa

Una referencia se considera **completa** cuando cumple:

```mermaid
graph TD
    A[Referencia] --> B{Tiene Descripción?}
    B -->|No| Z[❌ Incompleta]
    B -->|Sí| C{Tiene Imagen?}
    C -->|No| Z
    C -->|Sí| D{Tiene Nombre?}
    D -->|No| Z
    D -->|Sí| E{Tiene Precio > 0?}
    E -->|No| Z
    E -->|Sí| F{Tiene Categoría?}
    F -->|No| Z
    F -->|Sí| G{Tiene Color?}
    G -->|No| Z
    G -->|Sí| H{Tiene Talla?}
    H -->|No| Z
    H -->|Sí| Y[✔️ Completa]
    
    style Y fill:#4CAF50,color:#fff
    style Z fill:#F44336,color:#fff
```

### 7.2 Atributos Validados

| Atributo | Fuente | Validación |
|----------|--------|------------|
| Descripción | `elk_referencia_mae.descripcion` | No null, no vacío |
| Imagen | `elk_referencia_mae.url_imagen` | No null, no vacío |
| Nombre | `elk_referencia_mae.nom_referencia` | No null, no vacío |
| Precio | `elk_referencia_mae.valor_publico` | No null, > 0 |
| Categoría | `elk_referencia_mae.nom_categoria` | No null, no vacío |
| Color | `elk_equivalencia` (tipo 4) | Existe equivalencia |
| Talla | `elk_equivalencia` (tipo 1) | Existe equivalencia |
| Composición | `elk_equivalencia` (tipo 5) | Opcional |
| SIC | `elk_referencia_mae.atributo_sic` | Boolean |
| Actualizado | `elk_referencia_mae.actualizado` | Boolean |

---

## 8. Diseño de Interfaz

### 8.1 Layout de Búsqueda

```
┌─────────────────────────────────────────────────────────────┐
│ [Empresa ▼] [Año: 2024] [Colección] [Referencia: 11659150] │
│ [🔍 Consultar]                 [📅 Asignar fecha lanzamiento]│
└─────────────────────────────────────────────────────────────┘

Resultados (3)

┌──────────────────────────────────────────────────────────────┐
│ ☑️  [IMG]  11659150                                    ✔️     │
│          Camiseta Básica Algodón                            │
└──────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────┐
│ ☐  [IMG]  11659151                                    ❌     │
│          Pantalón Denim Stretch                             │
└──────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────┐
│ ☐  [IMG]  11659152                                    ✔️     │
│          Chaqueta Impermeable                               │
└──────────────────────────────────────────────────────────────┘
```

### 8.2 Modal de Atributos

```
┌────────────────────────────────────────────────┐
│ Atributos para la referencia 11659150    [✕] │
├────────────────────────────────────────────────┤
│ Atributos de la Referencia                     │
│                                                 │
│ ✓ Descripción    Camiseta de algodón 100%     │
│ ✓ Imagen         https://cdn.../img.jpg       │
│ ✓ Nombre         Camiseta Básica              │
│ ✓ Precio         89900                        │
│ ✓ Categoría      Camisetas                    │
│ ✗ Color          -                            │
│ ✗ Talla          -                            │
│ ✓ Composición    Algodón                      │
│ ✓ SIC            true                         │
│ ✓ Actualizado    true                         │
│                                                 │
│ Estado por Canal                                │
│                                                 │
│ [IC - Internet Colombia] ⚠️ 2                   │
│ [VN - Ventas Nacionales] ✓                     │
│ [IG - Instagram Shopping] ⚠️ 2                  │
│                                                 │
├────────────────────────────────────────────────┤
│                              [Cerrar]          │
└────────────────────────────────────────────────┘
```

### 8.3 Modal de Fecha de Lanzamiento

```
┌────────────────────────────────────────────────┐
│ 📅 Asignar Fecha de Lanzamiento          [✕] │
├────────────────────────────────────────────────┤
│ ℹ️ Se asignará la fecha a 2 referencias       │
│                                                 │
│ Seleccione la Fecha de Lanzamiento             │
│                                                 │
│        ┌───────────────────┐                   │
│        │  Diciembre 2024   │                   │
│        │  15              │                    │
│        └───────────────────┘                   │
│                                                 │
│ Seleccione los Canales                         │
│                                                 │
│ ☑️ Internet Colombia (IC)                      │
│ ☑️ Ventas Nacionales (VN)                      │
│ ☐ Instagram Shopping (IG)                     │
│ ☐ WhatsApp Business (WA)                      │
│                                                 │
├────────────────────────────────────────────────┤
│                   [Cancelar]  [✓ Asignar]     │
└────────────────────────────────────────────────┘
```

---

## 9. Manejo de Errores

### 9.1 Estrategia de Manejo de Errores

```mermaid
graph TD
    A[Solicitud Usuario] --> B{Validación Frontend}
    B -->|Error| C[Mostrar Alerta UI]
    B -->|OK| D[Llamada API]
    D --> E{Respuesta Backend}
    E -->|200 OK| F[Procesar Datos]
    E -->|400 Bad Request| G[BusinessException]
    E -->|404 Not Found| H[Recurso No Encontrado]
    E -->|500 Server Error| I[TechnicalException]
    
    G --> J[Mostrar Mensaje Negocio]
    H --> K[Mostrar Mensaje No Encontrado]
    I --> L[Mostrar Mensaje Técnico]
    
    F --> M[Actualizar UI]
    J --> M
    K --> M
    L --> M
    
    style C fill:#FFC107
    style G fill:#FF9800
    style H fill:#FF5722
    style I fill:#F44336
    style M fill:#4CAF50,color:#fff
```

### 9.2 Mensajes de Error Implementados

**Frontend:**
- "Debe seleccionar una empresa"
- "Debe ingresar una referencia para buscar"
- "No se encontraron referencias con ese código"
- "Debe seleccionar al menos una referencia"
- "Debe seleccionar una fecha"
- "Debe seleccionar al menos un canal"

**Backend:**
- "Referencia no encontrada" (404)
- "La fecha de lanzamiento es requerida" (400)
- "Debe seleccionar al menos un canal" (400)

---

## 10. Consideraciones de Seguridad

### 10.1 Autenticación y Autorización

```mermaid
graph LR
    A[Usuario] -->|Login| B[JWT Token]
    B --> C[localStorage]
    C --> D[RequestInterceptor]
    D -->|Headers| E[Backend API]
    
    D -.->|Authorization| F[JWT Token]
    D -.->|siconline-user| G[Username]
    
    E --> H{Validar Token}
    H -->|Válido| I[Procesar Request]
    H -->|Inválido| J[401 Unauthorized]
    
    J --> K[Redirect a Login]
    
    style B fill:#4CAF50,color:#fff
    style J fill:#F44336,color:#fff
```

### 10.2 Headers de Seguridad

Todos los requests incluyen:
- `Authorization`: JWT token del usuario autenticado
- `siconline-user`: Username del usuario (para auditoría)

### 10.3 Auditoría

Las operaciones de escritura registran:
- `usuario_creacion`: Usuario que creó el registro
- `fecha_creacion`: Timestamp de creación
- `usuario_actualizacion`: Usuario que actualizó
- `fecha_actualizacion`: Timestamp de actualización

---

## 11. Rendimiento y Optimización

### 11.1 Optimizaciones Implementadas

1. **Consultas Limitadas**: Máximo 50 resultados por búsqueda
2. **Índices de Base de Datos**: Sobre campos de búsqueda frecuente
3. **Lazy Loading**: Detalles de atributos solo al abrir modal
4. **Batch Processing**: Asignación paralela de fechas con Promise.all()

### 11.2 Tiempos Esperados

| Operación | Tiempo Esperado |
|-----------|-----------------|
| Búsqueda de referencias | < 2 segundos |
| Carga de atributos | < 1 segundo |
| Asignación de fecha (1 ref) | < 500ms |
| Asignación masiva (10 refs) | < 3 segundos |

---

## 12. Pruebas

### 12.1 Casos de Prueba Funcionales

```mermaid
graph TD
    A[Suite de Pruebas] --> B[Búsqueda]
    A --> C[Atributos]
    A --> D[Asignación Fecha]
    
    B --> B1[Búsqueda exitosa]
    B --> B2[Sin resultados]
    B --> B3[Validación campos]
    
    C --> C1[Abrir modal atributos]
    C --> C2[Mostrar faltantes]
    C --> C3[Tooltips canales]
    
    D --> D1[Asignación exitosa]
    D --> D2[Validación fecha]
    D --> D3[Validación canales]
    D --> D4[Asignación múltiple]
    
    style A fill:#2196F3,color:#fff
    style B fill:#4CAF50,color:#fff
    style C fill:#FF9800,color:#fff
    style D fill:#9C27B0,color:#fff
```

### 12.2 Matriz de Pruebas

| ID | Caso de Prueba | Entrada | Resultado Esperado |
|----|----------------|---------|-------------------|
| TC-01 | Búsqueda con referencia existente | Empresa: IC, Ref: 11659150 | Lista con 1+ referencias |
| TC-02 | Búsqueda sin resultados | Empresa: IC, Ref: 99999999 | Mensaje "No se encontraron" |
| TC-03 | Validación empresa vacía | Sin seleccionar empresa | Error "Debe seleccionar empresa" |
| TC-04 | Abrir detalle atributos | Click en validador ✔️/❌ | Modal con atributos y canales |
| TC-05 | Canal con faltantes | Referencia incompleta | Canal en rojo con badge contador |
| TC-06 | Tooltip atributos faltantes | Hover sobre canal rojo | Lista de atributos faltantes |
| TC-07 | Asignar fecha válida | Fecha + 2 canales + 1 ref | Toast éxito + fecha asignada |
| TC-08 | Asignar sin fecha | Solo canales seleccionados | Error "Debe seleccionar fecha" |
| TC-09 | Asignar sin canales | Solo fecha seleccionada | Error "Seleccione al menos un canal" |
| TC-10 | Asignación múltiple | 3 referencias + fecha + canales | 3 referencias actualizadas |

---

## 13. Despliegue

### 13.1 Compilación Backend

```bash
# siconline-util
cd c:\resources\xpert\gco\2025\siconline-util
mvn clean install

# siconline-vtex-services
cd c:\resources\xpert\gco\2025\siconline-vtex-services
mvn clean package

# Ejecutar aplicación
java -jar -Xms256m -Xmx512m \
  -Dsecurityfile=security.properties \
  target/siconline-vtex-services-3.1.0.jar
```

### 13.2 Compilación Frontend

```bash
# Desarrollo
cd c:\resources\xpert\gco\2025\elink-ng
ng serve

# Producción
ng build --prod

# Salida en dist/
```

### 13.3 Variables de Entorno

**Backend (application.properties):**
```properties
DB_HOST=localhost
DB_PORT=5432
DB_SCHEMA=elink_db
DB_USER=postgres
DB_PASS=password
```

**Frontend (environment.ts):**
```typescript
URL_PRODUCTOS: 'http://localhost:8080/commerce/referencia'
```

---

## 14. Mantenimiento y Soporte

### 14.1 Logs y Monitoreo

**Ubicación de Logs:**
- Backend: `/var/log/elink/elink-vtex.log`
- Formato: Log4j2 con AsyncLogger

**Niveles de Log:**
```java
LOG.info("Buscando referencia: " + referencia);
LOG.debug("Referencias encontradas: " + resultado.size());
LOG.error("Error al cargar atributos", error);
```

### 14.2 Problemas Comunes

| Problema | Causa | Solución |
|----------|-------|----------|
| 401 Unauthorized | Token expirado | Relogin en sistema |
| No se cargan canales | Error en MarketplaceService | Verificar conexión DB |
| Imagen no carga | URL inválida | Verificar url_imagen en BD |
| Fecha no se asigna | Validación fallida | Verificar logs backend |

---

## 15. Extensiones Futuras

### 15.1 Mejoras Propuestas

1. **Exportación a Excel**: Exportar resultados de búsqueda
2. **Filtros Avanzados**: Por categoría, precio, estado
3. **Validación Asíncrona**: Queue para validaciones pesadas
4. **Notificaciones**: Email cuando referencias estén completas
5. **Bulk Upload**: Carga masiva de fechas por CSV
6. **Historial**: Ver cambios de fecha de lanzamiento
7. **Dashboard**: Métricas de completitud por marca/canal

### 15.2 Roadmap

```mermaid
gantt
    title Roadmap de Mejoras
    dateFormat YYYY-MM-DD
    section Fase 1
    Exportación Excel       :2025-01-01, 15d
    Filtros Avanzados      :2025-01-10, 20d
    section Fase 2
    Validación Asíncrona   :2025-02-01, 30d
    Notificaciones Email   :2025-02-15, 20d
    section Fase 3
    Bulk Upload CSV        :2025-03-01, 25d
    Historial Cambios      :2025-03-15, 20d
    section Fase 4
    Dashboard Métricas     :2025-04-01, 30d
```

---

## 16. Conclusiones

El módulo **Validador Multicanal** proporciona una solución eficiente para:

✅ **Validación rápida** de completitud de referencias  
✅ **Visualización clara** del estado de atributos  
✅ **Asignación masiva** de fechas de lanzamiento  
✅ **Interfaz intuitiva** para usuarios de negocio  
✅ **Arquitectura escalable** para futuras extensiones  

La implementación sigue las mejores prácticas de:
- Arquitectura en capas (presentación, negocio, datos)
- Separación de responsabilidades (SoC)
- Principios SOLID
- Patrones de diseño (Service Layer, DTO, Repository)
- Convenciones del proyecto existente

---

## 17. Referencias

### 17.1 Documentación de Proyecto
- `.github/copilot-instructions.md` - Guías de desarrollo
- `implementacion-buscar-referencia.prompt.md` - User Story original

### 17.2 Tecnologías Utilizadas
- **Backend**: Java 8, Spring Boot 2.7.4, PostgreSQL 9.4+
- **Frontend**: Angular 7.2.0, TypeScript 3.2.2, Bootstrap 4.5.3
- **Librerías**: ngx-bootstrap, ngx-spinner, ag-grid, RxJS

### 17.3 Contacto y Soporte
- **Equipo**: Elink Development Team
- **Versión**: 2.0.2
- **Fecha**: Noviembre 2025

---

**Fin del Documento**
