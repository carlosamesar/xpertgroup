---
agent: agent
---

# Feature: 
Visualización del detalle de validación de atributos y canales

**Como** usuario del sistema
**Quiero** ver el detalle de validación al hacer clic en el icono de estado
  Para conocer qué atributos están correctos y qué canales tienen información faltante

# Components:
  - Componente base [/validador-multicanal]
  - Modal de validación de atributos y canales

# Background:
    Given que el usuario está visualizando una referencia en el listado
    And el icono validador (✔️ o ❌) está visible

## Scenario: Visualizar el listado de atributos en el modal de validación
    When el usuario hace clic en el icono validador
    Then el sistema debe abrir un modal de detalle
    And el modal debe contener la siguiente lista de atributos de la referencia:
      | Atributo          |
      | Descripción       |
      | Imagen            |
      | Talla             |
      | Color             |
      | Categoria         |
      | SIC               |
      | Precio            |
      | Nombre comercial  |
      | Actualizado?      |
    And cada atributo listado debe mostrar su propio icono validador asociado

## Scenario: Visualizar alertas en canales con información faltante
    Given que la marca tiene canales configurados
    And al menos un canal tiene información incompleta
    When el usuario hace clic en el icono validador
    Then en la parte inferior del modal se debe mostrar el listado de canales
    And los canales con información faltante se deben visualizar con un badge rojo o color rojo
    And los canales con información completa se deben visualizar con el estilo estándar