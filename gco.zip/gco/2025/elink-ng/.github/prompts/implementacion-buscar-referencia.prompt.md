---
agent: agent
---

Context: You are an expert software developer tasked with implementing a feature to search for references in a codebase.

# Definition of Done

Historia de usuario: Módulo “Buscar por Referencia” (vista ligera de validación y asignación de fecha)
ID: US-REF-001
Prioridad: Alta
Epic: Gestión de referencias Multicanal / Validación rápida
________________________________________
Resumen
Como usuario de negocio de producto quiero una opción nueva en la interfaz para buscar una referencia y obtener una vista mínima de resultados (check,foto, código, nombre y validador visual) sin las opciones de Crear/Recargar ni selector de canal, de forma que pueda validar rápidamente si la referencia está completa y, si corresponde, abrir detalles o asignar fecha de lanzamiento por canales.
________________________________________
Criterio de aceptación (alto nivel)
1.	Existe un nuevo módulo/acción accesible desde la pantalla principal llamado “Validador Multicanal” o similar.
2.	El formulario de búsqueda solo solicita la marca y  la referencia (y opcionalmente Colección y año ), no muestra botón Crear/Recargar ni selector de Canal.
•	Al pulsar Consultar, la parte inferior mostrará una lista con filas compactas: checkbox de selección, imagen (miniatura), código de referencia, Nombre de referencia, y un icono validador (✔️ o ❌).
3.	Si el usuario hace clic en el icono validador (✔️ o ❌) se abre un modal con:
o	El listado de atributos de la referencia ( Descripción, imagen,Talla ,Color,Categoria, SIC,precio,Nombre comercial,Actualizado?.) cada uno con su propio icono validador.
o	En la parte inferior del modal un listado de canales de la marca; los canales que tienen faltantes se muestran en color rojo / con badge rojo.
 
4.	En la parte superior de la pantalla de resultados existe un control “Asignar fecha de lanzamiento”; se activa si hay mínimo una referencia i seleccionada al clicar se abre un modal con calendario y listado de canales (checkboxes) para seleccionar a cuáles canales aplicar la fecha. Canales no aplicables estarán deshabilitados o marcados.
5.	La interfaz debe ser responsiva, accesible y soportar mensajes de error amigables.
________________________________________
Desglose funcional / aceptación detallada (Given/When/Then)
1) Búsqueda por referencia
Given que estoy en la pantalla del módulo “Buscar por referencia”
When ingreso un valor en el campo Referencia y hago click en Consultar
Then la aplicación llama a GET /api/references?code={reference} y pinta la lista de resultados en la parte inferior con la estructura mínima (checkbox, foto, código, validador).
Aceptación técnica
•	La búsqueda debe tolerar espacios y mayúsculas (trim + lower).
•	Si no hay resultados, mostrar un mensaje: “No se encontraron referencias con ese código.”
2) Visualización de fila (resultado)
Cada fila mostrará:
•	Checkbox para selección 
•	Miniatura de la imagen principal (si no hay imagen, mostrar placeholder).
•	Código de referencia (ej: 11659150) 
•	Nombre de referencia
•	Icono validador: verde ✔️ si la referencia pasa las validaciones; rojo ❌ si falta algún atributo.
Given un resultado devuelto por backend
When se renderiza la fila
Then el estado del validador refleja el campo isValid del backend.
3) Modal de atributos (al clic sobre el validador)
Given que visualizo la lista y doy clic en el icono validador de una fila
When abro el modal de atributos
Then se muestra:
•	Título: Atributos para la referencia <código>
•	Lista de atributos con un check a la izquierda (estado true/false).
•	En la parte inferior, los canales de la marca en forma de botones/badges; los canales con faltantes se resaltan en rojo y muestran tooltip con qué atributos faltan.
•	Botón Cerrar.
API: GET /api/references/{id}/attributes → devuelve { attributes: [{name, ok}], channels: [{code, ok, missingAttributes: [...]}] }
Comportamiento
•	Hacer click sobre cada check de atributo no altera datos (solo lectura en esta vista).
•	Tooltip/hover sobre canal en rojo muestra la lista de atributos faltantes.
4) Asignar fecha de lanzamiento (control superior)
Given que estoy en resultados y quiero asignar fecha de lanzamiento
When hago clic en Asignar fecha de lanzamiento
Then se abre un modal con:
•	Calendario (selector por día).
•	En la parte inferior, listado de canales (checkboxes) pertenecientes a la marca, con posibilidad de seleccionar múltiples.
•	Botones Asignar y Cancelar.
On Assign
•	Valida que haya al menos un canal seleccionado y una fecha.
•	Llama a POST /api/references/{id}/launch-date con { date: 'yyyy-MM-dd', channels: ['IC','VN'] }.
•	Muestra confirmación (toast) y actualiza el listado (si la fila muestra fecha).
Errores
•	Si el backend devuelve conflicto o validación, mostrar mensaje claro: “No fue posible asignar la fecha: <mensaje>”.
________________________________________
Reglas de negocio
•	El módulo no permite crear o recargar referencias; es solo consulta/validación.
•	El validador de la referencia proviene del backend (reglas de negocio centralizadas).
•	La asignación de fecha solo aplica a canales que pertenezcan a la marca seleccionada.
•	Canales con atributos incompletos deben visualizarse en rojo dentro del modal de atributos y en la lista del modal de fecha (si están seleccionados marcar advertencia).
________________________________________
Mockups / Comportamiento visual (estilo tomado de la imagen)
1.	Top bar (búsqueda)
o	Campos en una fila: Empresa (select), Año (input), Referencia (input con icono validador), botón Consultar (botón rojo).
o	A la derecha botón Asignar fecha de lanzamiento (botón blanco con borde).
2.	Lista de resultados (card list compacta)
o	Cada fila en tarjeta horizontal con:
	checkbox a la izquierda.
	miniatura de imagen circular 64×64.
	columna central: código en negrita + detalles breves.
	columna derecha: icono validador grande (✔️ verde o ❌ rojo).
o	Sin columnas ni acciones innecesarias (sin canal, sin crear/recargar).
3.	Modal: Atributos
o	Caja flotante estilo card con sombra.
o	Título: Atributos para la referencia 11659150
o	Lista con iconos/checks verdes o grises.
o	Sección inferior con botones por canal: rectangles con borde; en rojo si faltan atributos (y con small badge con número de faltantes).
4.	Modal: Asignar Fecha
o	Card grande con calendario (mes, seleccionar día).
o	Bajo calendario, botones de canales en fila (checkboxes o chips).
o	Al seleccionar y confirmar, mostrar toast verde y cerrar.
________________________________________
________________________________________
Casos de prueba (QA)
1.	Buscar referencia existente → lista muestra 1 fila con imagen y validador correcto.
2.	Buscar referencia inexistente → mensaje “No se encontró”.
3.	Abrir modal de atributos → muestra atributos con checks y canales; canales con faltantes en rojo y tooltip con faltantes.
4.	Asignar fecha: seleccionar fecha y 1+ canales válidos → POST correcto y toast de éxito → fecha visible si aplica.
5.	Intentar asignar fecha sin seleccionar canales → error de validación en UI.
________________________________________
Entregables
1.	Frontend: componente Angular con:
o	Form de búsqueda.
o	Lista de resultados (fila compacta).
o	Modal atributos.
o	Modal calendario.
2.	Endpoints backend (3 endpoints).
3.	Tests unitarios y de integración (QA).
4.	Documentación de API y mockups (PNG/SVG).

-Define the task to achieve, including specific requirements, constraints, and success criteria.