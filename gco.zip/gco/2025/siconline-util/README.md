# siconline-util

Utilitario/librería Java 8 (JAR) compartida por los servicios de Siconline. Centraliza DTOs comunes, utilitarios de consumo REST, generadores de reportes Excel y un modelo unificado de excepciones con soporte de mensajes localizables.

## Tabla de contenidos
- [Propósito](#propósito)
- [Arquitectura y estructura](#arquitectura-y-estructura)
- [Requisitos](#requisitos)
- [Compilación y pruebas](#compilación-y-pruebas)
- [Uso en proyectos consumidores](#uso-en-proyectos-consumidores)
- [Publicación](#publicación)
- [Convenciones y lineamientos](#convenciones-y-lineamientos)
- [Módulos clave y ejemplos](#módulos-clave-y-ejemplos)
  - [Cliente REST (`client/`)](#cliente-rest-client)
  - [Generadores Excel (`builder/`)](#generadores-excel-builder)
  - [Excepciones (`exception/`)](#excepciones-exception)
  - [Mensajes (`src/main/resources/mensajes.properties`)](#mensajes-srcmainresourcesmensajesproperties)
- [Depuración con NetBeans](#depuración-con-netbeans)
- [Soporte y contribución](#soporte-y-contribución)

## Propósito
Librería ligera y estable para:
- Compartir objetos de transferencia de datos (DTOs) entre servicios.
- Estandarizar llamadas REST (inyección de header de autenticación y manejo de errores remotos).
- Construir reportes Excel con estilos comunes.
- Unificar el manejo de errores de negocio vs técnicos y la localización de mensajes.

## Arquitectura y estructura
Empaquetado como JAR único, sin clase `main`. Estructura relevante:

```
src/main/java/com/gco/siconline/
  builder/   -> ExcelBuilder, ExcelBuilderV2 (Apache POI)
  client/    -> RestClient, HeaderRequestInterceptor, InterceptorErrorResponse
  dto/       -> DTOs planos compartidos (sufijos DTO/Dto)
  exception/ -> ApplicationException, BusinessException, TechnicalException
  ...
src/main/resources/
  mensajes.properties -> catálogo de códigos/mensajes (ES)
  security.properties -> propiedades de seguridad (consumidas por apps)
```

Decisiones clave:
- Compatibilidad Java 8; evitar nuevas características del lenguaje.
- Mezcla intencional de versiones Spring: `spring-web 4.2.5.RELEASE` y `spring-data-commons 1.11.4.RELEASE` con parent Spring Boot 2.7.4. No actualizar salvo solicitud explícita.
- Dependencias en `provided` no deben requerir inicialización en tiempo de ejecución dentro de esta librería.

## Requisitos
- Java 1.8
- Maven 3.6+

## Compilación y pruebas
- Compilar/instalar:

```powershell
mvn clean install
```

- Pruebas: JUnit 4, Mockito 1.9.5, Hamcrest. Usar anotaciones JUnit 4 (`@Test`).

Artefacto resultante: `target/siconline-util-<version>.jar`.

## Uso en proyectos consumidores
Agregar la dependencia en el `pom.xml` del servicio consumidor. Coordenadas actuales:

```xml
<dependency>
  <groupId>com.gco.siconline</groupId>
  <artifactId>siconline-util</artifactId>
  <version>1.1.19</version>
</dependency>
```

Si se consume desde el repositorio local, ejecutar previamente `mvn clean install` en este proyecto.

## Publicación
Configuración de publicación a Artifactory en `<distributionManagement>` del `pom.xml`. No modificar IDs/URLs sin solicitud expresa. Las credenciales se gestionan fuera del repositorio.

## Convenciones y lineamientos
- Mantener compatibilidad hacia atrás: campos nuevos en DTOs deben ser opcionales (valores `null` por defecto).
- No eliminar códigos existentes de `mensajes.properties` ni cambiar su semántica (hay duplicado intencional en 506).
- No cambiar firmas públicas en `RestClient` ni builders; agregar sobrecargas si es necesario.
- Evitar introducir frameworks/capa de negocio: esta librería debe permanecer ligera.

## Módulos clave y ejemplos

### Cliente REST (`client/`)
Clases:
- `RestClient`: envolturas para `POST`, `PUT` y método genérico `ejecutar(...)` con `RestTemplate`.
- `HeaderRequestInterceptor`: inyecta header `gsec-user-token` cuando el token no es vacío.
- `InterceptorErrorResponse`: traduce respuestas de error JSON remotas a excepciones locales.

Ejemplo `POST` con token y parámetros de ruta:

```java
RestClient client = new RestClient();
ResponseEntity<MiRespuesta> resp = client.post(
    "https://host/api/recurso/{id}",
    token,                      // se envía como header gsec-user-token
    requestBody,                // objeto request
    MiRespuesta.class,
    123                         // params de la ruta
);
MiRespuesta body = resp.getBody();
```

Ejemplo `PUT` sin parámetros de ruta:

```java
RestClient client = new RestClient();
client.put("https://host/api/recurso", token, requestBody);
```

Contrato de errores remotos esperado (JSON):

```json
{
  "exception": "com.gco.siconline.exception.BusinessException",
  "code": "400",
  "message": "Alguno de los campos obligatorios se encuentra vacío"
}
```

Si `exception` corresponde a `BusinessException`, se lanza `BusinessException(code, message)`; en caso contrario, `TechnicalException(message)`.

### Generadores Excel (`builder/`)
Estándares comunes:
- Encabezado: fondo negro, fuente blanca en negrita; `autoSizeColumn` al final.
- Reglas: omitir filas si algún valor es `"TOTAL"`; intentar conversión numérica salvo prefijos "111" (PLU) para preservar formato.

`ExcelBuilder` (mapea POJOs a columnas removiendo `null`):

```java
Map<String, Object> model = new HashMap<>();
model.put("columnas", new String[]{"Col1", "Col2", "Col3"});
model.put("datos", Arrays.asList(miPojo1, miPojo2));
return new ModelAndView(new ExcelBuilder(), model);
```

`ExcelBuilderV2` (espera arreglos ya ordenados por fila):

```java
Map<String, Object> model = new HashMap<>();
model.put("columnas", "Col1;Col2;Col3");
model.put("datos", Arrays.asList(new Object[]{"1110001", 10, "OK"}));
return new ModelAndView(new ExcelBuilderV2(), model);
```

### Excepciones (`exception/`)
Modelo base:
- `ApplicationException` almacena `code` (String) y mensaje.
- `BusinessException` para errores de negocio (mostrables/al usuario).
- `TechnicalException` para fallos técnicos/sistema.

Ejemplos:

```java
throw new BusinessException("400", "Alguno de los campos obligatorios se encuentra vacío");
throw new TechnicalException("Error al consultar el servicio externo");
```

### Mensajes (`src/main/resources/mensajes.properties`)
Catálogo de mensajes en español (códigos 400–511) con placeholders (`%s` o `:param`).
- Agregar nuevos códigos de forma secuencial y sin duplicados (salvo el 506 que ya está repetido y debe conservarse a menos que se solicite limpieza).
- Inyectar el `code` en las `BusinessException` para permitir localización en capas superiores.

## Depuración con NetBeans
Archivo `nbactions.xml` define acciones `run/debug/profile` usando `exec-maven-plugin` y el argumento `-Dsecurityfile=...`.
- Este proyecto no tiene clase `main`; las acciones están pensadas para apps consumidoras que cargan esta librería en su classpath.
- Ajustar la ruta de `securityfile` según el entorno.

## Soporte y contribución
- Abrir PRs manteniendo Java 8, sin introducir dependencias pesadas.
- Antes de cambiar versiones de dependencias o contratos de error, coordinar con los equipos consumidores.
- Verificar que los reportes Excel mantengan el estilo y la lógica de PLU.

> Nota: Este repositorio es de uso interno de GCO/Siconline. La distribución y las credenciales de Artifactory son gestionadas por el equipo de Infraestructura.
