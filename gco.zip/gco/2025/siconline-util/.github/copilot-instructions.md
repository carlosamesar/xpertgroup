# AI Coding Agent Instructions for `siconline-util`

## 1. Purpose & Scope
`siconline-util` is a Java 8 utility/library module (packaged as a JAR) consumed by larger Siconline services. It centralizes:
- Data transfer objects (`dto/`) shared across service boundaries.
- Standard REST invocation helpers (`client/`), adding an auth header token.
- Excel report builders (`builder/`) for tabular exports using Apache POI.
- Unified exception model (`exception/`) with business vs technical classification.
- Localized message codes (`mensajes.properties`) mapped to numeric identifiers.

Avoid introducing application-specific frameworks here; keep it lightweight and dependency-stable for downstream apps.

## 2. Build & Run Workflow
- Build: `mvn clean install` (Java 1.8; Spring Boot parent 2.7.4). No module reactor—single artifact.
- Tests: JUnit 4 + Mockito 1.9.5 + Hamcrest. Stick to JUnit 4 annotations (`@Test`).
- NetBeans run/debug actions (see `nbactions.xml`) invoke `exec-maven-plugin` with a custom `-Dsecurityfile=...` argument. This project itself has no main class; runtime is in consuming apps.
- Artifactory publishing configured via `<distributionManagement>`—do not alter IDs/URLs unless explicitly requested.

## 3. Dependency & Version Conventions
- Mixed Spring versions: provided-scope `spring-web 4.2.5.RELEASE`, `spring-data-commons 1.11.4.RELEASE` alongside Boot parent 2.7.4. This is intentional for backward compatibility in consumers; DO NOT "upgrade" casually.
- Libraries marked `<scope>provided</scope>` must not be referenced in code requiring library-side runtime initialization.
- Preserve Java 8 compatibility (avoid streams requiring newer language features, records, etc.).

## 4. Exception & Error Handling Pattern
- Base: `ApplicationException` stores a `code` (String) + message.
- `BusinessException` signals domain/user-correctable issues; `TechnicalException` for system faults.
- Remote error decoding: `InterceptorErrorResponse` expects JSON with fields: `exception` (FQCN), `code`, `message`. If `exception` == `BusinessException` then map accordingly; else throw `TechnicalException`.
- When adding new Business exceptions, ensure a numeric/string code aligns with `mensajes.properties` for localization.

## 5. REST Client Usage
- Use `RestClient.post/put/ejecutar` wrappers. They inject `gsec-user-token` header when `token` is non-empty.
- For new HTTP verbs, follow existing pattern: construct `HttpEntity`, delegate to `RestTemplate.exchange`. Keep optional path params via varargs.
- Do not embed retry or circuit logic here—belongs in higher-level services.

## 6. Excel Export Convention
- Builders (`ExcelBuilder`, `ExcelBuilderV2`) expect model Map containing:
  - `columnas`: either `String[]` or `"col1;col2;..."`.
  - `datos`: `List<Object>`; V2 expects elements already as `Object[]`; V1 maps POJOs via Jackson and removes nulls.
- Header style: black background, white bold font; auto-size columns after population.
- Special rules: skip rows containing cell value `"TOTAL"`; attempt numeric conversion unless prefix "111" (PLU code preservation).
- When extending, keep behavior consistent (avoid large refactors in style or cell logic).

## 7. DTO & Naming Conventions
- DTOs are flat Java beans suffixed with `DTO` or `Dto`, representing external service payloads and inventory processes (e.g., `ConsultaPedidoCedulaDTO`).
- Maintain existing naming; avoid adding business logic or persistence annotations here.

## 8. Messages & Localization
- `mensajes.properties` maps numeric codes (400–511) to Spanish messages with placeholders (`%s` or `:param`). Align new codes sequentially; avoid duplicates (note: code 506 duplicate present—preserve unless cleanup is requested explicitly).
- Inject codes into `BusinessException(code, message)` so consuming UI layers can localize.

## 9. Safe Change Guidelines
- Preserve backward compatibility: adding new DTO fields should be optional (use null defaults).
- Do not remove existing message codes or change their semantics.
- Keep public method signatures in `RestClient` and builders stable; add overloads instead of modifying existing ones.

## 10. Extension Examples
- Add GET helper:
  ```java
  public <T> ResponseEntity<T> get(String url, String token, Class<T> responseType, Object... params) {
      return ejecutar(url, token, HttpMethod.GET, null, responseType, params);
  }
  ```
- Add new Business code: append `512=Nuevo mensaje descriptivo` to properties; throw `new BusinessException("512", "Nuevo mensaje descriptivo")`.

## 11. Review Checklist for AI Changes
- Java 8 syntax only? (No var, records, modules.)
- Dependencies unchanged unless explicitly asked?
- Exceptions follow code/message usage?
- Excel builders maintain header styling and PLU numeric logic?
- New DTO fields are nullable and don’t introduce persistence logic.

Provide diffs only—avoid wholesale rewrites. Ask for clarification if a change would alter dependency versions or error contract.
