package com.gco.siconline.dto;

import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

public class ConsultaSolicitudDevolucionDTO {
	@JsonPropertyOrder({ "tipoDevolución", "fechaDevolución", "fechaPedido", "pedidoDevolver", "marca ",
			"nombreDevolucion", "cedulaPedido", "cedulaClienteBan", "banco", "tipocuenta", "numeroCuenta",
			"valDevolucion", "valDna",  "valCero","asesor", "motiDevolución", "observacion", "fechaCreacion ", "numCaso",
			"generaVale", "valorVale", "codVale", "pedidoManual", "valPedido", "formaPagoDv", "notaCredito",
			"fechaRecepción", "estado","nomEstado", "fechaAprobacion", "envioPropagos", "propagos", "estadoPropagos","nomEstadoPropagos"})
	
	 @JsonProperty("tipoDevolución")
	private String tipoDevolución;
	
	 @JsonProperty("fechaDevolución")
	private String fechaDevolución;
	 
	 @JsonProperty("fechaPedido")
	private String fechaPedido;
	 
	@JsonProperty("pedidoDevolver")
	private String pedidoDevolver;
	
	@JsonProperty("marca ")
	private String marca;
	
	@JsonProperty("nombreDevolucion")
	private String nombreDevolucion;
	
	@JsonProperty("cedulaPedido")
	private String cedulaPedido;
	
	@JsonProperty("cedulaClienteBan")
	private String cedulaClienteBan;
	
	@JsonProperty("banco")
	private Integer banco;
	
	@JsonProperty("tipocuenta")
	private Integer tipocuenta;
	

	@JsonProperty("numeroCuenta")
	private String numeroCuenta;
	
	@JsonProperty("valDevolucion")
	private BigDecimal valDevolucion;
	
	@JsonProperty("valDna")
	private BigDecimal valDna;
	
	@JsonProperty("valCero")
	private BigDecimal valCero;
	
	@JsonProperty("asesor")
	private String asesor;
	
	@JsonProperty("motiDevolución")
	private String motiDevolución;
	
	@JsonProperty("observacion")
	private String observacion;
	
	@JsonProperty("fechaCreacion")
	private Date fechaCreacion;
	
	 @JsonProperty("numCaso")
	private String numCaso;
	
	 
	 @JsonProperty("generaVale")
	private String generaVale;
	
	 @JsonProperty("valorVale")
	private BigDecimal valorVale;
	
	 @JsonProperty("codVale")
	private String codVale;
	
	 @JsonProperty("pedidoManual")
	private String pedidoManual;
	 
	 
	 @JsonProperty("valPedido")
	private BigDecimal valPedido;
	
	 @JsonProperty("formaPagoDv")
	private String formaPagoDv;
	 
	 @JsonProperty("notaCredito")
	private String notaCredito;
	 
	 @JsonProperty("fechaRecepción")
	private String fechaRecepción;
	 
	 @JsonProperty("estado")
	private Character estado;
	 
	 @JsonProperty("nomEstado")
		private String nomEstado;
	 
	 @JsonProperty("fechaAprobacion")
	private String fechaAprobacion;
	 
	 @JsonProperty("envioPropagos")
	private String envioPropagos;
	 
	 @JsonProperty("propagos")
	private String propagos;
	 
	 @JsonProperty("estadoPropagos")
	private String estadoPropagos;
	 
	 @JsonProperty("nomEstadoPropagos")
		private String nomEstadoPropagos;

	public String getTipoDevolución() {
		return tipoDevolución;
	}

	public void setTipoDevolución(String tipoDevolución) {
		this.tipoDevolución = tipoDevolución;
	}

	public String getFechaDevolución() {
		return fechaDevolución;
	}

	public void setFechaDevolución(String fechaDevolución) {
		this.fechaDevolución = fechaDevolución;
	}

	public String getFechaPedido() {
		return fechaPedido;
	}

	public void setFechaPedido(String fechaPedido) {
		this.fechaPedido = fechaPedido;
	}

	public String getPedidoDevolver() {
		return pedidoDevolver;
	}

	public void setPedidoDevolver(String pedidoDevolver) {
		this.pedidoDevolver = pedidoDevolver;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getNombreDevolucion() {
		return nombreDevolucion;
	}

	public void setNombreDevolucion(String nombreDevolucion) {
		this.nombreDevolucion = nombreDevolucion;
	}

	public String getCedulaPedido() {
		return cedulaPedido;
	}

	public void setCedulaPedido(String cedulaPedido) {
		this.cedulaPedido = cedulaPedido;
	}

	public String getCedulaClienteBan() {
		return cedulaClienteBan;
	}

	public void setCedulaClienteBan(String cedulaClienteBan) {
		this.cedulaClienteBan = cedulaClienteBan;
	}

	public Integer getBanco() {
		return banco;
	}

	public void setBanco(Integer banco) {
		this.banco = banco;
	}

	public Integer getTipocuenta() {
		return tipocuenta;
	}

	public void setTipocuenta(Integer tipocuenta) {
		this.tipocuenta = tipocuenta;
	}

	public String getNumeroCuenta() {
		return numeroCuenta;
	}

	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}

	public BigDecimal getValDevolucion() {
		return valDevolucion;
	}

	public void setValDevolucion(BigDecimal valDevolucion) {
		this.valDevolucion = valDevolucion;
	}

	public BigDecimal getValDna() {
		return valDna;
	}

	public void setValDna(BigDecimal valDna) {
		this.valDna = valDna;
	}

	public String getAsesor() {
		return asesor;
	}

	public void setAsesor(String asesor) {
		this.asesor = asesor;
	}

	public String getMotiDevolución() {
		return motiDevolución;
	}

	public void setMotiDevolución(String motiDevolución) {
		this.motiDevolución = motiDevolución;
	}

	public String getObservacion() {
		return observacion;
	}

	public void setObservacion(String observacion) {
		this.observacion = observacion;
	}

	public Date getFechaCreacion() {
		return fechaCreacion;
	}

	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}

	public String getNumCaso() {
		return numCaso;
	}

	public void setNumCaso(String numCaso) {
		this.numCaso = numCaso;
	}

	public String getGeneraVale() {
		return generaVale;
	}

	public void setGeneraVale(String generaVale) {
		this.generaVale = generaVale;
	}

	public BigDecimal getValorVale() {
		return valorVale;
	}

	public void setValorVale(BigDecimal valorVale) {
		this.valorVale = valorVale;
	}

	public String getCodVale() {
		return codVale;
	}

	public void setCodVale(String codVale) {
		this.codVale = codVale;
	}

	public String getPedidoManual() {
		return pedidoManual;
	}

	public void setPedidoManual(String pedidoManual) {
		this.pedidoManual = pedidoManual;
	}

	public BigDecimal getValPedido() {
		return valPedido;
	}

	public void setValPedido(BigDecimal valPedido) {
		this.valPedido = valPedido;
	}

	public String getFormaPagoDv() {
		return formaPagoDv;
	}

	public void setFormaPagoDv(String formaPagoDv) {
		this.formaPagoDv = formaPagoDv;
	}

	public String getNotaCredito() {
		return notaCredito;
	}

	public void setNotaCredito(String notaCredito) {
		this.notaCredito = notaCredito;
	}

	public String getFechaRecepción() {
		return fechaRecepción;
	}

	public void setFechaRecepción(String fechaRecepción) {
		this.fechaRecepción = fechaRecepción;
	}

	public Character getEstado() {
		return estado;
	}

	public void setEstado(Character estado) {
		this.estado = estado;
	}

	public String getFechaAprobacion() {
		return fechaAprobacion;
	}

	public void setFechaAprobacion(String fechaAprobacion) {
		this.fechaAprobacion = fechaAprobacion;
	}

	public String getEnvioPropagos() {
		return envioPropagos;
	}

	public void setEnvioPropagos(String envioPropagos) {
		this.envioPropagos = envioPropagos;
	}

	public String getPropagos() {
		return propagos;
	}

	public void setPropagos(String propagos) {
		this.propagos = propagos;
	}

	public String getEstadoPropagos() {
		return estadoPropagos;
	}

	public void setEstadoPropagos(String estadoPropagos) {
		this.estadoPropagos = estadoPropagos;
	}

	public BigDecimal getValCero() {
		return valCero;
	}

	public void setValCero(BigDecimal valCero) {
		this.valCero = valCero;
	}

	public String getNomEstado() {
		return nomEstado;
	}

	public void setNomEstado(String nomEstado) {
		this.nomEstado = nomEstado;
	}

	public String getNomEstadoPropagos() {
		return nomEstadoPropagos;
	}

	public void setNomEstadoPropagos(String nomEstadoPropagos) {
		this.nomEstadoPropagos = nomEstadoPropagos;
	}
	

}
