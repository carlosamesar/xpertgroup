package com.gco.siconline.dto;

import java.util.Date;

public class MovimientoGuiasRequest {
	String canal;
	String tipServicio;
	Date fechaIni;
	Date fechaFin;
	int codEmpresa;
	String despacho;
	
	  public String getCanal() {
	        return canal;
	    }

	    public void setCanal(String canal) {
	        this.canal = canal;
	    }

	    public String gettipServicio() {
	        return tipServicio;
	    }

	    public void settipServicio(String tipServicio) {
	        this.tipServicio = tipServicio;
	    }

	    public Date getFechaIni() {
	        return fechaIni;
	    }

	    public void setFechaIni(Date fechaIni) {
	        this.fechaIni = fechaIni;
	    }

	    public Date getFechaFin() {
	        return fechaFin;
	    }

	    public void setFechaFin(Date fechaFin) {
	        this.fechaFin = fechaFin;
	    }

	    public int getCodEmpresa() {
	        return codEmpresa;
	    }

	    public void setCodEmpresa(int codEmpresa) {
	        this.codEmpresa = codEmpresa;
	    }

	    public String getDespacho() {
	        return despacho;
	    }

	    public void setDespacho(String despacho) {
	        this.despacho = despacho;
	    }
		
	
}
