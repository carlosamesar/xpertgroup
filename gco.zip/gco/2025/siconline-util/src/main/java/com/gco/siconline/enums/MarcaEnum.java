package com.gco.siconline.enums;

import java.util.Arrays;

public enum MarcaEnum {

    AMERICANINO("70", "80998"),
    CHEVI("63", "84072"),
    NAF("14", "81998"),
    ESPRIT("34", "84097"),
    RIFLE("36", "84039"),
    DEFECTO("", "00000");

    private String marca;
    private String tercero;

    private MarcaEnum(String marca, String tercero) {
        this.marca = marca;
        this.tercero = tercero;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getTercero() {
        return tercero;
    }

    public void setTercero(String tercero) {
        this.tercero = tercero;
    }

    public static String getEnum(String marca) {

        return Arrays.asList(values()).stream().filter(x -> x.getMarca().equals(marca)).findFirst().orElse(DEFECTO).getTercero();
    }

}
