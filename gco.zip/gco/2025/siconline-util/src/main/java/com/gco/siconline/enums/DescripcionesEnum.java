/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gco.siconline.enums;

/**
 *
 * @author besmart
 */
public enum DescripcionesEnum {
    
    REFERENCIA("Referencia"),
    NOMBRE_COMERCIAL("Nombre comercial"),
    FILTRO_UNO("Filtro 1"),
    DESCRIP_FILTRO_UNO("Descripción filtro 1"),
    FILTRO_DOS("Filtro 2"),
    DESCRIP_FILTRO_DOS("Descripción filtro 2"),
    DESCRIPCION("Descripción"),
    PROVEEDOR("Proveedor"),
    MARKET_PLACE("Market place")
    ;
    
    private String value;

    private DescripcionesEnum(String value) {
            this.value = value;
    }

    public String getValue() {
            return value;
    }

    public void setValue(String value) {
            this.value = value;
    }
    
}
