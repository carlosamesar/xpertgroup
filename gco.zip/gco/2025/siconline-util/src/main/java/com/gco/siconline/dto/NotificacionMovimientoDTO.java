package com.gco.siconline.dto;

import java.io.Serializable;

public class NotificacionMovimientoDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer codEmpresa;
	private String codConcepto;
	private String numMovimiento;
	
	public NotificacionMovimientoDTO() {
		// TODO Auto-generated constructor stub
	}
	
	public String getCodConcepto() {
		return codConcepto;
	}
	
	public void setCodConcepto(String codConcepto) {
		this.codConcepto = codConcepto;
	}
	
	public String getNumMovimiento() {
		return numMovimiento;
	}
	
	public void setNumMovimiento(String numMovimiento) {
		this.numMovimiento = numMovimiento;
	}

	public Integer getCodEmpresa() {
		return codEmpresa;
	}

	public void setCodEmpresa(Integer codEmpresa) {
		this.codEmpresa = codEmpresa;
	}
	
}
