/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gco.siconline.dto.vtex;

import java.util.ArrayList;
import java.util.List;

/**
 * DTO para representar el estado de un canal respecto a una referencia
 * @author besmart
 */
public class CanalReferenciaDto {
    
    private String codigo;
    private String nombre;
    private boolean ok;
    private List<String> atributosFaltantes;
    
    public CanalReferenciaDto() {
        this.atributosFaltantes = new ArrayList<>();
    }

    public CanalReferenciaDto(String codigo, String nombre, boolean ok) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.ok = ok;
        this.atributosFaltantes = new ArrayList<>();
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public boolean isOk() {
        return ok;
    }

    public void setOk(boolean ok) {
        this.ok = ok;
    }

    public List<String> getAtributosFaltantes() {
        return atributosFaltantes;
    }

    public void setAtributosFaltantes(List<String> atributosFaltantes) {
        this.atributosFaltantes = atributosFaltantes;
    }
}
