package com.gco.siconline.enums;

public enum EstadosOleadaEnum {

    ANULADO("AN"),
    DESTELLE("DE"),
    FACTURADO("FC"),
    INCOMPLETO("IN"),
    PICKING("PI"),
    PREPARADO("PR"),
    BLOQUEADO("BL"),
    DESTELLE_INCOMPLETO("DI"),
    PEDIDO_COMPLETO("PC");
    
    private String value;

    private EstadosOleadaEnum(String value) {
        this.setValue(value);
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

}
