package com.gco.siconline.dto;

public class ResponseDTO {

    private String codigo;
    private String mensaje;
    private Object movimiento;

    public ResponseDTO() {
    }

    public ResponseDTO(String codigo, String mensaje) {
        super();
        this.codigo = codigo;
        this.mensaje = mensaje;
    }
    
    public ResponseDTO(String codigo, String mensaje, Object movimiento) {
        this.codigo = codigo;
        this.mensaje = mensaje;
        this.movimiento = movimiento;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public Object getMovimiento() {
        return movimiento;
    }

    public void setMovimiento(Object movimiento) {
        this.movimiento = movimiento;
    }
    

}
