package com.gco.siconline.dto;

public class ResponseDetUbicacionPluDTO {

    private String codUbicacion;
    private String codCaja;
    private String codPlu;
    private long cantidad;

    public ResponseDetUbicacionPluDTO(String codUbicacion, String codCaja, String codPlu, long cantidad) {

        this.codUbicacion = codUbicacion;
        this.codCaja = codCaja;
        this.codPlu = codPlu;
        this.cantidad = cantidad;
    }

    public String getCodUbicacion() {
        return codUbicacion;
    }

    public void setCodUbicacion(String codUbicacion) {
        this.codUbicacion = codUbicacion;
    }

    public String getCodCaja() {
        return codCaja;
    }

    public void setCodCaja(String codCaja) {
        this.codCaja = codCaja;
    }

    public String getCodPlu() {
        return codPlu;
    }

    public void setCodPlu(String codPlu) {
        this.codPlu = codPlu;
    }

    public long getCantidad() {
        return cantidad;
    }

    public void setCantidad(Integer cantidad) {
        this.cantidad = cantidad;
    }

}
