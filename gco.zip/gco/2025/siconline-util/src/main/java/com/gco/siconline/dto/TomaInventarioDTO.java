package com.gco.siconline.dto;

public class TomaInventarioDTO {

    private Integer idToma;
    private String usuario;
    private String estado;

    public Integer getIdToma() {
        return idToma;
    }

    public void setIdToma(Integer idToma) {
        this.idToma = idToma;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

}
