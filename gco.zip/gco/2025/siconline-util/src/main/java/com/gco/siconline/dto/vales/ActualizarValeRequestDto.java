package com.gco.siconline.dto.vales;

public class ActualizarValeRequestDto {
    private Long id;
    private String nombreAlianza;
    private String campana;
    private String idVtex;

    public ActualizarValeRequestDto() {
    }

    public ActualizarValeRequestDto(Long id, String nombreAlianza, String campana, String idVtex) {
        this.id = id;
        this.nombreAlianza = nombreAlianza;
        this.campana = campana;
        this.idVtex = idVtex;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombreAlianza() {
        return nombreAlianza;
    }

    public void setNombreAlianza(String nombreAlianza) {
        this.nombreAlianza = nombreAlianza;
    }

    public String getCampana() {
        return campana;
    }

    public void setCampana(String campana) {
        this.campana = campana;
    }

    public String getIdVtex() {
        return idVtex;
    }

    public void setIdVtex(String idVtex) {
        this.idVtex = idVtex;
    }
}
