package com.gco.siconline.dto;

import java.util.List;

public class RequestTotalConceptoDTO {

	private String periodo;
	private List<String> marcasId;
	private List<String> marcasCodigo;
	
	public RequestTotalConceptoDTO() {

	}

	public String getPeriodo() {
		return periodo;
	}

	public void setPeriodo(String periodo) {
		this.periodo = periodo;
	}

	public List<String> getMarcasId() {
		return marcasId;
	}

	public void setMarcasId(List<String> marcasId) {
		this.marcasId = marcasId;
	}

	public List<String> getMarcasCodigo() {
		return marcasCodigo;
	}

	public void setMarcasCodigo(List<String> marcasCodigo) {
		this.marcasCodigo = marcasCodigo;
	}

	
	
}
