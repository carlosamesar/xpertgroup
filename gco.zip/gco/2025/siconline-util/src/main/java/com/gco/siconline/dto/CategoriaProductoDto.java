/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gco.siconline.dto;

/**
 *
 * @author besmart
 */
public class CategoriaProductoDto {
    
    private Integer idCategoriaProducto;
    private Integer idMarketPlace;
    private Integer idCategoria;
    private String productoCategoria;
    private String codigoCategoria;
    private String brand;
    private String codColor;

    public Integer getIdCategoriaProducto() {
        return idCategoriaProducto;
    }

    public void setIdCategoriaProducto(Integer idCategoriaProducto) {
        this.idCategoriaProducto = idCategoriaProducto;
    }

    public Integer getIdMarketPlace() {
        return idMarketPlace;
    }

    public void setIdMarketPlace(Integer idMarketPlace) {
        this.idMarketPlace = idMarketPlace;
    }

    public Integer getIdCategoria() {
        return idCategoria;
    }

    public void setIdCategoria(Integer idCategoria) {
        this.idCategoria = idCategoria;
    }

    public String getProductoCategoria() {
        return productoCategoria;
    }

    public void setProductoCategoria(String productoCategoria) {
        this.productoCategoria = productoCategoria;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getCodigoCategoria() {
        return codigoCategoria;
    }

    public void setCodigoCategoria(String codigoCategoria) {
        this.codigoCategoria = codigoCategoria;
    }

    public String getCodColor() {
        return codColor;
    }

    public void setCodColor(String codColor) {
        this.codColor = codColor;
    }
    
    public String getProductoCategoriaColor() {
        
        return this.productoCategoria + (this.codColor == null ? "": this.codColor);
                
    }
    
    
}
