package com.gco.siconline.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RequestInformePedIncompDTO extends RequestPedidoDTO {

    protected String numOrdencompra;

	public String getNumOrdencompra() {
		return numOrdencompra;
	}

	public void setNumOrdencompra(String numOrdencompra) {
		this.numOrdencompra = numOrdencompra;
	}
    
   

}
