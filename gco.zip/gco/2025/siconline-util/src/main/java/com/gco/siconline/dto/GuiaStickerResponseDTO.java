package com.gco.siconline.dto;

import java.io.Serializable;

public class GuiaStickerResponseDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String guia;
	private String sticker;
	
	public GuiaStickerResponseDTO() {
		// TODO Auto-generated constructor stub
	}
	
	public String getGuia() {
		return guia;
	}
	
	public void setGuia(String guia) {
		this.guia = guia;
	}
	
	public String getSticker() {
		return sticker;
	}
	
	public void setSticker(String sticker) {
		this.sticker = sticker;
	}
	
}
