package com.gco.siconline.exception;

public class BusinessException extends ApplicationException {
	
	private static final long serialVersionUID = -9042191248221387305L;

	public BusinessException(Throwable exception) {
		this(null, exception);
	}
	
	public BusinessException(String message){
		this(null,message, null);
	}
	
	public BusinessException(String message, Throwable exception){
		this(null, message, exception);
	}
	
	public BusinessException(String code, String message, Throwable exception){
		super(code, message, exception);
	}
	
	public BusinessException(String code, String message){
		this(code, message,null);
	}
	
}
