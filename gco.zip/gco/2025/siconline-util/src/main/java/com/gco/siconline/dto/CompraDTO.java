package com.gco.siconline.dto;

public class CompraDTO {

    private String fechaCompra;
    private String dalm;
    private String sio;
    private String codReferencia;
    private String plu;
    private String talla;
    private String color;
    private String descripcionPlu;
    private String canPedida;
    private String canRecibida;

    public CompraDTO() {

    }

    public CompraDTO(String fechaCompra, String dalm, String sio, String codReferencia, String plu, String talla,
            String color, String descripcionPlu, String canPedida, String canRecibida) {
        this.fechaCompra = fechaCompra;
        this.dalm = dalm;
        this.sio = sio;
        this.codReferencia = codReferencia;
        this.plu = plu;
        this.talla = talla;
        this.color = color;
        this.descripcionPlu = descripcionPlu;
        this.canPedida = canPedida;
        this.canRecibida = canRecibida;
    }

    public String getFechaCompra() {
        return fechaCompra;
    }

    public void setFechaCompra(String fechaCompra) {
        this.fechaCompra = fechaCompra;
    }

    public String getDalm() {
        return dalm;
    }

    public void setDalm(String dalm) {
        this.dalm = dalm;
    }

    public String getSio() {
        return sio;
    }

    public void setSio(String sio) {
        this.sio = sio;
    }

    public String getCodReferencia() {
        return codReferencia;
    }

    public void setCodReferencia(String codReferencia) {
        this.codReferencia = codReferencia;
    }

    public String getPlu() {
        return plu;
    }

    public void setPlu(String plu) {
        this.plu = plu;
    }

    public String getTalla() {
        return talla;
    }

    public void setTalla(String talla) {
        this.talla = talla;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getDescripcionPlu() {
        return descripcionPlu;
    }

    public void setDescripcionPlu(String descripcionPlu) {
        this.descripcionPlu = descripcionPlu;
    }

    public String getCanPedida() {
        return canPedida;
    }

    public void setCanPedida(String canPedida) {
        this.canPedida = canPedida;
    }

    public String getCanRecibida() {
        return canRecibida;
    }

    public void setCanRecibida(String canRecibida) {
        this.canRecibida = canRecibida;
    }

}
