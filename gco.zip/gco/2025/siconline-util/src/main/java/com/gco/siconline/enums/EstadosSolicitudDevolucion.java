package com.gco.siconline.enums;

public enum EstadosSolicitudDevolucion {

	ABIERTO("1"), EXITOSO("0"), PENDIENTE("P"), RECHAZADO("R"), CANCELADO("C"),ESPERANDO("E"),VALE("5"),DEVOLUCIONDINERO("6"),CAMBIOPRENDA("7"),CAMBIOPRENDAEXITOSO("14"),CANCELADOPORAGOTADO("18");

	private String value;

	private EstadosSolicitudDevolucion(String value) {
		this.setValue(value);
	}

	public String value() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public static EstadosSolicitudDevolucion fromValue(String value) {
		for (EstadosSolicitudDevolucion es : EstadosSolicitudDevolucion.values()) {
			if (es.value.equals(value)) {
				return es;
			}
		}
		return null;
	}

}
