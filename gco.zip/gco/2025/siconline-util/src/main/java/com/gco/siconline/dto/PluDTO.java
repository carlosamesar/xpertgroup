package com.gco.siconline.dto;

public class PluDTO {

    private String codPlu;
    private String codReferencia;
    private String talla;
    private String color;
    private int cantidad;

    public String getCodPlu() {
        return codPlu;
    }

    public void setCodPlu(String codPlu) {
        this.codPlu = codPlu;
    }

    public String getCodReferencia() {
        return codReferencia;
    }

    public void setCodReferencia(String codReferencia) {
        this.codReferencia = codReferencia;
    }

    public String getTalla() {
        return talla;
    }

    public void setTalla(String talla) {
        this.talla = talla;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    @Override
    public boolean equals(Object obj) {
        
        if (obj instanceof PluDTO) {
            return ((PluDTO)obj).getCodPlu().equals(this.codPlu);
        } else {
            return false;
        }
        
        
    }
    
    

}
