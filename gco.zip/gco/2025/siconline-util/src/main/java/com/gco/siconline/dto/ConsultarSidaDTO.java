package com.gco.siconline.dto;

import java.util.Date;

public class ConsultarSidaDTO {
	private String codConcepto;
	private String codTercero;
	private String nomNombrecomercia;
	private String numMovimiento;
	private int numPeriodo;
	private Date fecMovimiento;
	private Date fecDocrespalda;
	private String numDocrespalda;
	private String numExportacion;
	private String numOrdencomprasoc;
	private String codReferencia;
	private String tipTalla;
	private String codColor;
	private String indCalidad;
	private String codProveedoref;
	private String codPlu;
	private double valUnidad;
	private int numCantidad;
	private double valTotal;
	private String codUsuario;
	private String indEstado;
	private int numAno;
	private int cantRecibida;
	private String idDelivery;
	


	public String getCodConcepto() {
		return codConcepto;
	}

	public void setCodConcepto(String codConcepto) {
		this.codConcepto = codConcepto;
	}

	public String getCodTercero() {
		return codTercero;
	}

	public void setCodTercero(String codTercero) {
		this.codTercero = codTercero;
	}

	public String getNomNombrecomercia() {
		return nomNombrecomercia;
	}

	public void setNomNombrecomercia(String nomNombrecomercia) {
		this.nomNombrecomercia = nomNombrecomercia;
	}

	public String getNumMovimiento() {
		return numMovimiento;
	}

	public void setNumMovimiento(String numMovimiento) {
		this.numMovimiento = numMovimiento;
	}

	public int getNumPeriodo() {
		return numPeriodo;
	}

	public void setNumPeriodo(int numPeriodo) {
		this.numPeriodo = numPeriodo;
	}

	public Date getFecMovimiento() {
		return fecMovimiento;
	}

	public void setFecMovimiento(Date fecMovimiento) {
		this.fecMovimiento = fecMovimiento;
	}

	public Date getFecDocrespalda() {
		return fecDocrespalda;
	}

	public void setFecDocrespalda(Date fecDocrespalda) {
		this.fecDocrespalda = fecDocrespalda;
	}

	public String getNumDocrespalda() {
		return numDocrespalda;
	}

	public void setNumDocrespalda(String numDocrespalda) {
		this.numDocrespalda = numDocrespalda;
	}

	public String getNumExportacion() {
		return numExportacion;
	}

	public void setNumExportacion(String numExportacion) {
		this.numExportacion = numExportacion;
	}

	public String getNumOrdencomprasoc() {
		return numOrdencomprasoc;
	}

	public void setNumOrdencomprasoc(String numOrdencomprasoc) {
		this.numOrdencomprasoc = numOrdencomprasoc;
	}

	public String getCodReferencia() {
		return codReferencia;
	}

	public void setCodReferencia(String codReferencia) {
		this.codReferencia = codReferencia;
	}

	public String getTipTalla() {
		return tipTalla;
	}

	public void setTipTalla(String tipTalla) {
		this.tipTalla = tipTalla;
	}

	public String getCodColor() {
		return codColor;
	}

	public void setCodColor(String codColor) {
		this.codColor = codColor;
	}

	public String getIndCalidad() {
		return indCalidad;
	}

	public void setIndCalidad(String indCalidad) {
		this.indCalidad = indCalidad;
	}

	public String getCodProveedoref() {
		return codProveedoref;
	}

	public void setCodProveedoref(String codProveedoref) {
		this.codProveedoref = codProveedoref;
	}

	public String getCodPlu() {
		return codPlu;
	}

	public void setCodPlu(String codPlu) {
		this.codPlu = codPlu;
	}

	public double getValUnidad() {
		return valUnidad;
	}

	public void setValUnidad(double valUnidad) {
		this.valUnidad = valUnidad;
	}

	public int getNumCantidad() {
		return numCantidad;
	}

	public void setNumCantidad(int numCantidad) {
		this.numCantidad = numCantidad;
	}

	public double getValTotal() {
		return valTotal;
	}

	public void setValTotal(double valTotal) {
		this.valTotal = valTotal;
	}

	
	public String getCodUsuario() {
		return codUsuario;
	}

	public void setCodUsuario(String codUsuario) {
		this.codUsuario = codUsuario;
	}

	public String getIndEstado() {
		return indEstado;
	}

	public void setIndEstado(String indEstado) {
		this.indEstado = indEstado;
	}


	public int getNumAno() {
		return numAno;
	}

	public void setNumAno(int numAno) {
		this.numAno = numAno;
	}

	public int getCantRecibida() {
		return cantRecibida;
	}

	public void setCantRecibida(int cantRecibida) {
		this.cantRecibida = cantRecibida;
	}

	public String getIdDelivery() {
		return idDelivery;
	}

	public void setIdDelivery(String idDelivery) {
		this.idDelivery = idDelivery;
	}

}
