package com.gco.siconline.dto;

public class ConfirmarPedidoDTO {
	
	private String fechaMovimiento;
	private String codOleada;
	private String numPedido;
	private String usuario;
	private String request;

	public ConfirmarPedidoDTO() {
		
	}
	

	public ConfirmarPedidoDTO(String fechaMovimiento, String codOleada, String numPedido, String usuario,
			String request) {
		super();
		this.fechaMovimiento = fechaMovimiento;
		this.codOleada = codOleada;
		this.numPedido = numPedido;
		this.usuario = usuario;
		this.request = request;
	}


	public String getFechaMovimiento() {
		return fechaMovimiento;
	}

	public void setFechaMovimiento(String fechaMovimiento) {
		this.fechaMovimiento = fechaMovimiento;
	}

	public String getCodOleada() {
		return codOleada;
	}

	public void setCodOleada(String codOleada) {
		this.codOleada = codOleada;
	}

	public String getNumPedido() {
		return numPedido;
	}

	public void setNumPedido(String numPedido) {
		this.numPedido = numPedido;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public String getRequest() {
		return request;
	}

	public void setRequest(String request) {
		this.request = request;
	}

	
}
