package com.gco.siconline.dto;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

public class ConsultaSidaRequest {
	private int codEmpresa;
	private String marca;
	private String nummovimiento;

	public int getCodEmpresa() {
		return codEmpresa;
	}

	public void setCodEmpresa(int codEmpresa) {
		this.codEmpresa = codEmpresa;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getnummovimiento() {
		return nummovimiento;
	}

	public void setnummovimiento(String nummovimiento) {
		this.nummovimiento = nummovimiento;
	}

	

}
