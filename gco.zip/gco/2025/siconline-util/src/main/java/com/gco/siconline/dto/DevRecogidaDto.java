/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gco.siconline.dto;

import java.util.Date;
import java.util.List;

/**
 *
 * @author Jeixonx
 */
public class DevRecogidaDto {

	private String fecCreacion;
	private String codMarca;
	private String codDynamic;
	private String numNit;
	private String nomRazonsocial;
	private String idRecogida;
	private String codEstado;

	public String getFecCreacion() {
		return fecCreacion;
	}

	public void setFecCreacion(String fecCreacion) {
		this.fecCreacion = fecCreacion;
	}

	public String getCodMarca() {
		return codMarca;
	}

	public void setCodMarca(String codMarca) {
		this.codMarca = codMarca;
	}

	public String getCodDynamic() {
		return codDynamic;
	}

	public void setCodDynamic(String codDynamic) {
		this.codDynamic = codDynamic;
	}

	public String getNumNit() {
		return numNit;
	}

	public void setNumNit(String numNit) {
		this.numNit = numNit;
	}

	public String getNomRazonsocial() {
		return nomRazonsocial;
	}

	public void setNomRazonsocial(String nomRazonsocial) {
		this.nomRazonsocial = nomRazonsocial;
	}

	public String getIdRecogida() {
		return idRecogida;
	}

	public void setIdRecogida(String idRecogida) {
		this.idRecogida = idRecogida;
	}

	public String getCodEstado() {
		return codEstado;
	}

	public void setCodEstado(String codEstado) {
		this.codEstado = codEstado;
	}
}

