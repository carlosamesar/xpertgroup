/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gco.siconline.dto;

import java.util.List;

/**
 *
 * @author besmart
 */
public class RequestPedidoIncompletoDTO {
    
    private String numPedido;
    private String caja;
    private String ubicacion;
    private String usuario;
    private String bodega;
    private List<PlusPedidoIncompletoDTO> plus;

    public String getNumPedido() {
        return numPedido;
    }

    public void setNumPedido(String numPedido) {
        this.numPedido = numPedido;
    }

    public String getCaja() {
        return caja;
    }

    public void setCaja(String caja) {
        this.caja = caja;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    public List<PlusPedidoIncompletoDTO> getPlus() {
        return plus;
    }

    public void setPlus(List<PlusPedidoIncompletoDTO> plus) {
        this.plus = plus;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getBodega() {
        return bodega;
    }

    public void setBodega(String bodega) {
        this.bodega = bodega;
    }
    
    
    
    
}
