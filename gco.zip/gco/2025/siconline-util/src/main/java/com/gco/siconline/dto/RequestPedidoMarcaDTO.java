package com.gco.siconline.dto;

import java.util.List;

public class RequestPedidoMarcaDTO {

    protected PluConsolidadoDTO plu;
    protected String usuario;
    protected ConceptoMaeDTO concepto;
    protected String sio;
    protected String codOleada;
    protected List<PedidoDTO> pedidos;
    protected List<PluConsolidadoDTO> pedidosSio;

    public PluConsolidadoDTO getPlu() {
        return plu;
    }

    public void setPlu(PluConsolidadoDTO plu) {
        this.plu = plu;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getSio() {
        return sio;
    }

    public void setSio(String sio) {
        this.sio = sio;
    }

    public ConceptoMaeDTO getConcepto() {
        return concepto;
    }

    public void setConcepto(ConceptoMaeDTO concepto) {
        this.concepto = concepto;
    }

    public String getCodOleada() {
        return codOleada;
    }

    public void setCodOleada(String codOleada) {
        this.codOleada = codOleada;
    }

    public List<PedidoDTO> getPedidos() {
        return pedidos;
    }

    public void setPedidos(List<PedidoDTO> pedidos) {
        this.pedidos = pedidos;
    }

    public List<PluConsolidadoDTO> getPedidosSio() {
        return pedidosSio;
    }

    public void setPedidosSio(List<PluConsolidadoDTO> pedidosSio) {
        this.pedidosSio = pedidosSio;
    }
}
