package com.gco.siconline.dto;

public class ResponseUbicacionDTO {

    private String codUbicacion;
    protected String codigo;
    protected String mensaje;
    protected String conteo;

    public ResponseUbicacionDTO(String codUbicacion, String codigo, String mensaje, String conteo) {
        this.codUbicacion = codUbicacion;
        this.codigo = codigo;
        this.mensaje = mensaje;
        this.conteo = conteo;
    }

    public ResponseUbicacionDTO() {

    }

    public String getCodUbicacion() {
        return codUbicacion;
    }

    public void setCodUbicacion(String codUbicacion) {
        this.codUbicacion = codUbicacion;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public String getConteo() {
        return conteo;
    }

    public void setConteo(String conteo) {
        this.conteo = conteo;
    }

}
