package com.gco.siconline.dto;

import java.math.BigInteger;
import java.util.Date;

public class PedidoFiltroDTO {

    public Integer codEmpresa;
    public String codDocumento;
    public String indAplicacion;
    public String codConcepto;
    public String codTercero;
    public String tipTercero;
    public String numPedido;
    public BigInteger numCantidad;
    public Date fecPedido;
    public String codOleada;
    public boolean bonoRegalo;
    public boolean reservado;
    public String codClasePed;
    public String idCliente;
    public String nomCliente;
    public String numOrdenCompra;
    public String estPedido;

    private boolean customizado;
    private boolean obsequio;

    private boolean facturado;
    private boolean pedidoBodega;
    private int diasAntiguedad;
    private String reseller;
    
    public String codBodega;
    public String isSolicitud;

    public Integer getCodEmpresa() {
        return codEmpresa;
    }

    public void setCodEmpresa(Integer codEmpresa) {
        this.codEmpresa = codEmpresa;
    }

    public String getCodDocumento() {
        return codDocumento;
    }

    public void setCodDocumento(String codDocumento) {
        this.codDocumento = codDocumento;
    }

    public String getIndAplicacion() {
        return indAplicacion;
    }

    public void setIndAplicacion(String indAplicacion) {
        this.indAplicacion = indAplicacion;
    }

    public String getCodConcepto() {
        return codConcepto;
    }

    public void setCodConcepto(String codConcepto) {
        this.codConcepto = codConcepto;
    }

    public String getCodTercero() {
        return codTercero;
    }

    public void setCodTercero(String codTercero) {
        this.codTercero = codTercero;
    }

    public String getTipTercero() {
        return tipTercero;
    }

    public void setTipTercero(String tipTercero) {
        this.tipTercero = tipTercero;
    }

    public String getNumPedido() {
        return numPedido;
    }

    public void setNumPedido(String numPedido) {
        this.numPedido = numPedido;
    }

    public BigInteger getNumCantidad() {
        return numCantidad;
    }

    public void setNumCantidad(BigInteger numCantidad) {
        this.numCantidad = numCantidad;
    }

    public Date getFecPedido() {
        return fecPedido;
    }

    public void setFecPedido(Date fecPedido) {
        this.fecPedido = fecPedido;
    }

    public String getCodOleada() {
        return codOleada;
    }

    public void setCodOleada(String codOleada) {
        this.codOleada = codOleada;
    }

    public boolean getBonoRegalo() {
        return bonoRegalo;
    }

    public void setBonoRegalo(boolean bonoRegalo) {
        this.bonoRegalo = bonoRegalo;
    }

    public boolean getReservado() {
        return reservado;
    }

    public void setReservado(boolean reservado) {
        this.reservado = reservado;
    }

    public String getCodClasePed() {
        return codClasePed;
    }

    public void setCodClasePed(String codClasePed) {
        this.codClasePed = codClasePed;
    }

    public String getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(String idCliente) {
        this.idCliente = idCliente;
    }

    public String getNomCliente() {
        return nomCliente;
    }

    public void setNomCliente(String nomCliente) {
        this.nomCliente = nomCliente;
    }

    public String getNumOrdenCompra() {
        return numOrdenCompra;
    }

    public void setNumOrdenCompra(String numOrdenCompra) {
        this.numOrdenCompra = numOrdenCompra;
    }

    public String getEstPedido() {
        return estPedido;
    }

    public void setEstPedido(String estPedido) {
        this.estPedido = estPedido;
    }

    public boolean isCustomizado() {
        return customizado;
    }

    public void setCustomizado(boolean customizado) {
        this.customizado = customizado;
    }

    public boolean isObsequio() {
        return obsequio;
    }

    public void setObsequio(boolean obsequio) {
        this.obsequio = obsequio;
    }

    public boolean isFacturado() {
        return facturado;
    }

    public void setFacturado(boolean facturado) {
        this.facturado = facturado;
    }

    public boolean getPedidoBodega() {
        return pedidoBodega;
    }

    public void setPedidoBodega(boolean pedidoBodega) {
        this.pedidoBodega = pedidoBodega;
    }

    public int getDiasAntiguedad() {
        return diasAntiguedad;
    }

    public void setDiasAntiguedad(int diasAntiguedad) {
        this.diasAntiguedad = diasAntiguedad;
    }

    public String getReseller() {
        return reseller;
    }

    public void setReseller(String reseller) {
        this.reseller = reseller;
    }

    public String getCodBodega() {
        return codBodega;
    }

    public void setCodBodega(String codBodega) {
        this.codBodega = codBodega;
    }

	public String getIsSolicitud() {
		return isSolicitud;
	}

	public void setIsSolicitud(String isSolicitud) {
		this.isSolicitud = isSolicitud;
	}


}
