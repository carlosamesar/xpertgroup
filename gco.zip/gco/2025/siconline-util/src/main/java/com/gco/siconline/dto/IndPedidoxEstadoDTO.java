/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gco.siconline.dto;

import java.math.BigInteger;

/**
 *
 * @author jeisonz
 */
public class IndPedidoxEstadoDTO {

    protected String id;
    protected String descripcion;
    protected BigInteger cantidad;

    public IndPedidoxEstadoDTO() {
    }

    public IndPedidoxEstadoDTO(String id, String descripcion, BigInteger cantidad) {
        this.id = id;
        this.descripcion = descripcion;
        this.cantidad = cantidad;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public BigInteger getCantidad() {
        return cantidad;
    }

    public void setCantidad(BigInteger cantidad) {
        this.cantidad = cantidad;
    }

}
