/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gco.siconline.dto;

/**
 *
 * @author besmart
 */
public class EquivalenciaDto {
    
    private Integer idEquivalencia;
    private Integer tipo;
    private String valor;
    private String equivalencia;
    
    
    public Integer getIdEquivalencia() {
        return idEquivalencia;
    }

    public void setIdEquivalencia(Integer idEquivalencia) {
        this.idEquivalencia = idEquivalencia;
    }
    

    public Integer getTipo() {
        return tipo;
    }

    public void setTipo(Integer tipo) {
        this.tipo = tipo;
    }

    public String getValor() {
        return valor;
    }

    public void setValor(String valor) {
        this.valor = valor;
    }

    public String getEquivalencia() {
        return equivalencia;
    }

    public void setEquivalencia(String equivalencia) {
        this.equivalencia = equivalencia;
    }
    
    
}
