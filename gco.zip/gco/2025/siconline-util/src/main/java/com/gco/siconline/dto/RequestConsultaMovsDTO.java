package com.gco.siconline.dto;

import java.util.ArrayList;
import java.util.List;

public class RequestConsultaMovsDTO {

    private String codConcepto;
    private String codTercero;
    private String numMovimiento;
    private String codReferencia;
    private String codPlu;
    private String tipTalla;
    private String numPedido;
    private String fechaInicial;
    private String fechaFinal;
    private String numPedidoVtex;
    private String numPedidoVtexLargo;

    protected List<String> listMarcas = new ArrayList<String>();

    public RequestConsultaMovsDTO() {
    }

    public String getCodConcepto() {
        return codConcepto;
    }

    public void setCodConcepto(String codConcepto) {
        this.codConcepto = codConcepto;
    }

    public String getCodTercero() {
        return codTercero;
    }

    public void setCodTercero(String codTercero) {
        this.codTercero = codTercero;
    }

    public String getNumMovimiento() {
        return numMovimiento;
    }

    public void setNumMovimiento(String numMovimiento) {
        this.numMovimiento = numMovimiento;
    }

    public String getCodReferencia() {
        return codReferencia;
    }

    public void setCodReferencia(String codReferencia) {
        this.codReferencia = codReferencia;
    }

    public String getCodPlu() {
        return codPlu;
    }

    public void setCodPlu(String codPlu) {
        this.codPlu = codPlu;
    }

    public String getTipTalla() {
        return tipTalla;
    }

    public void setTipTalla(String tipTalla) {
        this.tipTalla = tipTalla;
    }

    public String getNumPedido() {
        return numPedido;
    }

    public void setNumPedido(String numPedido) {
        this.numPedido = numPedido;
    }

    public String getFechaInicial() {
        return fechaInicial;
    }

    public void setFechaInicial(String fechaInicial) {
        this.fechaInicial = fechaInicial;
    }

    public String getFechaFinal() {
        return fechaFinal;
    }

    public void setFechaFinal(String fechaFinal) {
        this.fechaFinal = fechaFinal;
    }

    public List<String> getListMarcas() {
        return listMarcas;
    }

    public void setListMarcas(List<String> listMarcas) {
        this.listMarcas = listMarcas;
    }

    public String getNumPedidoVtex() {
        return numPedidoVtex;
    }

    public void setNumPedidoVtex(String numPedidoVtex) {
        this.numPedidoVtex = numPedidoVtex;
    }

    public String getNumPedidoVtexLargo() {
        return numPedidoVtexLargo;
    }

    public void setNumPedidoVtexLargo(String numPedidoVtexLargo) {
        this.numPedidoVtexLargo = numPedidoVtexLargo;
    }

}
