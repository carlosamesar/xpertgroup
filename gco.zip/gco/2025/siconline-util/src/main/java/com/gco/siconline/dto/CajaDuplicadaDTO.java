package com.gco.siconline.dto;

public class CajaDuplicadaDTO {

    private Integer duplicadas;
    private String codCaja;
    private String codUbicacion;

    public CajaDuplicadaDTO() {
    }

    public Integer getDuplicadas() {
        return duplicadas;
    }

    public void setDuplicadas(Integer duplicadas) {
        this.duplicadas = duplicadas;
    }

    public String getCodCaja() {
        return codCaja;
    }

    public void setCodCaja(String codCaja) {
        this.codCaja = codCaja;
    }

    public String getCodUbicacion() {
        return codUbicacion;
    }

    public void setCodUbicacion(String codUbicacion) {
        this.codUbicacion = codUbicacion;
    }

}
