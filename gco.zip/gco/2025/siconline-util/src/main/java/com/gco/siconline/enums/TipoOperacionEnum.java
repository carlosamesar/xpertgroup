package com.gco.siconline.enums;

public enum TipoOperacionEnum {

    ENTRADA("ENT"),
    SALIDA("SAL"),
    TRASLADO("TRL"),
    RESERVA("RES");

    /**
     * Constant value
     */
    private String value;

    /**
     * Constructor
     *
     * @param value Constant value
     */
    private TipoOperacionEnum(String value) {
        this.value = value;
    }

    /**
     * @return the value
     */
    public String getValue() {
        return value;
    }
}
