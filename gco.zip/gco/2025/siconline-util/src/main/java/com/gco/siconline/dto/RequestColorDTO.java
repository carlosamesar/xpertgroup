package com.gco.siconline.dto;

public class RequestColorDTO {

    protected Integer codEmpresa;

    protected String codColor;

    public RequestColorDTO() {

    }

    public RequestColorDTO(Integer codEmpresa, String codColor) {
        this.codEmpresa = codEmpresa;
        this.codColor = codColor;
    }

    public Integer getCodEmpresa() {
        return codEmpresa;
    }

    public void setCodEmpresa(Integer codEmpresa) {
        this.codEmpresa = codEmpresa;
    }

    public String getCodColor() {
        return codColor;
    }

    public void setCodColor(String codColor) {
        this.codColor = codColor;
    }

}
