package com.gco.siconline.dto;

public class UsuarioDTO {

    private String cdusuario;
    private String cddocumento;
    private String dsnombres;
    private String dsapellidos;
    private String dsclave;
    private boolean bloqueado;

    public String getCdusuario() {
        return cdusuario;
    }

    public void setCdusuario(String cdusuario) {
        this.cdusuario = cdusuario;
    }

    public String getCddocumento() {
        return cddocumento;
    }

    public void setCddocumento(String cddocumento) {
        this.cddocumento = cddocumento;
    }

    public String getDsnombres() {
        return dsnombres;
    }

    public void setDsnombres(String dsnombres) {
        this.dsnombres = dsnombres;
    }

    public String getDsapellidos() {
        return dsapellidos;
    }

    public void setDsapellidos(String dsapellidos) {
        this.dsapellidos = dsapellidos;
    }

    public String getDsclave() {
        return dsclave;
    }

    public void setDsclave(String dsclave) {
        this.dsclave = dsclave;
    }

    public boolean isBloqueado() {
        return bloqueado;
    }

    public void setBloqueado(boolean bloqueado) {
        this.bloqueado = bloqueado;
    }

}
