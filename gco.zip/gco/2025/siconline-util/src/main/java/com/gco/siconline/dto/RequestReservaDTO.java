package com.gco.siconline.dto;

import java.util.List;

public class RequestReservaDTO {

    private List<PluConsolidadoDTO> listPlus;
    private String codOleada;
    private String usuario;

    public List<PluConsolidadoDTO> getListPlus() {
        return listPlus;
    }

    public void setListPlus(List<PluConsolidadoDTO> listPlus) {
        this.listPlus = listPlus;
    }

    public String getCodOleada() {
        return codOleada;
    }

    public void setCodOleada(String codOleada) {
        this.codOleada = codOleada;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

}
