package com.gco.siconline.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ReferenciaKardexRequest {
	private int codEmpresa;
	private String marca;
	private List<String> referencias = new ArrayList<String>();
	private List<String> lineas = new ArrayList<String>();
	private List<String> colecciones = new ArrayList<String>();
	private List<String> anos = new ArrayList<String>();
	private List<String> zonas = new ArrayList<String>();

	private Date fecha;

	
	
	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public ReferenciaKardexRequest() {
	}

	public int getCodEmpresa() {
		return codEmpresa;
	}

	public void setCodEmpresa(int codEmpresa) {
		this.codEmpresa = codEmpresa;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public List<String> getReferencias() {
		return referencias;
	}

	public void setReferencias(List<String> referencias) {
		this.referencias = referencias;
	}

	public List<String> getLineas() {
		return lineas;
	}

	public void setLineas(List<String> lineas) {
		this.lineas = lineas;
	}

	public List<String> getColecciones() {
		return colecciones;
	}

	public void setColecciones(List<String> coleccion) {
		this.colecciones = coleccion;
	}

	public List<String> getAnos() {
		return anos;
	}

	public void setAnos(List<String> ano) {
		this.anos = ano;
	}

	public List<String> getZonas() {
		return zonas;
	}

	public void setZonas(List<String> zonas) {
		this.zonas = zonas;
	}
	
	
}
