package com.gco.siconline.dto;

public class RequestMovKardexDTO {

    protected String codOleada;
    protected String codPlu;

    public String getCodOleada() {
        return codOleada;
    }

    public void setCodOleada(String codOleada) {
        this.codOleada = codOleada;
    }

    public String getCodPlu() {
        return codPlu;
    }

    public void setCodPlu(String codPlu) {
        this.codPlu = codPlu;
    }

}
