/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gco.siconline.dto;

import java.util.Date;

/**
 *
 * @author besmart
 */
public class ReferenciaDuplicadaDtoV2 {

    private Integer codEmpresa;
    private String codBodega;
    private String tipTercerobod;
    private Integer numAno;
    private String codReferencia;
    private String codProveedoref;
    private Integer idControl;
    private String indEstado;
    private Date fecModificacion;
    private String codReferenciaCtrl;
    private String codProveedorefCtrl;
    private Integer numAnoCtrl;
    private String codConceptoPedido;
    private String numPedido;

    public Integer getCodEmpresa() {
        return codEmpresa;
    }

    public void setCodEmpresa(Integer codEmpresa) {
        this.codEmpresa = codEmpresa;
    }

    public String getCodBodega() {
        return codBodega;
    }

    public void setCodBodega(String codBodega) {
        this.codBodega = codBodega;
    }

    public String getTipTercerobod() {
        return tipTercerobod;
    }

    public void setTipTercerobod(String tipTercerobod) {
        this.tipTercerobod = tipTercerobod;
    }

    public Integer getNumAno() {
        return numAno;
    }

    public void setNumAno(Integer numAno) {
        this.numAno = numAno;
    }

    public String getCodReferencia() {
        return codReferencia;
    }

    public void setCodReferencia(String codReferencia) {
        this.codReferencia = codReferencia;
    }

    public String getCodProveedoref() {
        return codProveedoref;
    }

    public void setCodProveedoref(String codProveedoref) {
        this.codProveedoref = codProveedoref;
    }

    public Integer getIdControl() {
        return idControl;
    }

    public void setIdControl(Integer idControl) {
        this.idControl = idControl;
    }

    public String getIndEstado() {
        return indEstado;
    }

    public void setIndEstado(String indEstado) {
        this.indEstado = indEstado;
    }

    public Date getFecModificacion() {
        return fecModificacion;
    }

    public void setFecModificacion(Date fecModificacion) {
        this.fecModificacion = fecModificacion;
    }

    public String getCodReferenciaCtrl() {
        return codReferenciaCtrl;
    }

    public void setCodReferenciaCtrl(String codReferenciaCtrl) {
        this.codReferenciaCtrl = codReferenciaCtrl;
    }

    public String getCodProveedorefCtrl() {
        return codProveedorefCtrl;
    }

    public void setCodProveedorefCtrl(String codProveedorefCtrl) {
        this.codProveedorefCtrl = codProveedorefCtrl;
    }

    public Integer getNumAnoCtrl() {
        return numAnoCtrl;
    }

    public void setNumAnoCtrl(Integer numAnoCtrl) {
        this.numAnoCtrl = numAnoCtrl;
    }

    public String getCodConceptoPedido() {
        return codConceptoPedido;
    }

    public void setCodConceptoPedido(String codConceptoPedido) {
        this.codConceptoPedido = codConceptoPedido;
    }

    public String getNumPedido() {
        return numPedido;
    }

    public void setNumPedido(String numPedido) {
        this.numPedido = numPedido;
    }

}
