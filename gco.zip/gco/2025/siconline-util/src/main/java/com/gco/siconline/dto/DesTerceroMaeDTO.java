package com.gco.siconline.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DesTerceroMaeDTO {

    private String codTercero;
    private String nit;
    private String nombre;
    private String email;
    private String telPrincipal;
    private String telCorrespondencia;
    private String telDespacho;

    private String dirPrincipal;
    private String codPais;
    private String nomPais;
    private String codDepto;
    private String nomDepto;
    private String codCiudad;
    private String nomCiudad;

    private String dirFacturacion;
    private String codPaisFac;
    private String nomPaisFac;
    private String codDeptoFac;
    private String nomDeptoFac;
    private String codCiudadFac;
    private String nomCiudadFac;

    private String dirCorrespondencia;
    private String codPaisCorresp;
    private String nomPaisCorresp;
    private String codDeptoCorresp;
    private String nomDeptoCorresp;
    private String codCiudadCorresp;
    private String nomCiudadCorresp;

    private String autoretenedor;
    private String grancontribuyente;
    private String regimenIva;
    private String responsableRetefuente;

    public String getNit() {
        return nit;
    }

    public void setNit(String nit) {
        this.nit = nit;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelPrincipal() {
        return telPrincipal;
    }

    public void setTelPrincipal(String telPrincipal) {
        this.telPrincipal = telPrincipal;
    }

    public String getTelCorrespondencia() {
        return telCorrespondencia;
    }

    public void setTelCorrespondencia(String telCorrespondencia) {
        this.telCorrespondencia = telCorrespondencia;
    }

    public String getTelDespacho() {
        return telDespacho;
    }

    public void setTelDespacho(String telDespacho) {
        this.telDespacho = telDespacho;
    }

    public String getDirPrincipal() {
        return dirPrincipal;
    }

    public void setDirPrincipal(String dirPrincipal) {
        this.dirPrincipal = dirPrincipal;
    }

    public String getCodPais() {
        return codPais;
    }

    public void setCodPais(String codPais) {
        this.codPais = codPais;
    }

    public String getNomPais() {
        return nomPais;
    }

    public void setNomPais(String nomPais) {
        this.nomPais = nomPais;
    }

    public String getCodDepto() {
        return codDepto;
    }

    public void setCodDepto(String codDepto) {
        this.codDepto = codDepto;
    }

    public String getNomDepto() {
        return nomDepto;
    }

    public void setNomDepto(String nomDepto) {
        this.nomDepto = nomDepto;
    }

    public String getCodCiudad() {
        return codCiudad;
    }

    public void setCodCiudad(String codCiudad) {
        this.codCiudad = codCiudad;
    }

    public String getNomCiudad() {
        return nomCiudad;
    }

    public void setNomCiudad(String nomCiudad) {
        this.nomCiudad = nomCiudad;
    }

    public String getDirFacturacion() {
        return dirFacturacion;
    }

    public void setDirFacturacion(String dirFacturacion) {
        this.dirFacturacion = dirFacturacion;
    }

    public String getCodPaisFac() {
        return codPaisFac;
    }

    public void setCodPaisFac(String codPaisFac) {
        this.codPaisFac = codPaisFac;
    }

    public String getNomPaisFac() {
        return nomPaisFac;
    }

    public void setNomPaisFac(String nomPaisFac) {
        this.nomPaisFac = nomPaisFac;
    }

    public String getCodDeptoFac() {
        return codDeptoFac;
    }

    public void setCodDeptoFac(String codDeptoFac) {
        this.codDeptoFac = codDeptoFac;
    }

    public String getNomDeptoFac() {
        return nomDeptoFac;
    }

    public void setNomDeptoFac(String nomDeptoFac) {
        this.nomDeptoFac = nomDeptoFac;
    }

    public String getCodCiudadFac() {
        return codCiudadFac;
    }

    public void setCodCiudadFac(String codCiudadFac) {
        this.codCiudadFac = codCiudadFac;
    }

    public String getNomCiudadFac() {
        return nomCiudadFac;
    }

    public void setNomCiudadFac(String nomCiudadFac) {
        this.nomCiudadFac = nomCiudadFac;
    }

    public String getDirCorrespondencia() {
        return dirCorrespondencia;
    }

    public void setDirCorrespondencia(String dirCorrespondencia) {
        this.dirCorrespondencia = dirCorrespondencia;
    }

    public String getCodPaisCorresp() {
        return codPaisCorresp;
    }

    public void setCodPaisCorresp(String codPaisCorresp) {
        this.codPaisCorresp = codPaisCorresp;
    }

    public String getNomPaisCorresp() {
        return nomPaisCorresp;
    }

    public void setNomPaisCorresp(String nomPaisCorresp) {
        this.nomPaisCorresp = nomPaisCorresp;
    }

    public String getCodDeptoCorresp() {
        return codDeptoCorresp;
    }

    public void setCodDeptoCorresp(String codDeptoCorresp) {
        this.codDeptoCorresp = codDeptoCorresp;
    }

    public String getNomDeptoCorresp() {
        return nomDeptoCorresp;
    }

    public void setNomDeptoCorresp(String nomDeptoCorresp) {
        this.nomDeptoCorresp = nomDeptoCorresp;
    }

    public String getCodCiudadCorresp() {
        return codCiudadCorresp;
    }

    public void setCodCiudadCorresp(String codCiudadCorresp) {
        this.codCiudadCorresp = codCiudadCorresp;
    }

    public String getNomCiudadCorresp() {
        return nomCiudadCorresp;
    }

    public void setNomCiudadCorresp(String nomCiudadCorresp) {
        this.nomCiudadCorresp = nomCiudadCorresp;
    }

    public String getAutoretenedor() {
        return autoretenedor;
    }

    public void setAutoretenedor(String autoretenedor) {
        this.autoretenedor = autoretenedor;
    }

    public String getGrancontribuyente() {
        return grancontribuyente;
    }

    public void setGrancontribuyente(String grancontribuyente) {
        this.grancontribuyente = grancontribuyente;
    }

    public String getRegimenIva() {
        return regimenIva;
    }

    public void setRegimenIva(String regimenIva) {
        this.regimenIva = regimenIva;
    }

    public String getResponsableRetefuente() {
        return responsableRetefuente;
    }

    public void setResponsableRetefuente(String responsableRetefuente) {
        this.responsableRetefuente = responsableRetefuente;
    }

    public String getCodTercero() {
        return codTercero;
    }

    public void setCodTercero(String codTercero) {
        this.codTercero = codTercero;
    }

}
