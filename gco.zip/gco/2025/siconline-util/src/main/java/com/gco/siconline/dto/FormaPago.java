package com.gco.siconline.dto;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@XmlRootElement
@JsonIgnoreProperties(ignoreUnknown = true)
public class FormaPago implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 5942513297231853706L;
	private String id;
    private String nombre;
    private double valor;
    private String idTransaccion;
    private String bin;
    private double flete;
    private String idTxPago;
    private String codVale;
    private String pasarela;    

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public String getIdTransaccion() {
        return idTransaccion;
    }

    public void setIdTransaccion(String idTransaccion) {
        this.idTransaccion = idTransaccion;
    }

    public String getBin() {
        return bin;
    }

    public void setBin(String bin) {
        this.bin = bin;
    }

    public double getFlete() {
        return flete;
    }

    public void setFlete(double flete) {
        this.flete = flete;
    }

	public String getIdTxPago() {
		return idTxPago;
	}

	public void setIdTxPago(String idTxPago) {
		this.idTxPago = idTxPago;
	}

	public String getCodVale() {
		return codVale;
	}
	
	public void setCodVale(String codVale) {
		this.codVale = codVale;
	}

	public String getPasarela() {
		return pasarela;
	}
	
	public void setPasarela(String pasarela) {
		this.pasarela = pasarela;
	}
	
}
