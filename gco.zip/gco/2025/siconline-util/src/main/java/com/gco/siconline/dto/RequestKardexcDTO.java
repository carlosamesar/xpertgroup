package com.gco.siconline.dto;

import com.gco.siconline.enums.TipoOperacionEnum;

public class RequestKardexcDTO {

    protected TipoOperacionEnum tipoOperacion;
    protected Integer codEmpresa;
    protected String proveedor;
    protected String plu;
    protected String ubicacionOri;
    protected String canastaOri;
    protected String ubicacionDest;
    protected String canastaDest;
    protected Integer cantidad;
    protected String codUsuario;
    protected String documento;
    protected String bodegaOri;
    protected String bodegaDest;

    public TipoOperacionEnum getTipoOperacion() {
        return tipoOperacion;
    }

    public void setTipoOperacion(TipoOperacionEnum tipoOperacion) {
        this.tipoOperacion = tipoOperacion;
    }

    public Integer getCodEmpresa() {
        return codEmpresa;
    }

    public void setCodEmpresa(Integer compania) {
        this.codEmpresa = compania;
    }

    public String getProveedor() {
        return proveedor;
    }

    public void setProveedor(String proveedor) {
        this.proveedor = proveedor;
    }

    public String getPlu() {
        return plu;
    }

    public void setPlu(String plu) {
        this.plu = plu;
    }

    public String getUbicacionOri() {
        return ubicacionOri;
    }

    public void setUbicacionOri(String ubicacionOri) {
        this.ubicacionOri = ubicacionOri;
    }

    public String getCanastaOri() {
        return canastaOri;
    }

    public void setCanastaOri(String canastOri) {
        this.canastaOri = canastOri;
    }

    public String getUbicacionDest() {
        return ubicacionDest;
    }

    public void setUbicacionDest(String ubicacionDest) {
        this.ubicacionDest = ubicacionDest;
    }

    public String getCanastaDest() {
        return canastaDest;
    }

    public void setCanastaDest(String canastaDest) {
        this.canastaDest = canastaDest;
    }

    public Integer getCantidad() {
        return cantidad;
    }

    public void setCantidad(Integer cantidad) {
        this.cantidad = cantidad;
    }

    public String getCodUsuario() {
        return codUsuario;
    }

    public void setCodUsuario(String usuario) {
        this.codUsuario = usuario;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result
                + ((canastaOri == null) ? 0 : canastaOri.hashCode());
        result = prime * result
                + ((canastaDest == null) ? 0 : canastaDest.hashCode());
        result = prime * result
                + ((cantidad == null) ? 0 : cantidad.hashCode());
        result = prime * result
                + ((codEmpresa == null) ? 0 : codEmpresa.hashCode());
        result = prime * result
                + ((codUsuario == null) ? 0 : codUsuario.hashCode());
        result = prime * result
                + ((documento == null) ? 0 : documento.hashCode());
        result = prime * result + ((plu == null) ? 0 : plu.hashCode());
        result = prime * result
                + ((proveedor == null) ? 0 : proveedor.hashCode());
        result = prime * result
                + ((tipoOperacion == null) ? 0 : tipoOperacion.hashCode());
        result = prime * result
                + ((ubicacionDest == null) ? 0 : ubicacionDest.hashCode());
        result = prime * result
                + ((ubicacionOri == null) ? 0 : ubicacionOri.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        RequestKardexcDTO other = (RequestKardexcDTO) obj;
        if (canastaOri == null) {
            if (other.canastaOri != null) {
                return false;
            }
        } else if (!canastaOri.equals(other.canastaOri)) {
            return false;
        }
        if (canastaDest == null) {
            if (other.canastaDest != null) {
                return false;
            }
        } else if (!canastaDest.equals(other.canastaDest)) {
            return false;
        }
        if (cantidad == null) {
            if (other.cantidad != null) {
                return false;
            }
        } else if (!cantidad.equals(other.cantidad)) {
            return false;
        }
        if (codEmpresa == null) {
            if (other.codEmpresa != null) {
                return false;
            }
        } else if (!codEmpresa.equals(other.codEmpresa)) {
            return false;
        }
        if (codUsuario == null) {
            if (other.codUsuario != null) {
                return false;
            }
        } else if (!codUsuario.equals(other.codUsuario)) {
            return false;
        }
        if (documento == null) {
            if (other.documento != null) {
                return false;
            }
        } else if (!documento.equals(other.documento)) {
            return false;
        }
        if (plu == null) {
            if (other.plu != null) {
                return false;
            }
        } else if (!plu.equals(other.plu)) {
            return false;
        }
        if (proveedor == null) {
            if (other.proveedor != null) {
                return false;
            }
        } else if (!proveedor.equals(other.proveedor)) {
            return false;
        }
        if (tipoOperacion != other.tipoOperacion) {
            return false;
        }
        return true;
    }

    public String getBodegaOri() {
        return bodegaOri;
    }

    public void setBodegaOri(String bodegaOri) {
        this.bodegaOri = bodegaOri;
    }

    public String getBodegaDest() {
        return bodegaDest;
    }

    public void setBodegaDest(String bodegaDest) {
        this.bodegaDest = bodegaDest;
    }
    
    

}
