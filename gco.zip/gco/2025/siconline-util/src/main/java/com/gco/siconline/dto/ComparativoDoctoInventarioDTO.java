/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gco.siconline.dto;

import java.math.BigDecimal;
import java.math.BigInteger;

/**
 *
 * @author alejandrotamayo
 */
public class ComparativoDoctoInventarioDTO {

	private String numDocrespalda;
    private String numMovimiento;
    private String codPlu;
    private String codReferencia;
    private String tipTalla;
    private String codColor;
    private BigInteger despachado;
    private BigInteger ingresado;
    private String docAsociados;
    private BigDecimal precosteo;
    private BigDecimal costoDefinitivo;

    private String codCanasta;
    private String esMultibodega;
    private String idDelivery;
    private String numPedido;

    public String getCodCanasta() {
        return codCanasta;
    }

    public void setCodCanasta(String codCanasta) {
        this.codCanasta = codCanasta;
    }

    public String getNumMovimiento() {
        return numMovimiento;
    }

    public void setNumMovimiento(String numMovimiento) {
        this.numMovimiento = numMovimiento;
    }

    public String getCodPlu() {
        return codPlu;
    }

    public void setCodPlu(String codPlu) {
        this.codPlu = codPlu;
    }

    public String getCodReferencia() {
        return codReferencia;
    }

    public void setCodReferencia(String codReferencia) {
        this.codReferencia = codReferencia;
    }

    public String getTipTalla() {
        return tipTalla;
    }

    public void setTipTalla(String tipTalla) {
        this.tipTalla = tipTalla;
    }

    public String getCodColor() {
        return codColor;
    }

    public void setCodColor(String codColor) {
        this.codColor = codColor;
    }

    public BigInteger getDespachado() {
        return despachado;
    }

    public void setDespachado(BigInteger despachado) {
        this.despachado = despachado;
    }

    public BigInteger getIngresado() {
        return ingresado;
    }

    public void setIngresado(BigInteger ingresado) {
        this.ingresado = ingresado;
    }

    public String getDocAsociados() {
        return docAsociados;
    }

    public void setDocAsociados(String docAsociados) {
        this.docAsociados = docAsociados;
    }

	public BigDecimal getPrecosteo() {
		return precosteo;
	}

	public void setPrecosteo(BigDecimal precosteo) {
		this.precosteo = precosteo;
	}

	public BigDecimal getCostoDefinitivo() {
		return costoDefinitivo;
	}

	public void setCostoDefinitivo(BigDecimal costoDefinitivo) {
		this.costoDefinitivo = costoDefinitivo;
	}

	public String getNumDocrespalda() {
		return numDocrespalda;
	}

	public void setNumDocrespalda(String numDocrespalda) {
		this.numDocrespalda = numDocrespalda;
	}

	public String getIdDelivery() {
		return idDelivery;
	}

	public void setIdDelivery(String idDelivery) {
		this.idDelivery = idDelivery;
	}

	public String getEsMultibodega() {
		return esMultibodega;
	}

	public void setEsMultibodega(String esMultibodega) {
		this.esMultibodega = esMultibodega;
	}

	public String getNumPedido() {
		return numPedido;
	}

	public void setNumPedido(String numPedido) {
		this.numPedido = numPedido;
	}

    
}
