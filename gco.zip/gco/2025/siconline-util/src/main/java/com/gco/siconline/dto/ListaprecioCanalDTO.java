package com.gco.siconline.dto;

public class ListaprecioCanalDTO {
	private String divisa;
	private String codPais;
	private Integer idCanal;
	
	public ListaprecioCanalDTO() {
	}
	
	public String getDivisa() {
		return divisa;
	}
	
	public void setDivisa(String divisa) {
		this.divisa = divisa;
	}
	
	public String getCodPais() {
		return codPais;
	}
	
	public void setCodPais(String codPais) {
		this.codPais = codPais;
	}
	
	public Integer getIdCanal() {
		return idCanal;
	}
	
	public void setIdCanal(Integer idCanal) {
		this.idCanal = idCanal;
	}	
}
