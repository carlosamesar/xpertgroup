package com.gco.siconline.dto;

public class DetallePtlDTO {

    protected String closingDate;
    protected String locationDate;
    protected boolean marca;
    protected String pickContainerCode;
    protected String pickElementCode;
    protected String pickElementBarcode;
    protected String pickOperatorCode;
    protected String putPlaceCode;
    protected String clientCode;
    protected String documentCode;
    protected Integer quantity;
    protected String pickWaveCode;

    public String getClosingDate() {
        return closingDate;
    }

    public void setClosingDate(String closingDate) {
        this.closingDate = closingDate;
    }

    public String getLocationDate() {
        return locationDate;
    }

    public void setLocationDate(String locationDate) {
        this.locationDate = locationDate;
    }

    public boolean isMarca() {
        return marca;
    }

    public void setMarca(boolean marca) {
        this.marca = marca;
    }

    public String getPickContainerCode() {
        return pickContainerCode;
    }

    public void setPickContainerCode(String pickContainerCode) {
        this.pickContainerCode = pickContainerCode;
    }

    public String getPickElementCode() {
        return pickElementCode;
    }

    public void setPickElementCode(String pickElementCode) {
        this.pickElementCode = pickElementCode;
    }

    public String getPickElementBarcode() {
        return pickElementBarcode;
    }

    public void setPickElementBarcode(String pickElementBarcode) {
        this.pickElementBarcode = pickElementBarcode;
    }

    public String getPickOperatorCode() {
        return pickOperatorCode;
    }

    public void setPickOperatorCode(String pickOperatorCode) {
        this.pickOperatorCode = pickOperatorCode;
    }

    public String getPutPlaceCode() {
        return putPlaceCode;
    }

    public void setPutPlaceCode(String putPlaceCode) {
        this.putPlaceCode = putPlaceCode;
    }

    public String getClientCode() {
        return clientCode;
    }

    public void setClientCode(String clientCode) {
        this.clientCode = clientCode;
    }

    public String getDocumentCode() {
        return documentCode;
    }

    public void setDocumentCode(String documentCode) {
        this.documentCode = documentCode;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public String getPickWaveCode() {
        return pickWaveCode;
    }

    public void setPickWaveCode(String pickWaveCode) {
        this.pickWaveCode = pickWaveCode;
    }

}
