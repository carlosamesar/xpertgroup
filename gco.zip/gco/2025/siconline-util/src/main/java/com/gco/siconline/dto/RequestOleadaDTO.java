package com.gco.siconline.dto;

public class RequestOleadaDTO extends PageRequestDTO {

    protected Integer codEmpresa;

    protected String documento;

    public Integer getCodEmpresa() {
        return codEmpresa;
    }

    public void setCodEmpresa(Integer codEmpresa) {
        this.codEmpresa = codEmpresa;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String numMovimiento) {
        this.documento = numMovimiento;
    }

}
