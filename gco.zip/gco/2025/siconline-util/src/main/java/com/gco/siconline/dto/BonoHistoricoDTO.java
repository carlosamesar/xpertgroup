package com.gco.siconline.dto;

public class BonoHistoricoDTO {

    private String numDocumento;
    private String codReferencia;
    private String marca;
    private String codTercero;
    private String nitTercero;
    private String nombreTercero;
    private String formaPago;
    private double valor;
    private String numPedido;
    private String pedidoVtex;
    private String fecha;
    private double totalMarca;

    public BonoHistoricoDTO() {

    }

    public String getNumDocumento() {
        return numDocumento;
    }

    public void setNumDocumento(String numDocumento) {
        this.numDocumento = numDocumento;
    }

    public String getCodReferencia() {
        return codReferencia;
    }

    public void setCodReferencia(String codReferencia) {
        this.codReferencia = codReferencia;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getCodTercero() {
        return codTercero;
    }

    public void setCodTercero(String codTercero) {
        this.codTercero = codTercero;
    }

    public String getNitTercero() {
        return nitTercero;
    }

    public void setNitTercero(String nitTercero) {
        this.nitTercero = nitTercero;
    }

    public String getNombreTercero() {
        return nombreTercero;
    }

    public void setNombreTercero(String nombreTercero) {
        this.nombreTercero = nombreTercero;
    }

    public String getFormaPago() {
        return formaPago;
    }

    public void setFormaPago(String formaPago) {
        this.formaPago = formaPago;
    }

    public String getNumPedido() {
        return numPedido;
    }

    public void setNumPedido(String numPedido) {
        this.numPedido = numPedido;
    }

    public String getPedidoVtex() {
        return pedidoVtex;
    }

    public void setPedidoVtex(String pedidoVtex) {
        this.pedidoVtex = pedidoVtex;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public double getTotalMarca() {
        return totalMarca;
    }

    public void setTotalMarca(double totalMarca) {
        this.totalMarca = totalMarca;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

}
