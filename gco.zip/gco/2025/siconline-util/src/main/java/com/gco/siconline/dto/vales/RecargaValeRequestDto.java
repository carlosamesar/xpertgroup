package com.gco.siconline.dto.vales;

import java.math.BigDecimal;

public class RecargaValeRequestDto {

    private String description;
    private Integer value;

    public RecargaValeRequestDto() {
    }

    public RecargaValeRequestDto(String description, Integer value) {
        this.description = description;
        this.value = value;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getValue() {
        return value;
    }

    public void setValue(Integer value) {
        this.value = value;
    }
}
