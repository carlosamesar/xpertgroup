package com.gco.siconline.dto;

import java.sql.Timestamp;

public class OleadaPorEstadoDTO {

    private String codOleada;
    private Timestamp fecOleada;
    private String idEstadoOleada;
    private String descripcionEstado;
    private String idTipoDestino;
    private String descTipoDestino;
    private String usuario;
    private String marca;
    private String sio;
    private String codEmpresa;
    private String numPlusSio;
    private String numPlusBodega;
    private Boolean incompletos;
    private String reseller;
    private Integer tipoEnvio;

    public String getCodOleada() {
        return codOleada;
    }

    public void setCodOleada(String codOleada) {
        this.codOleada = codOleada;
    }

    public Timestamp getFecOleada() {
        return fecOleada;
    }

    public void setFecOleada(Timestamp fecOleada) {
        this.fecOleada = fecOleada;
    }

    public String getIdEstadoOleada() {
        return idEstadoOleada;
    }

    public void setIdEstadoOleada(String idEstadoOleada) {
        this.idEstadoOleada = idEstadoOleada;
    }

    public String getDescripcionEstado() {
        return descripcionEstado;
    }

    public void setDescripcionEstado(String descripcionEstado) {
        this.descripcionEstado = descripcionEstado;
    }

    public String getIdTipoDestino() {
        return idTipoDestino;
    }

    public void setIdTipoDestino(String idTipoDestino) {
        this.idTipoDestino = idTipoDestino;
    }

    public String getDescTipoDestino() {
        return descTipoDestino;
    }

    public void setDescTipoDestino(String descTipoDestino) {
        this.descTipoDestino = descTipoDestino;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getSio() {
        return sio;
    }

    public void setSio(String sio) {
        this.sio = sio;
    }

    public String getCodEmpresa() {
        return codEmpresa;
    }

    public void setCodEmpresa(String codEmpresa) {
        this.codEmpresa = codEmpresa;
    }

    public String getNumPlusSio() {
        return numPlusSio;
    }

    public void setNumPlusSio(String numPlusSio) {
        this.numPlusSio = numPlusSio;
    }

    public String getNumPlusBodega() {
        return numPlusBodega;
    }

    public void setNumPlusBodega(String numPlusBodega) {
        this.numPlusBodega = numPlusBodega;
    }

    public Boolean getIncompletos() {
        return incompletos;
    }

    public void setIncompletos(Boolean incompletos) {
        this.incompletos = incompletos;
    }

	public String getReseller() {
		return reseller;
	}

	public void setReseller(String reseller) {
		this.reseller = reseller;
	}

	public Integer getTipoEnvio() {
		return tipoEnvio;
	}

	public void setTipoEnvio(Integer tipoEnvio) {
		this.tipoEnvio = tipoEnvio;
	}
    
    
}
