package com.gco.siconline.dto;

public class FacturaAutomaticaDTO {

	private String numPedido;
	private Integer intento;

	public String getNumPedido() {
		return numPedido;
	}

	public void setNumPedido(String numPedido) {
		this.numPedido = numPedido;
	}

	public Integer getIntento() {
		return intento;
	}

	public void setIntento(Integer intento) {
		this.intento = intento;
	}

}
