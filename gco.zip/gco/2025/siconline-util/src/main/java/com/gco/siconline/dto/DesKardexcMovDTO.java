package com.gco.siconline.dto;

public class DesKardexcMovDTO {
    
    private Integer codEmpresa;
    private String codTercero;
    private String tipTercero;
    private String codReferenciac;
    private String codPluc;
    private String codUbicacion;
    private String codCaja;
    private String indCalidad;
    private String codProveedoref;
    private String tipTalla;
    private String codColor;
    private String codZona;
    private String codCalle;
    private String codCarrera;
    private String codNivel;
    private String codCajon;
    private Integer canExistencia;
    private Integer canEntrada;
    private Integer canSalida;
    private Integer canExistant;
    private String codUsuario;
    private Character indEstado;
    private String codBodega;
    private Integer canReserva;
    private Integer numAno;
    private String nombreReferencia;
    private String nombreColor;
    private Integer disponible;

    public Integer getCodEmpresa() {
        return codEmpresa;
    }

    public void setCodEmpresa(Integer codEmpresa) {
        this.codEmpresa = codEmpresa;
    }

    public String getCodTercero() {
        return codTercero;
    }

    public void setCodTercero(String codTercero) {
        this.codTercero = codTercero;
    }

    public String getTipTercero() {
        return tipTercero;
    }

    public void setTipTercero(String tipTercero) {
        this.tipTercero = tipTercero;
    }

    public String getCodReferenciac() {
        return codReferenciac;
    }

    public void setCodReferenciac(String codReferenciac) {
        this.codReferenciac = codReferenciac;
    }

    public String getCodPluc() {
        return codPluc;
    }

    public void setCodPluc(String codPluc) {
        this.codPluc = codPluc;
    }

    public String getCodUbicacion() {
        return codUbicacion;
    }

    public void setCodUbicacion(String codUbicacion) {
        this.codUbicacion = codUbicacion;
    }

    public String getCodCaja() {
        return codCaja;
    }

    public void setCodCaja(String codCaja) {
        this.codCaja = codCaja;
    }

    public String getIndCalidad() {
        return indCalidad;
    }

    public void setIndCalidad(String indCalidad) {
        this.indCalidad = indCalidad;
    }

    public String getCodProveedoref() {
        return codProveedoref;
    }

    public void setCodProveedoref(String codProveedoref) {
        this.codProveedoref = codProveedoref;
    }

    public String getTipTalla() {
        return tipTalla;
    }

    public void setTipTalla(String tipTalla) {
        this.tipTalla = tipTalla;
    }

    public String getCodColor() {
        return codColor;
    }

    public void setCodColor(String codColor) {
        this.codColor = codColor;
    }

    public String getCodZona() {
        return codZona;
    }

    public void setCodZona(String codZona) {
        this.codZona = codZona;
    }

    public String getCodCalle() {
        return codCalle;
    }

    public void setCodCalle(String codCalle) {
        this.codCalle = codCalle;
    }

    public String getCodCarrera() {
        return codCarrera;
    }

    public void setCodCarrera(String codCarrera) {
        this.codCarrera = codCarrera;
    }

    public String getCodNivel() {
        return codNivel;
    }

    public void setCodNivel(String codNivel) {
        this.codNivel = codNivel;
    }

    public String getCodCajon() {
        return codCajon;
    }

    public void setCodCajon(String codCajon) {
        this.codCajon = codCajon;
    }

    public Integer getCanExistencia() {
        return canExistencia;
    }

    public void setCanExistencia(Integer canExistencia) {
        this.canExistencia = canExistencia;
    }

    public Integer getCanEntrada() {
        return canEntrada;
    }

    public void setCanEntrada(Integer canEntrada) {
        this.canEntrada = canEntrada;
    }

    public Integer getCanSalida() {
        return canSalida;
    }

    public void setCanSalida(Integer canSalida) {
        this.canSalida = canSalida;
    }

    public Integer getCanExistant() {
        return canExistant;
    }

    public void setCanExistant(Integer canExistant) {
        this.canExistant = canExistant;
    }

    public String getCodUsuario() {
        return codUsuario;
    }

    public void setCodUsuario(String codUsuario) {
        this.codUsuario = codUsuario;
    }

    public Character getIndEstado() {
        return indEstado;
    }

    public void setIndEstado(Character indEstado) {
        this.indEstado = indEstado;
    }

    public String getCodBodega() {
        return codBodega;
    }

    public void setCodBodega(String codBodega) {
        this.codBodega = codBodega;
    }

    public Integer getCanReserva() {
        return canReserva;
    }

    public void setCanReserva(Integer canReserva) {
        this.canReserva = canReserva;
    }

    public Integer getNumAno() {
        return numAno;
    }

    public void setNumAno(Integer numAno) {
        this.numAno = numAno;
    }

    public String getNombreReferencia() {
        return nombreReferencia;
    }

    public void setNombreReferencia(String nombreReferencia) {
        this.nombreReferencia = nombreReferencia;
    }

    public String getNombreColor() {
        return nombreColor;
    }

    public void setNombreColor(String nombreColor) {
        this.nombreColor = nombreColor;
    }

    public Integer getDisponible() {
        return disponible;
    }

    public void setDisponible(Integer disponible) {
        this.disponible = disponible;
    }

    
}
