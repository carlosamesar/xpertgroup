package com.gco.siconline.dto;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class BonoHistoricoRequest {

    private String codTercero;
    private Timestamp fechaIni;
    private Timestamp fechaFin;
    private List<String> listMarcas = new ArrayList<String>();

    public String getCodTercero() {
        return codTercero;
    }

    public void setCodTercero(String codTercero) {
        this.codTercero = codTercero;
    }

    public Timestamp getFechaIni() {
        return fechaIni;
    }

    public void setFechaIni(Timestamp fechaIni) {
        this.fechaIni = fechaIni;
    }

    public Timestamp getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(Timestamp fechaFin) {
        this.fechaFin = fechaFin;
    }

    public List<String> getListMarcas() {
        return listMarcas;
    }

    public void setListMarcas(List<String> listMarcas) {
        this.listMarcas = listMarcas;
    }

}
