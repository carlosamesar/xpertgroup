package com.gco.siconline.enums;

public enum EstadosTomaInvEnum {

    ACTIVO("A"),
    INACTIVO("I"),
    CERRADO("C"),
    AJUSTADO("J");

    private String value;

    private EstadosTomaInvEnum(String value) {
        this.setValue(value);
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

}
