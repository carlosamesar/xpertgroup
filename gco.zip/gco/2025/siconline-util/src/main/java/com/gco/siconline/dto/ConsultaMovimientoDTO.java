/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gco.siconline.dto;

import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author alejandrotamayo
 */
public class ConsultaMovimientoDTO {

    private String codConcepto;
    private String numMovimiento;
    private Date fecMovimiento;
    private BigDecimal valGenerado;
    private String codTercero;
    private String nombreComercial;
    private String numTelefono;
    private String numDocRespalda;
    private String nomObservacion;
    private String indEstado;

    public String getCodConcepto() {
        return codConcepto;
    }

    public void setCodConcepto(String codConcepto) {
        this.codConcepto = codConcepto;
    }

    public String getNumMovimiento() {
        return numMovimiento;
    }

    public void setNumMovimiento(String numMovimiento) {
        this.numMovimiento = numMovimiento;
    }

    public Date getFecMovimiento() {
        return fecMovimiento;
    }

    public void setFecMovimiento(Date fecMovimiento) {
        this.fecMovimiento = fecMovimiento;
    }

    public BigDecimal getValGenerado() {
        return valGenerado;
    }

    public void setValGenerado(BigDecimal valGenerado) {
        this.valGenerado = valGenerado;
    }

    public String getCodTercero() {
        return codTercero;
    }

    public void setCodTercero(String codTercero) {
        this.codTercero = codTercero;
    }

    public String getNombreComercial() {
        return nombreComercial;
    }

    public void setNombreComercial(String nombreComercial) {
        this.nombreComercial = nombreComercial;
    }

    public String getNumTelefono() {
        return numTelefono;
    }

    public void setNumTelefono(String numTelefono) {
        this.numTelefono = numTelefono;
    }

    public String getNumDocRespalda() {
        return numDocRespalda;
    }

    public void setNumDocRespalda(String numDocRespalda) {
        this.numDocRespalda = numDocRespalda;
    }

    public String getNomObservacion() {
        return nomObservacion;
    }

    public void setNomObservacion(String nomObservacion) {
        this.nomObservacion = nomObservacion;
    }

    public String getIndEstado() {
        return indEstado;
    }

    public void setIndEstado(String indEstado) {
        this.indEstado = indEstado;
    }

}
