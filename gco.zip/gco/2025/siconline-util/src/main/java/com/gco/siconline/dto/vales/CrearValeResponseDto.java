package com.gco.siconline.dto.vales;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class CrearValeResponseDto {
    private String id;
    private String redemptionToken;
    private String redemptionCode;
    private double balance;
    private String relationName;
    private String emissionDate;
    private String expiringDate;
    private String caption;
    private String provider;
    private boolean discount;

    public CrearValeResponseDto() {}

    public CrearValeResponseDto(String id, String redemptionToken, String redemptionCode, double balance,
                           String relationName, String emissionDate, String expiringDate, String caption,
                           String provider, boolean discount) {
        this.id = id;
        this.redemptionToken = redemptionToken;
        this.redemptionCode = redemptionCode;
        this.balance = balance;
        this.relationName = relationName;
        this.emissionDate = emissionDate;
        this.expiringDate = expiringDate;
        this.caption = caption;
        this.provider = provider;
        this.discount = discount;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getRedemptionToken() {
        return redemptionToken;
    }

    public void setRedemptionToken(String redemptionToken) {
        this.redemptionToken = redemptionToken;
    }

    public String getRedemptionCode() {
        return redemptionCode;
    }

    public void setRedemptionCode(String redemptionCode) {
        this.redemptionCode = redemptionCode;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public String getRelationName() {
        return relationName;
    }

    public void setRelationName(String relationName) {
        this.relationName = relationName;
    }

    public String getEmissionDate() {
        return emissionDate;
    }

    public void setEmissionDate(String emissionDate) {
        this.emissionDate = emissionDate;
    }

    public String getExpiringDate() {
        return expiringDate;
    }

    public void setExpiringDate(String expiringDate) {
        this.expiringDate = expiringDate;
    }

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }

    public String getProvider() {
        return provider;
    }

    public void setProvider(String provider) {
        this.provider = provider;
    }

    public boolean isDiscount() {
        return discount;
    }

    public void setDiscount(boolean discount) {
        this.discount = discount;
    }
}
