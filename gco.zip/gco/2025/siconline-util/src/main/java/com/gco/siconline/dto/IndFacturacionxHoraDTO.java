/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gco.siconline.dto;

import java.math.BigInteger;

/**
 *
 * @author jeisonz
 */
public class IndFacturacionxHoraDTO {

    protected String hora;
    protected BigInteger cantidad;

    public IndFacturacionxHoraDTO() {
    }

    public IndFacturacionxHoraDTO(String hora, BigInteger cantidad) {
        this.hora = hora;
        this.cantidad = cantidad;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public BigInteger getCantidad() {
        return cantidad;
    }

    public void setCantidad(BigInteger cantidad) {
        this.cantidad = cantidad;
    }

}
