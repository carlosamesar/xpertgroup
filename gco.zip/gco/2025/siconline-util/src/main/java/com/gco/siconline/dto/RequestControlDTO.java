package com.gco.siconline.dto;

public class RequestControlDTO extends RequestOleadaDTO {

    protected String codConcepto;

    protected String codBodega;

    public String getCodConcepto() {
        return codConcepto;
    }

    public void setCodConcepto(String codConcepto) {
        this.codConcepto = codConcepto;
    }

    public String getCodBodega() {
        return codBodega;
    }

    public void setCodBodega(String codBodega) {
        this.codBodega = codBodega;
    }

}
