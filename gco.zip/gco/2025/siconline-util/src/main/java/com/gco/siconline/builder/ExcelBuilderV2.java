/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gco.siconline.builder;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.web.servlet.view.document.AbstractXlsxView;

/**
 *
 * @author agomez
 */
public class ExcelBuilderV2 extends AbstractXlsxView {

    @SuppressWarnings("unchecked")
    @Override
    protected void buildExcelDocument(Map<String, Object> map, Workbook workbook, HttpServletRequest hsr,
            HttpServletResponse response) throws Exception {

        String head = "";
        String[] columnas = null;

        // Si se está enviando la lista de columnas en un array
        if (map.get("columnas") instanceof String[]) {
            columnas = (String[]) map.get("columnas");
        } else {
            head = (String) map.get("columnas");
            columnas = head.split(";");
        }

        Sheet sheet = workbook.createSheet("Reporte");
        sheet.setDefaultColumnWidth(10);

        // create style for header cells
        CellStyle style = workbook.createCellStyle();
        style.setAlignment(CellStyle.ALIGN_CENTER);
        style.setFillForegroundColor(IndexedColors.BLACK.getIndex());
        style.setFillPattern(CellStyle.SOLID_FOREGROUND);
        Font font = workbook.createFont();
        font.setColor(IndexedColors.WHITE.getIndex());
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
        style.setFont(font);

        Row header = sheet.createRow(0);

        // Creo las columnas del excel
        for (int i = 0; i < columnas.length; i++) {

            String columna = columnas[i];

            Cell cell = header.createCell(i);
            cell.setCellValue(columna);
            cell.setCellStyle(style);

        }

        List<Object> listaDatos = (List<Object>) map.get("datos");

        for (int i = 0; i < listaDatos.size(); i++) {

            Object[] values = (Object[]) listaDatos.get(i);

            //ObjectMapper oMapper = new ObjectMapper();
            //Map<String, Object> mapO = oMapper.convertValue(listaDatos.get(i), Map.class);
            //mapO.values().removeIf(Objects::isNull);
            //Object[] values = mapO.values().toArray();
            Row fila = sheet.createRow(i + 1);

            for (int j = 0; j < columnas.length; j++) {

                if (values[j] != null) {

                    if (values[j] == "TOTAL") {
                        break;
                    }

                    // Validacion para que no convierta en numero el codigo de las PLU
                    if (values[j].toString().length() > 3 ? !(values[j].toString().substring(0, 4).equals("111"))
                            : false) {
                        fila.createCell(j).setCellValue(values[j].toString());
                    } else {

                        try {
                            fila.createCell(j).setCellValue(Double.parseDouble(values[j].toString()));
                        } catch (Exception e) {
                            fila.createCell(j).setCellValue(values[j].toString());
                        }
                    }

                }
            }

        }

        for (int columnIndex = 0; columnIndex < columnas.length; columnIndex++) {
            sheet.autoSizeColumn(columnIndex);
        }

    }

}
