package com.gco.siconline.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RequestTomaInventarioDTO {

    private Integer idToma;
    private String codUsuario;
    private String codUbicacion;
    private String codCaja;
    private String codPlu;
    private String estado;
    private Integer conteo;

    public String getCodUbicacion() {
        return codUbicacion;
    }

    public void setCodUbicacion(String codUbicacion) {
        this.codUbicacion = codUbicacion;
    }

    public String getCodCaja() {
        return codCaja;
    }

    public void setCodCaja(String codCaja) {
        this.codCaja = codCaja;
    }

    public String getCodPlu() {
        return codPlu;
    }

    public void setCodPlu(String codPlu) {
        this.codPlu = codPlu;
    }

    public String getCodUsuario() {
        return codUsuario;
    }

    public void setCodUsuario(String codUsuario) {
        this.codUsuario = codUsuario;
    }

    public Integer getIdToma() {
        return idToma;
    }

    public void setIdToma(Integer idToma) {
        this.idToma = idToma;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public Integer getConteo() {
        return conteo;
    }

    public void setConteo(Integer conteo) {
        this.conteo = conteo;
    }

}
