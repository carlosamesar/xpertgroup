/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gco.siconline.dto;

import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author besmart
 */
public class AuxiliarCarteraDTO {

    private String numDocumento;
    private String codConcepto;
    private Date fecElabora;
    private String codConceptobase;
    private String numDocumenbase;
    private BigDecimal valGenerado;
    private String tipOperacion;
    private String numNit;
    private String numDigitoVerifi;
    private String nomRazonsocial;
    private String codTercero;
    private String indBasetipo;
    private String tipTercero;
    private BigDecimal valSaldocierre;
    private BigDecimal valSaldoactual;
    private String nomConcepto;
    private String idTx;

    public String getNumDocumento() {
        return numDocumento;
    }

    public void setNumDocumento(String numDocumento) {
        this.numDocumento = numDocumento;
    }

    public String getCodConcepto() {
        return codConcepto;
    }

    public void setCodConcepto(String codConcepto) {
        this.codConcepto = codConcepto;
    }

    public Date getFecElabora() {
        return fecElabora;
    }

    public void setFecElabora(Date fecElabora) {
        this.fecElabora = fecElabora;
    }

    public String getCodConceptobase() {
        return codConceptobase;
    }

    public void setCodConceptobase(String codConceptobase) {
        this.codConceptobase = codConceptobase;
    }

    public String getNumDocumenbase() {
        return numDocumenbase;
    }

    public void setNumDocumenbase(String numDocumenbase) {
        this.numDocumenbase = numDocumenbase;
    }

    public BigDecimal getValGenerado() {
        return valGenerado;
    }

    public void setValGenerado(BigDecimal valGenerado) {
        this.valGenerado = valGenerado;
    }

    public String getTipOperacion() {
        return tipOperacion;
    }

    public void setTipOperacion(String tipOperacion) {
        this.tipOperacion = tipOperacion;
    }

    public String getNumNit() {
        return numNit;
    }

    public void setNumNit(String numNit) {
        this.numNit = numNit;
    }

    public String getNumDigitoVerifi() {
        return numDigitoVerifi;
    }

    public void setNumDigitoVerifi(String numDigitoVerifi) {
        this.numDigitoVerifi = numDigitoVerifi;
    }

    public String getNomRazonsocial() {
        return nomRazonsocial;
    }

    public void setNomRazonsocial(String nomRazonsocial) {
        this.nomRazonsocial = nomRazonsocial;
    }

    public String getCodTercero() {
        return codTercero;
    }

    public void setCodTercero(String codTercero) {
        this.codTercero = codTercero;
    }

    public String getIndBasetipo() {
        return indBasetipo;
    }

    public void setIndBasetipo(String indBasetipo) {
        this.indBasetipo = indBasetipo;
    }

    public String getTipTercero() {
        return tipTercero;
    }

    public void setTipTercero(String tipTercero) {
        this.tipTercero = tipTercero;
    }

    public BigDecimal getValSaldocierre() {
        return valSaldocierre;
    }

    public void setValSaldocierre(BigDecimal valSaldocierre) {
        this.valSaldocierre = valSaldocierre;
    }

    public BigDecimal getValSaldoactual() {
        return valSaldoactual;
    }

    public void setValSaldoactual(BigDecimal valSaldoactual) {
        this.valSaldoactual = valSaldoactual;
    }

    public String getNomConcepto() {
        return nomConcepto;
    }

    public void setNomConcepto(String nomConcepto) {
        this.nomConcepto = nomConcepto;
    }

    public String getIdTx() {
        return idTx;
    }

    public void setIdTx(String idTx) {
        this.idTx = idTx;
    }

}
