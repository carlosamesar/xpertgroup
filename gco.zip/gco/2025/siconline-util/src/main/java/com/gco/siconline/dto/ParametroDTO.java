package com.gco.siconline.dto;

public class ParametroDTO {

    private String nombreParam;
    private String valorParam;

    public ParametroDTO() {

    }

    public ParametroDTO(String nombreParam, String valorParam) {
        this.nombreParam = nombreParam;
        this.valorParam = valorParam;
    }

    public String getNombreParam() {
        return nombreParam;
    }

    public void setNombreParam(String nombreParam) {
        this.nombreParam = nombreParam;
    }

    public String getValorParam() {
        return valorParam;
    }

    public void setValorParam(String valorParam) {
        this.valorParam = valorParam;
    }

}
