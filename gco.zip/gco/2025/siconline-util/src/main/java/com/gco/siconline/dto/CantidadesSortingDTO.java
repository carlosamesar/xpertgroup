/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gco.siconline.dto;

/**
 *
 * @author besmart
 */
public class CantidadesSortingDTO {

    private String sorting;
    private Integer cantidadPedida;
    private Integer cantidadLeida;

    public String getSorting() {
        return sorting;
    }

    public void setSorting(String sorting) {
        this.sorting = sorting;
    }

    public Integer getCantidadPedida() {
        return cantidadPedida;
    }

    public void setCantidadPedida(Integer cantidadPedida) {
        this.cantidadPedida = cantidadPedida;
    }

    public Integer getCantidadLeida() {
        return cantidadLeida;
    }

    public void setCantidadLeida(Integer cantidadLeida) {
        this.cantidadLeida = cantidadLeida;
    }
    
    
    
    
}
