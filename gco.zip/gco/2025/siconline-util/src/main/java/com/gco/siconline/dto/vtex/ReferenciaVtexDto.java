/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gco.siconline.dto.vtex;

import com.fasterxml.jackson.databind.node.ArrayNode;
import com.gco.siconline.dto.PluDTO;
import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author besmart
 */
public class ReferenciaVtexDto extends PluDTO {
    
    private Integer ano;
    private String codProveedor;
    private String nomReferencia;
    private String nombreComercial;
    private String descripcion;
    private String idMarketplace;
    private String nomColor;
    private String equivTalla;
    private String equivColor;
    private String composicion;
    private String equivComposicion;
    private boolean tieneDescripcion;
    private boolean tieneImagen;
    private boolean tieneComposicion;
    private boolean tieneTalla;
    private boolean tieneColor;
    private boolean actualizado;
    private boolean tieneCategoria;
    private Date fechaLanzamiento;
    private Date fechaCarga;
    private String urlImagen;
    private String nomCategoria;
    private String numColeccion;
    private String colorFamily;
    private Float valorPublico;
    private String divisa;
    private boolean atributoSic;
    private String indOrigen;
    private String idReferencia;
    private ArrayNode exportacionAtributosSic;
    private String gender;
    private String fit;
    private String atributo;
    private String imgDesc;
    private String imgArray;

    public ReferenciaVtexDto() {
        
    }

    public Integer getAno() {
        return ano;
    }

    public void setAno(Integer ano) {
        this.ano = ano;
    }

    public String getCodProveedor() {
        return codProveedor;
    }

    public void setCodProveedor(String codProveedor) {
        this.codProveedor = codProveedor;
    }

    public String getNomReferencia() {
        return nomReferencia;
    }

    public void setNomReferencia(String nomReferencia) {
        this.nomReferencia = nomReferencia;
    }

    public String getNombreComercial() {
        return nombreComercial;
    }

    public void setNombreComercial(String nombreComercial) {
        this.nombreComercial = nombreComercial;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getIdMarketplace() {
        return idMarketplace;
    }

    public void setIdMarketplace(String idMarketplace) {
        this.idMarketplace = idMarketplace;
    }

    public String getNomColor() {
        return nomColor;
    }

    public void setNomColor(String nomColor) {
        this.nomColor = nomColor;
    }

    public String getEquivTalla() {
        return equivTalla;
    }

    public void setEquivTalla(String equivTalla) {
        this.equivTalla = equivTalla;
    }

    public String getEquivColor() {
        return equivColor;
    }

    public void setEquivColor(String equivColor) {
        this.equivColor = equivColor;
    }

    public String getComposicion() {
        return composicion;
    }

    public void setComposicion(String composicion) {
        this.composicion = composicion;
    }

    public String getEquivComposicion() {
        return equivComposicion;
    }

    public void setEquivComposicion(String equivComposicion) {
        this.equivComposicion = equivComposicion;
    }

    public boolean isTieneDescripcion() {
        return tieneDescripcion;
    }

    public void setTieneDescripcion(boolean tieneDescripcion) {
        this.tieneDescripcion = tieneDescripcion;
    }

    public boolean isTieneImagen() {
        return tieneImagen;
    }

    public void setTieneImagen(boolean tieneImagen) {
        this.tieneImagen = tieneImagen;
    }

    public boolean isTieneComposicion() {
        return tieneComposicion;
    }

    public void setTieneComposicion(boolean tieneComposicion) {
        this.tieneComposicion = tieneComposicion;
    }

    public boolean isTieneTalla() {
        return tieneTalla;
    }

    public void setTieneTalla(boolean tieneTalla) {
        this.tieneTalla = tieneTalla;
    }

    public boolean isTieneColor() {
        return tieneColor;
    }

    public void setTieneColor(boolean tieneColor) {
        this.tieneColor = tieneColor;
    }

    public boolean isActualizado() {
        return actualizado;
    }

    public void setActualizado(boolean actualizado) {
        this.actualizado = actualizado;
    }
    
    public Date getFechaLanzamiento() {
        return fechaLanzamiento;
    }
    
    public void setFechaLanzamiento(Date fechaLanzamiento) {
        this.fechaLanzamiento = fechaLanzamiento;
    }

    public Date getFechaCarga() {
        return fechaCarga;
    }

    public void setFechaCarga(Date fechaCarga) {
        this.fechaCarga = fechaCarga;
    }

    public String getUrlImagen() {
        return urlImagen;
    }

    public void setUrlImagen(String urlImagen) {
        this.urlImagen = urlImagen;
    }

    public String getNomCategoria() {
        return nomCategoria;
    }

    public void setNomCategoria(String nomCategoria) {
        this.nomCategoria = nomCategoria;
    }

    public String getNumColeccion() {
        return numColeccion;
    }

    public void setNumColeccion(String numColeccion) {
        this.numColeccion = numColeccion;
    }

    public boolean isTieneCategoria() {
        return tieneCategoria;
    }

    public void setTieneCategoria(boolean tieneCategoria) {
        this.tieneCategoria = tieneCategoria;
    }

    public String getColorFamily() {
        return colorFamily;
    }

    public void setColorFamily(String colorFamily) {
        this.colorFamily = colorFamily;
    }

    public Float getValorPublico() {
        return valorPublico;
    }

    public void setValorPublico(Float valorPublico) {
        this.valorPublico = valorPublico;
    }
        
    public String getDivisa() {
		return divisa;
	}

	public void setDivisa(String divisa) {
		this.divisa = divisa;
	}

	public boolean isAtributoSic() {
        return atributoSic;
    }

    public void setAtributoSic(boolean atributoSic) {
        this.atributoSic = atributoSic;
    }

    public String getIndOrigen() {
        return indOrigen;
    }

    public void setIndOrigen(String indOrigen) {
        this.indOrigen = indOrigen;
    }
    
    public String getIdReferencia() {
		return idReferencia;
	}

	public void setIdReferencia(String idReferencia) {
		this.idReferencia = idReferencia;
	}

	public ArrayNode getExportacionAtributosSic() {
        return exportacionAtributosSic;
    }

    public void setExportacionAtributosSic(ArrayNode exportacionAtributosSic) {
        this.exportacionAtributosSic = exportacionAtributosSic;
    }

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getFit() {
		return fit;
	}

	public void setFit(String fit) {
		this.fit = fit;
	}

	public String getAtributo() {
		return atributo;
	}

	public void setAtributo(String atributo) {
		this.atributo = atributo;
	}

	public String getImgDesc() {
		return imgDesc;
	}

	public void setImgDesc(String imgDesc) {
		this.imgDesc = imgDesc;
	}

	public String getImgArray() {
		return imgArray;
	}

	public void setImgArray(String imgArray) {
		this.imgArray = imgArray;
	}
    
    
}
