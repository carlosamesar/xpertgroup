/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gco.siconline.dto;

/**
 *
 * @author alejandrotamayo
 */
public class ComparativoInventarioCanastaDto {

    private String usuario;
    private Integer codEmpresa;
    private String codBodega;
    private String tipTerceroBod;
    private String codUbicacion;
    private Integer teorico;
    private Integer fisicoUno;
    private Integer fisicoDos;
    private Integer fisicoTres;
    private Integer codigo;
    private String trocadoUno;
    private String trocadoDos;
    private String trocadoTres;

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public Integer getCodEmpresa() {
        return codEmpresa;
    }

    public void setCodEmpresa(Integer codEmpresa) {
        this.codEmpresa = codEmpresa;
    }

    public String getCodBodega() {
        return codBodega;
    }

    public void setCodBodega(String codBodega) {
        this.codBodega = codBodega;
    }

    public String getTipTerceroBod() {
        return tipTerceroBod;
    }

    public void setTipTerceroBod(String tipTerceroBod) {
        this.tipTerceroBod = tipTerceroBod;
    }

    public String getCodUbicacion() {
        return codUbicacion;
    }

    public void setCodUbicacion(String codUbicacion) {
        this.codUbicacion = codUbicacion;
    }

    public Integer getTeorico() {
        return teorico;
    }

    public void setTeorico(Integer teorico) {
        this.teorico = teorico;
    }

    public Integer getFisicoUno() {
        return fisicoUno;
    }

    public void setFisicoUno(Integer fisicoUno) {
        this.fisicoUno = fisicoUno;
    }

    public Integer getFisicoDos() {
        return fisicoDos;
    }

    public void setFisicoDos(Integer fisicoDos) {
        this.fisicoDos = fisicoDos;
    }

    public Integer getFisicoTres() {
        return fisicoTres;
    }

    public void setFisicoTres(Integer fisicoTres) {
        this.fisicoTres = fisicoTres;
    }

    public Integer getCodigo() {
        return codigo;
    }

    public void setCodigo(Integer codigo) {
        this.codigo = codigo;
    }

    public String getTrocadoUno() {
        return trocadoUno;
    }

    public void setTrocadoUno(String trocadoUno) {
        this.trocadoUno = trocadoUno;
    }

    public String getTrocadoDos() {
        return trocadoDos;
    }

    public void setTrocadoDos(String trocadoDos) {
        this.trocadoDos = trocadoDos;
    }

    public String getTrocadoTres() {
        return trocadoTres;
    }

    public void setTrocadoTres(String trocadoTres) {
        this.trocadoTres = trocadoTres;
    }

}
