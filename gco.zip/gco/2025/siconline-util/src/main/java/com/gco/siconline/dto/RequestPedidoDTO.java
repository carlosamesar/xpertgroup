package com.gco.siconline.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RequestPedidoDTO extends PageRequestDTO {

    protected String codTercero;
    protected Date fechaInicial;
    protected Date fechaFinal;
    protected Integer cantInicial;
    protected Integer cantFinal;
    protected String numPedido;
    protected List<String> listMarcas = new ArrayList<String>();
    protected String nitTransportadora;
    protected Integer tipoEnvio;
    protected List<String> listCiudades = new ArrayList<String>();
    protected String codPais;
    protected int tienda;

    public String getCodTercero() {
        return codTercero;
    }

    public void setCodTercero(String codTercero) {
        this.codTercero = codTercero;
    }

    public Date getFechaInicial() {
        return fechaInicial;
    }

    public void setFechaInicial(Date fechaInicial) {
        this.fechaInicial = fechaInicial;
    }

    public Date getFechaFinal() {
        return fechaFinal;
    }

    public void setFechaFinal(Date fechaFinal) {
        this.fechaFinal = fechaFinal;
    }

    public Integer getCantInicial() {
        return cantInicial;
    }

    public void setCantInicial(Integer cantInicial) {
        this.cantInicial = cantInicial;
    }

    public Integer getCantFinal() {
        return cantFinal;
    }

    public void setCantFinal(Integer cantFinal) {
        this.cantFinal = cantFinal;
    }

    public String getNumPedido() {
        return numPedido;
    }

    public void setNumPedido(String numPedido) {
        this.numPedido = numPedido;
    }

    public List<String> getListMarcas() {
        return listMarcas;
    }

    public void setListMarcas(List<String> listMarcas) {
        this.listMarcas = listMarcas;
    }

    public String getNitTransportadora() {
            return nitTransportadora;
    }

    public void setNitTransportadora(String nitTransportadora) {
            this.nitTransportadora = nitTransportadora;
    }

    public Integer getTipoEnvio() {
            return tipoEnvio;
    }

    public void setTipoEnvio(Integer tipoEnvio) {
            this.tipoEnvio = tipoEnvio;
    }

    public List<String> getListCiudades() {
            return listCiudades;
    }

    public void setListCiudades(List<String> listCiudades) {
            this.listCiudades = listCiudades;
    }

    public String getCodPais() {
        return codPais;
    }

    public void setCodPais(String codPais) {
        this.codPais = codPais;
    }

	public int getTienda() {
		return tienda;
	}

	public void setTienda(int tienda) {
		this.tienda = tienda;
	}
    
    

    
}
