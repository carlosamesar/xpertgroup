package com.gco.siconline.dto;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;

public class PageRequestDTO {

    protected Integer requestPages;
    protected Integer numberOfRows;
    protected PageRequest page;
    protected String usuario;

    public Integer getRequestPages() {
        return requestPages;
    }

    public void setRequestPages(Integer requestPages) {
        this.requestPages = requestPages;
    }

    public Integer getNumberOfRows() {
        return numberOfRows;
    }

    public void setNumberOfRows(Integer numberOfRows) {
        this.numberOfRows = numberOfRows;
    }

    public PageRequest getPage() {
        if (page == null) {
            page = new PageRequest(requestPages, numberOfRows);
        }
        return page;
    }

    public PageRequest getPage(Sort sort) {
        if (page == null) {
            page = new PageRequest(requestPages, numberOfRows, sort);
        }
        return page;
    }

    public void setPage(PageRequest page) {
        this.page = page;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

}
