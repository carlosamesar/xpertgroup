/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gco.siconline.dto.vtex;

import java.util.ArrayList;
import java.util.List;

/**
 * DTO para la respuesta de detalle de atributos de una referencia
 * @author besmart
 */
public class DetalleAtributosReferenciaDto {
    
    private String idReferencia;
    private String codigoReferencia;
    private List<AtributoReferenciaDto> atributos;
    private List<CanalReferenciaDto> canales;
    
    public DetalleAtributosReferenciaDto() {
        this.atributos = new ArrayList<>();
        this.canales = new ArrayList<>();
    }

    public DetalleAtributosReferenciaDto(String idReferencia, String codigoReferencia) {
        this.idReferencia = idReferencia;
        this.codigoReferencia = codigoReferencia;
        this.atributos = new ArrayList<>();
        this.canales = new ArrayList<>();
    }

    public String getIdReferencia() {
        return idReferencia;
    }

    public void setIdReferencia(String idReferencia) {
        this.idReferencia = idReferencia;
    }

    public String getCodigoReferencia() {
        return codigoReferencia;
    }

    public void setCodigoReferencia(String codigoReferencia) {
        this.codigoReferencia = codigoReferencia;
    }

    public List<AtributoReferenciaDto> getAtributos() {
        return atributos;
    }

    public void setAtributos(List<AtributoReferenciaDto> atributos) {
        this.atributos = atributos;
    }

    public List<CanalReferenciaDto> getCanales() {
        return canales;
    }

    public void setCanales(List<CanalReferenciaDto> canales) {
        this.canales = canales;
    }
}
