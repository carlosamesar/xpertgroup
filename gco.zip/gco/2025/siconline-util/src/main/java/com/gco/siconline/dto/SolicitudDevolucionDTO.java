package com.gco.siconline.dto;

import java.util.Date;
import java.util.List;

import com.gco.siconline.enums.EstadosSolicitudDevolucion;

public class SolicitudDevolucionDTO {

    private Integer codSolicitud;
    private String codDynamic;
    private String numPedido;
    private String codTercero;
    private DesTerceroMaeDTO desTerceroMae;
    private Integer codEmpresa;
    private String codProveedorRef;
    private Date fecCreacion;
    private String numOrdenCompra;
    private String codEstado;
    private EstadosSolicitudDevolucion nombreEstado;
    private String codUsuario;
    private String nombreUsuario;
    private String numNit;
    private String DNA;
    private String devFlete;
    private String numPedidoCambio;


    private List<SolicitudDevolucionDetalleDTO> listaDetalleSolicitud;

    public Integer getCodSolicitud() {
        return codSolicitud;
    }

    public void setCodSolicitud(Integer codSolicitud) {
        this.codSolicitud = codSolicitud;
    }

    public String getNumPedido() {
        return numPedido;
    }

    public void setNumPedido(String numPedido) {
        this.numPedido = numPedido;
    }

    public String getCodTercero() {
        return codTercero;
    }

    public void setCodTercero(String codTercero) {
        this.codTercero = codTercero;
    }

    public String getCodProveedorRef() {
        return codProveedorRef;
    }

    public void setCodProveedorRef(String codProveedorRef) {
        this.codProveedorRef = codProveedorRef;
    }

    public Date getFecCreacion() {
        return fecCreacion;
    }

    public void setFecCreacion(Date fecCreacion) {
        this.fecCreacion = fecCreacion;
    }

    public String getNumOrdenCompra() {
        return numOrdenCompra;
    }

    public void setNumOrdenCompra(String numOrdenCompra) {
        this.numOrdenCompra = numOrdenCompra;
    }

    public String getCodEstado() {
        return codEstado;
    }

    public void setCodEstado(String codEstado) {
        this.codEstado = codEstado;
    }

    public String getCodUsuario() {
        return codUsuario;
    }

    public void setCodUsuario(String codUsuario) {
        this.codUsuario = codUsuario;
    }

    public String getCodDynamic() {
        return codDynamic;
    }

    public void setCodDynamic(String codDynamic) {
        this.codDynamic = codDynamic;
    }

    public List<SolicitudDevolucionDetalleDTO> getListaDetalleSolicitud() {
        return listaDetalleSolicitud;
    }

    public void setListaDetalleSolicitud(List<SolicitudDevolucionDetalleDTO> listaDetalleSolicitud) {
        this.listaDetalleSolicitud = listaDetalleSolicitud;
    }

    public Integer getCodEmpresa() {
        return codEmpresa;
    }

    public void setCodEmpresa(Integer codEmpresa) {
        this.codEmpresa = codEmpresa;
    }

    public EstadosSolicitudDevolucion getNombreEstado() {
        return nombreEstado;
    }

    public void setNombreEstado(EstadosSolicitudDevolucion nombreEstado) {
        this.nombreEstado = nombreEstado;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public DesTerceroMaeDTO getDesTerceroMae() {
        return desTerceroMae;
    }

    public void setDesTerceroMae(DesTerceroMaeDTO desTerceroMae) {
        this.desTerceroMae = desTerceroMae;
    }

    public String getNumNit() {
        return numNit;
    }

    public void setNumNit(String numNit) {
        this.numNit = numNit;
    }

	public String getDNA() {
		return DNA;
	}

	public void setDNA(String dNA) {
		DNA = dNA;
	}

	public String getDevFlete() {
		return devFlete;
	}

	public void setDevFlete(String devFlete) {
		this.devFlete = devFlete;
	}

	public String getNumPedidoCambio() {
		return numPedidoCambio;
	}

	public void setNumPedidoCambio(String numPedidoCambio) {
		this.numPedidoCambio = numPedidoCambio;
	}

	

	
}
