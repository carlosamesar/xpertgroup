package com.gco.siconline.dto;

import java.math.BigDecimal;

public class ReferenciaKardexDTO {
	private int codEmpresa;
	private String codTercero;
	private String codReferencia;
	private String tipTalla;
	private String codColor;
	private String indCalidad;
	private String codPlu;
	private int canExistencia;
	private int canEntrada;
	private int canSalida;
	private BigDecimal valCostopromedio;
	private BigDecimal valUltimocosto;
	private int numOrden;
	private int canExistant;
	private String desRutalogo;
	private String codProveedoref;
	private String codUbicacion;
	private BigDecimal costo;
	private BigDecimal lista;
	private BigDecimal pvp;
	private int disponible;

	public ReferenciaKardexDTO() {
	}

	public Integer getCodEmpresa() {
		return codEmpresa;
	}

	public void setCodEmpresa(Integer codEmpresa) {
		this.codEmpresa = codEmpresa;
	}

	public String getCodTercero() {
		return codTercero;
	}

	public void setCodTercero(String codTercero) {
		this.codTercero = codTercero;
	}

	public String getCodReferencia() {
		return codReferencia;
	}

	public void setCodReferencia(String codReferencia) {
		this.codReferencia = codReferencia;
	}

	public String getTipTalla() {
		return tipTalla;
	}

	public void setTipTalla(String tipTalla) {
		this.tipTalla = tipTalla;
	}

	public String getCodColor() {
		return codColor;
	}

	public void setCodColor(String codColor) {
		this.codColor = codColor;
	}

	public String getIndCalidad() {
		return indCalidad;
	}

	public void setIndCalidad(String indCalidad) {
		this.indCalidad = indCalidad;
	}

	public String getCodPlu() {
		return codPlu;
	}

	public void setCodPlu(String codPlu) {
		this.codPlu = codPlu;
	}

	public Integer getCanExistencia() {
		return canExistencia;
	}

	public void setCanExistencia(Integer canExistencia) {
		this.canExistencia = canExistencia;
	}

	public Integer getCanEntrada() {
		return canEntrada;
	}

	public void setCanEntrada(Integer canEntrada) {
		this.canEntrada = canEntrada;
	}

	public Integer getCanSalida() {
		return canSalida;
	}

	public void setCanSalida(Integer canSalida) {
		this.canSalida = canSalida;
	}

	public BigDecimal getValCostopromedio() {
		return valCostopromedio;
	}

	public void setValCostopromedio(BigDecimal valCostopromedio) {
		this.valCostopromedio = valCostopromedio;
	}

	public BigDecimal getValUltimocosto() {
		return valUltimocosto;
	}

	public void setValUltimocosto(BigDecimal valUltimocosto) {
		this.valUltimocosto = valUltimocosto;
	}

	public Integer getNumOrden() {
		return numOrden;
	}

	public void setNumOrden(Integer numOrden) {
		this.numOrden = numOrden;
	}

	public Integer getCanExistant() {
		return canExistant;
	}

	public void setCanExistant(Integer canExistant) {
		this.canExistant = canExistant;
	}

	public String getDesRutalogo() {
		return desRutalogo;
	}

	public void setDesRutalogo(String desRutalogo) {
		this.desRutalogo = desRutalogo;
	}

	public String getCodProveedoref() {
		return codProveedoref;
	}

	public void setCodProveedoref(String codProveedoref) {
		this.codProveedoref = codProveedoref;
	}

	public String getCodUbicacion() {
		return codUbicacion;
	}

	public void setCodUbicacion(String codUbicacion) {
		this.codUbicacion = codUbicacion;
	}

	public BigDecimal getCosto() {
		return costo;
	}

	public void setCosto(BigDecimal costo) {
		this.costo = costo;
	}

	public BigDecimal getLista() {
		return lista;
	}

	public void setLista(BigDecimal lista) {
		this.lista = lista;
	}

	public BigDecimal getPvp() {
		return pvp;
	}

	public void setPvp(BigDecimal pvp) {
		this.pvp = pvp;
	}

	public Integer getDisponible() {
		return disponible;
	}

	public void setDisponible(Integer disponible) {
		this.disponible = disponible;
	}

}
