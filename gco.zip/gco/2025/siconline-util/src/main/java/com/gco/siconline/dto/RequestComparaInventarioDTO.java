package com.gco.siconline.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RequestComparaInventarioDTO extends PageRequestDTO {

    protected Integer toma;
    protected boolean isKardex;
    protected String usuario;

    public Integer getToma() {
        return toma;
    }

    public void setToma(Integer toma) {
        this.toma = toma;
    }

    public boolean isKardex() {
        return isKardex;
    }

    public void setKardex(boolean isKardex) {
        this.isKardex = isKardex;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

}
