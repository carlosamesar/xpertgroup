package com.gco.siconline.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AlmacenarBonoDTO {

    private String codTercero;
    private String nomTercero;
    private String nitTercero;
    private String numPedido;
    private String marca;
    private String nitEmpresa;
    private String nombreEmpresa;
    private String consecutivo;
    private String fechaElaboracion;
    private String formasPago;
    private double totalPagado;

    List<DetalleBonoDTO> listBonos;
    List<FormaPagoRequest> listFormas;

    public String getCodTercero() {
        return codTercero;
    }

    public void setCodTercero(String codTercero) {
        this.codTercero = codTercero;
    }

    public String getNomTercero() {
        return nomTercero;
    }

    public void setNomTercero(String nomTercero) {
        this.nomTercero = nomTercero;
    }

    public String getNitTercero() {
        return nitTercero;
    }

    public void setNitTercero(String nitTercero) {
        this.nitTercero = nitTercero;
    }

    public String getNumPedido() {
        return numPedido;
    }

    public void setNumPedido(String numPedido) {
        this.numPedido = numPedido;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public List<DetalleBonoDTO> getListBonos() {
        return listBonos;
    }

    public void setListBonos(List<DetalleBonoDTO> listBonos) {
        this.listBonos = listBonos;
    }

    public List<FormaPagoRequest> getListFormas() {
        return listFormas;
    }

    public void setListFormas(List<FormaPagoRequest> listFormas) {
        this.listFormas = listFormas;
    }

    public String getNitEmpresa() {
        return nitEmpresa;
    }

    public void setNitEmpresa(String nitEmpresa) {
        this.nitEmpresa = nitEmpresa;
    }

    public String getConsecutivo() {
        return consecutivo;
    }

    public void setConsecutivo(String consecutivo) {
        this.consecutivo = consecutivo;
    }

    public String getFechaElaboracion() {
        return fechaElaboracion;
    }

    public void setFechaElaboracion(String fechaElaboracion) {
        this.fechaElaboracion = fechaElaboracion;
    }

    public String getFormasPago() {
        return formasPago;
    }

    public void setFormasPago(String formasPago) {
        this.formasPago = formasPago;
    }

    public String getNombreEmpresa() {
        return nombreEmpresa;
    }

    public void setNombreEmpresa(String nombreEmpresa) {
        this.nombreEmpresa = nombreEmpresa;
    }

    public double getTotalPagado() {
        return totalPagado;
    }

    public void setTotalPagado(double totalPagado) {
        this.totalPagado = totalPagado;
    }

}
