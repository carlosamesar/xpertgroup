/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gco.siconline.dto;

import java.math.BigDecimal;

/**
 *
 * @author besmart
 */
public class NuevoKardexDTO {
    
    private String plu;
    private Integer canExistencia;
    private BigDecimal costoPromedio;

    
    public String getPlu() {
        return plu;
    }

    public void setPlu(String plu) {
        this.plu = plu;
    }
    
    public Integer getCanExistencia() {
        return canExistencia;
    }

    public void setCanExistencia(Integer canExistencia) {
        this.canExistencia = canExistencia;
    }

    public BigDecimal getCostoPromedio() {
        return costoPromedio;
    }

    public void setCostoPromedio(BigDecimal costoPromedio) {
        this.costoPromedio = costoPromedio;
    }
    
    
}
