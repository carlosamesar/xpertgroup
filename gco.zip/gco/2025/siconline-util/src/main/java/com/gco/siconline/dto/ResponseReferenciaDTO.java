package com.gco.siconline.dto;

public class ResponseReferenciaDTO {

    protected String codReferencia;
    protected Long cantidad;

    public ResponseReferenciaDTO() {
    }

    public ResponseReferenciaDTO(String codigo, Long cantidad) {
        super();
        this.codReferencia = codigo;
        this.cantidad = cantidad;
    }

    public String getCodReferencia() {
        return codReferencia;
    }

    public void setCodReferencia(String codReferencia) {
        this.codReferencia = codReferencia;
    }

    public Long getCantidad() {
        return cantidad;
    }

    public void setCantidad(Long cantidad) {
        this.cantidad = cantidad;
    }

}
