/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gco.siconline.dto;

/**
 *
 * @author besmart
 */
public class UbicacionSortingIncompletosDto {
    
    private String ubicacionDestino;
    private String canastaDestino;
    private String pedido;
    private String proveedor;
    private String sio;
    private Integer idDetPedido;
    private String plu;
    private String ubicacionOrigen;
    private String canastaOrigen;
    private Integer codRespuesta;
    private String mensaje;
    private String estado;
    
    
    public String getUbicacionDestino() {
        return ubicacionDestino;
    }

    public void setUbicacionDestino(String ubicacionDestino) {
        this.ubicacionDestino = ubicacionDestino;
    }

    public String getCanastaDestino() {
        return canastaDestino;
    }

    public void setCanastaDestino(String canastaDestino) {
        this.canastaDestino = canastaDestino;
    }

    public String getPlu() {
        return plu;
    }

    public void setPlu(String plu) {
        this.plu = plu;
    }

    
    public String getPedido() {
        return pedido;
    }

    public void setPedido(String pedido) {
        this.pedido = pedido;
    }

    public String getProveedor() {
        return proveedor;
    }

    public void setProveedor(String proveedor) {
        this.proveedor = proveedor;
    }

    public String getSio() {
        return sio;
    }

    public void setSio(String sio) {
        this.sio = sio;
    }

    public Integer getIdDetPedido() {
        return idDetPedido;
    }

    public void setIdDetPedido(Integer idDetPedido) {
        this.idDetPedido = idDetPedido;
    }

    public String getUbicacionOrigen() {
        return ubicacionOrigen;
    }

    public void setUbicacionOrigen(String ubicacionOrigen) {
        this.ubicacionOrigen = ubicacionOrigen;
    }

    public String getCanastaOrigen() {
        return canastaOrigen;
    }

    public void setCanastaOrigen(String canastaOrigen) {
        this.canastaOrigen = canastaOrigen;
    }

    public Integer getCodRespuesta() {
        return codRespuesta;
    }

    public void setCodRespuesta(Integer codRespuesta) {
        this.codRespuesta = codRespuesta;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    
    
}
