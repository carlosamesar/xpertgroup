package com.gco.siconline.dto;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Timestamp;

public class ConsultaDevConsolidadotDTO {
	String numDevolucion;
	String fecha;
	String nomObservacion;
	String numOrdencompra;
	String factura;
	String flete;
	BigInteger numGuia;
	String codClaseped;
	String cedula;
	String nomRazonsocial;
	BigInteger numCantidad;
	BigDecimal valDev;
	String codFormaPago;
	String nomFormaPago;
	String codFormaPagoDev;
	String nomFormaPagoDev;
	BigDecimal valFlete;
	BigDecimal valDevSinIva;
	String horMovimientoDev;
	public String getNumDevolucion() {
		return numDevolucion;
	}
	public void setNumDevolucion(String numDevolucion) {
		this.numDevolucion = numDevolucion;
	}
	public String getFecha() {
		return fecha;
	}
	public void setFecha(String fecha) {
		this.fecha = fecha;
	}
	public String getNomObservacion() {
		return nomObservacion;
	}
	public void setNomObservacion(String nomObservacion) {
		this.nomObservacion = nomObservacion;
	}
	public String getNumOrdencompra() {
		return numOrdencompra;
	}
	public void setNumOrdencompra(String numOrdencompra) {
		this.numOrdencompra = numOrdencompra;
	}
	public String getFactura() {
		return factura;
	}
	public void setFactura(String factura) {
		this.factura = factura;
	}
	public String getFlete() {
		return flete;
	}
	public void setFlete(String flete) {
		this.flete = flete;
	}
	public BigInteger getNumGuia() {
		return numGuia;
	}
	public void setNumGuia(BigInteger numGuia) {
		this.numGuia = numGuia;
	}
	public String getCodClaseped() {
		return codClaseped;
	}
	public void setCodClaseped(String codClaseped) {
		this.codClaseped = codClaseped;
	}
	public String getCedula() {
		return cedula;
	}
	public void setCedula(String cedula) {
		this.cedula = cedula;
	}
	public String getNomRazonsocial() {
		return nomRazonsocial;
	}
	public void setNomRazonsocial(String nomRazonsocial) {
		this.nomRazonsocial = nomRazonsocial;
	}
	public BigInteger getNumCantidad() {
		return numCantidad;
	}
	public void setNumCantidad(BigInteger numCantidad) {
		this.numCantidad = numCantidad;
	}
	public BigDecimal getValDev() {
		return valDev;
	}
	public void setValDev(BigDecimal valDev) {
		this.valDev = valDev;
	}
	public String getCodFormaPago() {
		return codFormaPago;
	}
	public void setCodFormaPago(String codFormaPago) {
		this.codFormaPago = codFormaPago;
	}
	public String getNomFormaPago() {
		return nomFormaPago;
	}
	public void setNomFormaPago(String nomFormaPago) {
		this.nomFormaPago = nomFormaPago;
	}
	public String getCodFormaPagoDev() {
		return codFormaPagoDev;
	}
	public void setCodFormaPagoDev(String codFormaPagoDev) {
		this.codFormaPagoDev = codFormaPagoDev;
	}
	public String getNomFormaPagoDev() {
		return nomFormaPagoDev;
	}
	public void setNomFormaPagoDev(String nomFormaPagoDev) {
		this.nomFormaPagoDev = nomFormaPagoDev;
	}
	public BigDecimal getValFlete() {
		return valFlete;
	}
	public void setValFlete(BigDecimal valFlete) {
		this.valFlete = valFlete;
	}
	public BigDecimal getValDevSinIva() {
		return valDevSinIva;
	}
	public void setValDevSinIva(BigDecimal valDevSinIva) {
		this.valDevSinIva = valDevSinIva;
	}
	public String getHorMovimientoDev() {
		return horMovimientoDev;
	}
	public void setHorMovimientoDev(String horMovimientoDev) {
		this.horMovimientoDev = horMovimientoDev;
	}
	
	
	
}
