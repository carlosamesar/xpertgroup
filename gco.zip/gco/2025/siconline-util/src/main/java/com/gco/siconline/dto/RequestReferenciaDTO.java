package com.gco.siconline.dto;

public class RequestReferenciaDTO {

    protected Integer codEmpresa;

    protected String codBodega;

    protected String tipTercerobod;

    protected String codReferencia;

    protected String codProveedoref;

    public Integer getCodEmpresa() {
        return codEmpresa;
    }

    public void setCodEmpresa(Integer codEmpresa) {
        this.codEmpresa = codEmpresa;
    }

    public String getCodBodega() {
        return codBodega;
    }

    public void setCodBodega(String codBodega) {
        this.codBodega = codBodega;
    }

    public String getTipTercerobod() {
        return tipTercerobod;
    }

    public void setTipTercerobod(String tipTercerobod) {
        this.tipTercerobod = tipTercerobod;
    }

    public String getCodReferencia() {
        return codReferencia;
    }

    public void setCodReferencia(String codReferencia) {
        this.codReferencia = codReferencia;
    }

    public String getCodProveedoref() {
        return codProveedoref;
    }

    public void setCodProveedoref(String codProveedoref) {
        this.codProveedoref = codProveedoref;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result
                + ((codBodega == null) ? 0 : codBodega.hashCode());
        result = prime * result
                + ((codEmpresa == null) ? 0 : codEmpresa.hashCode());
        result = prime * result
                + ((codProveedoref == null) ? 0 : codProveedoref.hashCode());
        result = prime * result
                + ((codReferencia == null) ? 0 : codReferencia.hashCode());
        result = prime * result
                + ((tipTercerobod == null) ? 0 : tipTercerobod.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        RequestReferenciaDTO other = (RequestReferenciaDTO) obj;
        if (codBodega == null) {
            if (other.codBodega != null) {
                return false;
            }
        } else if (!codBodega.equals(other.codBodega)) {
            return false;
        }
        if (codEmpresa == null) {
            if (other.codEmpresa != null) {
                return false;
            }
        } else if (!codEmpresa.equals(other.codEmpresa)) {
            return false;
        }
        if (codProveedoref == null) {
            if (other.codProveedoref != null) {
                return false;
            }
        } else if (!codProveedoref.equals(other.codProveedoref)) {
            return false;
        }
        if (codReferencia == null) {
            if (other.codReferencia != null) {
                return false;
            }
        } else if (!codReferencia.equals(other.codReferencia)) {
            return false;
        }
        if (tipTercerobod == null) {
            if (other.tipTercerobod != null) {
                return false;
            }
        } else if (!tipTercerobod.equals(other.tipTercerobod)) {
            return false;
        }
        return true;
    }

}
