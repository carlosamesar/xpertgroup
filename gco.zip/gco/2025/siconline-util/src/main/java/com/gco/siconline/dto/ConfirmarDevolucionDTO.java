package com.gco.siconline.dto;

import java.util.List;

public class ConfirmarDevolucionDTO {

	private String codDynamic;
	private String numPedido;
	List<DetDevolucionPluDTO> listPlu;

	public String getCodDynamic() {
		return codDynamic;
	}

	public void setCodDynamic(String codDynamic) {
		this.codDynamic = codDynamic;
	}

	public String getNumPedido() {
		return numPedido;
	}

	public void setNumPedido(String numPedido) {
		this.numPedido = numPedido;
	}

	public List<DetDevolucionPluDTO> getListPlu() {
		return listPlu;
	}

	public void setListPlu(List<DetDevolucionPluDTO> listPlu) {
		this.listPlu = listPlu;
	}


	
	
}
