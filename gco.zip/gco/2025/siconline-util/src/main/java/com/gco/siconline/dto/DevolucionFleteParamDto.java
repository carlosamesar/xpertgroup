/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gco.siconline.dto;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author besmart
 */
public class DevolucionFleteParamDto {
    
    private Timestamp fechaIniDevolucion;
    private Timestamp fechaFinDevolucion;
    private String codTercero;
    private String numPedido;
    private List<String> listMarcas = new ArrayList<String>();

    public Timestamp getFechaIniDevolucion() {
        return fechaIniDevolucion;
    }

    public void setFechaIniDevolucion(Timestamp fechaIniDevolucion) {
        this.fechaIniDevolucion = fechaIniDevolucion;
    }

    public Timestamp getFechaFinDevolucion() {
        return fechaFinDevolucion;
    }

    public void setFechaFinDevolucion(Timestamp fechaFinDevolucion) {
        this.fechaFinDevolucion = fechaFinDevolucion;
    }

    public String getCodTercero() {
        return codTercero;
    }

    public void setCodTercero(String codTercero) {
        this.codTercero = codTercero;
    }

    public String getNumPedido() {
        return numPedido;
    }

    public void setNumPedido(String numPedido) {
        this.numPedido = numPedido;
    }

    public List<String> getListMarcas() {
        return listMarcas;
    }

    public void setListMarcas(List<String> listMarcas) {
        this.listMarcas = listMarcas;
    }
    
    
    
}
