/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gco.siconline.dto;

import com.fasterxml.jackson.annotation.JsonSetter;
import java.math.BigInteger;

/**
 *
 * @author besmart
 */
public class PedidoTrasladoDTO {
    
    private String codTercero;
    private String codPlu;
    private String codReferencia;
    private String tipTalla;
    private String codColor;
    private BigInteger cantidad;
    

    public String getCodPlu() {
        return codPlu;
    }
    
    @JsonSetter("EAN13")
    public void setCodPlu(String codPlu) {
        this.codPlu = codPlu;
    }

    public String getCodReferencia() {
        return codReferencia;
    }
    
    @JsonSetter("REFERENCIA")
    public void setCodReferencia(String codReferencia) {
        this.codReferencia = codReferencia;
    }

    public String getTipTalla() {
        return tipTalla;
    }
    
    @JsonSetter("TALLA")
    public void setTipTalla(String tipTalla) {
        this.tipTalla = tipTalla;
    }
    
    @JsonSetter("COLOR")
    public String getCodColor() {
        return codColor;
    }

    public void setCodColor(String codColor) {
        this.codColor = codColor;
    }
    
    public String getCodTercero() {
        return codTercero;
    }
    
    @JsonSetter("TERCERO DESTINO")
    public void setCodTercero(String codTercero) {
        this.codTercero = codTercero;
    }

    
    public BigInteger getCantidad() {
        return cantidad;
    }
    
    @JsonSetter("CANTIDAD")
    public void setCantidad(BigInteger cantidad) {
        this.cantidad = cantidad;
    }
    
    
    
}
