/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gco.siconline.dto.pedidosico;

/**
 *
 * @author alejandrotamayo
 */
public class Customizacion {
    
    private Descripcion descripcion;
    private String referencia;
    private String sku;
    private String plu;

    public Descripcion getDescripcion() {
    return descripcion;
    }

    public void setDescripcion(Descripcion descripcion) {
    this.descripcion = descripcion;
    }

    public String getReferencia() {
    return referencia;
    }

    public void setReferencia(String referencia) {
    this.referencia = referencia;
    }

    public String getSku() {
    return sku;
    }

    public void setSku(String sku) {
    this.sku = sku;
    }

    public String getPlu() {
        return plu;
    }

    public void setPlu(String plu) {
        this.plu = plu;
    }
    
    
    
}
