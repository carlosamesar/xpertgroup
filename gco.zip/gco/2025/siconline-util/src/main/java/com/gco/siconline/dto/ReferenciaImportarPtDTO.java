/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gco.siconline.dto;

import java.math.BigDecimal;

/**
 *
 * @author alejandrotamayo
 */
public class ReferenciaImportarPtDTO {

    private Integer codEmpresa;
    private String codConcepto;
    private String numMovimiento;
    private String codDocumento;
    private String indAplicacion;
    private String codTercero;
    private String codReferencia;
    private BigDecimal valUnidad;
    private Integer numCantidad;
    private BigDecimal valPublico;
    private String nomReferenciaexp;
    private String codRefarancel;
    private String codProveedoref;
    private BigDecimal valTotal;
    private BigDecimal valLista;
    private String numLinea;
    private String tipProducto;
    private Integer numAno;
    private String nomNombrecomercia;

    public Integer getCodEmpresa() {
        return codEmpresa;
    }

    public void setCodEmpresa(Integer codEmpresa) {
        this.codEmpresa = codEmpresa;
    }

    public String getCodConcepto() {
        return codConcepto;
    }

    public void setCodConcepto(String codConcepto) {
        this.codConcepto = codConcepto;
    }

    public String getNumMovimiento() {
        return numMovimiento;
    }

    public void setNumMovimiento(String numMovimiento) {
        this.numMovimiento = numMovimiento;
    }

    public String getCodDocumento() {
        return codDocumento;
    }

    public void setCodDocumento(String codDocumento) {
        this.codDocumento = codDocumento;
    }

    public String getIndAplicacion() {
        return indAplicacion;
    }

    public void setIndAplicacion(String indAplicacion) {
        this.indAplicacion = indAplicacion;
    }

    public String getCodTercero() {
        return codTercero;
    }

    public void setCodTercero(String codTercero) {
        this.codTercero = codTercero;
    }

    public String getCodReferencia() {
        return codReferencia;
    }

    public void setCodReferencia(String codReferencia) {
        this.codReferencia = codReferencia;
    }

    public BigDecimal getValUnidad() {
        return valUnidad;
    }

    public void setValUnidad(BigDecimal valUnidad) {
        this.valUnidad = valUnidad;
    }

    public Integer getNumCantidad() {
        return numCantidad;
    }

    public void setNumCantidad(Integer numCantidad) {
        this.numCantidad = numCantidad;
    }

    public BigDecimal getValPublico() {
        return valPublico;
    }

    public void setValPublico(BigDecimal valPublico) {
        this.valPublico = valPublico;
    }

    public String getNomReferenciaexp() {
        return nomReferenciaexp;
    }

    public void setNomReferenciaexp(String nomReferenciaexp) {
        this.nomReferenciaexp = nomReferenciaexp;
    }

    public String getCodRefarancel() {
        return codRefarancel;
    }

    public void setCodRefarancel(String codRefarancel) {
        this.codRefarancel = codRefarancel;
    }

    public String getCodProveedoref() {
        return codProveedoref;
    }

    public void setCodProveedoref(String codProveedoref) {
        this.codProveedoref = codProveedoref;
    }

    public BigDecimal getValTotal() {
        return valTotal;
    }

    public void setValTotal(BigDecimal valTotal) {
        this.valTotal = valTotal;
    }

    public BigDecimal getValLista() {
        return valLista;
    }

    public void setValLista(BigDecimal valLista) {
        this.valLista = valLista;
    }

    public String getNumLinea() {
        return numLinea;
    }

    public void setNumLinea(String numLinea) {
        this.numLinea = numLinea;
    }

    public String getTipProducto() {
        return tipProducto;
    }

    public void setTipProducto(String tipProducto) {
        this.tipProducto = tipProducto;
    }

    public Integer getNumAno() {
        return numAno;
    }

    public void setNumAno(Integer numAno) {
        this.numAno = numAno;
    }

    public String getNomNombrecomercia() {
        return nomNombrecomercia;
    }

    public void setNomNombrecomercia(String nomNombrecomercia) {
        this.nomNombrecomercia = nomNombrecomercia;
    }

}
