package com.gco.siconline.dto;

import com.gco.siconline.enums.TipoOperacionEnum;

public class RequestRegisterPickingDTO extends RequestControlDetalleDTO {

    protected TipoOperacionEnum tipoOperacion;
    protected String proveedor;
    protected String plu;
    protected String ubicacionOri;
    protected String canastaOri;
    protected String ubicacionDest;
    protected String canastaDest;
    protected Integer cantidad;

    public TipoOperacionEnum getTipoOperacion() {
        return tipoOperacion;
    }

    public void setTipoOperacion(TipoOperacionEnum tipoOperacion) {
        this.tipoOperacion = tipoOperacion;
    }

    public String getProveedor() {
        return proveedor;
    }

    public void setProveedor(String proveedor) {
        this.proveedor = proveedor;
    }

    public String getPlu() {
        return plu;
    }

    public void setPlu(String plu) {
        this.plu = plu;
    }

    public String getUbicacionOri() {
        return ubicacionOri;
    }

    public void setUbicacionOri(String ubicacionOri) {
        this.ubicacionOri = ubicacionOri;
    }

    public String getCanastaOri() {
        return canastaOri;
    }

    public void setCanastaOri(String canastOri) {
        this.canastaOri = canastOri;
    }

    public String getUbicacionDest() {
        return ubicacionDest;
    }

    public void setUbicacionDest(String ubicacionDest) {
        this.ubicacionDest = ubicacionDest;
    }

    public String getCanastaDest() {
        return canastaDest;
    }

    public void setCanastaDest(String canastaDest) {
        this.canastaDest = canastaDest;
    }

    public Integer getCantidad() {
        return cantidad;
    }

    public void setCantidad(Integer cantidad) {
        this.cantidad = cantidad;
    }
}
