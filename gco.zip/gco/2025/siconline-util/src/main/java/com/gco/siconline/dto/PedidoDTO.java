package com.gco.siconline.dto;

import com.fasterxml.jackson.annotation.JsonSetter;
import java.math.BigDecimal;
import java.math.BigInteger;

public class PedidoDTO {

    private Integer codEmpresa;

    private String codDocumento;

    private String indAplicacion;

    private String codConcepto;

    private String codTercero;

    private String tipTercero;

    private String numPedido;

    /**
     * Atributos faltantes reporte ciclopedido *
     */
    private BigInteger canPedida;

    private BigInteger cantidad;

    private BigInteger cantFacturada;

    private String codOleada;

    private String numMovimiento;

    private BigInteger numGuia;

    private String horaPedido;

    private String fechaOleada;

    private String fechaAsignacion;

    private String fechaInicioPicking;

    private String fechaFinPicking;

    private String fechaFactura;

    private String codProveedoref;

    private String codPlu;

    private String codReferencia;

    private String tipTalla;

    private String codColor;
    private String numSio;
    private String estPedido;
    private Integer idDpedido;
    private String codClasePed;
    
    private String idDelivery; // pedido MNG

    /**
     * Atributo observación para anulación de pedidos
     */
    private String observacion;

    private BigDecimal valUnidad;

    /**
     * Tipo de envío para saber qué consecutivo de guías otener
     *
     */
    private Integer tipoEnvio;

    public Integer getCodEmpresa() {
        return codEmpresa;
    }

    public void setCodEmpresa(Integer codEmpresa) {
        this.codEmpresa = codEmpresa;
    }

    public String getCodDocumento() {
        return codDocumento;
    }

    public void setCodDocumento(String codDocumento) {
        this.codDocumento = codDocumento;
    }

    public String getIndAplicacion() {
        return indAplicacion;
    }

    public void setIndAplicacion(String indAplicacion) {
        this.indAplicacion = indAplicacion;
    }

    public String getCodConcepto() {
        return codConcepto;
    }

    public void setCodConcepto(String codConcepto) {
        this.codConcepto = codConcepto;
    }

    public String getCodTercero() {
        return codTercero;
    }

    public void setCodTercero(String codTercero) {
        this.codTercero = codTercero;
    }

    public String getTipTercero() {
        return tipTercero;
    }

    public void setTipTercero(String tipTercero) {
        this.tipTercero = tipTercero;
    }

    /**
     * Set y get Reporte ciclo pedido
     */
    public String getNumPedido() {
        return numPedido;
    }

    public void setNumPedido(String numPedido) {
        this.numPedido = numPedido;
    }

    public BigInteger getCanPedida() {
        return canPedida;
    }

    public void setCanPedida(BigInteger canPedida) {
        this.canPedida = canPedida;
    }

    public BigInteger getCantidad() {
        return cantidad;
    }

    @JsonSetter("CANTIDAD")
    public void setCantidad(BigInteger cantidad) {
        this.cantidad = cantidad;
    }

    public BigInteger getCantFacturada() {
        return cantFacturada;
    }

    public void setCantFacturada(BigInteger cantFacturada) {
        this.cantFacturada = cantFacturada;
    }

    public String getCodOleada() {
        return codOleada;
    }

    public void setCodOleada(String codOleada) {
        this.codOleada = codOleada;
    }

    public String getNumMovimiento() {
        return numMovimiento;
    }

    public void setNumMovimiento(String numMovimiento) {
        this.numMovimiento = numMovimiento;
    }

    public BigInteger getNumGuia() {
        return numGuia;
    }

    public void setNumGuia(BigInteger numGuia) {
        this.numGuia = numGuia;
    }

    public String getHoraPedido() {
        return horaPedido;
    }

    public void setHoraPedido(String horaPedido) {
        this.horaPedido = horaPedido;
    }

    public String getFechaOleada() {
        return fechaOleada;
    }

    public void setFechaOleada(String fechaOleada) {
        this.fechaOleada = fechaOleada;
    }

    public String getFechaAsignacion() {
        return fechaAsignacion;
    }

    public void setFechaAsignacion(String fechaAsignacion) {
        this.fechaAsignacion = fechaAsignacion;
    }

    public String getFechaInicioPicking() {
        return fechaInicioPicking;
    }

    public void setFechaInicioPicking(String fechaInicioPicking) {
        this.fechaInicioPicking = fechaInicioPicking;
    }

    public String getFechaFinPicking() {
        return fechaFinPicking;
    }

    public void setFechaFinPicking(String fechaFinPicking) {
        this.fechaFinPicking = fechaFinPicking;
    }

    public String getFechaFactura() {
        return fechaFactura;
    }

    public void setFechaFactura(String fechaFactura) {
        this.fechaFactura = fechaFactura;
    }

    public String getCodPlu() {
        return codPlu;
    }

    @JsonSetter("EAN13")
    public void setCodPlu(String codPlu) {
        this.codPlu = codPlu;
    }

    public String getCodReferencia() {
        return codReferencia;
    }

    @JsonSetter("REFERENCIA")
    public void setCodReferencia(String codReferencia) {
        this.codReferencia = codReferencia;
    }

    public String getTipTalla() {
        return tipTalla;
    }

    @JsonSetter("TALLA")
    public void setTipTalla(String tipTalla) {
        this.tipTalla = tipTalla;
    }

    public String getCodColor() {
        return codColor;
    }

    @JsonSetter("COLOR")
    public void setCodColor(String codColor) {
        this.codColor = codColor;
    }

    public String getNumSio() {
        return numSio;
    }

    public void setNumSio(String numSio) {
        this.numSio = numSio;
    }

    public String getEstPedido() {
        return estPedido;
    }

    public void setEstPedido(String estPedido) {
        this.estPedido = estPedido;
    }

    public String getCodProveedoref() {
        return codProveedoref;
    }

    public void setCodProveedoref(String codProveedoref) {
        this.codProveedoref = codProveedoref;
    }

    public Integer getIdDpedido() {
        return idDpedido;
    }

    public void setIdDpedido(Integer idDpedido) {
        this.idDpedido = idDpedido;
    }

    public String getObservacion() {
        return observacion;
    }

    public void setObservacion(String observacion) {
        this.observacion = observacion;
    }

    public BigDecimal getValUnidad() {
        return valUnidad;
    }

    public void setValUnidad(BigDecimal precio) {
        this.valUnidad = precio;
    }

    public Integer getTipoEnvio() {
        return tipoEnvio;
    }

    public void setTipoEnvio(Integer tipoEnvio) {
        this.tipoEnvio = tipoEnvio;
    }

    public String getCodClasePed() {
        return codClasePed;
    }

    public void setCodClasePed(String codClasePed) {
        this.codClasePed = codClasePed;
    }

    public String getIdDelivery() {
        return idDelivery;
    }

    public void setIdDelivery(String idDelivery) {
        this.idDelivery = idDelivery;
    }
    
    

}
