package com.gco.siconline.enums;

public enum CompraEnum {

	DESCRIPCION_REF("DESCRIPCION REF."),
	CAJA("CAJA"),
	FECHA_FACTURA("FECHA FRA."),
	NUM_FACTURA("Nº FRA."),
	REFERENCIA("REFERENCIA"),
	TALLA("TALLA"),
	COLOR("COLOR"),
	PLU("EAN13"),
	CANTIDAD("UNIDAD PRENDAS"), 
	PRECOSTEO("PRECOSTEO"),
	NUM_SN("Nº SN"),
	ID_DELIVERY("PEDIDO ONLINE")
	;
	private String value;

	private CompraEnum(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
}
