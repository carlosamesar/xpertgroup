package com.gco.siconline.dto;

public class PluConsolidadoDTO {

    protected Integer codEmpresa;

    protected String codOleada;

    protected String codTercero;

    protected String numPedido;

    protected String codPlu;

    protected long numCantidad;

    protected String codBodegaCompra;

    protected String tipEmbalaje;

    public PluConsolidadoDTO() {

    }
    

    public PluConsolidadoDTO(String numPedido, String codPlu, int numCantidad) {
		this.numPedido = numPedido;
		this.codPlu = codPlu;
		this.numCantidad = numCantidad;
	}



	public PluConsolidadoDTO(Integer codEmpresa, String codOleada,
            String codPlu, String tipEmbalaje, long numCantidad) {
        this.codEmpresa = codEmpresa;
        this.codOleada = codOleada;
        this.codPlu = codPlu;
        this.numCantidad = numCantidad;
        this.tipEmbalaje = tipEmbalaje;
    }

    public Integer getCodEmpresa() {
        return codEmpresa;
    }

    public void setCodEmpresa(Integer codEmpresa) {
        this.codEmpresa = codEmpresa;
    }

    public String getCodOleada() {
        return codOleada;
    }

    public void setCodOleada(String codOleada) {
        this.codOleada = codOleada;
    }

    public String getCodTercero() {
        return codTercero;
    }

    public void setCodTercero(String codTercero) {
        this.codTercero = codTercero;
    }

    public String getNumPedido() {
        return numPedido;
    }

    public void setNumPedido(String numPedido) {
        this.numPedido = numPedido;
    }

    public String getCodPlu() {
        return codPlu;
    }

    public void setCodPlu(String codPlu) {
        this.codPlu = codPlu;
    }

    public long getNumCantidad() {
        return numCantidad;
    }

    public void setNumCantidad(long numCantidad) {
        this.numCantidad = numCantidad;
    }

    public String getCodBodegaCompra() {
        return codBodegaCompra;
    }

    public void setCodBodegaCompra(String codBodegaCompra) {
        this.codBodegaCompra = codBodegaCompra;
    }

    public String getTipEmbalaje() {
        return tipEmbalaje;
    }

    public void setTipEmbalaje(String tipEmbalaje) {
        this.tipEmbalaje = tipEmbalaje;
    }

}
