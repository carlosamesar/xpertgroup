/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gco.siconline.dto;

import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author besmart
 */
public class AjusteConsignacionDto {
    
    private String accion;
    private String numConsignacion;
    private String clasePed;
    private String numPedido;
    private Date fechaNueva;
    private BigDecimal montoNuevo;
    private String codFormaPago;

    public String getAccion() {
        return accion;
    }

    public void setAccion(String accion) {
        this.accion = accion;
    }

    public String getNumConsignacion() {
        return numConsignacion;
    }

    public void setNumConsignacion(String numConsignacion) {
        this.numConsignacion = numConsignacion;
    }

    public String getClasePed() {
        return clasePed;
    }

    public void setClasePed(String clasePed) {
        this.clasePed = clasePed;
    }

    public String getNumPedido() {
        return numPedido;
    }

    public void setNumPedido(String numPedido) {
        this.numPedido = numPedido;
    }

    public Date getFechaNueva() {
        return fechaNueva;
    }

    public void setFechaNueva(Date fechaNueva) {
        this.fechaNueva = fechaNueva;
    }

    public BigDecimal getMontoNuevo() {
        return montoNuevo;
    }

    public void setMontoNuevo(BigDecimal montoNuevo) {
        this.montoNuevo = montoNuevo;
    }

    public String getCodFormaPago() {
        return codFormaPago;
    }

    public void setCodFormaPago(String codFormaPago) {
        this.codFormaPago = codFormaPago;
    }
    
}
