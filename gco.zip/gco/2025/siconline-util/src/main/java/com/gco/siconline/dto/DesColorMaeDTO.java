package com.gco.siconline.dto;

public class DesColorMaeDTO {

    private String codColor;

    private Integer codEmpresa;

    private String codUsuario;

    private String indEstado;

    private String nomColor;

    private String nomDescripcion;

    public DesColorMaeDTO(String codColor, Integer codEmpresa, String codUsuario, String indEstado, String nomColor,
            String nomDescripcion) {
        super();
        this.codColor = codColor;
        this.codEmpresa = codEmpresa;
        this.codUsuario = codUsuario;
        this.indEstado = indEstado;
        this.nomColor = nomColor;
        this.nomDescripcion = nomDescripcion;
    }

    public String getCodColor() {
        return codColor;
    }

    public void setCodColor(String codColor) {
        this.codColor = codColor;
    }

    public Integer getCodEmpresa() {
        return codEmpresa;
    }

    public void setCodEmpresa(Integer codEmpresa) {
        this.codEmpresa = codEmpresa;
    }

    public String getCodUsuario() {
        return codUsuario;
    }

    public void setCodUsuario(String codUsuario) {
        this.codUsuario = codUsuario;
    }

    public String getIndEstado() {
        return indEstado;
    }

    public void setIndEstado(String indEstado) {
        this.indEstado = indEstado;
    }

    public String getNomColor() {
        return nomColor;
    }

    public void setNomColor(String nomColor) {
        this.nomColor = nomColor;
    }

    public String getNomDescripcion() {
        return nomDescripcion;
    }

    public void setNomDescripcion(String nomDescripcion) {
        this.nomDescripcion = nomDescripcion;
    }

}
