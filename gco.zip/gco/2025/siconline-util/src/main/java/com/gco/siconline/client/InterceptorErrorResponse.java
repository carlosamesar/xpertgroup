package com.gco.siconline.client;

import java.io.IOException;
import java.nio.charset.Charset;

import org.springframework.http.client.ClientHttpResponse;
import org.springframework.util.StreamUtils;
import org.springframework.web.client.DefaultResponseErrorHandler;
import org.springframework.web.client.ResponseErrorHandler;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gco.siconline.exception.BusinessException;
import com.gco.siconline.exception.TechnicalException;

public class InterceptorErrorResponse implements ResponseErrorHandler {

    private ResponseErrorHandler errorHandler = new DefaultResponseErrorHandler();

    public boolean hasError(ClientHttpResponse response) throws IOException {
        return errorHandler.hasError(response);
    }

    public void handleError(ClientHttpResponse response) throws IOException {
        String responseJson = StreamUtils.copyToString(response.getBody(), Charset.defaultCharset());
        ObjectMapper mapper = new ObjectMapper();
        JsonNode a = mapper.readTree(responseJson);
        try {
            if (a.get("exception") != null) {
                Class<?> exception = Class.forName(a.get("exception").asText());
                if (exception == BusinessException.class) {
                    throw new BusinessException(a.get("code") == null ? "" : a
                            .get("code").asText(), a.get("message").asText());
                } else {
                    throw new TechnicalException(a.get("message").asText());
                }
            } else {
                throw new TechnicalException(a.get("message").asText());
            }
        } catch (ClassNotFoundException e) {
            throw new TechnicalException(a.get("message").asText());
        }

    }
}
