package com.gco.siconline.dto;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class MensajeBD implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;
    private int codigo;
    private String mensaje;
    private HashMap<String, Object> propiedadesAdicionales;

    public MensajeBD() {
        propiedadesAdicionales = new HashMap<String, Object>();
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public Map<String, Object> getPropiedadesAdicionales() {
        return propiedadesAdicionales;
    }

    public void setPropiedadesAdicionales(HashMap<String, Object> propiedadesAdicionales) {
        this.propiedadesAdicionales = propiedadesAdicionales;
    }

    public static long getSerialversionuid() {
        return serialVersionUID;
    }

}
