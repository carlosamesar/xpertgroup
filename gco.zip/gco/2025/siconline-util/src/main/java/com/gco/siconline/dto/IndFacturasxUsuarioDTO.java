/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gco.siconline.dto;

import java.math.BigInteger;

/**
 *
 * @author jeisonz
 */
public class IndFacturasxUsuarioDTO {

    protected String usuario;
    protected BigInteger cantidad;

    public IndFacturasxUsuarioDTO() {
    }

    public IndFacturasxUsuarioDTO(String usuario, BigInteger cantidad) {
        this.usuario = usuario;
        this.cantidad = cantidad;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public BigInteger getCantidad() {
        return cantidad;
    }

    public void setCantidad(BigInteger cantidad) {
        this.cantidad = cantidad;
    }

}
