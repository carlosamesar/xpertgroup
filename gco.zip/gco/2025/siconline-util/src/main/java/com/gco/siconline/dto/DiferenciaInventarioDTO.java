/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gco.siconline.dto;

import java.math.BigDecimal;

/**
 *
 * @author alejandrotamayo
 */
public class DiferenciaInventarioDTO {

    private String codProveedoref;
    private String codReferencia;
    private String tipTalla;
    private String codColor;
    private String indCalidad;
    private String codPlu;
    private Integer karSico;
    private Integer karCanasta;
    private BigDecimal valUnidad;

    public String getCodProveedoref() {
        return codProveedoref;
    }

    public void setCodProveedoref(String codProveedoref) {
        this.codProveedoref = codProveedoref;
    }

    public String getCodReferencia() {
        return codReferencia;
    }

    public void setCodReferencia(String codReferencia) {
        this.codReferencia = codReferencia;
    }

    public String getTipTalla() {
        return tipTalla;
    }

    public void setTipTalla(String tipTalla) {
        this.tipTalla = tipTalla;
    }

    public String getCodColor() {
        return codColor;
    }

    public void setCodColor(String codColor) {
        this.codColor = codColor;
    }

    public String getIndCalidad() {
        return indCalidad;
    }

    public void setIndCalidad(String indCalidad) {
        this.indCalidad = indCalidad;
    }

    public String getCodPlu() {
        return codPlu;
    }

    public void setCodPlu(String codPlu) {
        this.codPlu = codPlu;
    }

    public Integer getKarSico() {
        return karSico;
    }

    public void setKarSico(Integer karSico) {
        this.karSico = karSico;
    }

    public Integer getKarCanasta() {
        return karCanasta;
    }

    public void setKarCanasta(Integer karCanasta) {
        this.karCanasta = karCanasta;
    }

    public BigDecimal getValUnidad() {
        return valUnidad;
    }

    public void setValUnidad(BigDecimal valUnidad) {
        this.valUnidad = valUnidad;
    }

}
