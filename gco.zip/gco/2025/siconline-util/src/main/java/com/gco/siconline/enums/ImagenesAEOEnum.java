package com.gco.siconline.enums;

public enum ImagenesAEOEnum {

	OF("of"), 
	OS("os"),
	OB("ob"), 
	F("f"), 
	B("b"), 
	D1("d1"), 
	D2("d2"), 
	D3("d3"), 
	R("r"), 
	L1("l1");

	private String value;
	
	private ImagenesAEOEnum(String value) {
        this.setValue(value);
    }

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

}
