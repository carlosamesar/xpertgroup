package com.gco.siconline.dto;

import java.util.Date;

public class DetalleBonoDTO {

    private String numMovimiento;
    private String observacion;
    private String concepto;
    private Date fecha;
    private String codReferencia;
    private double valUnidad;
    private String codPlu;
    private int canDespachada;
    private int canPendiente;
    private String nomReferencia;

    public DetalleBonoDTO() {

    }

    public String getNumMovimiento() {
        return numMovimiento;
    }

    public void setNumMovimiento(String numMovimiento) {
        this.numMovimiento = numMovimiento;
    }

    public String getObservacion() {
        return observacion;
    }

    public void setObservacion(String observacion) {
        this.observacion = observacion;
    }

    public String getConcepto() {
        return concepto;
    }

    public void setConcepto(String concepto) {
        this.concepto = concepto;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getCodReferencia() {
        return codReferencia;
    }

    public void setCodReferencia(String codReferencia) {
        this.codReferencia = codReferencia;
    }

    public double getValUnidad() {
        return valUnidad;
    }

    public void setValUnidad(double valUnidad) {
        this.valUnidad = valUnidad;
    }

    public String getCodPlu() {
        return codPlu;
    }

    public void setCodPlu(String codPlu) {
        this.codPlu = codPlu;
    }

    public int getCanDespachada() {
        return canDespachada;
    }

    public void setCanDespachada(int canDespachada) {
        this.canDespachada = canDespachada;
    }

    public int getCanPendiente() {
        return canPendiente;
    }

    public void setCanPendiente(int canPendiente) {
        this.canPendiente = canPendiente;
    }

    public String getNomReferencia() {
        return nomReferencia;
    }

    public void setNomReferencia(String nomReferencia) {
        this.nomReferencia = nomReferencia;
    }

}
