package com.gco.siconline.dto;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Timestamp;

public class ConsultaSolicitudDevDetDTO {
	
	String numDevolucion;
	String fecha;
	String nomObservacion;
	String numOrdencompra;
	String facturaFlete;
	String flete;
	BigInteger numGuia;
	String codClaseped;
	String cedula;
	String nomRazonsocial;
	String codReferencia;
	String tipTalla;
	String codColor;
	String codPlu;
	Integer numCantidad;
	BigDecimal valDev;
	String codFormaPago;
	String nomFormaPago;
	String codFormaPagoDev;
	String nomFormaPagoDev;
	BigDecimal valFlete;
	BigDecimal valDevSinIva;
	String horMovimientoDev;
	public String getNumDevolucion() {
		return numDevolucion;
	}
	public void setNumDevolucion(String numDevolucion) {
		this.numDevolucion = numDevolucion;
	}
	public String getFecha() {
		return fecha;
	}
	public void setFecha(String fecha) {
		this.fecha = fecha;
	}
	public String getNomObservacion() {
		return nomObservacion;
	}
	public void setNomObservacion(String nomObservacion) {
		this.nomObservacion = nomObservacion;
	}
	public String getNumOrdencompra() {
		return numOrdencompra;
	}
	public void setNumOrdencompra(String numOrdencompra) {
		this.numOrdencompra = numOrdencompra;
	}
	public String getFactura() {
		return facturaFlete;
	}
	public void setFactura(String facturaFlete) {
		this.facturaFlete = facturaFlete;
	}
	public BigInteger getNumGuia() {
		return numGuia;
	}
	public void setNumGuia(BigInteger numGuia) {
		this.numGuia = numGuia;
	}
	public String getCodClaseped() {
		return codClaseped;
	}
	public void setCodClaseped(String codClaseped) {
		this.codClaseped = codClaseped;
	}
	public String getCedula() {
		return cedula;
	}
	public void setCedula(String cedula) {
		this.cedula = cedula;
	}
	public String getNomRazonsocial() {
		return nomRazonsocial;
	}
	public void setNomRazonsocial(String nomRazonsocial) {
		this.nomRazonsocial = nomRazonsocial;
	}
	public String getCodReferencia() {
		return codReferencia;
	}
	public void setCodReferencia(String codReferencia) {
		this.codReferencia = codReferencia;
	}
	public String getTipTalla() {
		return tipTalla;
	}
	public void setTipTalla(String tipTalla) {
		this.tipTalla = tipTalla;
	}
	public String getCodColor() {
		return codColor;
	}
	public void setCodColor(String codColor) {
		this.codColor = codColor;
	}
	public String getCodPlu() {
		return codPlu;
	}
	public void setCodPlu(String codPlu) {
		this.codPlu = codPlu;
	}
	public Integer getNumCantidad() {
		return numCantidad;
	}
	public void setNumCantidad(Integer numCantidad) {
		this.numCantidad = numCantidad;
	}
	public BigDecimal getValDev() {
		return valDev;
	}
	public void setValDev(BigDecimal valDev) {
		this.valDev = valDev;
	}
	public String getCodFormaPago() {
		return codFormaPago;
	}
	public void setCodFormaPago(String codFormaPago) {
		this.codFormaPago = codFormaPago;
	}
	public String getNomFormaPago() {
		return nomFormaPago;
	}
	public void setNomFormaPago(String nomFormaPago) {
		this.nomFormaPago = nomFormaPago;
	}
	public String getCodFormaPagoDev() {
		return codFormaPagoDev;
	}
	public void setCodFormaPagoDev(String codFormaPagoDev) {
		this.codFormaPagoDev = codFormaPagoDev;
	}
	public String getNomFormaPagoDev() {
		return nomFormaPagoDev;
	}
	public void setNomFormaPagoDev(String nomFormaOagoDev) {
		this.nomFormaPagoDev = nomFormaOagoDev;
	}
	public BigDecimal getValFlete() {
		return valFlete;
	}
	public void setValFlete(BigDecimal valFlete) {
		this.valFlete = valFlete;
	}
	public BigDecimal getValDevSinIva() {
		return valDevSinIva;
	}
	public void setValDevSinIva(BigDecimal valDevSinIva) {
		this.valDevSinIva = valDevSinIva;
	}
	public String getHorMovimientoDev() {
		return horMovimientoDev;
	}
	public void setHorMovimientoDev(String horMovimientoDev) {
		this.horMovimientoDev = horMovimientoDev;
	}
	public String getFlete() {
		return flete;
	}
	public void setFlete(String flete) {
		this.flete = flete;
	}
	
	
	
	
}
