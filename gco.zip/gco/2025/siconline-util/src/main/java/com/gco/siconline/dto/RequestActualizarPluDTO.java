package com.gco.siconline.dto;

import java.io.Serializable;

public class RequestActualizarPluDTO implements Serializable{

    private String codPluc;
    private String codUbicacion;
    private String codCaja;
    private Integer canReserva;
    
    public RequestActualizarPluDTO() {
    }
    
	public RequestActualizarPluDTO(String codPluc, String codUbicacion, String codCaja, Integer canReserva) {
		this.codPluc = codPluc;
		this.codUbicacion = codUbicacion;
		this.codCaja = codCaja;
		this.canReserva = canReserva;
	}
	
	public String getCodPluc() {
		return codPluc;
	}
	public void setCodPluc(String codPluc) {
		this.codPluc = codPluc;
	}
	public String getCodUbicacion() {
		return codUbicacion;
	}
	public void setCodUbicacion(String codUbicacion) {
		this.codUbicacion = codUbicacion;
	}
	public String getCodCaja() {
		return codCaja;
	}
	public void setCodCaja(String codCaja) {
		this.codCaja = codCaja;
	}
	public Integer getCanReserva() {
		return canReserva;
	}
	public void setCanReserva(Integer canReserva) {
		this.canReserva = canReserva;
	}

    
    

}
