/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gco.siconline.dto;

/**
 *
 * @author alejandrotamayo
 */
public class ComparativoCanastaPluDTO {

    private Integer codigo;
    private Integer conteo;
    private String codUbicacion;
    private String codCaja;
    private String codPlu;
    private Integer canExistencia;
    private Integer fisicoUno;
    private Integer fisicoDos;
    private Integer fisicoTres;

    public Integer getCodigo() {
        return codigo;
    }

    public void setCodigo(Integer codigo) {
        this.codigo = codigo;
    }

    public Integer getConteo() {
        return conteo;
    }

    public void setConteo(Integer conteo) {
        this.conteo = conteo;
    }

    public String getCodUbicacion() {
        return codUbicacion;
    }

    public void setCodUbicacion(String codUbicacion) {
        this.codUbicacion = codUbicacion;
    }

    public String getCodCaja() {
        return codCaja;
    }

    public void setCodCaja(String codCaja) {
        this.codCaja = codCaja;
    }

    public String getCodPlu() {
        return codPlu;
    }

    public void setCodPlu(String codPlu) {
        this.codPlu = codPlu;
    }

    public Integer getCanExistencia() {
        return canExistencia;
    }

    public void setCanExistencia(Integer canExistencia) {
        this.canExistencia = canExistencia;
    }

    public Integer getFisicoUno() {
        return fisicoUno;
    }

    public void setFisicoUno(Integer fisicoUno) {
        this.fisicoUno = fisicoUno;
    }

    public Integer getFisicoDos() {
        return fisicoDos;
    }

    public void setFisicoDos(Integer fisicoDos) {
        this.fisicoDos = fisicoDos;
    }

    public Integer getFisicoTres() {
        return fisicoTres;
    }

    public void setFisicoTres(Integer fisicoTres) {
        this.fisicoTres = fisicoTres;
    }

}
