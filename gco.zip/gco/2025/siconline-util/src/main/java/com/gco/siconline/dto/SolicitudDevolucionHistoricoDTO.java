package com.gco.siconline.dto;

public class SolicitudDevolucionHistoricoDTO {

	
	
}
