package com.gco.siconline.dto;

import java.math.BigDecimal;
import java.util.Date;

public class ConsultaPedidoCedulaDTO {
	private String pedido;
	private Date fechaCreacion;
	private String numNit;
	private String nombre;
	private String ordenCompra;
	private String pedidoMarket;
	private String estPedido;


	public String getPedido() {
		return pedido;
	}

	public void setPedido(String pedido) {
		this.pedido = pedido;
	}

	public Date getFechaCreacion() {
		return fechaCreacion;
	}

	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}

	public String getNumNit() {
		return numNit;
	}

	public void setNumNit(String numNit) {
		this.numNit = numNit;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getOrdenCompra() {
		return ordenCompra;
	}

	public void setOrdenCompra(String ordenCompra) {
		this.ordenCompra = ordenCompra;
	}

	public String getPedidoMarket() {
		return pedidoMarket;
	}

	public void setPedidoMarket(String pedidoMarket) {
		this.pedidoMarket = pedidoMarket;
	}
	
	public String getEstPedido() {
		return estPedido;
	}

	public void setEstPedido(String estPedido) {
		this.estPedido = estPedido;
	}
	

	@Override
	public String toString() {
		return "ConsultaPedidoCedulaDTO [pedido=" + pedido + ", fechaCreacion=" + fechaCreacion + ", numNit=" + numNit
				+ ", nombre=" + nombre + ", ordenCompra=" + ordenCompra + ", pedidoMarket=" + pedidoMarket + ",estPedido=" + estPedido + "]";
	}

}
