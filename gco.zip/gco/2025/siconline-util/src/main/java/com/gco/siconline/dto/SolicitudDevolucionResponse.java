package com.gco.siconline.dto;

import java.util.List;

public class SolicitudDevolucionResponse <T> {

	private String codigoRespuesta;
	private String descripcionRespuesta;
	List<T> listaRespuesta;
	
	
	public String getDescripcionRespuesta() {
		return descripcionRespuesta;
	}
	public void setDescripcionRespuesta(String descripcionRespuesta) {
		this.descripcionRespuesta = descripcionRespuesta;
	}
	public List<T> getListaRespuesta() {
		return listaRespuesta;
	}
	public void setListaRespuesta(List<T> listaRespuesta) {
		this.listaRespuesta = listaRespuesta;
	}
	public String getCodigoRespuesta() {
		return codigoRespuesta;
	}
	public void setCodigoRespuesta(String codigoRespuesta) {
		this.codigoRespuesta = codigoRespuesta;
	}
	
}
