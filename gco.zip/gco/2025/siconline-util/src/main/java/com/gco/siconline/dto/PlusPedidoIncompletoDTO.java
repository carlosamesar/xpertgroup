package com.gco.siconline.dto;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author besmart
 */
public class PlusPedidoIncompletoDTO {
    
    private String proveedoref;
    private String plu;
    private Integer cantidad;

    public String getProveedoref() {
        return proveedoref;
    }

    public void setProveedoref(String proveedoref) {
        this.proveedoref = proveedoref;
    }

    public String getPlu() {
        return plu;
    }

    public void setPlu(String plu) {
        this.plu = plu;
    }

    public Integer getCantidad() {
        return cantidad;
    }

    public void setCantidad(Integer cantidad) {
        this.cantidad = cantidad;
    }
    
}
