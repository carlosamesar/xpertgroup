package com.gco.siconline.dto.vales;

public class ActualizarValeVtexDto {
    private String expiringDate;

    public ActualizarValeVtexDto() {
    }

    public ActualizarValeVtexDto(String expiringDate) {
        this.expiringDate = expiringDate;
    }

    public String getExpiringDate() {
        return expiringDate;
    }

    public void setExpiringDate(String expiringDate) {
        this.expiringDate = expiringDate;
    }
}
