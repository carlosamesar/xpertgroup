package com.gco.siconline.client;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;

import com.gco.siconline.exception.BusinessException;

public class RestClient {

    private static final String GSEC_USER_TOKEN = "gsec-user-token";

    public RestTemplate getInstance(String optionalToken) {

        RestTemplate restTemplate = new RestTemplate();
        if (!StringUtils.isEmpty(optionalToken)) {
            adicionarToken(restTemplate, optionalToken);
        }
        restTemplate.setErrorHandler(new InterceptorErrorResponse());
        return restTemplate;
    }

    public void put(String url, String token, Object request, Object... paramsPath) throws BusinessException {
        ejecutar(url, token, HttpMethod.PUT, request, String.class, paramsPath);
    }

    public void put(String url, String token, Object request) throws BusinessException {
        Object[] paramsPath = null;
        ejecutar(url, token, HttpMethod.PUT, request, String.class, paramsPath);
    }

    public <T> ResponseEntity<T> post(String url, String token, Object request, Class<T> responsetype, Object... paramsPath) {
        return ejecutar(url, token, HttpMethod.POST, request, responsetype, paramsPath);
    }

    public <T> ResponseEntity<T> post(String url, String token, Object request, Class<T> responsetype) {
        Object[] paramsPath = null;
        return ejecutar(url, token, HttpMethod.POST, request, responsetype, paramsPath);
    }

    public <T> ResponseEntity<T> ejecutar(String url, String token, HttpMethod metodo, Object request, Class<T> responsetype, Object... paramsPath) {
        HttpEntity<Object> requestHttp = new HttpEntity<>(request);

        if (paramsPath != null) {
            return getInstance(token).exchange(url, metodo, requestHttp, responsetype, paramsPath);
        } else {
            return getInstance(token).exchange(url, metodo, requestHttp, responsetype);
        }
    }

    private void adicionarToken(RestTemplate restTemplate, String token) {
        List<ClientHttpRequestInterceptor> interceptor = new ArrayList<ClientHttpRequestInterceptor>();
        interceptor.add(new HeaderRequestInterceptor(GSEC_USER_TOKEN, token));
        restTemplate.setInterceptors(interceptor);
    }

}
