package com.gco.siconline.dto;

import java.math.BigDecimal;

public class DetPedidoDTO {
	
	private String codPlu;
	private String codReferencia;
	private String tipTalla;
	private String codColor;
	private String codBodega;
	private int canPendiente;
	private BigDecimal valUnidad;
	private String numOrdenpedido;
	private String observacion;
	
	
	public String getCodPlu() {
		return codPlu;
	}
	public void setCodPlu(String codPlu) {
		this.codPlu = codPlu;
	}
	public String getCodReferencia() {
		return codReferencia;
	}
	public void setCodReferencia(String codReferencia) {
		this.codReferencia = codReferencia;
	}
	public String getTipTalla() {
		return tipTalla;
	}
	public void setTipTalla(String tipTalla) {
		this.tipTalla = tipTalla;
	}
	public String getCodColor() {
		return codColor;
	}
	public void setCodColor(String codColor) {
		this.codColor = codColor;
	}
	public String getCodBodega() {
		return codBodega;
	}
	public void setCodBodega(String codBodega) {
		this.codBodega = codBodega;
	}
	public int getCanPendiente() {
		return canPendiente;
	}
	public void setCanPendiente(int canPendiente) {
		this.canPendiente = canPendiente;
	}
	public BigDecimal getValUnidad() {
		return valUnidad;
	}
	public void setValUnidad(BigDecimal valUnidad) {
		this.valUnidad = valUnidad;
	}
	public String getNumOrdenpedido() {
		return numOrdenpedido;
	}
	public void setNumOrdenpedido(String numOrdenpedido) {
		this.numOrdenpedido = numOrdenpedido;
	}
	public String getObservacion() {
		return observacion;
	}
	public void setObservacion(String observacion) {
		this.observacion = observacion;
	}
	
	

}
