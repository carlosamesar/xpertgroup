package com.gco.siconline.dto;

import java.util.Date;

public class RequestCompraDTO {

    private String marca;
    private Date fechaInicial;
    private Date fechaFinal;
    private String compra;
    private String sio;

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public Date getFechaInicial() {
        return fechaInicial;
    }

    public void setFechaInicial(Date fechaInicial) {
        this.fechaInicial = fechaInicial;
    }

    public Date getFechaFinal() {
        return fechaFinal;
    }

    public void setFechaFinal(Date fechaFinal) {
        this.fechaFinal = fechaFinal;
    }

    public String getCompra() {
        return compra;
    }

    public void setCompra(String compra) {
        this.compra = compra;
    }

    public String getSio() {
        return sio;
    }

    public void setSio(String sio) {
        this.sio = sio;
    }

}
