/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gco.siconline.dto;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;

/**
 *
 * @author alejandrotamayo
 */
public class GestionDevolucionDto {

    private String codClasePed;
    private String codTercero;
    private String nomRazonSocial;
    private String pedVtex;
    private String numPedido;
    private String factura;
    private BigInteger numGuia;
    private String codPlu;
    private String codReferencia;
    private String tipTalla;
    private String codColor;
    private String numDevolucion;
    private String horMovimiento;
    private String codFormaPago;
    private String nomFormaPago;
    private Integer numCantidad;
    private BigDecimal valUnidad;
    private String codFormaPagoDev;
    private String nomFormaPagoDev;
    private BigDecimal valorRestante;
    private String horMovimientoFact;

    private String numDocRespalda;
    private String tipTercero;
    private String diff;

    public void setCodFormaPagoDev(String codFormaPagoDev) {
        this.codFormaPagoDev = codFormaPagoDev;
    }

    public String getCodFormaPagoDev() {
        return codFormaPagoDev;
    }

    public void setNomFormaPagoDev(String nomFormaPagoDev) {
        this.nomFormaPagoDev = nomFormaPagoDev;
    }

    public String getNomFormaPagoDev() {
        return nomFormaPagoDev;
    }

    public void setValorRestante(BigDecimal valorRestante) {
        this.valorRestante = valorRestante;
    }

    public BigDecimal getValorRestante() {
        return valorRestante;
    }

    public void setHorMovimientoFact(String horMovimientoFact) {
        this.horMovimientoFact = horMovimientoFact;
    }

    public String getHorMovimientoFact() {
        return horMovimientoFact;
    }

    public String getNumDevolucion() {
        return numDevolucion;
    }

    public void setNumDevolucion(String numDevolucion) {
        this.numDevolucion = numDevolucion;
    }

    public String getHorMovimiento() {
        return horMovimiento;
    }

    public void setHorMovimiento(String horMovimiento) {
        this.horMovimiento = horMovimiento;
    }

    public String getPedVtex() {
        return pedVtex;
    }

    public void setPedVtex(String pedVtex) {
        this.pedVtex = pedVtex;
    }

    public String getNumDocRespalda() {
        return numDocRespalda;
    }

    public void setNumDocRespalda(String numDocRespalda) {
        this.numDocRespalda = numDocRespalda;
    }

    public String getNumPedido() {
        return numPedido;
    }

    public void setNumPedido(String numPedido) {
        this.numPedido = numPedido;
    }

    public String getFactura() {
        return factura;
    }

    public void setFactura(String factura) {
        this.factura = factura;
    }

    public BigInteger getNumGuia() {
        return numGuia;
    }

    public void setNumGuia(BigInteger numGuia) {
        this.numGuia = numGuia;
    }

    public String getCodClasePed() {
        return codClasePed;
    }

    public void setCodClasePed(String codClasePed) {
        this.codClasePed = codClasePed;
    }

    public String getCodTercero() {
        return codTercero;
    }

    public void setCodTercero(String codTercero) {
        this.codTercero = codTercero;
    }

    public String getTipTercero() {
        return tipTercero;
    }

    public void setTipTercero(String tipTercero) {
        this.tipTercero = tipTercero;
    }

    public String getNomRazonSocial() {
        return nomRazonSocial;
    }

    public void setNomRazonSocial(String nomRazonSocial) {
        this.nomRazonSocial = nomRazonSocial;
    }

    public String getCodReferencia() {
        return codReferencia;
    }

    public void setCodReferencia(String codReferencia) {
        this.codReferencia = codReferencia;
    }

    public String getTipTalla() {
        return tipTalla;
    }

    public void setTipTalla(String tipTalla) {
        this.tipTalla = tipTalla;
    }

    public String getCodColor() {
        return codColor;
    }

    public void setCodColor(String codColor) {
        this.codColor = codColor;
    }

    public String getCodPlu() {
        return codPlu;
    }

    public void setCodPlu(String codPlu) {
        this.codPlu = codPlu;
    }

    public Integer getNumCantidad() {
        return numCantidad;
    }

    public void setNumCantidad(Integer numCantidad) {
        this.numCantidad = numCantidad;
    }

    public BigDecimal getValUnidad() {
        return valUnidad;
    }

    public void setValUnidad(BigDecimal valUnidad) {
        this.valUnidad = valUnidad;
    }

    public String getDiff() {
        return diff;
    }

    public void setDiff(String diff) {
        this.diff = diff;
    }

    public String getCodFormaPago() {
        return codFormaPago;
    }

    public void setCodFormaPago(String codFormaPago) {
        this.codFormaPago = codFormaPago;
    }

    public String getNomFormaPago() {
        return nomFormaPago;
    }

    public void setNomFormaPago(String nomFormaPago) {
        this.nomFormaPago = nomFormaPago;
    }

}
