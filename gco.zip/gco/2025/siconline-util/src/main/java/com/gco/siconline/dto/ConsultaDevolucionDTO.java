package com.gco.siconline.dto;

public class ConsultaDevolucionDTO {

	private String fechaInicial;
	private String fechaFinal;
	private String nitTercero;
	private String email;
	private String marca;
	private String estado;
	private String numPedido;
	
	
	public String getFechaInicial() {
		return fechaInicial;
	}
	public void setFechaInicial(String fechaInicial) {
		this.fechaInicial = fechaInicial;
	}
	public String getFechaFinal() {
		return fechaFinal;
	}
	public void setFechaFinal(String fechaFinal) {
		this.fechaFinal = fechaFinal;
	}
	public String getNitTercero() {
		return nitTercero;
	}
	public void setNitTercero(String nitTercero) {
		this.nitTercero = nitTercero;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	
	public String getNumPedido() {
		return numPedido;
	}
	
	public void setNumPedido(String numPedido) {
		this.numPedido = numPedido;
	}
	
}
