/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gco.siconline.dto;

import java.sql.Timestamp;
import java.util.Date;

/**
 *
 * @author besmart
 */
public class ValeDto {
	
    private String codVale;
    private String codRedencion;
    private String nombreVale;
    private String etiqueta;
    private double valor;
    private double saldo;
    private Date fechaRedencion;
    private String usuario;
    private String fechaExpiracion;

    public String getCodVale() {
        return codVale;
    }

    public void setCodVale(String codVale) {
        this.codVale = codVale;
    }
    
    public String getCodRedencion() {
		return codRedencion;
	}
    
    public void setCodRedencion(String codRedencion) {
		this.codRedencion = codRedencion;
	}
    
    public String getNombreVale() {
		return nombreVale;
	}
    
    public void setNombreVale(String nombreVale) {
		this.nombreVale = nombreVale;
	}
    
    public String getEtiqueta() {
		return etiqueta;
	}
    
    public void setEtiqueta(String etiqueta) {
		this.etiqueta = etiqueta;
	}

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public Date getFechaRedencion() {
        return fechaRedencion;
    }

    public void setFechaRedencion(Date fechaRedencion) {
        this.fechaRedencion = fechaRedencion;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

	public String getFechaExpiracion() {
		return fechaExpiracion;
	}

	public void setFechaExpiracion(String fechaExpiracion) {
		this.fechaExpiracion = fechaExpiracion;
	}
    
}

