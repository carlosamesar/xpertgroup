package com.gco.siconline.dto;

import java.util.List;

public class ResultMovimientosGuiasDTO {
	
	private String marca;
	private List<MovimientoGuiasDTO> resultGuias;
	private int sumUnidades;
	
	public ResultMovimientosGuiasDTO() {
		// TODO Auto-generated constructor stub
	}
	public ResultMovimientosGuiasDTO(String marca,List<MovimientoGuiasDTO> resultguia,int sumUn) {
		this.marca=marca;
		this.resultGuias=resultguia;
		this.sumUnidades=sumUn;
	}
	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}
	public List<MovimientoGuiasDTO> getResultGuias() {
		return resultGuias;
	}
	public void setResultGuias(List<MovimientoGuiasDTO> resultGuias) {
		this.resultGuias = resultGuias;
	}

	public int getSumUnidades() {
		return sumUnidades;
	}
	public void setSumUnidades(int sumUnidades) {
		this.sumUnidades = sumUnidades;
	}
}
