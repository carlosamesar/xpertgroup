package com.gco.siconline.dto;

import java.math.BigDecimal;

public class DetDevolucionPluDTO {

    private String codPlu;
    private int linea;
    private String concepto;
    private String movimiento;
    private int tipoDevolucion;
    private String formaPago;
    private String canasta;
    private boolean devuelveFlete;
    private Integer codEmpresaDev;
    private String codDocumentoDev;
    private String indAplicacionDev;
    private String codConceptoDev;
    private String estPedidos;
    private BigDecimal valPromocion;
    private BigDecimal valCero;
        

    public String getCodPlu() {
        return codPlu;
    }

    public void setCodPlu(String codPlu) {
        this.codPlu = codPlu;
    }

    public int getLinea() {
        return linea;
    }

    public void setLinea(int linea) {
        this.linea = linea;
    }

    public String getConcepto() {
        return concepto;
    }

    public void setConcepto(String concepto) {
        this.concepto = concepto;
    }

    public String getMovimiento() {
        return movimiento;
    }

    public void setMovimiento(String movimiento) {
        this.movimiento = movimiento;
    }

    public int getTipoDevolucion() {
        return tipoDevolucion;
    }

    public void setTipoDevolucion(int tipoDevolucion) {
        this.tipoDevolucion = tipoDevolucion;
    }

    public String getFormaPago() {
        return formaPago;
    }

    public void setFormaPago(String formaPago) {
        this.formaPago = formaPago;
    }

    public String getCanasta() {
            return canasta;
    }

    public void setCanasta(String canasta) {
            this.canasta = canasta;
    }

    public boolean isDevuelveFlete() {
        return devuelveFlete;
    }

    public void setDevuelveFlete(boolean devuelveFlete) {
        this.devuelveFlete = devuelveFlete;
    }

    public Integer getCodEmpresaDev() {
        return codEmpresaDev;
    }

    public void setCodEmpresaDev(Integer codEmpresaDev) {
        this.codEmpresaDev = codEmpresaDev;
    }

    public String getCodDocumentoDev() {
        return codDocumentoDev;
    }

    public void setCodDocumentoDev(String codDocumentoDev) {
        this.codDocumentoDev = codDocumentoDev;
    }

    public String getIndAplicacionDev() {
        return indAplicacionDev;
    }

    public void setIndAplicacionDev(String indAplicacionDev) {
        this.indAplicacionDev = indAplicacionDev;
    }

    public String getCodConceptoDev() {
        return codConceptoDev;
    }

    public void setCodConceptoDev(String codConceptoDev) {
        this.codConceptoDev = codConceptoDev;
    }

    public String getEstPedidos() {
        return estPedidos;
    }

    public void setEstPedidos(String estPedidos) {
        this.estPedidos = estPedidos;
    }

    public BigDecimal getValPromocion() {
        return valPromocion;
    }

    public void setValPromocion(BigDecimal valPromocion) {
        this.valPromocion = valPromocion;
    }

	public BigDecimal getValCero() {
		return valCero;
	}

	public void setValCero(BigDecimal valCero) {
		this.valCero = valCero;
	}
    
    
    
}
