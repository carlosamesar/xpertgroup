package com.gco.siconline.dto;

import java.math.BigDecimal;

public class ConsignacionDTO {

	private String serieNumeroDocumento;   
	private String fecDoc;   
	private Double monto;                               
	private String codFormapago;  
	private String nombreFormapago;
	private String fecConsig;
	private String numPedido;
	private String numOrdencompra;
	private String nomObservacion;
	private String codClaseped;
	private String estado;
	private String idPago;

	
	
	public String getSerieNumeroDocumento() {
		return serieNumeroDocumento;
	}
	public void setSerieNumeroDocumento(String serieNumeroDocumento) {
		this.serieNumeroDocumento = serieNumeroDocumento;
	}
	
	public String getFecDoc() {
		return fecDoc;
	}
	public void setFecDoc(String fecDoc) {
		this.fecDoc = fecDoc;
	}
	public Double getMonto() {
		return monto;
	}
	public void setMonto(Double monto) {
		this.monto = monto;
	}
	
	public String getCodFormapago() {
		return codFormapago;
	}
	public void setCodFormapago(String codFormapago) {
		this.codFormapago = codFormapago;
	}
	public String getNombreFormapago() {
		return nombreFormapago;
	}
	public void setNombreFormapago(String nombreFormapago) {
		this.nombreFormapago = nombreFormapago;
	}
	
	
	public String getFecConsig() {
		return fecConsig;
	}
	public void setFecConsig(String fecConsig) {
		this.fecConsig = fecConsig;
	}
	
	
	public String getNumPedido() {
		return numPedido;
	}
	public void setNumPedido(String numPedido) {
		this.numPedido = numPedido;
	}
	public String getNumOrdencompra() {
		return numOrdencompra;
	}
	public void setNumOrdencompra(String numOrdencompra) {
		this.numOrdencompra = numOrdencompra;
	}
	public String getNomObservacion() {
		return nomObservacion;
	}
	public void setNomObservacion(String nomObservacion) {
		this.nomObservacion = nomObservacion;
	}
	public String getCodClaseped() {
		return codClaseped;
	}
	public void setCodClaseped(String codClaseped) {
		this.codClaseped = codClaseped;
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	
	public String getIdPago() {
		return idPago;
	}
	public void setIdPago(String idPago) {
		this.idPago = idPago;
	}
	
	
}
