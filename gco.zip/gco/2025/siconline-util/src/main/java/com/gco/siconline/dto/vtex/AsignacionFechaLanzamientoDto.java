/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gco.siconline.dto.vtex;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * DTO para la solicitud de asignación de fecha de lanzamiento
 * @author besmart
 */
public class AsignacionFechaLanzamientoDto {
    
    private Date fecha;
    private List<String> canales;
    
    public AsignacionFechaLanzamientoDto() {
        this.canales = new ArrayList<>();
    }

    public AsignacionFechaLanzamientoDto(Date fecha, List<String> canales) {
        this.fecha = fecha;
        this.canales = canales;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public List<String> getCanales() {
        return canales;
    }

    public void setCanales(List<String> canales) {
        this.canales = canales;
    }
}
