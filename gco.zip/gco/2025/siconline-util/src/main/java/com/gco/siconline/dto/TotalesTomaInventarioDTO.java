/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gco.siconline.dto;

import java.math.BigDecimal;

/**
 *
 * @author alejandrotamayo
 */
public class TotalesTomaInventarioDTO {

    private BigDecimal teorico;
    private BigDecimal conteoUno;
    private BigDecimal conteoDos;
    private BigDecimal conteoTres;

    public BigDecimal getTeorico() {
        return teorico;
    }

    public void setTeorico(BigDecimal teorico) {
        this.teorico = teorico;
    }

    public BigDecimal getConteoUno() {
        return conteoUno;
    }

    public void setConteoUno(BigDecimal conteoUno) {
        this.conteoUno = conteoUno;
    }

    public BigDecimal getConteoDos() {
        return conteoDos;
    }

    public void setConteoDos(BigDecimal conteoDos) {
        this.conteoDos = conteoDos;
    }

    public BigDecimal getConteoTres() {
        return conteoTres;
    }

    public void setConteoTres(BigDecimal conteoTres) {
        this.conteoTres = conteoTres;
    }

}
