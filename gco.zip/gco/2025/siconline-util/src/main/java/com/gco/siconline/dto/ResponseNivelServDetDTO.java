package com.gco.siconline.dto;

import java.math.BigDecimal;

public class ResponseNivelServDetDTO {

    private String marca;
    private String codMarca;
    private String fecha;
    private String cedula;
    private String nombre;
    private String email;
    private String numPedido;
    private String numOrdencompra;
    private String horaPedido;
    private String nomReferencia;
    private String plu;
    private String codReferencia;
    private String talla;
    private String color;
    private String codBodega;
    private BigDecimal valUnidad;
    private String numGuia;
    private int pedidosSinFacturar;
    private int unidadesPedidas;
    private int unidadesFacturadas;
    private String numMovimiento;
    private String fechaFactura;
    private String estadoDespacho;
    private String estado;

    public ResponseNivelServDetDTO() {
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getCodMarca() {
        return codMarca;
    }

    public void setCodMarca(String codMarca) {
        this.codMarca = codMarca;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNumPedido() {
        return numPedido;
    }

    public void setNumPedido(String numPedido) {
        this.numPedido = numPedido;
    }

    public String getNumOrdencompra() {
        return numOrdencompra;
    }

    public void setNumOrdencompra(String numOrdencompra) {
        this.numOrdencompra = numOrdencompra;
    }

    public String getHoraPedido() {
        return horaPedido;
    }

    public void setHoraPedido(String horaPedido) {
        this.horaPedido = horaPedido;
    }

    public String getPlu() {
        return plu;
    }

    public void setPlu(String plu) {
        this.plu = plu;
    }

    public String getNumGuia() {
        return numGuia;
    }

    public void setNumGuia(String numGuia) {
        this.numGuia = numGuia;
    }

    public int getPedidosSinFacturar() {
        return pedidosSinFacturar;
    }

    public void setPedidosSinFacturar(int pedidosSinFacturar) {
        this.pedidosSinFacturar = pedidosSinFacturar;
    }

    public int getUnidadesPedidas() {
        return unidadesPedidas;
    }

    public void setUnidadesPedidas(int unidadesPedidas) {
        this.unidadesPedidas = unidadesPedidas;
    }

    public int getUnidadesFacturadas() {
        return unidadesFacturadas;
    }

    public void setUnidadesFacturadas(int unidadesFacturadas) {
        this.unidadesFacturadas = unidadesFacturadas;
    }

    public String getNomReferencia() {
        return nomReferencia;
    }

    public void setNomReferencia(String nomReferencia) {
        this.nomReferencia = nomReferencia;
    }

    public String getCodReferencia() {
        return codReferencia;
    }

    public void setCodReferencia(String codReferencia) {
        this.codReferencia = codReferencia;
    }

    public String getTalla() {
        return talla;
    }

    public void setTalla(String talla) {
        this.talla = talla;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getCodBodega() {
        return codBodega;
    }

    public void setCodBodega(String codBodega) {
        this.codBodega = codBodega;
    }

    public BigDecimal getValUnidad() {
        return valUnidad;
    }

    public void setValUnidad(BigDecimal valUnidad) {
        this.valUnidad = valUnidad;
    }

    public String getNumMovimiento() {
        return numMovimiento;
    }

    public void setNumMovimiento(String numMovimiento) {
        this.numMovimiento = numMovimiento;
    }

    public String getFechaFactura() {
        return fechaFactura;
    }

    public void setFechaFactura(String fechaFactura) {
        this.fechaFactura = fechaFactura;
    }

    public String getEstadoDespacho() {
        return estadoDespacho;
    }

    public void setEstadoDespacho(String estadoDespacho) {
        this.estadoDespacho = estadoDespacho;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

}
