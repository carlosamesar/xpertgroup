package com.gco.siconline.dto;

import java.math.BigInteger;
import java.util.List;

import com.gco.siconline.ptl.dto.Company;

public class TotalConceptoDTO {

    private BigInteger cantAnterior;
    private Double valorAnterior;

    private List<ConceptoMaeDTO> conceptos;

    private BigInteger cantActual;
    private Double valorActual;

    private Company company;

    public TotalConceptoDTO() {

    }

    public BigInteger getCantAnterior() {
        return cantAnterior;
    }

    public void setCantAnterior(BigInteger cantAnterior) {
        this.cantAnterior = cantAnterior;
    }

    public Double getValorAnterior() {
        return valorAnterior;
    }

    public void setValorAnterior(Double valorAnterior) {
        this.valorAnterior = valorAnterior;
    }

    public List<ConceptoMaeDTO> getConceptos() {
        return conceptos;
    }

    public void setConceptos(List<ConceptoMaeDTO> conceptos) {
        this.conceptos = conceptos;
    }

    public BigInteger getCantActual() {
        return cantActual;
    }

    public void setCantActual(BigInteger cantActual) {
        this.cantActual = cantActual;
    }

    public Double getValorActual() {
        return valorActual;
    }

    public void setValorActual(Double valorActual) {
        this.valorActual = valorActual;
    }

    public void setCompany(Company company) {
        this.company = company;
    }

    public Company getCompany() {
        return company;
    }
}
