/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gco.siconline.dto.vtex;

/**
 * DTO para representar un atributo de referencia con su estado de validación
 * @author besmart
 */
public class AtributoReferenciaDto {
    
    private String nombre;
    private boolean ok;
    private String valor;
    
    public AtributoReferenciaDto() {
    }

    public AtributoReferenciaDto(String nombre, boolean ok) {
        this.nombre = nombre;
        this.ok = ok;
    }

    public AtributoReferenciaDto(String nombre, boolean ok, String valor) {
        this.nombre = nombre;
        this.ok = ok;
        this.valor = valor;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public boolean isOk() {
        return ok;
    }

    public void setOk(boolean ok) {
        this.ok = ok;
    }

    public String getValor() {
        return valor;
    }

    public void setValor(String valor) {
        this.valor = valor;
    }
}
