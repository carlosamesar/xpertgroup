package com.gco.siconline.dto.vales;

import java.math.BigDecimal;

public class ValesResponseDto {
    private Long id;
    private String nombreAlianza;
    private String email;
    private BigDecimal valor;
    private String marca;
    private String estado;
    private String fechaCreacion;
    private String fechaExpiracion;
    private String idVtex;
    private String cupon;
    private String campana;
    private Boolean recargado;

    public ValesResponseDto() {
    }

    public ValesResponseDto(Long id, String nombreAlianza, String email, BigDecimal valor, String marca, String estado,
                            String fechaCreacion, String fechaExpiracion, String idVtex, String cupon, String campana, Boolean recargado) {
        this.id = id;
        this.nombreAlianza = nombreAlianza;
        this.email = email;
        this.valor = valor;
        this.marca = marca;
        this.estado = estado;
        this.fechaCreacion = fechaCreacion;
        this.fechaExpiracion = fechaExpiracion;
        this.idVtex = idVtex;
        this.cupon = cupon;
        this.campana = campana;
        this.recargado = recargado;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombreAlianza() {
        return nombreAlianza;
    }

    public void setNombreAlianza(String nombreAlianza) {
        this.nombreAlianza = nombreAlianza;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public BigDecimal getValor() {
        return valor;
    }

    public void setValor(BigDecimal valor) {
        this.valor = valor;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(String fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public String getFechaExpiracion() {
        return fechaExpiracion;
    }

    public void setFechaExpiracion(String fechaExpiracion) {
        this.fechaExpiracion = fechaExpiracion;
    }

    public String getIdVtex() {
        return idVtex;
    }

    public void setIdVtex(String idVtex) {
        this.idVtex = idVtex;
    }

    public String getCupon() {
        return cupon;
    }

    public void setCupon(String cupon) {
        this.cupon = cupon;
    }

    public String getCampana() {
        return campana;
    }

    public void setCampana(String campana) {
        this.campana = campana;
    }

    public Boolean getRecargado() {
        return recargado;
    }

    public void setRecargado(Boolean recargado) {
        this.recargado = recargado;
    }
}
