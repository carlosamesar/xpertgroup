package com.gco.siconline.enums;

public enum EstadosPickingEnum {
    ACTIVO("A"), EMPEZADO("E"), TERMINADO("T"), NO_ENCONTRADO("N"), ANULADO("X");
    private String value;

    private EstadosPickingEnum(String value) {
        this.setValue(value);
    }

    public String value() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

}
