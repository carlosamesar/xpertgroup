package com.gco.siconline.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RequestBuscarTercero {

    private String codTercero;
    private String nitTercero;
    private String email;

    public String getCodTercero() {
        return codTercero;
    }

    public void setCodTercero(String codTercero) {
        this.codTercero = codTercero;
    }

    public String getNitTercero() {
        return nitTercero;
    }

    public void setNitTercero(String nitTercero) {
        this.nitTercero = nitTercero;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

}
