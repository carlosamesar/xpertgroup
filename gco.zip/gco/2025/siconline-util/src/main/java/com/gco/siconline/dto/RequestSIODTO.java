package com.gco.siconline.dto;

public class RequestSIODTO {

    protected String numPedido;
    protected String plu;
    protected Integer empresa;

    public String getNumPedido() {
        return numPedido;
    }

    public void setNumPedido(String numPedido) {
        this.numPedido = numPedido;
    }

    public String getPlu() {
        return plu;
    }

    public void setPlu(String plu) {
        this.plu = plu;
    }

    public Integer getEmpresa() {
        return empresa;
    }

    public void setEmpresa(Integer empresa) {
        this.empresa = empresa;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result
                + ((numPedido == null) ? 0 : numPedido.hashCode());
        result = prime * result + ((plu == null) ? 0 : plu.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        RequestSIODTO other = (RequestSIODTO) obj;
        if (numPedido == null) {
            if (other.numPedido != null) {
                return false;
            }
        } else if (!numPedido.equals(other.numPedido)) {
            return false;
        }
        if (plu == null) {
            if (other.plu != null) {
                return false;
            }
        } else if (!plu.equals(other.plu)) {
            return false;
        }
        return true;
    }

}
