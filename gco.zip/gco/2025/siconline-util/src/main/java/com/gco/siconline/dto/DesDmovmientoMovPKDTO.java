package com.gco.siconline.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DesDmovmientoMovPKDTO {

    private Integer codEmpresa;

    private String codDocumento;

    private String indAplicacion;

    private String codConcepto;

    private String tipClasemovto;

    private String codTercero;

    private String tipTercero;

    private String numMovimiento;

    private String codReferencia;

    private String tipTalla;

    private String codColor;

    private String indCalidad;

    private String codProveedoref;

    private String numMovtoasoc;

    private String numOrdencompra;

    private Integer linea;

    private Integer idDpedido;

    public Integer getCodEmpresa() {
        return codEmpresa;
    }

    public void setCodEmpresa(Integer codEmpresa) {
        this.codEmpresa = codEmpresa;
    }

    public String getCodDocumento() {
        return codDocumento;
    }

    public void setCodDocumento(String codDocumento) {
        this.codDocumento = codDocumento;
    }

    public String getIndAplicacion() {
        return indAplicacion;
    }

    public void setIndAplicacion(String indAplicacion) {
        this.indAplicacion = indAplicacion;
    }

    public String getCodConcepto() {
        return codConcepto;
    }

    public void setCodConcepto(String codConcepto) {
        this.codConcepto = codConcepto;
    }

    public String getTipClasemovto() {
        return tipClasemovto;
    }

    public void setTipClasemovto(String tipClasemovto) {
        this.tipClasemovto = tipClasemovto;
    }

    public String getCodTercero() {
        return codTercero;
    }

    public void setCodTercero(String codTercero) {
        this.codTercero = codTercero;
    }

    public String getTipTercero() {
        return tipTercero;
    }

    public void setTipTercero(String tipTercero) {
        this.tipTercero = tipTercero;
    }

    public String getNumMovimiento() {
        return numMovimiento;
    }

    public void setNumMovimiento(String numMovimiento) {
        this.numMovimiento = numMovimiento;
    }

    public String getCodReferencia() {
        return codReferencia;
    }

    public void setCodReferencia(String codReferencia) {
        this.codReferencia = codReferencia;
    }

    public String getTipTalla() {
        return tipTalla;
    }

    public void setTipTalla(String tipTalla) {
        this.tipTalla = tipTalla;
    }

    public String getCodColor() {
        return codColor;
    }

    public void setCodColor(String codColor) {
        this.codColor = codColor;
    }

    public String getIndCalidad() {
        return indCalidad;
    }

    public void setIndCalidad(String indCalidad) {
        this.indCalidad = indCalidad;
    }

    public String getCodProveedoref() {
        return codProveedoref;
    }

    public void setCodProveedoref(String codProveedoref) {
        this.codProveedoref = codProveedoref;
    }

    public String getNumMovtoasoc() {
        return numMovtoasoc;
    }

    public void setNumMovtoasoc(String numMovtoasoc) {
        this.numMovtoasoc = numMovtoasoc;
    }

    public String getNumOrdencompra() {
        return numOrdencompra;
    }

    public void setNumOrdencompra(String numOrdencompra) {
        this.numOrdencompra = numOrdencompra;
    }

    public Integer getLinea() {
        return linea;
    }

    public void setLinea(Integer linea) {
        this.linea = linea;
    }

    public Integer getIdDpedido() {
        return idDpedido;
    }

    public void setIdDpedido(Integer idDpedido) {
        this.idDpedido = idDpedido;
    }

}
