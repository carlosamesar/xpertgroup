package com.gco.siconline.dto;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class VentasContadoRequest {

	private int codEmpresa;
	private Timestamp fechaIni;
	private Timestamp fechaFin;
	private List<String> listMarcas = new ArrayList<String>();

	public int getCodEmpresa() {
		return codEmpresa;
	}

	public void setCodEmpresa(int codEmpresa) {
		this.codEmpresa = codEmpresa;
	}

	public Timestamp getFechaIni() {
		return fechaIni;
	}

	public void setFechaIni(Timestamp fechaIni) {
		this.fechaIni = fechaIni;
	}

	public Timestamp getFechaFin() {
		return fechaFin;
	}

	public void setFechaFin(Timestamp fechaFin) {
		this.fechaFin = fechaFin;
	}

	public List<String> getListMarcas() {
		return listMarcas;
	}

	public void setListMarcas(List<String> listMarcas) {
		this.listMarcas = listMarcas;
	}

}
