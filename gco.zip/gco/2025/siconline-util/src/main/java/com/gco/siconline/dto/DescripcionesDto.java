/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gco.siconline.dto;

import com.fasterxml.jackson.annotation.JsonSetter;

/**
 *
 * @author besmart
 */
public class DescripcionesDto {
    
    // Este DTO tiene setters "duplicados" pero se hace esto para que jackson
    // pueda deserializar por un nombre de propiedad u otro.
    
    private String referencia;
    
    private String nombreComercial;
    
    private String nombrePersonalizado;
    
    private String filtroUno;
    
    private String descripcionFiltroUno;
    
    private String filtroDos;
    
    private String descripcionFiltroDos;
    
    private String descripcion;
    
    private String proveedor;
    
    private Integer marketPlace;
    
    private boolean atributosSIC;
    
    private String canal;


    public String getReferencia() {
        return referencia;
    }

    public String getNombreComercial() {
        return nombreComercial;
    }

    public String getFiltroUno() {
        return filtroUno;
    }

    public String getDescripcionFiltroUno() {
        return descripcionFiltroUno;
    }

    public String getFiltroDos() {
        return filtroDos;
    }

    public String getDescripcionFiltroDos() {
        return descripcionFiltroDos;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public String getProveedor() {
        return proveedor;
    }

    public Integer getMarketPlace() {
        return marketPlace;
    }
    
    
    
    

    public void setReferencia(String referencia) {
        this.referencia = referencia;
    }

    public void setNombreComercial(String nombreComercial) {
        this.nombreComercial = nombreComercial;
    }

    public void setFiltroUno(String filtroUno) {
        this.filtroUno = filtroUno;
    }

    public void setDescripcionFiltroUno(String descripcionFiltroUno) {
        this.descripcionFiltroUno = descripcionFiltroUno;
    }

    public void setFiltroDos(String filtroDos) {
        this.filtroDos = filtroDos;
    }

    public void setDescripcionFiltroDos(String descripcionFiltroDos) {
        this.descripcionFiltroDos = descripcionFiltroDos;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public void setProveedor(String proveedor) {
        this.proveedor = proveedor;
    }

    public void setMarketPlace(Integer marketPlace) {
        this.marketPlace = marketPlace;
    }
    
    
    @JsonSetter("Referencia")
    public void setLaReferencia(String referencia) {
        this.referencia = referencia;
    }
    
    @JsonSetter("Nombre comercial")
    public void setLaNombreComercial(String nombreComercial) {
        this.nombreComercial = nombreComercial;
    }

    @JsonSetter("Filtro 1")
    public void setElFiltroUno(String filtroUno) {
        this.filtroUno = filtroUno;
    }

    @JsonSetter("Descripción filtro 1")
    public void setLaDescripcionFiltroUno(String descripcionFiltroUno) {
        this.descripcionFiltroUno = descripcionFiltroUno;
    }
    
    @JsonSetter("Filtro 2")
    public void setElFiltroDos(String filtroDos) {
        this.filtroDos = filtroDos;
    }
    
    @JsonSetter("Descripción filtro 2")
    public void setLaDescripcionFiltroDos(String descripcionFiltroDos) {
        this.descripcionFiltroDos = descripcionFiltroDos;
    }
    
    @JsonSetter("Descripción")
    public void setLaDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    
    @JsonSetter("Proveedor")
    public void setElProveedor(String proveedor) {
        this.proveedor = proveedor;
    }
    
    @JsonSetter("Market place")
    public void setElMarketPlace(Integer marketPlace) {
        this.marketPlace = marketPlace;
    }

	public String getNombrePersonalizado() {
		return nombrePersonalizado;
	}

	public void setNombrePersonalizado(String nombrePersonalizado) {
		this.nombrePersonalizado = nombrePersonalizado;
	}

	public boolean getAtributosSic() {
		return atributosSIC;
	}

	public void setAtributosSic(boolean atributosSIC) {
		this.atributosSIC = atributosSIC;
	}

	public String getCanal() {
		return canal;
	}

	public void setCanal(String canal) {
		this.canal = canal;
	}
    
	
	
}
