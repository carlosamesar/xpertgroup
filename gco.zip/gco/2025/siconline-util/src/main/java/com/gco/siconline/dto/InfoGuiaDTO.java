package com.gco.siconline.dto;

import java.util.List;

public class InfoGuiaDTO {

    private String numPedido;
    private String nomCliente;
    private String dirCliente;
    private String ciudad;
    private String departamento;
    private List<PluDTO> plus;

    public String getNumPedido() {
        return numPedido;
    }

    public void setNumPedido(String numPedido) {
        this.numPedido = numPedido;
    }

    public String getNomCliente() {
        return nomCliente;
    }

    public void setNomCliente(String nomCliente) {
        this.nomCliente = nomCliente;
    }

    public String getDirCliente() {
        return dirCliente;
    }

    public void setDirCliente(String dirCliente) {
        this.dirCliente = dirCliente;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    public List<PluDTO> getPlus() {
        return plus;
    }

    public void setPlus(List<PluDTO> plus) {
        this.plus = plus;
    }

}
