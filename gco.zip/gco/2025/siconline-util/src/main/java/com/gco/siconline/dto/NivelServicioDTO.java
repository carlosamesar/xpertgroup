package com.gco.siconline.dto;

import java.math.BigDecimal;

public class NivelServicioDTO {

    private String marca;
    private String fecha;
    private Integer pedidos = 0;
    private Integer pedidosPendFacturar = 0;
    private BigDecimal unidadesPedidas = new BigDecimal(0);
    private BigDecimal unidadesFacturadas = new BigDecimal(0);
    private BigDecimal unidadesPendientes = new BigDecimal(0);

    public NivelServicioDTO() {

    }

    public NivelServicioDTO(String marca, String fecha, Integer pedidos, Integer pedidosPendFacturar, BigDecimal unidadesPedidas,
            BigDecimal unidadesFacturadas, BigDecimal unidadesPendientes) {
        super();
        this.marca = marca;
        this.fecha = fecha;
        this.pedidos = pedidos;
        this.pedidosPendFacturar = pedidosPendFacturar;
        this.unidadesPedidas = unidadesPedidas;
        this.unidadesFacturadas = unidadesFacturadas;
        this.unidadesPendientes = unidadesPendientes;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public Integer getPedidos() {
        return pedidos;
    }

    public void setPedidos(Integer pedidos) {
        this.pedidos = pedidos;
    }

    public Integer getPedidosPendFacturar() {
        return pedidosPendFacturar;
    }

    public void setPedidosPendFacturar(Integer pedidosPendFacturar) {
        this.pedidosPendFacturar = pedidosPendFacturar;
    }

    public BigDecimal getUnidadesPedidas() {
        return unidadesPedidas;
    }

    public void setUnidadesPedidas(BigDecimal unidadesPedidas) {
        this.unidadesPedidas = unidadesPedidas;
    }

    public BigDecimal getUnidadesFacturadas() {
        return unidadesFacturadas;
    }

    public void setUnidadesFacturadas(BigDecimal unidadesFacturadas) {
        this.unidadesFacturadas = unidadesFacturadas;
    }

    public BigDecimal getUnidadesPendientes() {
        return unidadesPendientes;
    }

    public void setUnidadesPendientes(BigDecimal unidadesPendientes) {
        this.unidadesPendientes = unidadesPendientes;
    }

}
