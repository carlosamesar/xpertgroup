package com.gco.siconline.dto;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class WhiteLabelDto {
	
	@JsonProperty("UrlLogo")
    private String urlLogo;

    @JsonProperty("SellerId")
    private String sellerId;

    @JsonProperty("Name")
    private String name;

    @JsonProperty("Email")
    private String email;

    @JsonProperty("Description")
    private String description;

    @JsonProperty("ExchangeReturnPolicy")
    private String exchangeReturnPolicy;

    @JsonProperty("DeliveryPolicy")
    private String deliveryPolicy;

    @JsonProperty("SecutityPrivacyPolicy")
    private String secutityPrivacyPolicy;

    @JsonProperty("CNPJ")
    private String cnpj;

    @JsonProperty("CSCIdentification")
    private String cscIdentification;

    @JsonProperty("ArchiveId")
    private String archiveId;

    @JsonProperty("ProductCommissionPercentage")
    private double productCommissionPercentage;

    @JsonProperty("FreightCommissionPercentage")
    private double freightCommissionPercentage;

    @JsonProperty("CategoryCommissionPercentage")
    private String categoryCommissionPercentage;

    @JsonProperty("FulfillmentEndpoint")
    private String fulfillmentEndpoint;

    @JsonProperty("CatalogSystemEndpoint")
    private String catalogSystemEndpoint;

    @JsonProperty("IsActive")
    private boolean isActive;

    @JsonProperty("IsBetterScope")
    private boolean isBetterScope;

    @JsonProperty("MerchantName")
    private String merchantName;

    @JsonProperty("UserName")
    private String userName;

    @JsonProperty("Password")
    private String password;

    @JsonProperty("UseHybridPaymentOptions")
    private boolean useHybridPaymentOptions;

    @JsonProperty("FulfillmentSellerId")
    private String fulfillmentSellerId;

    @JsonProperty("SellerType")
    private int sellerType;

    @JsonProperty("trustPolicy")
    private String trustPolicy;

    @JsonProperty("policies")
    private List<String> policies;

    @JsonProperty("Groups")
    private List<Object> groups;

    // Getters y setters
    public String getUrlLogo() {
        return urlLogo;
    }

    public void setUrlLogo(String urlLogo) {
        this.urlLogo = urlLogo;
    }

    public String getSellerId() {
        return sellerId;
    }

    public void setSellerId(String sellerId) {
        this.sellerId = sellerId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getExchangeReturnPolicy() {
        return exchangeReturnPolicy;
    }

    public void setExchangeReturnPolicy(String exchangeReturnPolicy) {
        this.exchangeReturnPolicy = exchangeReturnPolicy;
    }

    public String getDeliveryPolicy() {
        return deliveryPolicy;
    }

    public void setDeliveryPolicy(String deliveryPolicy) {
        this.deliveryPolicy = deliveryPolicy;
    }

    public String getSecutityPrivacyPolicy() {
        return secutityPrivacyPolicy;
    }

    public void setSecutityPrivacyPolicy(String secutityPrivacyPolicy) {
        this.secutityPrivacyPolicy = secutityPrivacyPolicy;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getCscIdentification() {
        return cscIdentification;
    }

    public void setCscIdentification(String cscIdentification) {
        this.cscIdentification = cscIdentification;
    }

    public String getArchiveId() {
        return archiveId;
    }

    public void setArchiveId(String archiveId) {
        this.archiveId = archiveId;
    }

    public double getProductCommissionPercentage() {
        return productCommissionPercentage;
    }

    public void setProductCommissionPercentage(double productCommissionPercentage) {
        this.productCommissionPercentage = productCommissionPercentage;
    }

    public double getFreightCommissionPercentage() {
        return freightCommissionPercentage;
    }

    public void setFreightCommissionPercentage(double freightCommissionPercentage) {
        this.freightCommissionPercentage = freightCommissionPercentage;
    }

    public String getCategoryCommissionPercentage() {
        return categoryCommissionPercentage;
    }

    public void setCategoryCommissionPercentage(String categoryCommissionPercentage) {
        this.categoryCommissionPercentage = categoryCommissionPercentage;
    }

    public String getFulfillmentEndpoint() {
        return fulfillmentEndpoint;
    }

    public void setFulfillmentEndpoint(String fulfillmentEndpoint) {
        this.fulfillmentEndpoint = fulfillmentEndpoint;
    }

    public String getCatalogSystemEndpoint() {
        return catalogSystemEndpoint;
    }

    public void setCatalogSystemEndpoint(String catalogSystemEndpoint) {
        this.catalogSystemEndpoint = catalogSystemEndpoint;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean isActive) {
        this.isActive = isActive;
    }

    public boolean isBetterScope() {
        return isBetterScope;
    }

    public void setBetterScope(boolean isBetterScope) {
        this.isBetterScope = isBetterScope;
    }

    public String getMerchantName() {
        return merchantName;
    }

    public void setMerchantName(String merchantName) {
        this.merchantName = merchantName;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isUseHybridPaymentOptions() {
        return useHybridPaymentOptions;
    }

    public void setUseHybridPaymentOptions(boolean useHybridPaymentOptions) {
        this.useHybridPaymentOptions = useHybridPaymentOptions;
    }

    public String getFulfillmentSellerId() {
        return fulfillmentSellerId;
    }

    public void setFulfillmentSellerId(String fulfillmentSellerId) {
        this.fulfillmentSellerId = fulfillmentSellerId;
    }

    public int getSellerType() {
        return sellerType;
    }

    public void setSellerType(int sellerType) {
        this.sellerType = sellerType;
    }

    public String getTrustPolicy() {
        return trustPolicy;
    }

    public void setTrustPolicy(String trustPolicy) {
        this.trustPolicy = trustPolicy;
    }

    public List<String> getPolicies() {
        return policies;
    }

    public void setPolicies(List<String> policies) {
        this.policies = policies;
    }

    public List<Object> getGroups() {
        return groups;
    }

    public void setGroups(List<Object> groups) {
        this.groups = groups;
    }
}

