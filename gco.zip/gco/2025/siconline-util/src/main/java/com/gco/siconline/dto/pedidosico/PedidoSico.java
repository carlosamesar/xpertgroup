
package com.gco.siconline.dto.pedidosico;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Generated;

@Generated("org.jsonschema2pojo")
public class PedidoSico {

    private String empresa;
    private String codDocumento;
    private String indAplicacion;
    private String codConcepto;
    private String idTercero;
    private String tipTercero;
    private String numPedido;
    private String bodega;
    private String tipTercerobod;
    private String codVendedor;
    private String tipTerceroven;
    private String fecPedido;
    private String descuentopie;
    private String descuentopp;
    private String fecEntrega;
    private String tipPedido;
    private String tipComision;
    private String codLista;
    private String porPedido;
    private String numPeriodo;
    private String codTermino;
    private String codFormaenvio;
    private String estPedido;
    private String codUsuarioautor;
    private String codUsuario;
    private String nomObservacion;
    private String indEstado;
    private String codClaseped;
    private String nomRazonsocial;
    private String dirFactura;
    private String dirDespacho;
    private String telDespacho;
    private String telFactura;
    private String email;
    private String codCiudad;
    private String numPedidoMarket;
    private String estadoMarket;
    private String nombreTienda;
    private int idMarket; 
    private UtmMedium customizacion;
    
    private List<DetallePedido> detallePedido = new ArrayList<>();
    
    private List<FormaPago> detalleFormaPago = new ArrayList<>();
    
    private Map<String, Object> additionalProperties = new HashMap<>();

    public String getEmpresa() {
        return empresa;
    }

    public void setEmpresa(String empresa) {
        this.empresa = empresa;
    }

    public String getCodDocumento() {
        return codDocumento;
    }

    public void setCodDocumento(String codDocumento) {
        this.codDocumento = codDocumento;
    }

    public String getIndAplicacion() {
        return indAplicacion;
    }

    public void setIndAplicacion(String indAplicacion) {
        this.indAplicacion = indAplicacion;
    }

    public String getCodConcepto() {
        return codConcepto;
    }

    public void setCodConcepto(String codConcepto) {
        this.codConcepto = codConcepto;
    }

    public String getIdTercero() {
        return idTercero;
    }

    public void setIdTercero(String idTercero) {
        this.idTercero = idTercero;
    }

    public String getTipTercero() {
        return tipTercero;
    }

    public void setTipTercero(String tipTercero) {
        this.tipTercero = tipTercero;
    }

    public String getNumPedido() {
        return numPedido;
    }

    public void setNumPedido(String numPedido) {
        this.numPedido = numPedido;
    }

    public String getBodega() {
        return bodega;
    }

    public void setBodega(String bodega) {
        this.bodega = bodega;
    }

    public String getTipTercerobod() {
        return tipTercerobod;
    }

    public void setTipTercerobod(String tipTercerobod) {
        this.tipTercerobod = tipTercerobod;
    }

    public String getCodVendedor() {
        return codVendedor;
    }

    public void setCodVendedor(String codVendedor) {
        this.codVendedor = codVendedor;
    }

    public String getTipTerceroven() {
        return tipTerceroven;
    }

    public void setTipTerceroven(String tipTerceroven) {
        this.tipTerceroven = tipTerceroven;
    }

    public String getFecPedido() {
        return fecPedido;
    }

    public void setFecPedido(String fecPedido) {
        this.fecPedido = fecPedido;
    }

    public String getDescuentopie() {
        return descuentopie;
    }

    public void setDescuentopie(String descuentopie) {
        this.descuentopie = descuentopie;
    }

    public String getDescuentopp() {
        return descuentopp;
    }

    public void setDescuentopp(String descuentopp) {
        this.descuentopp = descuentopp;
    }

    public String getFecEntrega() {
        return fecEntrega;
    }

    public void setFecEntrega(String fecEntrega) {
        this.fecEntrega = fecEntrega;
    }

    public String getTipPedido() {
        return tipPedido;
    }

    public void setTipPedido(String tipPedido) {
        this.tipPedido = tipPedido;
    }

    public String getTipComision() {
        return tipComision;
    }

    public void setTipComision(String tipComision) {
        this.tipComision = tipComision;
    }

    public String getCodLista() {
        return codLista;
    }

    public void setCodLista(String codLista) {
        this.codLista = codLista;
    }

    public String getPorPedido() {
        return porPedido;
    }

    public void setPorPedido(String porPedido) {
        this.porPedido = porPedido;
    }

    public String getNumPeriodo() {
        return numPeriodo;
    }

    public void setNumPeriodo(String numPeriodo) {
        this.numPeriodo = numPeriodo;
    }

    public String getCodTermino() {
        return codTermino;
    }

    public void setCodTermino(String codTermino) {
        this.codTermino = codTermino;
    }

    public String getCodFormaenvio() {
        return codFormaenvio;
    }

    public void setCodFormaenvio(String codFormaenvio) {
        this.codFormaenvio = codFormaenvio;
    }

    public String getEstPedido() {
        return estPedido;
    }

    public void setEstPedido(String estPedido) {
        this.estPedido = estPedido;
    }

    public String getCodUsuarioautor() {
        return codUsuarioautor;
    }

    public void setCodUsuarioautor(String codUsuarioautor) {
        this.codUsuarioautor = codUsuarioautor;
    }

    public String getCodUsuario() {
        return codUsuario;
    }

    public void setCodUsuario(String codUsuario) {
        this.codUsuario = codUsuario;
    }

    public String getNomObservacion() {
        return nomObservacion;
    }

    public void setNomObservacion(String nomObservacion) {
        this.nomObservacion = nomObservacion;
    }

    public String getIndEstado() {
        return indEstado;
    }

    public void setIndEstado(String indEstado) {
        this.indEstado = indEstado;
    }

    public String getCodClaseped() {
        return codClaseped;
    }

    public void setCodClaseped(String codClaseped) {
        this.codClaseped = codClaseped;
    }

    public String getNomRazonsocial() {
        return nomRazonsocial;
    }

    public void setNomRazonsocial(String nomRazonsocial) {
        this.nomRazonsocial = nomRazonsocial;
    }

    public String getDirFactura() {
        return dirFactura;
    }

    public void setDirFactura(String dirFactura) {
        this.dirFactura = dirFactura;
    }

    public String getDirDespacho() {
        return dirDespacho;
    }

    public void setDirDespacho(String dirDespacho) {
        this.dirDespacho = dirDespacho;
    }

    public String getTelDespacho() {
        return telDespacho;
    }

    public void setTelDespacho(String telDespacho) {
        this.telDespacho = telDespacho;
    }

    public String getTelFactura() {
        return telFactura;
    }

    public void setTelFactura(String telFactura) {
        this.telFactura = telFactura;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCodCiudad() {
        return codCiudad;
    }

    public void setCodCiudad(String codCiudad) {
        this.codCiudad = codCiudad;
    }

    public List<DetallePedido> getDetallePedido() {
        return detallePedido;
    }

    public void setDetallePedido(List<DetallePedido> detallePedido) {
        this.detallePedido = detallePedido;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public String getNumPedidoMarket() {
        return numPedidoMarket;
    }

    public void setNumPedidoMarket(String numPedidoMarket) {
        this.numPedidoMarket = numPedidoMarket;
    }

    public String getEstadoMarket() {
        return estadoMarket;
    }

    public void setEstadoMarket(String estadoMarket) {
        this.estadoMarket = estadoMarket;
    }

    public String getNombreTienda() {
        return nombreTienda;
    }

    public void setNombreTienda(String nombreTienda) {
        this.nombreTienda = nombreTienda;
    }

    public int getIdMarket() {
        return idMarket;
    }

    public void setIdMarket(int idMarket) {
        this.idMarket = idMarket;
    }

    public List<FormaPago> getDetalleFormaPago() {
        return detalleFormaPago;
    }

    public void setDetalleFormaPago(List<FormaPago> detalleFormaPago) {
        this.detalleFormaPago = detalleFormaPago;
    }

    public UtmMedium getCustomizacion() {
        return customizacion;
    }

    public void setCustomizacion(UtmMedium customizacion) {
        this.customizacion = customizacion;
    }
    

}
