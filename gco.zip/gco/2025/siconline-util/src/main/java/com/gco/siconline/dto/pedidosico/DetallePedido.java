
package com.gco.siconline.dto.pedidosico;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Generated;

@Generated("org.jsonschema2pojo")
public class DetallePedido {

    private String PLU;
    private String referencia;
    private String tipTalla;
    private String codColor;
    private String calidad;
    private String codProveedoref;
    private int cantidad;
    private double valor;
    private String codUsuario;
    private String observacion;
    private String dirDespacho;
    private String indEstado;
    private String codBodega;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private String codBodegaCompra;
    private String estadoReservado;
    private double valorDescuento;

    public String getPLU() {
        return PLU;
    }

    public void setPLU(String PLU) {
        this.PLU = PLU;
    }

    public String getReferencia() {
        return referencia;
    }

    public void setReferencia(String referencia) {
        this.referencia = referencia;
    }

    public String getTipTalla() {
        return tipTalla;
    }

    public void setTipTalla(String tipTalla) {
        this.tipTalla = tipTalla;
    }

    public String getCodColor() {
        return codColor;
    }

    public void setCodColor(String codColor) {
        this.codColor = codColor;
    }

    public String getCalidad() {
        return calidad;
    }

    public void setCalidad(String calidad) {
        this.calidad = calidad;
    }

    public String getCodProveedoref() {
        return codProveedoref;
    }

    public void setCodProveedoref(String codProveedoref) {
        this.codProveedoref = codProveedoref;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public String getCodUsuario() {
        return codUsuario;
    }

    public void setCodUsuario(String codUsuario) {
        this.codUsuario = codUsuario;
    }

    public String getObservacion() {
        return observacion;
    }

    public void setObservacion(String observacion) {
        this.observacion = observacion;
    }

    public String getDirDespacho() {
        return dirDespacho;
    }

    public void setDirDespacho(String dirDespacho) {
        this.dirDespacho = dirDespacho;
    }

    public String getIndEstado() {
        return indEstado;
    }

    public void setIndEstado(String indEstado) {
        this.indEstado = indEstado;
    }

    public String getCodBodega() {
        return codBodega;
    }

    public void setCodBodega(String codBodega) {
        this.codBodega = codBodega;
    }
    
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public String getCodBodegaCompra() {
        return codBodegaCompra;
    }

    public void setCodBodegaCompra(String codBodegaCompra) {
        this.codBodegaCompra = codBodegaCompra;
    }

    public String getEstadoReservado() {
        return estadoReservado;
    }

    public void setEstadoReservado(String estadoReservado) {
        this.estadoReservado = estadoReservado;
    }

    public double getValorDescuento() {
        return valorDescuento;
    }

    public void setValorDescuento(double valorDescuento) {
        this.valorDescuento = valorDescuento;
    }
    
    
    
}
