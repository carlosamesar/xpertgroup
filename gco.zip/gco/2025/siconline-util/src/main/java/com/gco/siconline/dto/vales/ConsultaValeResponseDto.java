package com.gco.siconline.dto.vales;

import java.math.BigDecimal;

public class ConsultaValeResponseDto {
    private String id;
    private String redemptionCode;
    private BigDecimal balance;

    public ConsultaValeResponseDto() {
    }

    public ConsultaValeResponseDto(String id, String redemptionCode, BigDecimal balance) {
        this.id = id;
        this.redemptionCode = redemptionCode;
        this.balance = balance;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getRedemptionCode() {
        return redemptionCode;
    }

    public void setRedemptionCode(String redemptionCode) {
        this.redemptionCode = redemptionCode;
    }

    public BigDecimal getBalance() {
        return balance;
    }

    public void setBalance(BigDecimal balance) {
        this.balance = balance;
    }
}
