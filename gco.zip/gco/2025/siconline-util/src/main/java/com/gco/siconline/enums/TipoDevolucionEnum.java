package com.gco.siconline.enums;

public enum TipoDevolucionEnum {

	SALDO_A_FAVOR(1),
	CAMBIO_DE_PRENDA(2),
	DEVOLUCION_DE_DINERO(3),
	DAFITI(4),
	RECHAZO_DIAN(6);
	
	private Integer value;
		
	private TipoDevolucionEnum(Integer value) {
		this.value = value;
	}
	
	public Integer getValue() {
		return value;
	}
	
}
