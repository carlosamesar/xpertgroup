/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gco.siconline.enums;

/**
 *
 * @author besmart
 */
public enum PedidoReservaEnum {
    
    PEDIDO("PEDIDO"),
    TIENDA("TIENDA"),
    REFERENCIA("REFERENCIA"),
    TALLA("TALLA"),
    COLOR("COLOR"),
    PLU("PLU"),
    CANTIDAD("CANTIDAD"),
    NUEVO_PEDIDO("NUEVO PEDIDO")
    ;
    private String value;

    private PedidoReservaEnum(String value) {
            this.value = value;
    }

    public String getValue() {
            return value;
    }

    public void setValue(String value) {
            this.value = value;
    }
    
}
