package com.gco.siconline.dto;

import java.util.Date;

public class ConsultarFecDevDTO {
    private Date FechaIn;

	public Date getFechaIn() {
		return FechaIn;
	}

	public void setFechaIn(Date fechaIn) {
		FechaIn = fechaIn;
	}

    
    
}
