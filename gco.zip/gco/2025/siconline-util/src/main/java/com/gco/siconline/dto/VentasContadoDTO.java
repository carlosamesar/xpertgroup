package com.gco.siconline.dto;



public class VentasContadoDTO {

    private String codTercero;
    private String codConcepto;
    private String numMovimiento;
    private String horMovimiento;
    private String nomNombrecomercia;
    private int totCan;
    private String nomObservacion;
    private double totValor;
    private double valSinIva;
    private double  valIva;		
    private double totDescuento;
    private String codProveedoref;
    
    public VentasContadoDTO() {
    }

    public String getCodTercero() {
        return codTercero;
    }

    public void setCodTercero(String codTercero) {
        this.codTercero = codTercero;
    }

    public String getCodConcepto() {
        return codConcepto;
    }

    public void setCodConcepto(String codConcepto) {
        this.codConcepto = codConcepto;
    }

    public String getNumMovimiento() {
        return numMovimiento;
    }

    public void setNumMovimiento(String numMovimiento) {
        this.numMovimiento = numMovimiento;
    }

    public String getHorMovimiento() {
        return horMovimiento;
    }

    public void setHorMovimiento(String horMovimiento) {
        this.horMovimiento = horMovimiento;
    }

    public String getNomNombrecomercia() {
        return nomNombrecomercia;
    }

    public void setNomNombrecomercia(String nomNombrecomercia) {
        this.nomNombrecomercia = nomNombrecomercia;
    }

    public int getTotCan() {
        return totCan;
    }

    public void setTotCan(int totCan) {
        this.totCan = totCan;
    }

    public String getNomObservacion() {
        return nomObservacion;
    }

    public void setNomObservacion(String nomObservacion) {
        this.nomObservacion = nomObservacion;
    }

    public double getTotValor() {
        return totValor;
    }

    public void setTotValor(double totValor) {
        this.totValor = totValor;
    }

	public double getValSinIva() {
		return valSinIva;
	}

	public void setValSinIva(double valSinIva) {
		this.valSinIva = valSinIva;
	}

	public double getValIva() {
		return valIva;
	}

	public void setValIva(double valIva) {
		this.valIva = valIva;
	}

	public double getTotDescuento() {
		return totDescuento;
	}

	public void setTotDescuento(double totDescuento) {
		this.totDescuento = totDescuento;
	}

	public String getCodProveedoref() {
		return codProveedoref;
	}

	public void setCodProveedoref(String cod_proveedoref) {
		this.codProveedoref = cod_proveedoref;
	}
   

   
}
