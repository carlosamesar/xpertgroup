/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gco.siconline.dto;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author alejandrotamayo
 */
public class ArbolUbicacionesDTO {

    public String cod;
    public String padre;
    public Integer codEmpresa;
    public String codBodega;
    public String tipTercerobod;
    public String codUbicacion;
    public String descripcion;
    public boolean seleccionado = false;

    // Hijos
    public List<ArbolUbicacionesDTO> children;

    public ArbolUbicacionesDTO() {
        children = new ArrayList<>();
    }

    public void crearNodo(ArbolUbicacionesDTO nodo) {

        if (nodo.cod.equals("-1")) {

            this.cod = nodo.cod;
            this.padre = nodo.padre;
            this.codEmpresa = nodo.codEmpresa;
            this.codBodega = nodo.codBodega;
            this.tipTercerobod = nodo.tipTercerobod;
            this.codUbicacion = nodo.codUbicacion;
            this.descripcion = nodo.descripcion;

        } else if (this.cod.equals(nodo.padre)) {

            children.add(nodo);

        } else {

            for (ArbolUbicacionesDTO hijo : children) {
                hijo.crearNodo(nodo);
            }

        }

    }

}
