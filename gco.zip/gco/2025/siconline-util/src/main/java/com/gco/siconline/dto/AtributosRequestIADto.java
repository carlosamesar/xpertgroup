package com.gco.siconline.dto;

public class AtributosRequestIADto {
	
	String nombre;
	String descripcion;
	String empresa;
	String referencia;
	String canal;
	String sensation;
	String use;
	String recommendation;
	String features;
	String careInstructions;
	String metaTags;
	String medaDataTile;
	String medaDataDescription;	
	String imgDescription;
    String modelSize;
    String notes;


	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public String getEmpresa() {
		return empresa;
	}
	public void setEmpresa(String empresa) {
		this.empresa = empresa;
	}
	public String getReferencia() {
		return referencia;
	}
	public void setReferencia(String referencia) {
		this.referencia = referencia;
	}
	public String getCanal() {
		return canal;
	}
	public void setCanal(String canal) {
		this.canal = canal;
	}
	public String getSensation() {
		return sensation;
	}
	public void setSensation(String sensation) {
		this.sensation = sensation;
	}
	public String getUse() {
		return use;
	}
	public void setUse(String use) {
		this.use = use;
	}
	public String getRecommendation() {
		return recommendation;
	}
	public void setRecommendation(String recommendation) {
		this.recommendation = recommendation;
	}
	public String getFeatures() {
		return features;
	}
	public void setFeatures(String features) {
		this.features = features;
	}
	public String getCareInstructions() {
		return careInstructions;
	}
	public void setCareInstructions(String careInstructions) {
		this.careInstructions = careInstructions;
	}
	public String getMetaTags() {
		return metaTags;
	}
	public void setMetaTags(String metaTags) {
		this.metaTags = metaTags;
	}
    public String getModelSize() {return modelSize;}
    public void setModelSize(String modelSize) {this.modelSize = modelSize;}
    public String getNotes() {return notes;}
    public void setNotes(String notes) {this.notes = notes;}

    public String getImgDescription() {
		return imgDescription;
	}
	public void setImgDescription(String imgDescription) {
		this.imgDescription = imgDescription;
	}
	public String getMedaDataTile() {
		return medaDataTile;
	}
	public void setMedaDataTile(String medaDataTile) {
		this.medaDataTile = medaDataTile;
	}
	public String getMedaDataDescription() {
		return medaDataDescription;
	}
	public void setMedaDataDescription(String medaDataDescription) {
		this.medaDataDescription = medaDataDescription;
	}


	
	
}
