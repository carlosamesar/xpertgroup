package com.gco.siconline.dto;

import java.util.ArrayList;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class DetallePedidoMarketPlace {

    private String plu;
    
    @NotNull(message = "El código de referencia es obligatorio.")
    private String referencia;
    
    @NotNull(message = "No se encontró la talla del PLU.")
    private String tipTalla;
    
    @NotNull(message = "No se encontró el color del PLU.")
    private String codColor;
    
    private String calidad;
    
    @NotNull(message = "No se encontró proveedor de la referencia.")
    private String codProveedoref;
    
    private int cantidad;
    private double valor;
    private String codUsuario;
    private String observacion;
    private String indEstado;
    private String dirDespacho;
    private String codBodegaCompra;
    private String estadoReservado;
    private double valorDescuento;
    private String idDelivery;
    private int lineaDelivery;
    private Integer idDpedido;
    
    private ArrayList<BeneficioDto> beneficios;

    public String getPLU() {
        return plu;
    }

    public void setPLU(String pLU) {
        plu = pLU;
    }

    public String getReferencia() {
        return referencia;
    }

    public void setReferencia(String referencia) {
        this.referencia = referencia;
    }

    public String getTipTalla() {
        return tipTalla;
    }

    public void setTipTalla(String tipTalla) {
        this.tipTalla = tipTalla;
    }

    public String getCodColor() {
        return codColor;
    }

    public void setCodColor(String codColor) {
        this.codColor = codColor;
    }

    public String getCalidad() {
        return calidad;
    }

    public void setCalidad(String calidad) {
        this.calidad = calidad;
    }

    public String getCodProveedoref() {
        return codProveedoref;
    }

    public void setCodProveedoref(String codProveedoref) {
        this.codProveedoref = codProveedoref;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public String getCodUsuario() {
        return codUsuario;
    }

    public void setCodUsuario(String codUsuario) {
        this.codUsuario = codUsuario;
    }

    public String getObservacion() {
        return observacion;
    }

    public void setObservacion(String observacion) {
        this.observacion = observacion;
    }

    public String getIndEstado() {
        return indEstado;
    }

    public void setIndEstado(String indEstado) {
        this.indEstado = indEstado;
    }

    public String getDirDespacho() {
        return dirDespacho;
    }

    public void setDirDespacho(String dirDespacho) {
        this.dirDespacho = dirDespacho;
    }

    public String getCodBodegaCompra() {
        return codBodegaCompra;
    }

    public void setCodBodegaCompra(String codBodegaCompra) {
        this.codBodegaCompra = codBodegaCompra;
    }

    public String getEstadoReservado() {
        return estadoReservado;
    }

    public void setEstadoReservado(String estadoReservado) {
        this.estadoReservado = estadoReservado;
    }

    public double getValorDescuento() {
        return valorDescuento;
    }

    public void setValorDescuento(double valorDescuento) {
        this.valorDescuento = valorDescuento;
    }

    public String getIdDelivery() {
        return idDelivery;
    }

    public void setIdDelivery(String idDelivery) {
        this.idDelivery = idDelivery;
    }

    public int getLineaDelivery() {
        return lineaDelivery;
    }

    public void setLineaDelivery(int lineaDelivery) {
        this.lineaDelivery = lineaDelivery;
    }

    public ArrayList<BeneficioDto> getBeneficios() {
        return beneficios;
    }

    public void setBeneficios(ArrayList<BeneficioDto> beneficios) {
        this.beneficios = beneficios;
    }

    public Integer getIdDpedido() {
        return idDpedido;
    }

    public void setIdDpedido(Integer idDpedido) {
        this.idDpedido = idDpedido;
    }
    
    

}
