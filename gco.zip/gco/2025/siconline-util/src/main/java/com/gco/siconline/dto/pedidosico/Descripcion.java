/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gco.siconline.dto.pedidosico;

/**
 *
 * @author alejandrotamayo
 */
public class Descripcion {
    
    private String apliqueelegido_vf;
    private String apliqueelegido_vp;
    private String textoelegido_vf;
    private String textoelegido_vp;

    public String getApliqueelegido_vf() {
        return apliqueelegido_vf;
    }

    public void setApliqueelegido_vf(String apliqueelegido_vf) {
        this.apliqueelegido_vf = apliqueelegido_vf;
    }

    public String getApliqueelegido_vp() {
        return apliqueelegido_vp;
    }

    public void setApliqueelegido_vp(String apliqueelegido_vp) {
        this.apliqueelegido_vp = apliqueelegido_vp;
    }

    public String getTextoelegido_vf() {
        return textoelegido_vf;
    }

    public void setTextoelegido_vf(String textoelegido_vf) {
        this.textoelegido_vf = textoelegido_vf;
    }

    public String getTextoelegido_vp() {
        return textoelegido_vp;
    }

    public void setTextoelegido_vp(String textoelegido_vp) {
        this.textoelegido_vp = textoelegido_vp;
    }

    
    
}
