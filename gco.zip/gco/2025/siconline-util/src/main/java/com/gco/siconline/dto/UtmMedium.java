/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gco.siconline.dto;

/**
 *
 * @author alejandrotamayo
 */
public class UtmMedium {

    private Customizacion customizacion;

    public Customizacion getCustomizacion() {
        return customizacion;
    }

    public void setCustomizacion(Customizacion customizacion) {
        this.customizacion = customizacion;
    }

}
