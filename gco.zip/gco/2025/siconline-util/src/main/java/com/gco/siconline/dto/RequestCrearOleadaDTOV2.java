package com.gco.siconline.dto;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RequestCrearOleadaDTOV2 extends RequestCrearOleadaDTO {

    protected boolean duplicados;

    public boolean isDuplicados() {
        return duplicados;
    }

    public void setDuplicados(boolean duplicados) {
        this.duplicados = duplicados;
    }

}
