package com.gco.siconline.dto;

import java.util.List;

import org.springframework.data.domain.Page;

public abstract class PageResponseDTO<T> implements Page<T> {

    private Long totalRows;
    private int totalPages;
    private List<T> listResponse;

    public Long getTotalRows() {
        totalRows = this.getTotalElements();
        return totalRows;
    }

    public int getTotalPages() {
        totalPages = this.getTotalPages();
        return totalPages;
    }

    public List<T> getResponse() {
        listResponse = this.getContent();
        return listResponse;
    }

}
