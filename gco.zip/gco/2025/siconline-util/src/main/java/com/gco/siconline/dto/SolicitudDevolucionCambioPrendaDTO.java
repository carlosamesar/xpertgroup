package com.gco.siconline.dto;

import java.util.Date;

public class SolicitudDevolucionCambioPrendaDTO {

	private Integer codSolicitudCambioPrenda;	
	private Integer codDetalleSolicitud;	
	private String codPluNueva;	
	private String codReferenciaNueva;	
	private String nombreReferenciaNueva;
	private String tipTallaNueva;	
	private String codColorNueva;	
	private String nombreColorNueva;
	private String codEstado;	
	private String nombreEstado;
	private String codUsuario;	
	private Date fecCreacion;
	
	public Integer getCodSolicitudCambioPrenda() {
		return codSolicitudCambioPrenda;
	}
	public void setCodSolicitudCambioPrenda(Integer codSolicitudCambioPrenda) {
		this.codSolicitudCambioPrenda = codSolicitudCambioPrenda;
	}
	public Integer getCodDetalleSolicitud() {
		return codDetalleSolicitud;
	}
	public void setCodDetalleSolicitud(Integer codDetalleSolicitud) {
		this.codDetalleSolicitud = codDetalleSolicitud;
	}
	public String getCodPluNueva() {
		return codPluNueva;
	}
	public void setCodPluNueva(String codPluNueva) {
		this.codPluNueva = codPluNueva;
	}
	public String getCodReferenciaNueva() {
		return codReferenciaNueva;
	}
	public void setCodReferenciaNueva(String codReferenciaNueva) {
		this.codReferenciaNueva = codReferenciaNueva;
	}
	public String getTipTallaNueva() {
		return tipTallaNueva;
	}
	public void setTipTallaNueva(String tipTallaNueva) {
		this.tipTallaNueva = tipTallaNueva;
	}
	public String getCodColorNueva() {
		return codColorNueva;
	}
	public void setCodColorNueva(String codColorNueva) {
		this.codColorNueva = codColorNueva;
	}
	public String getCodEstado() {
		return codEstado;
	}
	public void setCodEstado(String codEstado) {
		this.codEstado = codEstado;
	}
	public String getCodUsuario() {
		return codUsuario;
	}
	public void setCodUsuario(String codUsuario) {
		this.codUsuario = codUsuario;
	}
	public Date getFecCreacion() {
		return fecCreacion;
	}
	public void setFecCreacion(Date fecCreacion) {
		this.fecCreacion = fecCreacion;
	}
	public String getNombreReferenciaNueva() {
		return nombreReferenciaNueva;
	}
	public void setNombreReferenciaNueva(String nombreReferenciaNueva) {
		this.nombreReferenciaNueva = nombreReferenciaNueva;
	}
	public String getNombreColorNueva() {
		return nombreColorNueva;
	}
	public void setNombreColorNueva(String nombreColorNueva) {
		this.nombreColorNueva = nombreColorNueva;
	}
	public String getNombreEstado() {
		return nombreEstado;
	}
	public void setNombreEstado(String nombreEstado) {
		this.nombreEstado = nombreEstado;
	}
	
}
