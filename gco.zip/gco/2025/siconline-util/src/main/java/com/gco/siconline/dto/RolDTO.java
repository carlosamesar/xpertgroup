package com.gco.siconline.dto;

public class RolDTO {

    private String nameRole;
    private Long nmrol;
    private Long node;

    public String getNameRole() {
        return nameRole;
    }

    public void setNameRole(String nameRole) {
        this.nameRole = nameRole;
    }

    public Long getNmrol() {
        return nmrol;
    }

    public void setNmrol(Long nmrol) {
        this.nmrol = nmrol;
    }

    public Long getNode() {
        return node;
    }

    public void setNode(Long node) {
        this.node = node;
    }

}
