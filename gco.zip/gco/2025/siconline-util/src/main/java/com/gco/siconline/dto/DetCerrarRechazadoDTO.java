package com.gco.siconline.dto;

public class DetCerrarRechazadoDTO {
	int codCambioP;
	int codDetSol;
	String codEstado;
	String codTipoDevolucion;
	int linea;
	public int getCodCambioP() {
		return codCambioP;
	}
	public void setCodCambioP(int codCambioP) {
		this.codCambioP = codCambioP;
	}
	public int getCodDetSol() {
		return codDetSol;
	}
	public void setCodDetSol(int codDetSol) {
		this.codDetSol = codDetSol;
	}
	public String getCodEstado() {
		return codEstado;
	}
	public void setCodEstado(String codEstado) {
		this.codEstado = codEstado;
	}
	public String getCodTipoDevolucion() {
		return codTipoDevolucion;
	}
	public void setCodTipoDevolucion(String codTipoDevolucion) {
		this.codTipoDevolucion = codTipoDevolucion;
	}
	public int getLinea() {
		return linea;
	}
	public void setLinea(int linea) {
		this.linea = linea;
	}
	
	
}
