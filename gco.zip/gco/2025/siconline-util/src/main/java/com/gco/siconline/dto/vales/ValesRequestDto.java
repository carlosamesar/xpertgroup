package com.gco.siconline.dto.vales;

import java.math.BigDecimal;

public class ValesRequestDto {
    private String empresa;
    private String canal;
    private String relationName;
    private String caption;
    private int quantity;
    private String emissionDate;
    private String expiringDate;
    private boolean restrictedToOwner;
    private boolean multipleRedemptions;
    private boolean multipleCredits;
    private String profileId;
    private String description;
    private BigDecimal value;
    private String name;
    private String usuario;

    public ValesRequestDto() {}

    public ValesRequestDto(String empresa, String canal, String relationName, String caption, int quantity,
                          String emissionDate, String expiringDate, boolean restrictedToOwner,
                          boolean multipleRedemptions, boolean multipleCredits, String profileId,
                          String description, BigDecimal value, String name, String usuario) {
        this.empresa = empresa;
        this.canal = canal;
        this.relationName = relationName;
        this.caption = caption;
        this.quantity = quantity;
        this.emissionDate = emissionDate;
        this.expiringDate = expiringDate;
        this.restrictedToOwner = restrictedToOwner;
        this.multipleRedemptions = multipleRedemptions;
        this.multipleCredits = multipleCredits;
        this.profileId = profileId;
        this.description = description;
        this.value = value;
        this.name = name;
        this.usuario = usuario;
    }

    public String getEmpresa() {
        return empresa;
    }

    public void setEmpresa(String empresa) {
        this.empresa = empresa;
    }

    public String getCanal() {
        return canal;
    }

    public void setCanal(String canal) {
        this.canal = canal;
    }

    public String getRelationName() {
        return relationName;
    }

    public void setRelationName(String relationName) {
        this.relationName = relationName;
    }

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getEmissionDate() {
        return emissionDate;
    }

    public void setEmissionDate(String emissionDate) {
        this.emissionDate = emissionDate;
    }

    public String getExpiringDate() {
        return expiringDate;
    }

    public void setExpiringDate(String expiringDate) {
        this.expiringDate = expiringDate;
    }

    public boolean getRestrictedToOwner() {
        return restrictedToOwner;
    }

    public void setRestrictedToOwner(boolean restrictedToOwner) {
        this.restrictedToOwner = restrictedToOwner;
    }

    public boolean getMultipleRedemptions() {
        return multipleRedemptions;
    }

    public void setMultipleRedemptions(boolean multipleRedemptions) {
        this.multipleRedemptions = multipleRedemptions;
    }

    public boolean getMultipleCredits() {
        return multipleCredits;
    }

    public void setMultipleCredits(boolean multipleCredits) {
        this.multipleCredits = multipleCredits;
    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public BigDecimal getValue() {
        return value;
    }

    public void setValue(BigDecimal value) {
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }
}
