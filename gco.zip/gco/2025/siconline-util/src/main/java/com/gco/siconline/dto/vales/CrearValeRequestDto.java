package com.gco.siconline.dto.vales;

public class CrearValeRequestDto {
    private String relationName;
    private String emissionDate;
    private String expiringDate;
    private String caption;
    private boolean restrictedToOwner;
    private boolean multipleRedemptions;
    private boolean multipleCredits;
    private String profileId;

    public CrearValeRequestDto() {
    }

    public CrearValeRequestDto(String relationName, String emissionDate, String expiringDate, String caption, boolean restrictedToOwner, boolean multipleRedemptions, boolean multipleCredits, String profileId) {
        this.relationName = relationName;
        this.emissionDate = emissionDate;
        this.expiringDate = expiringDate;
        this.caption = caption;
        this.restrictedToOwner = restrictedToOwner;
        this.multipleRedemptions = multipleRedemptions;
        this.multipleCredits = multipleCredits;
        this.profileId = profileId;
    }

    public String getRelationName() {
        return relationName;
    }

    public void setRelationName(String relationName) {
        this.relationName = relationName;
    }

    public String getEmissionDate() {
        return emissionDate;
    }

    public void setEmissionDate(String emissionDate) {
        this.emissionDate = emissionDate;
    }

    public String getExpiringDate() {
        return expiringDate;
    }

    public void setExpiringDate(String expiringDate) {
        this.expiringDate = expiringDate;
    }

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }

    public boolean isRestrictedToOwner() {
        return restrictedToOwner;
    }

    public void setRestrictedToOwner(boolean restrictedToOwner) {
        this.restrictedToOwner = restrictedToOwner;
    }

    public boolean isMultipleRedemptions() {
        return multipleRedemptions;
    }

    public void setMultipleRedemptions(boolean multipleRedemptions) {
        this.multipleRedemptions = multipleRedemptions;
    }

    public boolean isMultipleCredits() {
        return multipleCredits;
    }

    public void setMultipleCredits(boolean multipleCredits) {
        this.multipleCredits = multipleCredits;
    }

    public String getProfileId() {
        return profileId;
    }

    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }
}
