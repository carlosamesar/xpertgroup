package com.gco.siconline.dto;

public class PluReservaDTO {

    private String codPlu;

    private Integer cantidad;

    private Integer reservas;

    public PluReservaDTO(String codPlu, Integer cantidad, Integer reservas) {
        this.codPlu = codPlu;
        this.cantidad = cantidad;
        this.reservas = reservas;
    }

    public String getCodPlu() {
        return codPlu;
    }

    public void setCodPlu(String codPlu) {
        this.codPlu = codPlu;
    }

    public Integer getCantidad() {
        return cantidad;
    }

    public void setCantidad(Integer cantidad) {
        this.cantidad = cantidad;
    }

    public Integer getReservas() {
        return reservas;
    }

    public void setReservas(Integer reservas) {
        this.reservas = reservas;
    }

}
