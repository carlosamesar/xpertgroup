package com.gco.siconline.enums;

public enum TransporteEnum {

	ID_DELIVERY("ID_DELIVERY"),
	COD_BARRAS("COD_BARRAS"),
	PLU("PLU"),
	CANTIDAD("CANTIDAD"),
	GUIA("GUIA"),
	FECHA("FECHA")
	;
	private String value;

	private TransporteEnum(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
}
