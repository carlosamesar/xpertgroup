package com.gco.siconline.dto;

public class FormaPagoDTO {

    private String codFormaPago;
    private String nomFormaPago;
    private Character indEstado;
    private String codFpCanal;

    public String getCodFormaPago() {
        return codFormaPago;
    }

    public void setCodFormaPago(String codFormaPago) {
        this.codFormaPago = codFormaPago;
    }

    public String getNomFormaPago() {
        return nomFormaPago;
    }

    public void setNomFormaPago(String nomFormaPago) {
        this.nomFormaPago = nomFormaPago;
    }

    public String getCodFpCanal() {
        return codFpCanal;
    }

    public void setCodFpCanal(String codFpCanal) {
        this.codFpCanal = codFpCanal;
    }

    public Character getIndEstado() {
        return indEstado;
    }

    public void setIndEstado(Character indEstado) {
        this.indEstado = indEstado;
    }

}
