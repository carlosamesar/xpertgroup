package com.gco.siconline.dto;

import java.math.BigInteger;
import java.util.Date;

public class MovimientoGuiasDTO {
	private BigInteger numGuia ;      				    
	private String codTercero ;                          
	private int numUnidades ;                         
	private int numPeso ;                             
	private int codEmpresa ;                          
	private String codPais ;                             
	private String codDepartamento;                     
	private String codCiudad ;                           
	private String tipTercero ;                          
	private Date fecFecha ;                            
	private String nomCliente ;  
	private String num_exportacion ; 
	private String obs_facturas ; 
	private String obs_pedidos ; 
	private String num_despachocoord ; 
        private int enviadoGuia;
        private String codConcepto;
        private String nomResultadoGuia;
        private String numMovimiento;
        
	public BigInteger getNumGuia() {
        return numGuia;
    }

    public void setNumGuia(BigInteger numGuia) {
        this.numGuia = numGuia;
    }

    public String getCodTercero() {
        return codTercero;
    }

    public void setCodTercero(String codTercero) {
        this.codTercero = codTercero;
    }

    public int getNumUnidades() {
        return numUnidades;
    }

    public void setNumUnidades(int numUnidades) {
        this.numUnidades = numUnidades;
    }

    public int getNumPeso() {
        return numPeso;
    }

    public void setNumPeso(int numPeso) {
        this.numPeso = numPeso;
    }

    public int getCodEmpresa() {
        return codEmpresa;
    }

    public void setCodEmpresa(int codEmpresa) {
        this.codEmpresa = codEmpresa;
    }

    public String getCodPais() {
        return codPais;
    }

    public void setCodPais(String codPais) {
        this.codPais = codPais;
    }

    public String getCodDepartamento() {
        return codDepartamento;
    }

    public void setCodDepartamento(String codDepartamento) {
        this.codDepartamento = codDepartamento;
    }

    public String getCodCiudad() {
        return codCiudad;
    }

    public void setCodCiudad(String codCiudad) {
        this.codCiudad = codCiudad;
    }

    public String getTipTercero() {
        return tipTercero;
    }

    public void setTipTercero(String tipTercero) {
        this.tipTercero = tipTercero;
    }

    public Date getFecFecha() {
        return fecFecha;
    }

    public void setFecFecha(Date fecFecha) {
        this.fecFecha = fecFecha;
    }

    public String getNomCliente() {
        return nomCliente;
    }

    public void setNomCliente(String nomCliente) {
        this.nomCliente = nomCliente;
    }
    public String getNum_exportacion() {
        return num_exportacion;
    }

    public void setNum_exportacion(String num_exportacion) {
        this.num_exportacion = num_exportacion;
    }

    public String getObs_facturas() {
        return obs_facturas;
    }

    public void setObs_facturas(String obs_facturas) {
        this.obs_facturas = obs_facturas;
    }

    public String getObs_pedidos() {
        return obs_pedidos;
    }

    public void setObs_pedidos(String obs_pedidos) {
        this.obs_pedidos = obs_pedidos;
    }

    public String getNum_despachocoord() {
        return num_despachocoord;
    }

    public void setNum_despachocoord(String num_despachocoord) {
        this.num_despachocoord = num_despachocoord;
    }

    public int getEnviadoGuia() {
        return enviadoGuia;
    }

    public void setEnviadoGuia(int enviadoGuia) {
        this.enviadoGuia = enviadoGuia;
    }

    public String getCodConcepto() {
        return codConcepto;
    }

    public void setCodConcepto(String codConcepto) {
        this.codConcepto = codConcepto;
    }

    public String getNomResultadoGuia() {
        return nomResultadoGuia;
    }

    public void setNomResultadoGuia(String nomResultadoGuia) {
        this.nomResultadoGuia = nomResultadoGuia;
    }

    public String getNumMovimiento() {
        return numMovimiento;
    }

    public void setNumMovimiento(String numMovimiento) {
        this.numMovimiento = numMovimiento;
    }
 
    
    
}
