/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gco.siconline.dto;

/**
 *
 * @author besmart
 */
public class DetalleIncompletoDTO extends DetallePtlDTO {
    
    private String sio;

    public String getSio() {
        return sio;
    }

    public void setSio(String sio) {
        this.sio = sio;
    }
    
    
}
