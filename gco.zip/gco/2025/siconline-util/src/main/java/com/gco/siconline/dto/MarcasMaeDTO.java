/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gco.siconline.dto;

/**
 *
 * @author aalvarez
 */
public class MarcasMaeDTO {

    private short codEmpresa;
    private String codMarca;
    private String nomMarca;
    private String nomRutalogo;
    private Character indEstado;
    private String codEmpresaequiv;

    public MarcasMaeDTO() {
    }

    public MarcasMaeDTO(short codEmpresa, String codMarca, String nomMarca, String nomRutalogo, Character indEstado, String codEmpresaequiv) {
        this.codEmpresa = codEmpresa;
        this.codMarca = codMarca;
        this.nomMarca = nomMarca;
        this.nomRutalogo = nomRutalogo;
        this.indEstado = indEstado;
        this.codEmpresaequiv = codEmpresaequiv;
    }

    public short getCodEmpresa() {
        return codEmpresa;
    }

    public void setCodEmpresa(short codEmpresa) {
        this.codEmpresa = codEmpresa;
    }

    public String getCodMarca() {
        return codMarca;
    }

    public void setCodMarca(String codMarca) {
        this.codMarca = codMarca;
    }

    public String getNomMarca() {
        return nomMarca;
    }

    public void setNomMarca(String nomMarca) {
        this.nomMarca = nomMarca;
    }

    public String getNomRutalogo() {
        return nomRutalogo;
    }

    public void setNomRutalogo(String nomRutalogo) {
        this.nomRutalogo = nomRutalogo;
    }

    public Character getIndEstado() {
        return indEstado;
    }

    public void setIndEstado(Character indEstado) {
        this.indEstado = indEstado;
    }

    public String getCodEmpresaequiv() {
        return codEmpresaequiv;
    }

    public void setCodEmpresaequiv(String codEmpresaequiv) {
        this.codEmpresaequiv = codEmpresaequiv;
    }

}
