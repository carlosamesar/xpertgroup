package com.gco.siconline.dto;

import java.math.BigDecimal;
import java.util.Date;

import com.gco.siconline.enums.EstadosSolicitudDevolucion;

public class SolicitudDevolucionDetalleDTO {

    private Integer codSolicitud;
    private String codPlu;
    private String codReferencia;
    private String nombreReferencia;
    private String tipTalla;
    private String codColor;
    private String nombreColor;
    private Integer linea;
    private String codEstado;
    private EstadosSolicitudDevolucion nombreEstado;
    private String codUsuario;
    private String nombreUsuario;
    private String codMotivoDevolucion;
    private Integer idMotivoDevolucion;
    private String descMotivoDevolucion;
    private Date fecCreacion;
    private Integer codDetalleSolicitud;
    private Object motivoDevolucionInfo;
    private String codTipoDevolucion;
    private String nombreTipoDevolucion;
    private String observacion;
    private boolean devFlete;
    private BigDecimal valPromocion;
    private BigDecimal valCero;

    public Integer getCodSolicitud() {
        return codSolicitud;
    }

    public void setCodSolicitud(Integer codSolicitud) {
        this.codSolicitud = codSolicitud;
    }

    public String getCodPlu() {
        return codPlu;
    }

    public void setCodPlu(String codPlu) {
        this.codPlu = codPlu;
    }

    public String getCodReferencia() {
        return codReferencia;
    }

    public void setCodReferencia(String codReferencia) {
        this.codReferencia = codReferencia;
    }

    public String getTipTalla() {
        return tipTalla;
    }

    public void setTipTalla(String tipTalla) {
        this.tipTalla = tipTalla;
    }

    public Integer getLinea() {
        return linea;
    }

    public void setLinea(Integer linea) {
        this.linea = linea;
    }

    public String getCodEstado() {
        return codEstado;
    }

    public void setCodEstado(String codEstado) {
        this.codEstado = codEstado;
    }

    public String getCodUsuario() {
        return codUsuario;
    }

    public void setCodUsuario(String codUsuario) {
        this.codUsuario = codUsuario;
    }

    public Date getFecCreacion() {
        return fecCreacion;
    }

    public void setFecCreacion(Date fecCreacion) {
        this.fecCreacion = fecCreacion;
    }

    public Integer getCodDetalleSolicitud() {
        return codDetalleSolicitud;
    }

    public void setCodDetalleSolicitud(Integer codDetalleSolicitud) {
        this.codDetalleSolicitud = codDetalleSolicitud;
    }

    public String getCodColor() {
        return codColor;
    }

    public void setCodColor(String codColor) {
        this.codColor = codColor;
    }

    public Object getMotivoDevolucionInfo() {
        return motivoDevolucionInfo;
    }

    public void setMotivoDevolucionInfo(Object motivoDevolucionInfo) {
        this.motivoDevolucionInfo = motivoDevolucionInfo;
    }

    public String getNombreReferencia() {
        return nombreReferencia;
    }

    public void setNombreReferencia(String nombreReferencia) {
        this.nombreReferencia = nombreReferencia;
    }

    public String getNombreColor() {
        return nombreColor;
    }

    public void setNombreColor(String nombreColor) {
        this.nombreColor = nombreColor;
    }

    public EstadosSolicitudDevolucion getNombreEstado() {
        return nombreEstado;
    }

    public void setNombreEstado(EstadosSolicitudDevolucion nombreEstado) {
        this.nombreEstado = nombreEstado;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public String getCodMotivoDevolucion() {
        return codMotivoDevolucion;
    }

    public void setCodMotivoDevolucion(String codMotivoDevolucion) {
        this.codMotivoDevolucion = codMotivoDevolucion;
    }

    public Integer getIdMotivoDevolucion() {
        return idMotivoDevolucion;
    }

    public void setIdMotivoDevolucion(Integer idMotivoDevolucion) {
        this.idMotivoDevolucion = idMotivoDevolucion;
    }

    public String getDescMotivoDevolucion() {
        return descMotivoDevolucion;
    }

    public void setDescMotivoDevolucion(String descMotivoDevolucion) {
        this.descMotivoDevolucion = descMotivoDevolucion;
    }

    public String getNombreTipoDevolucion() {
        return nombreTipoDevolucion;
    }

    public void setNombreTipoDevolucion(String nombreTipoDevolucion) {
        this.nombreTipoDevolucion = nombreTipoDevolucion;
    }

    public String getCodTipoDevolucion() {
        return codTipoDevolucion;
    }

    public void setCodTipoDevolucion(String codTipoDevolucion) {
        this.codTipoDevolucion = codTipoDevolucion;
    }

    public String getObservacion() {
        return observacion;
    }

    public void setObservacion(String observacion) {
        this.observacion = observacion;
    }

    public boolean isDevFlete() {
        return devFlete;
    }

    public void setDevFlete(boolean devFlete) {
        this.devFlete = devFlete;
    }

    public BigDecimal getValPromocion() {
		return valPromocion;
	}
    
    public void setValPromocion(BigDecimal valPromocion) {
		this.valPromocion = valPromocion;
	}

	public BigDecimal getValCero() {
		return valCero;
	}

	public void setValCero(BigDecimal valCero) {
		this.valCero = valCero;
	}
    
    
    
}
