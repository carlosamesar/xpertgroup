package com.gco.siconline.dto;

import java.util.Date;

public class KardexcDTO {

    private String fechaAux;
    private Date fechaMovimiento;
    private String ubicacion;
    private String codCanasta;
    private String proveedor;
    private String codPlu;
    private String descripcionPlu;
    private String referencia;
    private String talla;
    private String codColor;
    private String nomColor;
    private String usuario;
    private String numMovimiento;
    private String numPedido;
    private int cantExistencia;
    private int cantReservada;
    private String concepto;
    private String canDisponible;
    private int sumUnidades;
    private int sumReservas;

    public KardexcDTO() {

    }

    public KardexcDTO(String ubicacion, String codCanasta, String proveedor, String codPlu,
            String talla, String usuario, int cantExistencia, int cantReservada) {
        this.ubicacion = ubicacion;
        this.codCanasta = codCanasta;
        this.proveedor = proveedor;
        this.codPlu = codPlu;
        this.talla = talla;
        this.usuario = usuario;
        this.cantExistencia = cantExistencia;
        this.cantReservada = cantReservada;
    }

    public KardexcDTO(Date fechaMovimiento, String referencia, String ubicacion, String codCanasta,
            String concepto, String numMovimiento, int cantExistencia, String usuario) {
        this.fechaMovimiento = fechaMovimiento;
        this.referencia = referencia;
        this.ubicacion = ubicacion;
        this.codCanasta = codCanasta;
        this.concepto = concepto;
        this.numMovimiento = numMovimiento;
        this.cantExistencia = cantExistencia;
        this.usuario = usuario;
    }

    public KardexcDTO(String ubicacion, String codCanasta, String proveedor, String codPlu, String referencia,
            String talla, String color, int cantExistencia, int cantReservada, int canDisponible) {
        this.ubicacion = ubicacion;
        this.codCanasta = codCanasta;
        this.proveedor = proveedor;
        this.codPlu = codPlu;
        this.referencia = referencia;
        this.talla = talla;
        this.cantExistencia = cantExistencia;
        this.cantReservada = cantReservada;
        this.canDisponible = "" + canDisponible;
        this.codColor = color;
    }

    public KardexcDTO(String ubicacion, String codCanasta, String proveedor, String codPlu,
            String talla, String referencia, String color, String usuario, int cantExistencia, int cantReservada) {
        this.ubicacion = ubicacion;
        this.codCanasta = codCanasta;
        this.proveedor = proveedor;
        this.codPlu = codPlu;
        this.talla = talla;
        this.usuario = usuario;
        this.cantExistencia = cantExistencia;
        this.cantReservada = cantReservada;
        this.referencia = referencia;
        this.codColor = color;
    }

    public KardexcDTO(String ubicacion, String codCanasta, String proveedor, String codPlu,
            String talla, String color, String usuario, int cantExistencia, int cantReservada) {
        this.ubicacion = ubicacion;
        this.codCanasta = codCanasta;
        this.proveedor = proveedor;
        this.codPlu = codPlu;
        this.talla = talla;
        this.usuario = usuario;
        this.cantExistencia = cantExistencia;
        this.cantReservada = cantReservada;
        this.codColor = color;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    public String getCodCanasta() {
        return codCanasta;
    }

    public void setCodCanasta(String codCanasta) {
        this.codCanasta = codCanasta;
    }

    public String getProveedor() {
        return proveedor;
    }

    public void setProveedor(String proveedor) {
        this.proveedor = proveedor;
    }

    public String getCodPlu() {
        return codPlu;
    }

    public void setCodPlu(String codPlu) {
        this.codPlu = codPlu;
    }

    public String getDescripcionPlu() {
        return descripcionPlu;
    }

    public void setDescripcionPlu(String descripcionPlu) {
        this.descripcionPlu = descripcionPlu;
    }

    public String getReferencia() {
        return referencia;
    }

    public void setReferencia(String referencia) {
        this.referencia = referencia;
    }

    public String getTalla() {
        return talla;
    }

    public void setTalla(String talla) {
        this.talla = talla;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public int getCantExistencia() {
        return cantExistencia;
    }

    public void setCantExistencia(int cantExistencia) {
        this.cantExistencia = cantExistencia;
    }

    public int getCantReservada() {
        return cantReservada;
    }

    public void setCantReservada(int cantReservada) {
        this.cantReservada = cantReservada;
    }

    public Date getFechaMovimiento() {
        return fechaMovimiento;
    }

    public void setFechaMovimiento(Date fechaMovimiento) {
        this.fechaMovimiento = fechaMovimiento;
    }

    public String getConcepto() {
        return concepto;
    }

    public void setConcepto(String concepto) {
        this.concepto = concepto;
    }

    public String getNumMovimiento() {
        return numMovimiento;
    }

    public void setNumMovimiento(String numMovimiento) {
        this.numMovimiento = numMovimiento;
    }

    public String getCanDisponible() {
        return canDisponible;
    }

    public void setCanDisponible(String canDisponible) {
        this.canDisponible = canDisponible;
    }

    public String getNumPedido() {
        return numPedido;
    }

    public void setNumPedido(String numPedido) {
        this.numPedido = numPedido;
    }

    public String getCodColor() {
        return codColor;
    }

    public void setCodColor(String codColor) {
        this.codColor = codColor;
    }

    public String getNomColor() {
        return nomColor;
    }

    public void setNomColor(String nomColor) {
        this.nomColor = nomColor;
    }

    public int getSumUnidades() {
        return sumUnidades;
    }

    public void setSumUnidades(int sumUnidades) {
        this.sumUnidades = sumUnidades;
    }

    public int getSumReservas() {
        return sumReservas;
    }

    public void setSumReservas(int sumReservas) {
        this.sumReservas = sumReservas;
    }

    public String getFechaAux() {
        return fechaAux;
    }

    public void setFechaAux(String fechaAux) {
        this.fechaAux = fechaAux;
    }

}
