package com.gco.siconline.dto;

public class SellerDTO {

    private String nombreSeller;
    private String idSeller;
    private String codigoFpSeller;
    
	public String getNombreSeller() {
		return nombreSeller;
	}
	public void setNombreSeller(String nombreSeller) {
		this.nombreSeller = nombreSeller;
	}
	public String getIdSeller() {
		return idSeller;
	}
	public void setIdSeller(String idSeller) {
		this.idSeller = idSeller;
	}
	public String getCodigoFpSeller() {
		return codigoFpSeller;
	}
	public void setCodigoFpSeller(String codigoSeller) {
		this.codigoFpSeller = codigoSeller;
	}
    
    
}
