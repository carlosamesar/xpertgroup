package com.gco.siconline.dto;

public class ResponseConsultaPluDTO {

    private String codigo;
    private String mensaje;
    private Integer canReserva;

    public ResponseConsultaPluDTO() {
    }

    public ResponseConsultaPluDTO(String codigo, String mensaje) {
        super();
        this.codigo = codigo;
        this.mensaje = mensaje;
    }
    
    public ResponseConsultaPluDTO(String codigo, String mensaje, Integer canReserva) {
        this.codigo = codigo;
        this.mensaje = mensaje;
        this.canReserva = canReserva;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public Integer getCanReserva() {
        return canReserva;
    }

    public void setCanReserva(Integer canReserva) {
        this.canReserva = canReserva;
    }
    

}
