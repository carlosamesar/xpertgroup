package com.gco.siconline.dto;

public class RequestControlUserDTO extends RequestControlDTO {

    private String codUsuario;

    public String getCodUsuario() {
        return codUsuario;
    }

    public void setCodUsuario(String codUsuario) {
        this.codUsuario = codUsuario;
    }
}
