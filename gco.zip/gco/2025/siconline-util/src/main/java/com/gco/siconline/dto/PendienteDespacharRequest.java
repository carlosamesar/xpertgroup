package com.gco.siconline.dto;

import java.sql.Date;

public class PendienteDespacharRequest {

    private int codEmpresa;
    private String marca;
    private Date fechaIni;
    private Date fechaFin;

    public PendienteDespacharRequest() {

    }

    public int getcodEmpresa() {
        return codEmpresa;
    }

    public void setcodEmpresa(int codEmpresa) {
        this.codEmpresa = codEmpresa;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public Date getFechaIni() {
        return fechaIni;
    }

    public void setFechaIni(Date fechaIni) {
        this.fechaIni = fechaIni;
    }

    public Date getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(Date fechaFin) {
        this.fechaFin = fechaFin;
    }

}
