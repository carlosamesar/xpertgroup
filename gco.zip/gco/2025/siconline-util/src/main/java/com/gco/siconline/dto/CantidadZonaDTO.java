package com.gco.siconline.dto;

import java.math.BigDecimal;
import java.math.BigInteger;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


@JsonPropertyOrder({ "codPlu", "codReferencia", "codProveedoref", "codTercero", "tipTalla","codColor","indCalidad","numOrden","valUltimocosto","valCostopromedio","a","b"
	,"c","d","e","f","i","j","l","n","p","r","s","u","o","z","m","t","g","totalUnidades","noPickeable","pickeable","unidadesPedido","pedidos","disponible","idMarketplace"})


public class CantidadZonaDTO {
	 @JsonProperty("codPlu")	
	private String codPlu;
	 
	 @JsonProperty("codReferencia")
	private String codReferencia;
	 
	 @JsonProperty("codProveedoref")
	private String codProveedoref;
	 
	 @JsonProperty("codTercero")
	private String codTercero;
	 
	 @JsonProperty("tipTalla")
	 private String tipTalla;
	 
	 @JsonProperty("codColor")
	private String codColor;
	 
	 @JsonProperty("indCalidad")
	private String indCalidad;
	 
	 @JsonProperty("numOrden")
	private int numOrden;
	 
	 @JsonProperty("valUltimocosto")
	private BigDecimal valUltimocosto;
	 
	 @JsonProperty("valCostopromedio")
	private BigDecimal valCostopromedio;
	 
	 @JsonProperty("a")
	private BigInteger a;
	 
	 @JsonProperty("b")
	private BigInteger b;
	 
	 @JsonProperty("c")
	private BigInteger c;
	 
	 @JsonProperty("d")
	private BigInteger d;
	 
	 @JsonProperty("e")
	private BigInteger e;
	 
	 @JsonProperty("f")
	private BigInteger f;
	 
	 @JsonProperty("i")
	private BigInteger i;
	 
	 @JsonProperty("j")
	private BigInteger j;
	 
	 @JsonProperty("l")
	private BigInteger l;
	 
	 @JsonProperty("n")
	private BigInteger n;
	 
	 @JsonProperty("p")
	private BigInteger p;
	 
	 @JsonProperty("r")
	private BigInteger r;
	 
	 @JsonProperty("s")
	private BigInteger s;
	 
	 @JsonProperty("u")
	private BigInteger u;
	 
	 @JsonProperty("o")
	private BigInteger O;
	 
	 @JsonProperty("z")
		private BigInteger z;
	 @JsonProperty("m")
		private BigInteger m;
	 
	 @JsonProperty("t")
		private BigInteger t;
	 
	 @JsonProperty("g")
		private BigInteger g;
	 
	 @JsonProperty("totalUnidades")
	private BigInteger totalUnidades;
	 
	 @JsonProperty("noPickeable")
	private BigInteger noPickeable;
	 
	 @JsonProperty("pickeable")
	private BigInteger pickeable;
	 
	 @JsonProperty("unidadesPedido")
	private BigInteger unidadesPedido;
	 
	 @JsonProperty("pedidos")
	private String pedidos;
	 
	 @JsonProperty("disponible")
	private BigDecimal disponible;
	 
	 @JsonProperty("idMarketplace")
	private String idMarketplace;
	 
	public String getCodPlu() {
		return codPlu;
	}
	public void setCodPlu(String codPlu) {
		this.codPlu = codPlu;
	}
	public String getCodReferencia() {
		return codReferencia;
	}
	public void setCodReferencia(String codReferencia) {
		this.codReferencia = codReferencia;
	}
	public String getCodProveedoref() {
		return codProveedoref;
	}
	public void setCodProveedoref(String codProveedoref) {
		this.codProveedoref = codProveedoref;
	}
	public String getCodTercero() {
		return codTercero;
	}
	public void setCodTercero(String codTercero) {
		this.codTercero = codTercero;
	}
	public String getTipTalla() {
		return tipTalla;
	}
	public void setTipTalla(String tipTalla) {
		this.tipTalla = tipTalla;
	}
	public String getCodColor() {
		return codColor;
	}
	public void setCodColor(String codColor) {
		this.codColor = codColor;
	}
	public String getIndCalidad() {
		return indCalidad;
	}
	public void setIndCalidad(String indCalidad) {
		this.indCalidad = indCalidad;
	}
	public int getNumOrden() {
		return numOrden;
	}
	public void setNumOrden(int numOrden) {
		this.numOrden = numOrden;
	}
	public BigDecimal getValUltimocosto() {
		return valUltimocosto;
	}
	public void setValUltimocosto(BigDecimal valUltimocosto) {
		this.valUltimocosto = valUltimocosto;
	}
	public BigDecimal getValCostopromedio() {
		return valCostopromedio;
	}
	public void setValCostopromedio(BigDecimal valCostopromedio) {
		this.valCostopromedio = valCostopromedio;
	}
	public BigInteger getA() {
		return a;
	}
	public void setA(BigInteger a) {
		this.a = a;
	}
	public BigInteger getB() {
		return b;
	}
	public void setB(BigInteger b) {
		this.b = b;
	}
	public BigInteger getC() {
		return c;
	}
	public void setC(BigInteger c) {
		this.c = c;
	}
	public BigInteger getD() {
		return d;
	}
	public void setD(BigInteger d) {
		this.d = d;
	}
	public BigInteger getE() {
		return e;
	}
	public void setE(BigInteger e) {
		this.e = e;
	}
	public BigInteger getF() {
		return f;
	}
	public void setF(BigInteger f) {
		this.f = f;
	}
	public BigInteger getI() {
		return i;
	}
	public void setI(BigInteger i) {
		this.i = i;
	}
	public BigInteger getJ() {
		return j;
	}
	public void setJ(BigInteger j) {
		this.j = j;
	}
	public BigInteger getL() {
		return l;
	}
	public void setL(BigInteger l) {
		this.l = l;
	}
	public BigInteger getN() {
		return n;
	}
	public void setN(BigInteger n) {
		this.n = n;
	}
	public BigInteger getP() {
		return p;
	}
	public void setP(BigInteger p) {
		this.p = p;
	}
	public BigInteger getR() {
		return r;
	}
	public void setR(BigInteger r) {
		this.r = r;
	}
	public BigInteger getS() {
		return s;
	}
	public void setS(BigInteger s) {
		this.s = s;
	}
	public BigInteger getU() {
		return u;
	}
	public void setU(BigInteger u) {
		this.u = u;
	}
	
	public BigInteger getO() {
		return O;
	}
	public void setO(BigInteger o) {
		O = o;
	}
	
	public BigInteger getZ() {
		return z;
	}
	public void setZ(BigInteger z) {
		this.z = z;
	}
	
	
	public BigInteger getM() {
		return m;
	}
	public void setM(BigInteger m) {
		this.m = m;
	}
	public BigInteger getTotalUnidades() {
		return totalUnidades;
	}
	public void setTotalUnidades(BigInteger totalUnidades) {
		this.totalUnidades = totalUnidades;
	}
	public BigInteger getNoPickeable() {
		return noPickeable;
	}
	public void setNoPickeable(BigInteger noPickeable) {
		this.noPickeable = noPickeable;
	}
	public BigInteger getPickeable() {
		return pickeable;
	}
	public void setPickeable(BigInteger pickeable) {
		this.pickeable = pickeable;
	}
	public BigInteger getUnidadesPedido() {
		return unidadesPedido;
	}
	public void setUnidadesPedido(BigInteger unidadesPedido) {
		this.unidadesPedido = unidadesPedido;
	}
	public String getPedidos() {
		return pedidos;
	}
	public void setPedidos(String pedidos) {
		this.pedidos = pedidos;
	}
	public BigDecimal getDisponible() {
		return disponible;
	}
	public void setDisponible(BigDecimal disponible) {
		this.disponible = disponible;
	}
	public String getIdMarketplace() {
		return idMarketplace;
	}
	public void setIdMarketplace(String idMarketplace) {
		this.idMarketplace = idMarketplace;
	}
	public BigInteger getT() {
		return t;
	}
	public void setT(BigInteger t) {
		this.t = t;
	}
	public BigInteger getG() {
		return g;
	}
	public void setG(BigInteger g) {
		this.g = g;
	}
	
	
}
