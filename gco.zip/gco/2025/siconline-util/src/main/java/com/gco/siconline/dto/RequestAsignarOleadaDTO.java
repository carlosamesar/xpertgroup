package com.gco.siconline.dto;

public class RequestAsignarOleadaDTO extends RequestOleadaDTO {

    protected String codUsuario;

    public String getCodUsuario() {
        return codUsuario;
    }

    public void setCodUsuario(String codUsuario) {
        this.codUsuario = codUsuario;
    }

}
