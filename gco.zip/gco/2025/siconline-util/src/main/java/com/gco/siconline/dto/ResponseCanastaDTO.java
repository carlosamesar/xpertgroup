package com.gco.siconline.dto;

public class ResponseCanastaDTO {

    protected String codCaja;
    protected Long cantidad;

    public ResponseCanastaDTO() {
    }

    public ResponseCanastaDTO(String codigo, Long cantidad) {
        super();
        this.codCaja = codigo;
        this.cantidad = cantidad;
    }

    public Long getCantidad() {
        return cantidad;
    }

    public void setCantidad(Long cantidad) {
        this.cantidad = cantidad;
    }

    public String getCodCaja() {
        return codCaja;
    }

    public void setCodCaja(String codCaja) {
        this.codCaja = codCaja;
    }

}
