package com.gco.siconline.dto;

import java.math.BigDecimal;
import java.util.Date;

public class ResponseConsultaMovsDTO {

    private String desRutaLogo;
    private int codEmpresa;
    private String indAplicacion;
    private String codConcepto;
    private String tipClasemovto;
    private String codTercero;
    private String tipTercero;
    private String numMovimiento;
    private String indCalidad;
    private String codReferencia;
    private String tipTalla;
    private String codColor;
    private String nomColor;
    private int numCantidad;
    private Date fecMovtoasoc;
    private String horMovimiento;
    private String numMovtoasoc;
    private String numDocrespalda;
    private String codPlu;
    private String codProveedoref;
    private String indEstado;
    private int numPeriodo;
    private String codVendedor;
    private BigDecimal porDescuentopie;
    private String cPor;
    private BigDecimal valUnidad;
    private BigDecimal ahorro;
    
    private BigDecimal valDescuento;
    private BigDecimal valTotal;
    private BigDecimal subTotal;
    private BigDecimal valorSinIva;
    private BigDecimal valorIva;
    

    public ResponseConsultaMovsDTO() {
    }

    public String getDesRutaLogo() {
        return desRutaLogo;
    }

    public void setDesRutaLogo(String desRutaLogo) {
        this.desRutaLogo = desRutaLogo;
    }

    public int getCodEmpresa() {
        return codEmpresa;
    }

    public void setCodEmpresa(int codEmpresa) {
        this.codEmpresa = codEmpresa;
    }

    public String getIndAplicacion() {
        return indAplicacion;
    }

    public void setIndAplicacion(String indAplicacion) {
        this.indAplicacion = indAplicacion;
    }

    public String getCodConcepto() {
        return codConcepto;
    }

    public void setCodConcepto(String codConcepto) {
        this.codConcepto = codConcepto;
    }

    public String getTipClasemovto() {
        return tipClasemovto;
    }

    public void setTipClasemovto(String tipClasemovto) {
        this.tipClasemovto = tipClasemovto;
    }

    public String getCodTercero() {
        return codTercero;
    }

    public void setCodTercero(String codTercero) {
        this.codTercero = codTercero;
    }

    public String getTipTercero() {
        return tipTercero;
    }

    public void setTipTercero(String tipTercero) {
        this.tipTercero = tipTercero;
    }

    public String getNumMovimiento() {
        return numMovimiento;
    }

    public void setNumMovimiento(String numMovimiento) {
        this.numMovimiento = numMovimiento;
    }

    public String getIndCalidad() {
        return indCalidad;
    }

    public void setIndCalidad(String indCalidad) {
        this.indCalidad = indCalidad;
    }

    public String getCodReferencia() {
        return codReferencia;
    }

    public void setCodReferencia(String codReferencia) {
        this.codReferencia = codReferencia;
    }

    public String getTipTalla() {
        return tipTalla;
    }

    public void setTipTalla(String tipTalla) {
        this.tipTalla = tipTalla;
    }

    public String getCodColor() {
        return codColor;
    }

    public void setCodColor(String codColor) {
        this.codColor = codColor;
    }

    public BigDecimal getValUnidad() {
        return valUnidad;
    }

    public void setValUnidad(BigDecimal valUnidad) {
        this.valUnidad = valUnidad;
    }

    public int getNumCantidad() {
        return numCantidad;
    }

    public void setNumCantidad(int numCantidad) {
        this.numCantidad = numCantidad;
    }

    public String getHorMovimiento() {
        return horMovimiento;
    }

    public void setHorMovimiento(String horMovimiento) {
        this.horMovimiento = horMovimiento;
    }

    public String getNumMovtoasoc() {
        return numMovtoasoc;
    }

    public void setNumMovtoasoc(String numMovtoasoc) {
        this.numMovtoasoc = numMovtoasoc;
    }

    public String getCodPlu() {
        return codPlu;
    }

    public void setCodPlu(String codPlu) {
        this.codPlu = codPlu;
    }

    public String getCodProveedoref() {
        return codProveedoref;
    }

    public void setCodProveedoref(String codProveedoref) {
        this.codProveedoref = codProveedoref;
    }

    public String getIndEstado() {
        return indEstado;
    }

    public void setIndEstado(String indEstado) {
        this.indEstado = indEstado;
    }

    public int getNumPeriodo() {
        return numPeriodo;
    }

    public void setNumPeriodo(int numPeriodo) {
        this.numPeriodo = numPeriodo;
    }

    public String getCodVendedor() {
        return codVendedor;
    }

    public void setCodVendedor(String codVendedor) {
        this.codVendedor = codVendedor;
    }

    public BigDecimal getPorDescuentopie() {
        return porDescuentopie;
    }

    public void setPorDescuentopie(BigDecimal porDescuentopie) {
        this.porDescuentopie = porDescuentopie;
    }

    public String getcPor() {
        return cPor;
    }

    public void setcPor(String cPor) {
        this.cPor = cPor;
    }

    public Date getFecMovtoasoc() {
        return fecMovtoasoc;
    }

    public void setFecMovtoasoc(Date fecMovtoasoc) {
        this.fecMovtoasoc = fecMovtoasoc;
    }

    public String getNumDocrespalda() {
        return numDocrespalda;
    }

    public void setNumDocrespalda(String numDocrespalda) {
        this.numDocrespalda = numDocrespalda;
    }

    public BigDecimal getSubTotal() {
        return subTotal;
    }

    public void setSubTotal(BigDecimal subTotal) {
        this.subTotal = subTotal;
    }

    public String getNomColor() {
        return nomColor;
    }

    public void setNomColor(String nomColor) {
        this.nomColor = nomColor;
    }

    public BigDecimal getValDescuento() {
        return valDescuento;
    }

    public void setValDescuento(BigDecimal valDescuento) {
        this.valDescuento = valDescuento;
    }

    public BigDecimal getValTotal() {
        return valTotal;
    }

    public void setValTotal(BigDecimal valTotal) {
        this.valTotal = valTotal;
    }

    public BigDecimal getValorSinIva() {
        return valorSinIva;
    }

    public void setValorSinIva(BigDecimal valorSinIva) {
        this.valorSinIva = valorSinIva;
    }

    public BigDecimal getValorIva() {
        return valorIva;
    }

    public void setValorIva(BigDecimal valorIva) {
        this.valorIva = valorIva;
    }

    public BigDecimal getAhorro() {
        return ahorro;
    }

    public void setAhorro(BigDecimal ahorro) {
        this.ahorro = ahorro;
    }
    
    
}
