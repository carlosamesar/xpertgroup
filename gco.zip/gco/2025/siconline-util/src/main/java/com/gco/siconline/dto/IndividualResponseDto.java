package com.gco.siconline.dto;



public class IndividualResponseDto {
    private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
    
	 public IndividualResponseDto(String message) {
	        this.message = message;
	    }

}
