package com.gco.siconline.dto;

import java.util.List;

public class RequestBloqueoPedidoDTO {

    private List<Object> pedidos;
    private String observacion;

    public List<Object> getPedidos() {
        return pedidos;
    }

    public void setPedidos(List<Object> pedidos) {
        this.pedidos = pedidos;
    }

    public String getObservacion() {
        return observacion;
    }

    public void setObservacion(String observacion) {
        this.observacion = observacion;
    }

}
