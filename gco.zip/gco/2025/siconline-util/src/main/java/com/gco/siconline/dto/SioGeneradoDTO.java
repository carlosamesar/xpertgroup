package com.gco.siconline.dto;

import java.util.Date;

public class SioGeneradoDTO {

    private Date fecPedido;
    private String codTercero;
    private String numPedido;
    private String codReferencia;
    private String tipTalla;
    private String codPlu;
    private String codColor;
    private String estPedido;
    private Integer canPedida;

    public SioGeneradoDTO(Date fecPedido, String codTercero, String numPedido, String codReferencia, String tipTalla,
            String codPlu, String codColor, String estPedido, Integer canPedida) {
        super();
        this.fecPedido = fecPedido;
        this.codTercero = codTercero;
        this.numPedido = numPedido;
        this.codReferencia = codReferencia;
        this.tipTalla = tipTalla;
        this.codPlu = codPlu;
        this.codColor = codColor;
        this.estPedido = estPedido;
        this.canPedida = canPedida;
    }

    public Date getFecPedido() {
        return fecPedido;
    }

    public void setFecPedido(Date fecPedido) {
        this.fecPedido = fecPedido;
    }

    public String getCodTercero() {
        return codTercero;
    }

    public void setCodTercero(String codTercero) {
        this.codTercero = codTercero;
    }

    public String getNumPedido() {
        return numPedido;
    }

    public void setNumPedido(String numPedido) {
        this.numPedido = numPedido;
    }

    public String getCodReferencia() {
        return codReferencia;
    }

    public void setCodReferencia(String codReferencia) {
        this.codReferencia = codReferencia;
    }

    public String getTipTalla() {
        return tipTalla;
    }

    public void setTipTalla(String tipTalla) {
        this.tipTalla = tipTalla;
    }

    public String getCodPlu() {
        return codPlu;
    }

    public void setCodPlu(String codPlu) {
        this.codPlu = codPlu;
    }

    public String getCodColor() {
        return codColor;
    }

    public void setCodColor(String codColor) {
        this.codColor = codColor;
    }

    public String getEstPedido() {
        return estPedido;
    }

    public void setEstPedido(String estPedido) {
        this.estPedido = estPedido;
    }

    public Integer getCanPedida() {
        return canPedida;
    }

    public void setCanPedida(Integer canPedida) {
        this.canPedida = canPedida;
    }

}
