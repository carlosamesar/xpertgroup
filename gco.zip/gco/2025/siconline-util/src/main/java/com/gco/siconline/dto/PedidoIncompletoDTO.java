package com.gco.siconline.dto;

import java.math.BigDecimal;

public class PedidoIncompletoDTO extends PedidoIncompletoFiltroDTO{
	
	private String correoCliente;
	private String telCliente;
	private String pluFaltante;
	private String codReferencia;
	private String tipTalla;
	private String codColor;
	private BigDecimal valUnidad;
	

	public PedidoIncompletoDTO() {
	}


	public String getCorreoCliente() {
		return correoCliente;
	}


	public void setCorreoCliente(String correoCliente) {
		this.correoCliente = correoCliente;
	}


	public String getTelCliente() {
		return telCliente;
	}


	public void setTelCliente(String telCliente) {
		this.telCliente = telCliente;
	}


	public String getPluFaltante() {
		return pluFaltante;
	}


	public void setPluFaltante(String pluFaltante) {
		this.pluFaltante = pluFaltante;
	}


	public String getCodReferencia() {
		return codReferencia;
	}


	public void setCodReferencia(String codReferencia) {
		this.codReferencia = codReferencia;
	}


	public String getTipTalla() {
		return tipTalla;
	}


	public void setTipTalla(String tipTalla) {
		this.tipTalla = tipTalla;
	}


	public String getCodColor() {
		return codColor;
	}


	public void setCodColor(String codColor) {
		this.codColor = codColor;
	}


	public BigDecimal getValUnidad() {
		return valUnidad;
	}


	public void setValUnidad(BigDecimal valUnidad) {
		this.valUnidad = valUnidad;
	}
	
	

}
