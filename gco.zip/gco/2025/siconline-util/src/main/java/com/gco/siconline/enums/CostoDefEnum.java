package com.gco.siconline.enums;

public enum CostoDefEnum {

	NUM_SN("Nº SN"),
	CAJA("CAJA"),
	REFERENCIA("REFERENCIA"),
	COSTO_UNITARIO_PROMEDIO("COSTO UNITARIO PROMEDIO")
	;
	private String value;

	private CostoDefEnum(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
}
