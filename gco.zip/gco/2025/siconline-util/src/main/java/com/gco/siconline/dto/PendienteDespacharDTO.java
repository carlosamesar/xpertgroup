package com.gco.siconline.dto;

import java.math.BigDecimal;
import java.util.Date;

public class PendienteDespacharDTO {

    private String codProveedoref;
    private String codReferencia;
    private String nomReferencia;
    private String numPedido;
    private String numOrdenCompra;
    private String tipTalla;
    private String codColor;
    private String nomColor;
    private int canPedida;
    private String codPlu;
    private double valUnidad;
    private int canPendiente;
    private Date fecPedido;
    private BigDecimal porDescuentopie;
    private String codTercero;
    private String tipTercero;
    private String nomEmpresa;
    private String desRutalogo;
    private String nomNombrecomercia;
    private String numNit;
    private String direccion;
    private String numTelefonodes;
    private Number cFlete;
    private String diasRetraso;
    private String nomObservacion;
    private String estPedido;

    public String getCodProveedoref() {
        return codProveedoref;
    }

    public void setCodProveedoref(String codProveedoref) {
        this.codProveedoref = codProveedoref;
    }

    public String getCodReferencia() {
        return codReferencia;
    }

    public void setCodReferencia(String codReferencia) {
        this.codReferencia = codReferencia;
    }

    public String getNomReferencia() {
        return nomReferencia;
    }

    public void setNomReferencia(String nomReferencia) {
        this.nomReferencia = nomReferencia;
    }

    public String getNumPedido() {
        return numPedido;
    }

    public void setNumPedido(String numPedido) {
        this.numPedido = numPedido;
    }

    public String getNumOrdenCompra() {
        return numOrdenCompra;
    }

    public void setNumOrdenCompra(String numOrdenCompra) {
        this.numOrdenCompra = numOrdenCompra;
    }

    public String getTipTalla() {
        return tipTalla;
    }

    public void setTipTalla(String tipTalla) {
        this.tipTalla = tipTalla;
    }

    public String getCodColor() {
        return codColor;
    }

    public void setCodColor(String codColor) {
        this.codColor = codColor;
    }

    public String getNomColor() {
        return nomColor;
    }

    public void setNomColor(String nomColor) {
        this.nomColor = nomColor;
    }

    public int getCanPedida() {
        return canPedida;
    }

    public void setCanPedida(int canPedida) {
        this.canPedida = canPedida;
    }

    public String getCodPlu() {
        return codPlu;
    }

    public void setCodPlu(String codPlu) {
        this.codPlu = codPlu;
    }

    public double getValUnidad() {
        return valUnidad;
    }

    public void setValUnidad(double valUnidad) {
        this.valUnidad = valUnidad;
    }

    public int getCanPendiente() {
        return canPendiente;
    }

    public void setCanPendiente(int canPendiente) {
        this.canPendiente = canPendiente;
    }

    public Date getFecPedido() {
        return fecPedido;
    }

    public void setFecPedido(Date fecPedido) {
        this.fecPedido = fecPedido;
    }

    public BigDecimal getPorDescuentopie() {
        return porDescuentopie;
    }

    public void setPorDescuentopie(BigDecimal porDescuentopie) {
        this.porDescuentopie = porDescuentopie;
    }

    public String getCodTercero() {
        return codTercero;
    }

    public void setCodTercero(String codTercero) {
        this.codTercero = codTercero;
    }

    public String getTipTercero() {
        return tipTercero;
    }

    public void setTipTercero(String tipTercero) {
        this.tipTercero = tipTercero;
    }

    public String getNomEmpresa() {
        return nomEmpresa;
    }

    public void setNomEmpresa(String nomEmpresa) {
        this.nomEmpresa = nomEmpresa;
    }

    public String getDesRutalogo() {
        return desRutalogo;
    }

    public void setDesRutalogo(String desRutalogo) {
        this.desRutalogo = desRutalogo;
    }

    public String getNomNombrecomercia() {
        return nomNombrecomercia;
    }

    public void setNomNombrecomercia(String nomNombrecomercia) {
        this.nomNombrecomercia = nomNombrecomercia;
    }

    public String getNumNit() {
        return numNit;
    }

    public void setNumNit(String numNit) {
        this.numNit = numNit;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getNumTelefonodes() {
        return numTelefonodes;
    }

    public void setNumTelefonodes(String numTelefonodes) {
        this.numTelefonodes = numTelefonodes;
    }

    public Number getcFlete() {
        return cFlete;
    }

    public void setcFlete(Number cFlete) {
        this.cFlete = cFlete;
    }

    public String getDiasRetraso() {
        return diasRetraso;
    }

    public void setDiasRetraso(String diasRetraso) {
        this.diasRetraso = diasRetraso;
    }

    public String getNomObservacion() {
        return nomObservacion;
    }

    public void setNomObservacion(String nomObservacion) {
        this.nomObservacion = nomObservacion;
    }

    public String getEstPedido() {
        return estPedido;
    }

    public void setEstPedido(String estPedido) {
        this.estPedido = estPedido;
    }

}
