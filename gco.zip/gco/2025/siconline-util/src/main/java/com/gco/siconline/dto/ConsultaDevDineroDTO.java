package com.gco.siconline.dto;

import java.math.BigDecimal;
import java.util.Date;

public class ConsultaDevDineroDTO {

    private String movimiento;
    private String pedido;
    private String ordenCompra;
    private String casoDynamic;
    private Date fechaCreacion;
    private BigDecimal ValorDev;
    private String codDetalleSolicitud;
    private int codSolicitudDinero;
    private boolean incompleto;

    public String getMovimiento() {
        return movimiento;
    }

    public void setMovimiento(String movimiento) {
        this.movimiento = movimiento;
    }

    public String getPedido() {
        return pedido;
    }

    public void setPedido(String pedido) {
        this.pedido = pedido;
    }

    public String getOrdenCompra() {
        return ordenCompra;
    }

    public void setOrdenCompra(String ordenCompra) {
        this.ordenCompra = ordenCompra;
    }

    public String getCasoDynamic() {
        return casoDynamic;
    }

    public void setCasoDynamic(String casoDynamic) {
        this.casoDynamic = casoDynamic;
    }

    public Date getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(Date fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public BigDecimal getValorDev() {
        return ValorDev;
    }

    public void setValorDev(BigDecimal valorDev) {
        ValorDev = valorDev;
    }

    public String getCodDetalleSolicitud() {
        return codDetalleSolicitud;
    }

    public void setCodDetalleSolicitud(String codDetalleSolicitud) {
        this.codDetalleSolicitud = codDetalleSolicitud;
    }

    public int getCodSolicitudDinero() {
        return codSolicitudDinero;
    }

    public void setCodSolicitudDinero(int codSolicitudDinero) {
        this.codSolicitudDinero = codSolicitudDinero;
    }

    public boolean isIncompleto() {
        return incompleto;
    }

    public void setIncompleto(boolean incompleto) {
        this.incompleto = incompleto;
    }
    
    

}
