package com.gco.siconline.dto;

import java.math.BigDecimal;

public class DesReferenciaMaeDTO {

    private Integer codEmpresa;

    private String codReferencia;

    private String codProveedoref;

    private BigDecimal valRefpublico;

    public Integer getCodEmpresa() {
        return codEmpresa;
    }

    public void setCodEmpresa(Integer codEmpresa) {
        this.codEmpresa = codEmpresa;
    }

    public String getCodReferencia() {
        return codReferencia;
    }

    public void setCodReferencia(String codReferencia) {
        this.codReferencia = codReferencia;
    }

    public String getCodProveedoref() {
        return codProveedoref;
    }

    public void setCodProveedoref(String codProveedoref) {
        this.codProveedoref = codProveedoref;
    }

    public BigDecimal getValRefpublico() {
        return valRefpublico;
    }

    public void setValRefpublico(BigDecimal valRefpublico) {
        this.valRefpublico = valRefpublico;
    }

}
