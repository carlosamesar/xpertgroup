package com.gco.siconline.dto;

import java.util.List;

public class RolesUsuarioDTO {

    private String cdusuario;
    private List<UsuarioRolDTO> lstRoles;

    public String getCdusuario() {
        return cdusuario;
    }

    public void setCdusuario(String cdusuario) {
        this.cdusuario = cdusuario;
    }

    public List<UsuarioRolDTO> getLstRoles() {
        return lstRoles;
    }

    public void setLstRoles(List<UsuarioRolDTO> lstRoles) {
        this.lstRoles = lstRoles;
    }
}
