package com.gco.siconline.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RequestCrearOleadaDTO {

    private TipoDestinoDTO tipoDestino;
    private List<PedidoDTO> pedidos;
    private String usuario;
    private List<PluConsolidadoDTO> pedidoALaMarca;
    private List<Object> listPlus;
    private String codOleada;

    public TipoDestinoDTO getTipoDestino() {
        return tipoDestino;
    }

    public void setTipoDestino(TipoDestinoDTO estadoDespacho) {
        this.tipoDestino = estadoDespacho;
    }

    public List<PedidoDTO> getPedidos() {
        return pedidos;
    }

    public void setPedidos(List<PedidoDTO> pedidos) {
        this.pedidos = pedidos;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public List<PluConsolidadoDTO> getPedidoALaMarca() {
        return pedidoALaMarca;
    }

    public void setPedidoALaMarca(List<PluConsolidadoDTO> pedidoALaMarca) {
        this.pedidoALaMarca = pedidoALaMarca;
    }

    public List<Object> getListPlus() {
        return listPlus;
    }

    public void setListPlus(List<Object> listPlus) {
        this.listPlus = listPlus;
    }

    public String getCodOleada() {
        return codOleada;
    }

    public void setCodOleada(String codOleada) {
        this.codOleada = codOleada;
    }

   
    

}
