package com.gco.siconline.dto;

public class DesDcontrolpMovDTO {

    private String numMovimiento;

    private String codUsuario;

    private String codPlu;

    private String codReferencia;

    private String tipTalla;

    private String codColor;

    private String nomColor;

    private Integer numCantidad;

    private Integer numCanLeida;

    private String codUbicacion;

    private String codCaja;

    public DesDcontrolpMovDTO(String numMovimiento, String codUsuario, String codPlu, String codReferencia, String tipTalla, String codColor,
            String nomColor, Integer numCantidad, Integer numCanLeida, String codUbicacion, String codCaja) {
        this.numMovimiento = numMovimiento;
        this.codUsuario = codUsuario;
        this.codPlu = codPlu;
        this.codReferencia = codReferencia;
        this.tipTalla = tipTalla;
        this.codColor = codColor;
        this.nomColor = nomColor;
        this.numCantidad = numCantidad;
        this.numCanLeida = numCanLeida;
        this.codUbicacion = codUbicacion;
        this.codCaja = codCaja;
    }

    public String getNumMovimiento() {
        return numMovimiento;
    }

    public void setNumMovimiento(String numMovimiento) {
        this.numMovimiento = numMovimiento;
    }

    public String getCodUsuario() {
        return codUsuario;
    }

    public void setCodUsuario(String codUsuario) {
        this.codUsuario = codUsuario;
    }

    public String getCodPlu() {
        return codPlu;
    }

    public void setCodPlu(String codPlu) {
        this.codPlu = codPlu;
    }

    public String getCodReferencia() {
        return codReferencia;
    }

    public void setCodReferencia(String codReferencia) {
        this.codReferencia = codReferencia;
    }

    public String getTipTalla() {
        return tipTalla;
    }

    public void setTipTalla(String tipTalla) {
        this.tipTalla = tipTalla;
    }

    public String getCodColor() {
        return codColor;
    }

    public void setCodColor(String codColor) {
        this.codColor = codColor;
    }

    public String getNomColor() {
        return nomColor;
    }

    public void setNomColor(String nomColor) {
        this.nomColor = nomColor;
    }

    public Integer getNumCantidad() {
        return numCantidad;
    }

    public void setNumCantidad(Integer numCantidad) {
        this.numCantidad = numCantidad;
    }

    public Integer getNumCanLeida() {
        return numCanLeida;
    }

    public void setNumCanLeida(Integer numCanLeida) {
        this.numCanLeida = numCanLeida;
    }

    public String getCodUbicacion() {
        return codUbicacion;
    }

    public void setCodUbicacion(String codUbicacion) {
        this.codUbicacion = codUbicacion;
    }

    public String getCodCaja() {
        return codCaja;
    }

    public void setCodCaja(String codCaja) {
        this.codCaja = codCaja;
    }

}
