/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gco.siconline.dto;

/**
 *
 * @author besmart
 */
public class BodegaReservaDto {
    
    private Integer uid;
    private String codigo;
    private String codigoErp;
    private String estado;
    private String tipoBodega;
    private Integer uidMarketplace;
    private String proveedor;

    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        this.uid = uid;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getCodigoErp() {
        return codigoErp;
    }

    public void setCodigoErp(String codigoErp) {
        this.codigoErp = codigoErp;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getTipoBodega() {
        return tipoBodega;
    }

    public void setTipoBodega(String tipoBodega) {
        this.tipoBodega = tipoBodega;
    }

    public Integer getUidMarketplace() {
        return uidMarketplace;
    }

    public void setUidMarketplace(Integer uidMarketplace) {
        this.uidMarketplace = uidMarketplace;
    }

    public String getProveedor() {
        return proveedor;
    }

    public void setProveedor(String proveedor) {
        this.proveedor = proveedor;
    }
    
    
    
    
}
