package com.gco.siconline.dto;

public class RequestDPedNumPedDTO extends PageRequestDTO {

    protected String numPedido;

    public String getNumPedido() {
        return numPedido;
    }

    public void setNumPedido(String numPedido) {
        this.numPedido = numPedido;
    }

}
