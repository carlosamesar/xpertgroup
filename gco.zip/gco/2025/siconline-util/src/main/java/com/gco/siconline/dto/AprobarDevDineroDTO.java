package com.gco.siconline.dto;

import java.math.BigDecimal;

public class AprobarDevDineroDTO {
	private String codDetalleSolicitud;
	private String movimiento;
	private BigDecimal valorDev;
	private boolean aprobado;

	

	public String getCodDetalleSolicitud() {
		return codDetalleSolicitud;
	}

	public void setCodDetalleSolicitud(String codDetalleSolicitud) {
		this.codDetalleSolicitud = codDetalleSolicitud;
	}

	

	public String getMovimiento() {
		return movimiento;
	}

	public void setMovimiento(String movimiento) {
		this.movimiento = movimiento;
	}

	public BigDecimal getValorDev() {
		return valorDev;
	}

	public void setValorDev(BigDecimal valorDev) {
		this.valorDev = valorDev;
	}

	public boolean isAprobado() {
		return aprobado;
	}

	public void setAprobado(boolean aprobado) {
		this.aprobado = aprobado;
	}

}
