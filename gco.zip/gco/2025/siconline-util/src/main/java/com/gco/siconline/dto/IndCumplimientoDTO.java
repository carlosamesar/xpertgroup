/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gco.siconline.dto;

import java.math.BigInteger;

/**
 *
 * @author jeisonz
 */
public class IndCumplimientoDTO {

    protected Integer id;
    protected String indicador;
    protected BigInteger cantidad;

    public IndCumplimientoDTO() {
    }

    public IndCumplimientoDTO(Integer id, String indicador, BigInteger cantidad) {
        this.id = id;
        this.indicador = indicador;
        this.cantidad = cantidad;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getIndicador() {
        return indicador;
    }

    public void setIndicador(String indicador) {
        this.indicador = indicador;
    }

    public BigInteger getCantidad() {
        return cantidad;
    }

    public void setCantidad(BigInteger cantidad) {
        this.cantidad = cantidad;
    }

}
