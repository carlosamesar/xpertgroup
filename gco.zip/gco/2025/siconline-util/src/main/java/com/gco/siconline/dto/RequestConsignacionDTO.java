package com.gco.siconline.dto;

import java.util.Date;
import java.util.List;

public class RequestConsignacionDTO {
private Date fechaIn;
private Date FechaFin;
private int codEmpresa;
private List<String> formasPago;


public Date getFechaIn() {
	return fechaIn;
}
public void setFechaIn(Date fechaIn) {
	this.fechaIn = fechaIn;
}
public Date getFechaFin() {
	return FechaFin;
}
public void setFechaFin(Date fechaFin) {
	FechaFin = fechaFin;
}

public int getCodEmpresa() {
	return codEmpresa;
}
public void setCodEmpresa(int codEmpresa) {
	this.codEmpresa = codEmpresa;
}
public List<String> getFormasPago() {
	return formasPago;
}
public void setFormasPago(List<String> formasPago) {
	this.formasPago = formasPago;
}


}
