/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gco.siconline.dto;

import java.util.Date;

/**
 *
 * @author besmart
 */
public interface ReferenciaDuplicadaDto {

    public Integer getCodEmpresa();

    public String getCodBodega();

    public String getTipTercerobod();

    public Integer getNumAno();

    public String getCodReferencia();

    public String getCodProveedoref();

    public Integer getIdControl();

    public String getIndEstado();

    public Date getFecModificacion();

    public String getCodReferenciaCtrl();

    public String getCodProveedorefCtrl();

    public Integer getNumAnoCtrl();

    public String getCodConceptoPedido();

    public String getNumPedido();

}
