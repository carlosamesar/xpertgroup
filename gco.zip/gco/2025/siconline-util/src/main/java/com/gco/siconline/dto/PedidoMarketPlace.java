package com.gco.siconline.dto;

import java.io.Serializable;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@XmlRootElement
@JsonIgnoreProperties(ignoreUnknown = true)
public class PedidoMarketPlace implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = -6280787913496084931L;
	private int empresa;
    private String codDocumento;
    private String indAplicacion;
    private String codConcepto;

    @NotNull(message = "El documento de identificación del tercero es obligatorio.")
    private String idTercero; // CXXdula o nit del tercero
    private String tipTercero;

    @NotNull(message = "No se encontro numero de pedido.")
    private String numPedido;
    private String bodega;
    private String tipTercerobod;
    private String codVendedor;
    private String tipTerceroven;

    @NotNull(message = "No se encontro fecha de pedido.")
    private Date fecPedido;
    private double descuentopie;
    private double descuentopp;
    private Date fecEntrega;
    private Date fecRegistro;
    private String tipPedido;
    private String tipComision;
    private String codLista;
    private double porPedido;
    private int numPeriodo;
    private String codTermino;
    private String codFormaenvio;

    @NotNull(message = "No se encontro estado asociado al pedido.")
    private String estPedido;
    private String codUsuarioautor;

    @NotNull(message = "El usuario es obligatorio.")
    private String codUsuario;
    private String nomObservacion;
    private String indEstado;
    private String codClaseped;

    @NotNull(message = "El nombre del cliente es obligatorio.")
    private String nomRazonsocial;
    private String dirFactura;

    @NotNull(message = "La direccion de despacho del cliente es obligatoria.")
    private String dirDespacho;

    private String telDespacho;
    private String telFactura;

    @NotNull(message = "El correo electronico del cliente es obligatorio.")
    private String email;

    @NotNull(message = "La ciuad es obligatoria para la creación del cliente.")
    private String codCiudad;

    private String codMoneda;
    private String codZona;
    private String ordenCompra;
    private ArrayList<DetallePedidoMarketPlace> detallePedido;
    private UtmMedium customizacion;
    private String pedidoBase;
    private double flete;
    private Long numGuia;
    private ArrayList<FormaPago> detalleFormaPago;
    private ArrayList<ValeDto> infoVales;
    private ArrayList<BeneficioDto> beneficios;
    
    private Timestamp fecCreacion;
    private String reseller;
    private String guia;
    private String transportadora;
    private double valorPCE;
    private String formaPagoPCE;
    private String codPais;
    

    public PedidoMarketPlace() {

        Date fechaActual = new Date();

        SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
        String date = DATE_FORMAT.format(fechaActual);

        fecPedido = fechaActual;
        fecEntrega = fecPedido;
        descuentopie = 0;
        descuentopp = 0;

    }

    public String getCodCiudad() {
        return codCiudad;
    }

    public void setCodCiudad(String codCiudad) {
        this.codCiudad = codCiudad;
    }

    public String getCodMoneda() {
        return codMoneda;
    }

    public void setCodMoneda(String codMoneda) {
        this.codMoneda = codMoneda;
    }

    public String getCodZona() {
        return codZona;
    }

    public void setCodZona(String codZona) {
        this.codZona = codZona;
    }

    public int getEmpresa() {
        return empresa;
    }

    public void setEmpresa(int empresa) {
        this.empresa = empresa;
    }

    public String getCodDocumento() {
        return codDocumento;
    }

    public void setCodDocumento(String codDocumento) {
        this.codDocumento = codDocumento;
    }

    public String getIndAplicacion() {
        return indAplicacion;
    }

    public void setIndAplicacion(String indAplicacion) {
        this.indAplicacion = indAplicacion;
    }

    public String getCodConcepto() {
        return codConcepto;
    }

    public void setCodConcepto(String codConcepto) {
        this.codConcepto = codConcepto;
    }

    public String getIdTercero() {
        return idTercero;
    }

    public void setIdTercero(String idTercero) {
        this.idTercero = idTercero;
    }

    public String getTipTercero() {
        return tipTercero;
    }

    public void setTipTercero(String tipTercero) {
        this.tipTercero = tipTercero;
    }

    public String getNumPedido() {
        return numPedido;
    }

    public void setNumPedido(String numPedido) {
        this.numPedido = numPedido;
    }

    public String getBodega() {
        return bodega;
    }

    public void setBodega(String bodega) {
        this.bodega = bodega;
    }

    public String getTipTercerobod() {
        return tipTercerobod;
    }

    public void setTipTercerobod(String tipTercerobod) {
        this.tipTercerobod = tipTercerobod;
    }

    public String getCodVendedor() {
        return codVendedor;
    }

    public void setCodVendedor(String codVendedor) {
        this.codVendedor = codVendedor;
    }

    public String getTipTerceroven() {
        return tipTerceroven;
    }

    public void setTipTerceroven(String tipTerceroven) {
        this.tipTerceroven = tipTerceroven;
    }

    public Date getFecPedido() {
        return fecPedido;
    }

    public void setFecPedido(Date fecPedido) {
        this.fecPedido = fecPedido;
    }

    public double getDescuentopie() {
        return descuentopie;
    }

    public void setDescuentopie(double descuentopie) {
        this.descuentopie = descuentopie;
    }

    public double getDescuentopp() {
        return descuentopp;
    }

    public void setDescuentopp(double descuentopp) {
        this.descuentopp = descuentopp;
    }

    public Date getFecEntrega() {
        return fecEntrega;
    }

    public void setFecEntrega(Date fecEntrega) {
        this.fecEntrega = fecEntrega;
    }

    public String getTipPedido() {
        return tipPedido;
    }

    public void setTipPedido(String tipPedido) {
        this.tipPedido = tipPedido;
    }

    public String getTipComision() {
        return tipComision;
    }

    public void setTipComision(String tipComision) {
        this.tipComision = tipComision;
    }

    public String getCodLista() {
        return codLista;
    }

    public void setCodLista(String codLista) {
        this.codLista = codLista;
    }

    public double getPorPedido() {
        return porPedido;
    }

    public void setPorPedido(double porPedido) {
        this.porPedido = porPedido;
    }

    public int getNumPeriodo() {
        return numPeriodo;
    }

    public void setNumPeriodo(int numPeriodo) {
        this.numPeriodo = numPeriodo;
    }

    public String getCodTermino() {
        return codTermino;
    }

    public void setCodTermino(String codTermino) {
        this.codTermino = codTermino;
    }

    public String getCodFormaenvio() {
        return codFormaenvio;
    }

    public void setCodFormaenvio(String codFormaenvio) {
        this.codFormaenvio = codFormaenvio;
    }

    public String getEstPedido() {
        return estPedido;
    }

    public void setEstPedido(String estPedido) {
        this.estPedido = estPedido;
    }

    public String getCodUsuarioautor() {
        return codUsuarioautor;
    }

    public void setCodUsuarioautor(String codUsuarioautor) {
        this.codUsuarioautor = codUsuarioautor;
    }

    public String getCodUsuario() {
        return codUsuario;
    }

    public void setCodUsuario(String codUsuario) {
        this.codUsuario = codUsuario;
    }

    public String getNomObservacion() {
        return nomObservacion;
    }

    public void setNomObservacion(String nomObservacion) {
        this.nomObservacion = nomObservacion;
    }

    public String getIndEstado() {
        return indEstado;
    }

    public void setIndEstado(String indEstado) {
        this.indEstado = indEstado;
    }

    public String getCodClaseped() {
        return codClaseped;
    }

    public void setCodClaseped(String codClaseped) {
        this.codClaseped = codClaseped;
    }

    public String getNomRazonsocial() {
        return nomRazonsocial;
    }

    public void setNomRazonsocial(String nomRazonsocial) {
        this.nomRazonsocial = nomRazonsocial;
    }

    public String getDirFactura() {
        return dirFactura;
    }

    public void setDirFactura(String dirFactura) {
        this.dirFactura = dirFactura;
    }

    public String getDirDespacho() {
        return dirDespacho;
    }

    public void setDirDespacho(String dirDespacho) {
        this.dirDespacho = dirDespacho;
    }

    public String getTelDespacho() {
        return telDespacho;
    }

    public void setTelDespacho(String telDespacho) {
        this.telDespacho = telDespacho;
    }

    public String getTelFactura() {
        return telFactura;
    }

    public void setTelFactura(String telFactura) {
        this.telFactura = telFactura;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public ArrayList<DetallePedidoMarketPlace> getDetallePedido() {
        return detallePedido;
    }

    public void setDetallePedido(ArrayList<DetallePedidoMarketPlace> detallePedido) {
        this.detallePedido = detallePedido;
    }

    public String getOrdenCompra() {
        return ordenCompra;
    }

    public void setOrdenCompra(String ordenCompra) {
        this.ordenCompra = ordenCompra;
    }

    public ArrayList<FormaPago> getDetalleFormaPago() {
        return detalleFormaPago;
    }

    public void setDetalleFormaPago(ArrayList<FormaPago> detalleFormaPago) {
        this.detalleFormaPago = detalleFormaPago;
    }

    public UtmMedium getCustomizacion() {
        return customizacion;
    }

    public void setCustomizacion(UtmMedium customizacion) {
        this.customizacion = customizacion;
    }

    public String getPedidoBase() {
        return pedidoBase;
    }

    public void setPedidoBase(String pedidoBase) {
        this.pedidoBase = pedidoBase;
    }

    public double getFlete() {
        return flete;
    }

    public void setFlete(double flete) {
        this.flete = flete;
    }

    public Date getFecRegistro() {
        return fecRegistro;
    }

    public void setFecRegistro(Date fecRegistro) {
        this.fecRegistro = fecRegistro;
    }

    public ArrayList<ValeDto> getInfoVales() {
        return infoVales;
    }

    public void setInfoVales(ArrayList<ValeDto> infoVales) {
        this.infoVales = infoVales;
    }

    public ArrayList<BeneficioDto> getBeneficios() {
        return beneficios;
    }

    public void setBeneficios(ArrayList<BeneficioDto> beneficios) {
        this.beneficios = beneficios;
    }

    public Timestamp getFecCreacion() {
            return fecCreacion;
    }

    public void setFecCreacion(Timestamp fecCreacion) {
            this.fecCreacion = fecCreacion;
    }

    public String getReseller() {
        return reseller;
    }

    public void setReseller(String reseller) {
        this.reseller = reseller;
    }

    public String getGuia() {
        return guia;
    }

    public void setGuia(String guia) {
        this.guia = guia;
    }

    public String getTransportadora() {
        return transportadora;
    }

    public void setTransportadora(String transportadora) {
        this.transportadora = transportadora;
    }

    public double getValorPCE() {
        return valorPCE;
    }

    public void setValorPCE(double valorPCE) {
        this.valorPCE = valorPCE;
    }

    public String getFormaPagoPCE() {
        return formaPagoPCE;
    }

    public void setFormaPagoPCE(String formaPagoPCE) {
        this.formaPagoPCE = formaPagoPCE;
    }
    
    public Long getNumGuia() {
		return numGuia;
	}
    
    public void setNumGuia(Long numGuia) {
		this.numGuia = numGuia;
	}

    public String getCodPais() {
        return codPais;
    }

    public void setCodPais(String codPais) {
        this.codPais = codPais;
    }
    
    
}
