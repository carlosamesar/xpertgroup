package com.gco.siconline.dto;

import java.util.ArrayList;
import java.util.List;

public class RequestInventarioPtlDTO {

    protected String pickWaveCode;
    protected String documentCode;
    protected boolean incompleto;

    List<DetallePtlDTO> detail = new ArrayList<>();

    public String getPickWaveCode() {
        return pickWaveCode;
    }

    public void setPickWaveCode(String pickWaveCode) {
        this.pickWaveCode = pickWaveCode;
    }

    public String getDocumentCode() {
        return documentCode;
    }

    public void setDocumentCode(String documentCode) {
        this.documentCode = documentCode;
    }

    public List<DetallePtlDTO> getDetail() {
        return detail;
    }

    public void setDetail(List<DetallePtlDTO> detail) {
        this.detail = detail;
    }

    public boolean isIncompleto() {
        return incompleto;
    }

    public void setIncompleto(boolean incompleto) {
        this.incompleto = incompleto;
    }
    
}
