package com.gco.siconline.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class FormaPagoRequest {

    private FormaPagoDTO formaPago;
    private Date fechaMovimiento;
    private double valor;
    private double valorFlete;
    private int conFormaPago;
    private String fechaReporte;

    public FormaPagoDTO getFormaPago() {
        return formaPago;
    }

    public void setFormaPago(FormaPagoDTO formaPago) {
        this.formaPago = formaPago;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public Date getFechaMovimiento() {
        return fechaMovimiento;
    }

    public void setFechaMovimiento(Date fechaMovimiento) {
        this.fechaMovimiento = fechaMovimiento;
    }

    public int getConFormaPago() {
        return conFormaPago;
    }

    public void setConFormaPago(int conFormaPago) {
        this.conFormaPago = conFormaPago;
    }

    public String getFechaReporte() {
        return fechaReporte;
    }

    public void setFechaReporte(String fechaReporte) {
        this.fechaReporte = fechaReporte;
    }

    public double getValorFlete() {
        return valorFlete;
    }

    public void setValorFlete(double valorFlete) {
        this.valorFlete = valorFlete;
    }

}
