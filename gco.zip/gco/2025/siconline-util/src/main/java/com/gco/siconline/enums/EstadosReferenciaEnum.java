package com.gco.siconline.enums;

public enum EstadosReferenciaEnum {
	
	ACTIVO("D"),
    INACTIVO("I");
	
	private String value;

	private EstadosReferenciaEnum(String value) {
		this.setValue(value);
	}

	public String value() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public static EstadosReferenciaEnum fromValue(String value) {
		for (EstadosReferenciaEnum estado : EstadosReferenciaEnum.values()) {
			if (estado.value.equals(value)) {
				return estado;
			}
		}
		return null;
	}

}
