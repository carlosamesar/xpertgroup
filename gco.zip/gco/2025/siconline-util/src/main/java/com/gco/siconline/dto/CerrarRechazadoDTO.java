package com.gco.siconline.dto;

import java.util.List;

public class CerrarRechazadoDTO {
	int codSolicitud;
	String pedidoVtex;
	String marca;
	List<DetCerrarRechazadoDTO> listPlu;

	public int getCodSolicitud() {
		return codSolicitud;
	}

	public void setCodSolicitud(int codSolicitud) {
		this.codSolicitud = codSolicitud;
	}

	public String getPedidoVtex() {
		return pedidoVtex;
	}

	public void setPedidoVtex(String pedidoVtex) {
		this.pedidoVtex = pedidoVtex;
	}

	public List<DetCerrarRechazadoDTO> getListPlu() {
		return listPlu;
	}

	public void setListPlu(List<DetCerrarRechazadoDTO> listPlu) {
		this.listPlu = listPlu;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	
}
