/*
 * To change this license header(); choose License Headers in Project Properties.
 * To change this template file(); choose Tools | Templates
 * and open the template in the editor.
 */
package com.gco.siconline.dto;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;

/**
 *
 * @author besmart
 */
public interface PtlPluDto {

    Integer getCodEmpresa();

    String getCodOleada();

    String getCodTercero();

    String getNumPedido();

    String getCodPlu();

    String getCiudad();

    String getCodReferencia();

    String getDepartamento();

    String getDireccion();

    Date getFecCreacion();

    String getIndEstado();

    String getIndFacturacion();

    String getIndTipo();

    String getNit();

    String getNomColor();

    Integer getNumCantidad();

    String getPais();

    BigDecimal getPorDescuentopie();

    BigDecimal getPorDescuentopp();

    BigDecimal getPorPedido();

    String getRazonsocial();
    
    String getReseller();

    String getTipTalla();

    String getTipTercero();
    
    BigDecimal getValUnitario();

    String getCodBodegaCompra();

    String getDesEstadodespachoMae();

    String getNumOrdenpedido();

    BigInteger getTotalCantidad();

    BigInteger getTotalCanLeida();

}
