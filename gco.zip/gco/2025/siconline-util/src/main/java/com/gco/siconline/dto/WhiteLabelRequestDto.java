package com.gco.siconline.dto;

public class WhiteLabelRequestDto {
    private String marca;
    private String apiKey;
    private String apiToken;
    private String name;
    private String isBetterScope;

    // Constructor vacío
    public WhiteLabelRequestDto() {}

    // Constructor con parámetros
    public WhiteLabelRequestDto(String marca, String apiKey, String apiToken, String name, String isBetterScope) {
        this.marca = marca;
        this.apiKey = apiKey;
        this.apiToken = apiToken;
        this.name = name;
        this.isBetterScope = isBetterScope;
    }

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getApiKey() {
		return apiKey;
	}

	public void setApiKey(String apiKey) {
		this.apiKey = apiKey;
	}

	public String getApiToken() {
		return apiToken;
	}

	public void setApiToken(String apiToken) {
		this.apiToken = apiToken;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getIsBetterScope() {
		return isBetterScope;
	}

	public void setIsBetterScope(String isBetterScope) {
		this.isBetterScope = isBetterScope;
	}

  
}
