package com.gco.siconline.dto;

public class UsuarioRolDTO {

    private String cdUsuario;

    private Long nmConrol;

    public String getCdUsuario() {
        return cdUsuario;
    }

    public void setCdUsuario(String cdUsuario) {
        this.cdUsuario = cdUsuario;
    }

    public Long getNmConrol() {
        return nmConrol;
    }

    public void setNmConrol(Long nmConrol) {
        this.nmConrol = nmConrol;
    }

}
