package com.gco.siconline.dto;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class EntradasYSalidasInventarioDTO {

    private String codigoTercero;
    private String nitTercero;
    private String nombreTercero;
    private String codConcepto;
    private String nombreConcepto;
    private String numMovimiento;
    private Date fecha;
    private String docReferencia;
    private String estado;
    private int totalPlus;
    private String total;
    private String usuario;
    private String observaciones;

    List<DetMovimientoDTO> listDetalle;

    public String getCodigoTercero() {
        return codigoTercero;
    }

    public void setCodigoTercero(String codigoTercero) {
        this.codigoTercero = codigoTercero;
    }

    public String getNitTercero() {
        return nitTercero;
    }

    public void setNitTercero(String nitTercero) {
        this.nitTercero = nitTercero;
    }

    public String getNombreTercero() {
        return nombreTercero;
    }

    public void setNombreTercero(String nombreTercero) {
        this.nombreTercero = nombreTercero;
    }

    public String getNumMovimiento() {
        return numMovimiento;
    }

    public void setNumMovimiento(String numMovimiento) {
        this.numMovimiento = numMovimiento;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getDocReferencia() {
        return docReferencia;
    }

    public void setDocReferencia(String docReferencia) {
        this.docReferencia = docReferencia;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public int getTotalPlus() {
        return totalPlus;
    }

    public void setTotalPlus(int totalPlus) {
        this.totalPlus = totalPlus;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public List<DetMovimientoDTO> getListDetalle() {
        return listDetalle;
    }

    public void setListDetalle(List<DetMovimientoDTO> listDetalle) {
        this.listDetalle = listDetalle;
    }

    public String getCodConcepto() {
        return codConcepto;
    }

    public void setCodConcepto(String codConcepto) {
        this.codConcepto = codConcepto;
    }

    public String getNombreConcepto() {
        return nombreConcepto;
    }

    public void setNombreConcepto(String nombreConcepto) {
        this.nombreConcepto = nombreConcepto;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

	public String getObservaciones() {
		return observaciones;
	}

	public void setObservaciones(String observaciones) {
		this.observaciones = observaciones;
	}

}
