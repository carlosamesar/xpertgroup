package com.gco.siconline.dto;

import java.util.Date;

public class SolicitudDevolucionDevolucionDineroDTO {

	private Integer codSolicitudDevolucionDinero;
	private Integer codDetalleSolicitud;
	private Integer codBanco;
	private Integer codTipoCuenta;
	private String numCuenta;
	private String observaciones;
	private String codEstado;
	private String codUsuario;
	private Date fecCreacion;
	private String tipoDocumento;
	private String identificacion;
	private String nombres;
	private String apellidos;

	public Integer getCodSolicitudDevolucionDinero() {
		return codSolicitudDevolucionDinero;
	}

	public void setCodSolicitudDevolucionDinero(Integer codSolicitudDevolucionDinero) {
		this.codSolicitudDevolucionDinero = codSolicitudDevolucionDinero;
	}

	public Integer getCodDetalleSolicitud() {
		return codDetalleSolicitud;
	}

	public void setCodDetalleSolicitud(Integer codDetalleSolicitud) {
		this.codDetalleSolicitud = codDetalleSolicitud;
	}

	public Integer getCodBanco() {
		return codBanco;
	}

	public void setCodBanco(Integer codBanco) {
		this.codBanco = codBanco;
	}

	public Integer getCodTipoCuenta() {
		return codTipoCuenta;
	}

	public void setCodTipoCuenta(Integer codTipoCuenta) {
		this.codTipoCuenta = codTipoCuenta;
	}

	public String getNumCuenta() {
		return numCuenta;
	}

	public void setNumCuenta(String numCuenta) {
		this.numCuenta = numCuenta;
	}

	public String getObservaciones() {
		return observaciones;
	}

	public void setObservaciones(String observaciones) {
		this.observaciones = observaciones;
	}

	public String getCodEstado() {
		return codEstado;
	}

	public void setCodEstado(String codEstado) {
		this.codEstado = codEstado;
	}

	public String getCodUsuario() {
		return codUsuario;
	}

	public void setCodUsuario(String codUsuario) {
		this.codUsuario = codUsuario;
	}

	public Date getFecCreacion() {
		return fecCreacion;
	}

	public void setFecCreacion(Date fecCreacion) {
		this.fecCreacion = fecCreacion;
	}

	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public String getIdentificacion() {
		return identificacion;
	}

	public void setIdentificacion(String identificacion) {
		this.identificacion = identificacion;
	}

	public String getNombres() {
		return nombres;
	}

	public void setNombres(String nombres) {
		this.nombres = nombres;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

}
