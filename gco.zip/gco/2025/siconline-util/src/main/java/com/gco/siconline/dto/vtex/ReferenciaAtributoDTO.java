package com.gco.siconline.dto.vtex;

import java.io.Serializable;

public class ReferenciaAtributoDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String codReferencia;
	private String codColor;
	private String codProveedoref;
	private Integer numAno;
	private String codPlu;
	private String talla;
	private Integer existe;
	private String estadoInventario;
	private String estadoReferencia;
	private String estadoAtributo;
	private Integer numAtributos;
	private String tieneTodoAtributo;
	private String nombresAtributosSIC;
	
	public ReferenciaAtributoDTO() {
		// TODO Auto-generated constructor stub
	}

	public String getCodReferencia() {
		return codReferencia;
	}

	public void setCodReferencia(String codReferencia) {
		this.codReferencia = codReferencia;
	}

	public String getCodColor() {
		return codColor;
	}

	public void setCodColor(String codColor) {
		this.codColor = codColor;
	}

	public String getCodProveedoref() {
		return codProveedoref;
	}

	public void setCodProveedoref(String codProveedoref) {
		this.codProveedoref = codProveedoref;
	}

	public Integer getNumAno() {
		return numAno;
	}

	public void setNumAno(Integer numAno) {
		this.numAno = numAno;
	}

	public String getCodPlu() {
		return codPlu;
	}

	public void setCodPlu(String codPlu) {
		this.codPlu = codPlu;
	}

	public String getTalla() {
		return talla;
	}

	public void setTalla(String talla) {
		this.talla = talla;
	}

	public Integer getExiste() {
		return existe;
	}

	public void setExiste(Integer existe) {
		this.existe = existe;
	}

	public String getEstadoInventario() {
		return estadoInventario;
	}

	public void setEstadoInventario(String estadoInventario) {
		this.estadoInventario = estadoInventario;
	}

	public String getEstadoReferencia() {
		return estadoReferencia;
	}

	public void setEstadoReferencia(String estadoReferencia) {
		this.estadoReferencia = estadoReferencia;
	}

	public String getEstadoAtributo() {
		return estadoAtributo;
	}

	public void setEstadoAtributo(String estadoAtributo) {
		this.estadoAtributo = estadoAtributo;
	}

	public Integer getNumAtributos() {
		return numAtributos;
	}

	public void setNumAtributos(Integer numAtributos) {
		this.numAtributos = numAtributos;
	}

	public String getTieneTodoAtributo() {
		return tieneTodoAtributo;
	}

	public void setTieneTodoAtributo(String tieneTodoAtributo) {
		this.tieneTodoAtributo = tieneTodoAtributo;
	}

	public String getNombresAtributosSIC() {
		return nombresAtributosSIC;
	}

	public void setNombresAtributosSIC(String nombresAtributosSIC) {
		this.nombresAtributosSIC = nombresAtributosSIC;
	}
	
	
}
