package com.gco.siconline.dto;

import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DetMovimientoDTO {

    private DesDmovmientoMovPKDTO id;

    private String codConceptoasoc;

    private String codDocumentoasoc;

    private String codPlu;

    private String codPluc;

    private String codTerceroAsoc;

    private String codUsuario;

    private Date fecCausal;

    private Date fecMovtoasoc;

    private String indEstado;

    private String nomObservacion;

    private Integer numCantidad;

    private String numDocasociado;

    private String numLote;

    private BigDecimal porDescuento;

    private BigDecimal porIva;

    private String tipCausal;

    private String valTotal;

    private String valUnidad;

    private String codCanasta;

    private String nomReferencia;

    public DesDmovmientoMovPKDTO getId() {
        return id;
    }

    public void setId(DesDmovmientoMovPKDTO id) {
        this.id = id;
    }

    public String getCodConceptoasoc() {
        return codConceptoasoc;
    }

    public void setCodConceptoasoc(String codConceptoasoc) {
        this.codConceptoasoc = codConceptoasoc;
    }

    public String getCodDocumentoasoc() {
        return codDocumentoasoc;
    }

    public void setCodDocumentoasoc(String codDocumentoasoc) {
        this.codDocumentoasoc = codDocumentoasoc;
    }

    public String getCodPlu() {
        return codPlu;
    }

    public void setCodPlu(String codPlu) {
        this.codPlu = codPlu;
    }

    public String getCodPluc() {
        return codPluc;
    }

    public void setCodPluc(String codPluc) {
        this.codPluc = codPluc;
    }

    public String getCodTerceroAsoc() {
        return codTerceroAsoc;
    }

    public void setCodTerceroAsoc(String codTerceroAsoc) {
        this.codTerceroAsoc = codTerceroAsoc;
    }

    public String getCodUsuario() {
        return codUsuario;
    }

    public void setCodUsuario(String codUsuario) {
        this.codUsuario = codUsuario;
    }

    public Date getFecCausal() {
        return fecCausal;
    }

    public void setFecCausal(Date fecCausal) {
        this.fecCausal = fecCausal;
    }

    public Date getFecMovtoasoc() {
        return fecMovtoasoc;
    }

    public void setFecMovtoasoc(Date fecMovtoasoc) {
        this.fecMovtoasoc = fecMovtoasoc;
    }

    public String getIndEstado() {
        return indEstado;
    }

    public void setIndEstado(String indEstado) {
        this.indEstado = indEstado;
    }

    public String getNomObservacion() {
        return nomObservacion;
    }

    public void setNomObservacion(String nomObservacion) {
        this.nomObservacion = nomObservacion;
    }

    public Integer getNumCantidad() {
        return numCantidad;
    }

    public void setNumCantidad(Integer numCantidad) {
        this.numCantidad = numCantidad;
    }

    public String getNumDocasociado() {
        return numDocasociado;
    }

    public void setNumDocasociado(String numDocasociado) {
        this.numDocasociado = numDocasociado;
    }

    public String getNumLote() {
        return numLote;
    }

    public void setNumLote(String numLote) {
        this.numLote = numLote;
    }

    public BigDecimal getPorDescuento() {
        return porDescuento;
    }

    public void setPorDescuento(BigDecimal porDescuento) {
        this.porDescuento = porDescuento;
    }

    public BigDecimal getPorIva() {
        return porIva;
    }

    public void setPorIva(BigDecimal porIva) {
        this.porIva = porIva;
    }

    public String getTipCausal() {
        return tipCausal;
    }

    public void setTipCausal(String tipCausal) {
        this.tipCausal = tipCausal;
    }

    public String getValTotal() {
        return valTotal;
    }

    public void setValTotal(String valTotal) {
        this.valTotal = valTotal;
    }

    public String getValUnidad() {
        return valUnidad;
    }

    public void setValUnidad(String valUnidad) {
        this.valUnidad = valUnidad;
    }

    public String getCodCanasta() {
        return codCanasta;
    }

    public void setCodCanasta(String codCanasta) {
        this.codCanasta = codCanasta;
    }

    public String getNomReferencia() {
        return nomReferencia;
    }

    public void setNomReferencia(String nomReferencia) {
        this.nomReferencia = nomReferencia;
    }

}
