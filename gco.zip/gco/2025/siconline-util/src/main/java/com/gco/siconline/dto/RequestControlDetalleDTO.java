package com.gco.siconline.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RequestControlDetalleDTO extends RequestControlUserDTO {

    protected Integer codConsecutivo;

    protected String codUbicacion;

    public Integer getCodConsecutivo() {
        return codConsecutivo;
    }

    public void setCodConsecutivo(Integer codConsecutivo) {
        this.codConsecutivo = codConsecutivo;
    }

    public String getCodUbicacion() {
        return codUbicacion;
    }

    public void setCodUbicacion(String codUbicacion) {
        this.codUbicacion = codUbicacion;
    }
}
