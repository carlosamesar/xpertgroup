/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gco.siconline.dto;

import java.sql.Timestamp;
import java.util.Date;

/**
 *
 * @author Brayam Castrillon
 */
public class ValeRedimidoDto {
	
	private String idVale;
	private String numeroNit;
	private String nomRazonSocial;
	private String numTelefono;
	private String nombreVale;
	private String codVale;
	private double valorInicial;
	private double valor;
	private double saldo;
	private String fechaEmision;
	private String fechaExpiracion;
	public String getIdVale() {
		return idVale;
	}
	public void setIdVale(String idVale) {
		this.idVale = idVale;
	}
	public String getNumeroNit() {
		return numeroNit;
	}
	public void setNumeroNit(String numeroNit) {
		this.numeroNit = numeroNit;
	}
	public String getNomRazonSocial() {
		return nomRazonSocial;
	}
	public void setNomRazonSocial(String nomRazonSocial) {
		this.nomRazonSocial = nomRazonSocial;
	}
	public String getNumTelefono() {
		return numTelefono;
	}
	public void setNumTelefono(String numTelefono) {
		this.numTelefono = numTelefono;
	}
	public String getNombreVale() {
		return nombreVale;
	}
	public void setNombreVale(String nombreVale) {
		this.nombreVale = nombreVale;
	}
	public String getCodVale() {
		return codVale;
	}
	public void setCodVale(String codVale) {
		this.codVale = codVale;
	}
	public double getValorInicial() {
		return valorInicial;
	}
	public void setValorInicial(double valorInicial) {
		this.valorInicial = valorInicial;
	}
	public double getValor() {
		return valor;
	}
	public void setValor(double valor) {
		this.valor = valor;
	}
	public double getSaldo() {
		return saldo;
	}
	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
	public String getFechaEmision() {
		return fechaEmision;
	}
	public void setFechaEmision(String fechaEmision) {
		this.fechaEmision = fechaEmision;
	}
	public String getFechaExpiracion() {
		return fechaExpiracion;
	}
	public void setFechaExpiracion(String fechaExpiracion) {
		this.fechaExpiracion = fechaExpiracion;
	}
	
	
	    
}

