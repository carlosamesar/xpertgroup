package com.gco.siconline.dto;

public class InfoReferenciaDTO {
	
	private String codProveedoref;
	private String codReferencia;
	private String nomReferencia;
	private String nomPersonalizado;
	private String descripcion;
	private String categoria;
	
	public InfoReferenciaDTO() {
		// TODO Auto-generated constructor stub
	}

	public String getCodProveedoref() {
		return codProveedoref;
	}

	public void setCodProveedoref(String codProveedoref) {
		this.codProveedoref = codProveedoref;
	}

	public String getCodReferencia() {
		return codReferencia;
	}

	public void setCodReferencia(String codReferencia) {
		this.codReferencia = codReferencia;
	}

	public String getNomReferencia() {
		return nomReferencia;
	}

	public void setNomReferencia(String nomReferencia) {
		this.nomReferencia = nomReferencia;
	}

	public String getNomPersonalizado() {
		return nomPersonalizado;
	}

	public void setNomPersonalizado(String nomPersonalizado) {
		this.nomPersonalizado = nomPersonalizado;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	
	public String getCategoria() {
		return categoria;
	}
	
	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}

}
