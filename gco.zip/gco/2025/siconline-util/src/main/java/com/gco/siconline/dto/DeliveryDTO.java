package com.gco.siconline.dto;

public class DeliveryDTO {

	private String numPedido;
	private String idDelivery;
	private String codPlu;
	
	public DeliveryDTO() {
		
	}

	public String getNumPedido() {
		return numPedido;
	}

	public void setNumPedido(String numPedido) {
		this.numPedido = numPedido;
	}

	public String getIdDelivery() {
		return idDelivery;
	}

	public void setIdDelivery(String idDelivery) {
		this.idDelivery = idDelivery;
	}

	public String getCodPlu() {
		return codPlu;
	}

	public void setCodPlu(String codPlu) {
		this.codPlu = codPlu;
	}
	
	

}
